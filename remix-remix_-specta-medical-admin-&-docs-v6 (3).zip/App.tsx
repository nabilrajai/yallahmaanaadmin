
import React, { useState, createContext, useContext, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Link, Navigate, useLocation } from 'react-router-dom';
import { translations, Language } from './i18n';
import { api } from './api';
import Login from './pages/Login';
import AdminDashboard from './pages/AdminDashboard';
import AdminProducts from './pages/AdminProducts';
import AdminSAV from './pages/AdminSAV';
import AdminNewSAV from './pages/AdminNewSAV';
import AdminClients from './pages/AdminClients';
import AdminFormations from './pages/AdminFormations';
import AdminCatalogueSetup from './pages/AdminCatalogueSetup';
import AdminMachines from './pages/AdminMachines';
import AdminOrders from './pages/AdminOrders';
import AdminDevis from './pages/AdminDevis';
import AdminReglements from './pages/AdminReglements';
import AdminUsers from './pages/AdminUsers';
import AdminStaffLogs from './pages/AdminStaffLogs';
import AdminSettings from './pages/AdminSettings';
import AdminNotifications from './pages/AdminNotifications';
import AdminReels from './pages/AdminReels';
import AdminTracking from './pages/AdminTracking';
import AdminReviews from './pages/AdminReviews';
import AdminCommercials from './pages/AdminCommercials';
import AdminCommercialRegions from './pages/AdminCommercialRegions';
import AdminCommercialTeam from './pages/AdminCommercialTeam';
import AdminCommercialVisits from './pages/AdminCommercialVisits';
import CommercialDashboard from './pages/CommercialDashboard';
import AdminPromotions from './pages/AdminPromotions';
import AdminSpareParts from './pages/AdminSpareParts';
import AdminPartPriceRequests from './pages/AdminPartPriceRequests';
import AdminFidelityRules from './pages/AdminFidelityRules';

const AppContext = createContext<any>(null);
export const useApp = () => useContext(AppContext);

const ProtectedRoute = ({ children, module }: { children?: React.ReactNode, module: string }) => {
  const { checkPermission } = useApp();
  if (!checkPermission(module, 'view')) {
    return <Navigate to="/admin/dashboard" replace />;
  }
  return <>{children}</>;
};

const Layout = ({ children }: { children?: React.ReactNode }) => {
  const { t, lang, setLang, user, logout, theme, primaryColor, checkPermission, deniedModal, setDeniedModal, unreadCounts, clearCount } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();
  const isAdmin = location.pathname.startsWith('/admin');

  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location.pathname]);

  if (!isAdmin) return <>{children}</>;

  return (
    <div className={`flex min-h-screen ${theme === 'dark' ? 'bg-slate-950 text-white' : 'bg-[#f8fafd] text-slate-900'}`}>
      {mobileMenuOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[60] xl:hidden" onClick={() => setMobileMenuOpen(false)} />
      )}

      <aside className={`fixed xl:sticky top-0 left-0 h-screen w-64 border-r z-[70] transition-transform duration-300 xl:translate-x-0 flex flex-col ${mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'} ${theme === 'dark' ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
        <div className="p-6 flex items-center justify-between">
          <img src="https://specta.ma/images/Specta_logo.webp" alt="Specta" className={`h-9 ${theme === 'dark' ? 'brightness-0 invert' : ''}`} />
        </div>

        <nav className="flex-1 px-3 py-2 space-y-4 overflow-y-auto sidebar-scroll">
          {/* 1. CONTRÔLE PRINCIPAL */}
          {checkPermission('dashboard', 'view') && (
            <div>
                <p className="px-4 text-[10px] font-black text-slate-400 uppercase tracking-[2px] mb-2">Contrôle Principal</p>
                <div className="space-y-1">
                  <SidebarLink to="/admin/dashboard" icon="ti-layout-dashboard" label="Tableau de Bord" />
                </div>
            </div>
          )}

          {/* 2. COMMANDE */}
          {(checkPermission('orders', 'view') || checkPermission('devis', 'view') || checkPermission('promotions', 'view')) && (
            <div>
                <p className="px-4 text-[10px] font-black text-slate-400 uppercase tracking-[2px] mb-2">Commande</p>
                <div className="space-y-1">
                    {checkPermission('orders', 'view') && <SidebarLink to="/admin/orders-consumables" icon="ti-package" label="Commandes Consommables" badgeCount={unreadCounts?.consumables} />}
                    {checkPermission('orders', 'view') && <SidebarLink to="/admin/orders-machines" icon="ti-device-analytics" label="Commandes Machines" />}
                    {checkPermission('devis', 'view') && <SidebarLink to="/admin/devis" icon="ti-file-invoice" label="Devis & offres" badgeCount={unreadCounts?.devis} />}
                    {checkPermission('promotions', 'view') && <SidebarLink to="/admin/promotions" icon="ti-tag" label="Promotions & Réductions" />}
                    {checkPermission('promotions', 'view') && <SidebarLink to="/admin/fidelity-rules" icon="ti-award" label="Règles de Fidélité" />}
                </div>
            </div>
          )}

          {/* 3. COMMERCIAL */}
          {(checkPermission('clients', 'view') || checkPermission('commercials', 'view')) && (
            <div>
                <p className="px-4 text-[10px] font-black text-slate-400 uppercase tracking-[2px] mb-2">Commercial</p>
                <div className="space-y-1">
                    {checkPermission('clients', 'view') && <SidebarLink to="/admin/clients" icon="ti-users" label="Registre Clients" badgeCount={unreadCounts?.clients} />}
                    {checkPermission('commercials', 'view') && <SidebarLink to="/admin/commercials" icon="ti-chart-arrows-vertical" label="Performance Commerciale" />}
                    {checkPermission('commercials', 'view') && <SidebarLink to="/admin/commercial-team" icon="ti-user-check" label="Commerciaux & Leads" />}
                    {checkPermission('commercials', 'view') && <SidebarLink to="/admin/commercial-visits" icon="ti-calendar-event" label="Demandes de Visite" badgeCount={unreadCounts?.visits} showDot={true} />}
                    {checkPermission('commercials', 'view') && <SidebarLink to="/admin/commercial-regions" icon="ti-map-2" label="Analyse Régionale" />}
                </div>
            </div>
          )}

          {/* 4. SAV */}
          {(checkPermission('sav', 'view') || checkPermission('products', 'view') || checkPermission('reviews', 'view')) && (
            <div>
                <p className="px-4 text-[10px] font-black text-slate-400 uppercase tracking-[2px] mb-2">SAV</p>
                <div className="space-y-1">
                    {checkPermission('sav', 'view') && <SidebarLink to="/admin/sav" icon="ti-alert-circle" label="Tickets SAV" badgeCount={unreadCounts?.sav} />}
                    {checkPermission('products', 'view') && <SidebarLink to="/admin/spare-parts" icon="ti-settings-2" label="Pièces de Rechange" />}
                    {checkPermission('products', 'view') && <SidebarLink to="/admin/part-price-requests" icon="ti-receipt" label="Demandes de Prix" />}
                    {checkPermission('reviews', 'view') && <SidebarLink to="/admin/reviews" icon="ti-star-half" label="Avis & Retours Clients" />}
                </div>
            </div>
          )}

          {/* 5. MARKETING */}
          {(checkPermission('reels', 'view') || checkPermission('notifications', 'view')) && (
            <div>
                <p className="px-4 text-[10px] font-black text-slate-400 uppercase tracking-[2px] mb-2">Marketing</p>
                <div className="space-y-1">
                    {checkPermission('reels', 'view') && <SidebarLink to="/admin/reels" icon="ti-movie" label="Gestion des Reels" />}
                    {checkPermission('notifications', 'view') && <SidebarLink to="/admin/notifications" icon="ti-bell-ringing" label="Notifications Push" />}
                </div>
            </div>
          )}

          {/* 6. FORMATIONS */}
          {checkPermission('formations', 'view') && (
            <div>
                <p className="px-4 text-[10px] font-black text-slate-400 uppercase tracking-[2px] mb-2">Formations</p>
                <div className="space-y-1">
                    <SidebarLink to="/admin/formations" icon="ti-school" label="Formations & Académie" />
                </div>
            </div>
          )}

          {/* 7. INVENTAIRE */}
          {(checkPermission('machines', 'view') || checkPermission('products', 'view')) && (
            <div>
                <p className="px-4 text-[10px] font-black text-slate-400 uppercase tracking-[2px] mb-2">Inventaire</p>
                <div className="space-y-1">
                    {checkPermission('machines', 'view') && <SidebarLink to="/admin/machines" icon="ti-device-analytics" label="Machines & Équipements" />}
                    {checkPermission('products', 'view') && <SidebarLink to="/admin/products" icon="ti-package" label="Consommables" />}
                    {checkPermission('products', 'view') && <SidebarLink to="/admin/catalogue-setup" icon="ti-settings-automation" label="Catégories & Marques" />}
                </div>
            </div>
          )}

          {/* 8. ADMINISTRATEUR */}
          {(checkPermission('users', 'view') || checkPermission('staff-logs', 'view') || checkPermission('commercials', 'view') || checkPermission('tracking', 'view') || checkPermission('settings', 'view')) && (
            <div>
                <p className="px-4 text-[10px] font-black text-slate-400 uppercase tracking-[2px] mb-2">Administrateur</p>
                <div className="space-y-1">
                    {checkPermission('users', 'view') && <SidebarLink to="/admin/users" icon="ti-users-group" label="Utilisateurs & Accès" />}
                    {checkPermission('staff-logs', 'view') && <SidebarLink to="/admin/staff-logs" icon="ti-clipboard-list" label="Journaux d'Audit" />}
                    {checkPermission('commercials', 'view') && <SidebarLink to="/admin/tracking-commercials" icon="ti-current-location" label="Suivi GPS Commerciaux" />}
                    {checkPermission('tracking', 'view') && <SidebarLink to="/admin/tracking-technicians" icon="ti-compass" label="Tech Fleet Intelligence" />}
                    {checkPermission('settings', 'view') && <SidebarLink to="/admin/settings" icon="ti-settings" label="Paramètres Système" />}
                </div>
            </div>
          )}
        </nav>

        <div className={`p-4 mx-3 mb-4 rounded-2xl border ${theme === 'dark' ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-100'}`}>
          <div className="flex items-center gap-3">
            <img src={user?.avatar_url ? (user.avatar_url.startsWith('http') ? user.avatar_url : `https://birdeye-intelligence.ma/Spetcapp/Backend/storage/app/public/${user.avatar_url}`) : 'https://ui-avatars.com/api/?background=5D87FF&color=fff&name=' + user?.name} className="w-9 h-9 rounded-full border-2 border-white shadow-sm object-cover" alt="" />
            <div className="flex-1 overflow-hidden">
              <h6 className="text-xs font-bold truncate">{user?.name}</h6>
              <p className="text-[9px] font-black uppercase text-blue-600">{user?.role?.name || 'Staff'}</p>
            </div>
            <button onClick={logout} className="p-2 text-slate-400 hover:text-red-500 transition-colors"><i className="ti ti-power text-lg"></i></button>
          </div>
        </div>
      </aside>

      <main className="flex-1 flex flex-col h-screen overflow-hidden relative">
        <header className={`h-[72px] border-b flex items-center justify-between px-8 z-[80] sticky top-0 shrink-0 ${theme === 'dark' ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-slate-200'} backdrop-blur-md`}>
          <div className="flex items-center gap-4">
             <button onClick={() => setMobileMenuOpen(true)} className="xl:hidden p-2 text-slate-600"><i className="ti ti-menu-2 text-2xl"></i></button>
             <h2 className="text-lg font-black tracking-tight">Specta Intelligence Platform</h2>
          </div>
          <button onClick={() => setLang(lang === 'en' ? 'fr' : 'en')} className="px-4 py-2 rounded-full border text-[10px] font-black uppercase tracking-widest">{lang}</button>
        </header>

        <div className="p-8 flex-1 overflow-y-auto animate-in fade-in duration-500">
          {children}
        </div>
      </main>

      {/* ACCESS DENIED MODAL */}
      {deniedModal && (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-md z-[500] flex items-center justify-center p-4">
            <div className="bg-white rounded-3xl shadow-2xl p-10 text-center max-w-sm w-full animate-in zoom-in-95 border-4 border-white">
                <div className="w-20 h-20 bg-rose-50 text-rose-500 rounded-2xl flex items-center justify-center text-5xl mx-auto mb-6 shadow-inner animate-pulse">
                    <i className="ti ti-shield-lock"></i>
                </div>
                <h3 className="text-xl font-black text-slate-800 mb-2 tracking-tighter uppercase leading-tight">Accès Refusé</h3>
                <p className="text-slate-500 text-sm font-medium leading-relaxed mb-10 italic">
                    Désolé, votre profil staff n'a pas l'autorisation d'effectuer l'action : <span className="text-rose-600 font-black">"{deniedModal.toUpperCase()}"</span> sur ce module.
                </p>
                <button 
                    onClick={() => setDeniedModal(null)} 
                    className="w-full py-4 bg-slate-900 text-white rounded-xl font-black text-[10px] uppercase tracking-widest active:scale-95 transition-all shadow-xl"
                >
                    Compris
                </button>
            </div>
        </div>
      )}

      <style>{`
        :root { --primary-color: ${primaryColor}; }
        .bg-blue-600 { background-color: var(--primary-color) !important; }
        .text-blue-600 { color: var(--primary-color) !important; }
        .border-blue-600 { border-color: var(--primary-color) !important; }
      `}</style>
    </div>
  );
};

const SidebarLink = ({ to, icon, label, badgeCount, showDot }: any) => {
  const location = useLocation();
  const active = location.pathname === to;
  const count = typeof badgeCount === 'number' ? badgeCount : 0;

  return (
    <Link 
      to={to} 
      className={`flex items-center justify-between gap-2 px-4 py-2.5 rounded-xl transition-all duration-300 group ${
        active ? 'bg-blue-600 text-white shadow-lg font-bold translate-x-1' : 'text-slate-500 hover:translate-x-1'
      }`}
    >
      <div className="flex items-center gap-3 min-w-0">
        <i className={`ti ${icon} text-lg ${active ? 'text-white' : 'text-slate-400 group-hover:text-blue-500'}`}></i>
        <span className="text-xs font-semibold truncate flex items-center gap-1.5">
          <span>{label}</span>
          {showDot && (
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse shrink-0 inline-block shadow-sm"></span>
          )}
        </span>
      </div>
      {count > 0 && (
        <span className="relative flex items-center justify-center h-5 min-w-[20px] px-1.5 rounded-full bg-rose-500 text-white text-[10px] font-black shadow-md shrink-0">
          <span className="animate-ping absolute inset-0 rounded-full bg-rose-400 opacity-50"></span>
          <span className="relative">{count > 99 ? '99+' : count}</span>
        </span>
      )}
    </Link>
  );
};

export default function App() {
  const [lang, setLang] = useState<Language>(() => (localStorage.getItem('specta_lang') as Language) || 'fr');
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem('specta_user') || 'null'));
  const [theme, setTheme] = useState(() => localStorage.getItem('specta_theme') || 'light');
  const [primaryColor, setPrimaryColor] = useState(() => localStorage.getItem('specta_color') || '#2563eb');
  const [deniedModal, setDeniedModal] = useState<string | null>(null);
  
  const [unreadCounts, setUnreadCounts] = useState<{ clients: number; sav: number; devis: number; consumables: number; visits: number }>(() => {
    const saved = localStorage.getItem('specta_unread_counts');
    const parsed = saved ? JSON.parse(saved) : {};
    return {
      clients: parsed.clients || 0,
      sav: parsed.sav || 0,
      devis: parsed.devis || 0,
      consumables: parsed.consumables || 0,
      visits: parsed.visits || 0
    };
  });

  useEffect(() => { localStorage.setItem('specta_lang', lang); }, [lang]);
  useEffect(() => { localStorage.setItem('specta_theme', theme); }, [theme]);
  useEffect(() => { localStorage.setItem('specta_color', primaryColor); }, [primaryColor]);
  useEffect(() => { localStorage.setItem('specta_unread_counts', JSON.stringify(unreadCounts)); }, [unreadCounts]);

  const clearCount = (key: 'clients' | 'sav' | 'devis' | 'consumables') => {
    setUnreadCounts(prev => ({ ...prev, [key]: 0 }));
  };

  // Exact isMachineOrder helper matching AdminOrders.tsx
  const isMachineOrder = (order: any): boolean => {
    if (!order) return false;
    const orderType = String(order.order_type || order.type || '').toLowerCase();
    if (orderType === 'machine' || orderType === 'devis' || orderType === 'quote') return true;
    const orderNumber = String(order.order_number || '').toUpperCase();
    if (orderNumber.startsWith('DEV') || orderNumber.startsWith('QUO') || orderNumber.startsWith('MAC')) return true;

    if (Array.isArray(order.items) && order.items.length > 0) {
      const hasMachineItem = order.items.some((item: any) => {
        if (item?.machine || item?.machine_id) return true;
        if (item?.type === 'machine') return true;
        if (item?.product?.type === 'machine' || item?.product?.category?.slug?.includes('machine')) return true;
        const itemName = String(item?.machine?.name || item?.product?.name || item?.name || '').toLowerCase();
        return (
          itemName.includes('machine') || 
          itemName.includes('scanner') || 
          itemName.includes('laser') || 
          itemName.includes('échographe') || 
          itemName.includes('echographe') ||
          itemName.includes('fauteuil') || 
          itemName.includes('autoclave') || 
          itemName.includes('analyseur') ||
          itemName.includes('panoramique') ||
          itemName.includes('capteur')
        );
      });
      if (hasMachineItem) return true;
    }

    if (typeof order.notes === 'string') {
      const notesLower = order.notes.toLowerCase();
      if (notesLower.includes('demande de devis') || notesLower.includes('machine')) return true;
    }

    return false;
  };

  // Helper to check if an item has status "En Attente" / "Pending" / "Nouvelles"
  const isPendingStatus = (item: any): boolean => {
    if (!item) return false;
    const statusStr = (
      item.status?.slug || 
      item.status?.name || 
      item.status || 
      item.state || 
      ''
    ).toString().toLowerCase();

    return (
      statusStr === 'pending' ||
      statusStr === 'new' ||
      statusStr === 'draft' ||
      statusStr.includes('attente') || 
      statusStr.includes('pending') || 
      statusStr.includes('nouvell') || 
      statusStr.includes('draft') ||
      item.status_id === 1
    );
  };

  // 1-minute interval API polling to calculate REAL live unread pending requests
  useEffect(() => {
    if (!user) return;

    const pollNewDemandes = async () => {
      try {
        const [clientsRes, savRes, devisRes, ordersRes, visitsRes] = await Promise.allSettled([
          api.clients.list('per_page=200'),
          api.reclamations.list('per_page=200'),
          api.devis.list('per_page=200'),
          api.orders.list('per_page=200'),
          api.commercialVisits.getAll()
        ]);

        let cCount = 0;
        let sCount = 0;
        let dCount = 0;
        let oCount = 0;
        let vCount = 0;

        // 1. Clients in pending / new status
        if (clientsRes.status === 'fulfilled' && clientsRes.value) {
          const list = Array.isArray(clientsRes.value.data) ? clientsRes.value.data : Array.isArray(clientsRes.value) ? clientsRes.value : [];
          cCount = list.filter((c: any) => isPendingStatus(c)).length;
        }

        // 2. SAV Tickets in "Nouvelles" status
        if (savRes.status === 'fulfilled' && savRes.value) {
          const list = Array.isArray(savRes.value.data) ? savRes.value.data : Array.isArray(savRes.value) ? savRes.value : [];
          if (list.length > 0) {
            sCount = list.filter((t: any) => isPendingStatus(t)).length;
          } else {
            const cachedTickets = JSON.parse(localStorage.getItem('specta_cached_reclamations') || '[]');
            sCount = cachedTickets.filter((t: any) => isPendingStatus(t)).length;
          }
        } else {
          const cachedTickets = JSON.parse(localStorage.getItem('specta_cached_reclamations') || '[]');
          sCount = cachedTickets.filter((t: any) => isPendingStatus(t)).length;
        }

        // 3. Devis in pending / draft status
        if (devisRes.status === 'fulfilled' && devisRes.value) {
          const list = Array.isArray(devisRes.value.data) ? devisRes.value.data : Array.isArray(devisRes.value) ? devisRes.value : [];
          dCount = list.filter((d: any) => isPendingStatus(d)).length;
        }

        // 4. Consumable Orders in pending status ("En Attente")
        if (ordersRes.status === 'fulfilled' && ordersRes.value) {
          const list = Array.isArray(ordersRes.value.data) ? ordersRes.value.data : Array.isArray(ordersRes.value) ? ordersRes.value : [];
          const consumableOrders = list.filter((o: any) => !isMachineOrder(o));
          oCount = consumableOrders.filter((o: any) => isPendingStatus(o)).length;
        }

        // 5. Commercial Visits in pending status ("en_attente")
        if (visitsRes.status === 'fulfilled' && visitsRes.value) {
          const res = visitsRes.value;
          let rawVisits = [];
          if (res?.data?.data && Array.isArray(res.data.data)) {
            rawVisits = res.data.data;
          } else if (Array.isArray(res?.data)) {
            rawVisits = res.data;
          } else if (Array.isArray(res)) {
            rawVisits = res;
          } else if (Array.isArray(res?.visits)) {
            rawVisits = res.visits;
          }
          vCount = rawVisits.filter((v: any) => {
            const st = String(v.status || '').toLowerCase();
            return st === 'en_attente' || st === 'pending' || st.includes('attente');
          }).length;
        } else {
          try {
            const saved = localStorage.getItem('specta_commercial_visit_requests');
            if (saved) {
              const parsed = JSON.parse(saved);
              vCount = parsed.filter((v: any) => {
                const st = String(v.status || '').toLowerCase();
                return st === 'en_attente' || st === 'pending' || st.includes('attente');
              }).length;
            }
          } catch (e) {}
        }

        setUnreadCounts({
          clients: cCount,
          sav: sCount,
          devis: dCount,
          consumables: oCount,
          visits: vCount
        });
      } catch (err) {
        console.warn("Sidebar 1-min polling notice:", err);
      }
    };

    pollNewDemandes();
    const interval = setInterval(pollNewDemandes, 60000);
    return () => clearInterval(interval);
  }, [user]);

  const logout = () => {
    localStorage.removeItem('specta_token');
    localStorage.removeItem('specta_user');
    setUser(null);
  };

  // Centralized Permission Engine
  const checkPermission = (module: string, action: 'view' | 'add' | 'edit' | 'delete'): boolean => {
      // RULE: If permissions object is null, undefined, or empty -> Full Access (Admin bypass)
      if (!user?.permissions || Object.keys(user.permissions).length === 0) {
          return true;
      }
      
      const targetModule = module === 'delivery-tracking' ? 'tracking' : module;
      const permObj = user.permissions[targetModule];
      
      if (!permObj) return false;
      return permObj[action] === true;
  };

  const showDenied = (actionLabel: string) => {
      setDeniedModal(actionLabel);
  };

  return (
    <AppContext.Provider value={{ 
        lang, setLang, t: translations[lang], 
        user, setUser, logout, 
        theme, setTheme, 
        primaryColor, setPrimaryColor,
        checkPermission,
        deniedModal, setDeniedModal,
        showDenied,
        unreadCounts,
        clearCount
    }}>
      <Router>
        <Layout>
          <Routes>
            <Route path="/" element={user ? <Navigate to="/admin/dashboard" /> : <Navigate to="/login" />} />
            <Route path="/login" element={user ? <Navigate to="/admin/dashboard" /> : <Login />} />
            <Route path="/admin/*" element={user ? (
              <Routes>
                <Route path="dashboard" element={user.role_id === 3 ? <CommercialDashboard /> : <AdminDashboard />} />
                <Route path="products" element={<ProtectedRoute module="products"><AdminProducts /></ProtectedRoute>} />
                <Route path="spare-parts" element={<ProtectedRoute module="products"><AdminSpareParts /></ProtectedRoute>} />
                <Route path="part-price-requests" element={<ProtectedRoute module="products"><AdminPartPriceRequests /></ProtectedRoute>} />
                <Route path="fidelity-rules" element={<ProtectedRoute module="promotions"><AdminFidelityRules /></ProtectedRoute>} />
                <Route path="catalogue-setup" element={<ProtectedRoute module="products"><AdminCatalogueSetup /></ProtectedRoute>} />
                <Route path="formations" element={<ProtectedRoute module="formations"><AdminFormations /></ProtectedRoute>} />
                <Route path="clients" element={<ProtectedRoute module="clients"><AdminClients /></ProtectedRoute>} />
                <Route path="machines" element={<ProtectedRoute module="machines"><AdminMachines /></ProtectedRoute>} />
                <Route path="orders" element={<ProtectedRoute module="orders"><AdminOrders /></ProtectedRoute>} />
                <Route path="orders-consumables" element={<ProtectedRoute module="orders"><AdminOrders forcedType="consumable" /></ProtectedRoute>} />
                <Route path="orders-machines" element={<ProtectedRoute module="orders"><AdminOrders forcedType="machine" /></ProtectedRoute>} />
                <Route path="devis" element={<ProtectedRoute module="devis"><AdminDevis /></ProtectedRoute>} />
                <Route path="promotions" element={<ProtectedRoute module="promotions"><AdminPromotions /></ProtectedRoute>} />
                <Route path="reglements" element={<ProtectedRoute module="reglements"><AdminReglements /></ProtectedRoute>} />
                <Route path="sav/new" element={<ProtectedRoute module="sav"><AdminNewSAV /></ProtectedRoute>} />
                <Route path="sav" element={<ProtectedRoute module="sav"><AdminSAV /></ProtectedRoute>} />
                <Route path="tracking" element={<ProtectedRoute module="tracking"><AdminTracking /></ProtectedRoute>} />
                <Route path="tracking-commercials" element={<ProtectedRoute module="commercials"><AdminTracking lockedFleet="commercials" /></ProtectedRoute>} />
                <Route path="tracking-technicians" element={<ProtectedRoute module="tracking"><AdminTracking lockedFleet="technicians" /></ProtectedRoute>} />

                <Route path="reviews" element={<ProtectedRoute module="reviews"><AdminReviews /></ProtectedRoute>} />
                <Route path="staff-logs" element={<ProtectedRoute module="staff-logs"><AdminStaffLogs /></ProtectedRoute>} />
                <Route path="reels" element={<ProtectedRoute module="reels"><AdminReels /></ProtectedRoute>} />
                <Route path="notifications" element={<ProtectedRoute module="notifications"><AdminNotifications /></ProtectedRoute>} />
                <Route path="users" element={<ProtectedRoute module="users"><AdminUsers /></ProtectedRoute>} />
                <Route path="settings" element={<ProtectedRoute module="settings"><AdminSettings /></ProtectedRoute>} />
                <Route path="commercial-team" element={<ProtectedRoute module="commercials"><AdminCommercialTeam /></ProtectedRoute>} />
                <Route path="commercial-visits" element={<ProtectedRoute module="commercials"><AdminCommercialVisits /></ProtectedRoute>} />
                <Route path="commercials" element={<ProtectedRoute module="commercials"><AdminCommercials /></ProtectedRoute>} />
                <Route path="commercial-regions" element={<ProtectedRoute module="commercials"><AdminCommercialRegions /></ProtectedRoute>} />
                <Route path="*" element={<Navigate to="dashboard" />} />
              </Routes>
            ) : <Navigate to="/login" />} />
          </Routes>
        </Layout>
      </Router>
    </AppContext.Provider>
  );
}