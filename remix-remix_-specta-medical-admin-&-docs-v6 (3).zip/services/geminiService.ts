
import { GoogleGenAI } from "@google/genai";

// Fixed: Use process.env.API_KEY directly and use gemini-3-pro-preview for complex reasoning tasks
export async function getAIDiagnostic(description: string, language: string) {
  // Always initialize with the named parameter apiKey
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = language === 'fr' 
    ? `En tant qu'expert en maintenance biomédicale Specta, analyse le problème suivant et propose une solution technique immédiate en 3 étapes : ${description}`
    : `As a Specta biomedical maintenance expert, analyze the following issue and propose an immediate 3-step technical solution: ${description}`;

  try {
    // Fixed: Call generateContent directly on ai.models and use the 'text' property on the response
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
    });
    // The .text property directly returns the generated string
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return language === 'fr' ? "Erreur lors de la génération du diagnostic." : "Error generating diagnostic.";
  }
}
