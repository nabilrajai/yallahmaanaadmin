
import React, { useState, useEffect } from 'react';
import { api } from '../api';
import { useApp } from '../App';

const REG_STATUS_FLOW: { id: string; label: string; color: string; icon: string; tooltip: string }[] = [
  { id: 'pending', label: 'En Attente', color: 'bg-slate-400', icon: 'ti-clock', tooltip: 'Mettre en attente' },
  { id: 'confirmed', label: 'Confirmé', color: 'bg-blue-600', icon: 'ti-checkbox', tooltip: 'Confirmer l\'inscription' },
  { id: 'attended', label: 'Présent', color: 'bg-emerald-600', icon: 'ti-user-check', tooltip: 'Marquer comme présent' },
  { id: 'cancelled', label: 'Annulé', color: 'bg-rose-500', icon: 'ti-user-x', tooltip: 'Annuler l\'inscription' }
];

const PAYMENT_METHODS = [
  { id: 'Espèces', label: 'Espèces (Cash)' },
  { id: 'Chèque', label: 'Chèque' },
  { id: 'Virement', label: 'Virement' },
  { id: 'Effet', label: 'Effet' }
];

export default function AdminFormations() {
  const { theme } = useApp();
  const [formations, setFormations] = useState<any[]>([]);
  const [clients, setClients] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedFormation, setSelectedFormation] = useState<any>(null);
  const [registrations, setRegistrations] = useState<any[]>([]);
  const [loadingRegs, setLoadingRegs] = useState(false);
  
  const [modal, setModal] = useState<{ type: 'add' | 'edit' | 'delete' | null, item: any }>({ type: null, item: null });
  const [modalFormationType, setModalFormationType] = useState<'event' | 'machine_training'>('event');
  const [paymentModal, setPaymentModal] = useState<{ reg: any, status: string, memo: string } | null>(null);
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'event' | 'machine_training'>('all');
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const fetchFormations = async () => {
    setLoading(true);
    try {
      const [resFormations, resClients] = await Promise.all([
        api.formations.list().catch(() => ({ data: [] })),
        api.clients.list('per_page=200').catch(() => ({ data: [] }))
      ]);
      const results = Array.isArray(resFormations.data) ? resFormations.data : (Array.isArray(resFormations) ? resFormations : []);
      const clientList = Array.isArray(resClients.data) ? resClients.data : (Array.isArray(resClients) ? resClients : []);
      
      setFormations(results);
      setClients(clientList);

      if (results.length > 0 && !selectedFormation) {
          handleSelectFormation(results[0]);
      }
    } catch (e) { console.error(e); } finally { setLoading(false); }
  };

  const fetchRegistrations = async (formationId: number) => {
    setLoadingRegs(true);
    try {
        const res = await api.formations.registrations(formationId);
        const results = res.registrations || (Array.isArray(res.data) ? res.data : (Array.isArray(res) ? res : []));
        setRegistrations(results);
    } catch (e) { setRegistrations([]); } finally { setLoadingRegs(false); }
  };

  useEffect(() => { fetchFormations(); }, []);

  const handleSelectFormation = (f: any) => {
      setSelectedFormation(f);
      fetchRegistrations(f.id);
  };

  const handleUpdateRegStatus = async (reg: any, newStatus: string) => {
    if (newStatus === 'confirmed') {
        const formationHeader = `FORMATION: ${selectedFormation.title}\nDATE: ${selectedFormation.start_date}\nLIEU: ${selectedFormation.location}\nINSTRUCTEUR: ${selectedFormation.instructor_name}\n---------------------------\nNotes Admin: `;
        setPaymentModal({ reg, status: newStatus, memo: formationHeader });
        return;
    }
    await executeStatusUpdate(reg.id, newStatus, reg.notes || '');
  };

  const executeStatusUpdate = async (regId: number, status: string, notes: string, paymentData?: any) => {
      setIsSubmitting(true);
      try {
          await api.formations.updateRegistration(regId, status);
          if (paymentData && paymentData.amount > 0) {
              const clientId = paymentModal?.reg.user?.client_id || paymentModal?.reg.client_id;
              if (clientId) {
                  await api.payments.create({
                      client_id: clientId,
                      amount: paymentData.amount,
                      payment_date: paymentData.payment_date,
                      due_date: paymentData.due_date || null,
                      method: paymentData.method,
                      reference: paymentData.reference || `ACADEMIE-${regId}`,
                      notes: notes
                  });
              }
          }
          if (selectedFormation) fetchRegistrations(selectedFormation.id);
          setPaymentModal(null);
      } catch (e: any) {
          console.error("Sync Error:", e);
      } finally {
          setIsSubmitting(false);
      }
  };

  const handleSaveFormation = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    
    // Explicitly handle the image file to ensure it's appended correctly as a File object
    const imageInput = form.querySelector('input[name="image"]') as HTMLInputElement;
    if (imageInput && imageInput.files && imageInput.files.length > 0) {
        formData.set('image', imageInput.files[0]);
    } else {
        formData.delete('image');
    }
    
    try {
      if (modal.type === 'add') await api.formations.create(formData);
      else await api.formations.update(modal.item.id, formData);
      setModal({ type: null, item: null });
      fetchFormations();
    } catch (e: any) { 
        console.error(e);
        alert(e.message || "Erreur d'enregistrement."); 
    } finally { 
        setIsSubmitting(false); 
    }
  };

  const getFullImageUrl = (path: string) => {
    if (!path) return 'https://placehold.co/600x400?text=SPECTA+ACADEMIE';
    if (path.startsWith('http')) return path;
    return `https://birdeye-intelligence.ma/Spetcapp/Backend/storage/app/public/${path}`;
  };

  const formatDateForInput = (dateStr: string) => {
    if (!dateStr) return '';
    try {
      const d = new Date(dateStr);
      if (!isNaN(d.getTime())) {
        return d.toISOString().split('T')[0];
      }
      const parts = dateStr.split('/');
      if (parts.length === 3) {
        return `${parts[2]}-${parts[1]}-${parts[0]}`;
      }
      return dateStr.split(' ')[0];
    } catch (e) {
      return '';
    }
  };

  const filteredFormations = formations.filter(f => {
    const matchesSearch = f.title.toLowerCase().includes(searchTerm.toLowerCase());
    if (filterType === 'all') return matchesSearch;
    if (filterType === 'event') return matchesSearch && (f.type === 'event' || !f.type);
    if (filterType === 'machine_training') return matchesSearch && (f.type === 'machine_training' || f.client_id);
    return matchesSearch;
  });

  return (
    <div className="h-full flex flex-col gap-8 animate-in fade-in duration-700 pb-10">
      {/* HEADER SECTION */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 bg-white p-10 rounded-[4rem] shadow-sm border border-slate-100">
        <div>
          <h1 className="text-5xl font-black text-slate-800 tracking-tighter mb-2">Académie & Formations</h1>
          <p className="text-slate-400 font-black uppercase text-[10px] tracking-[4px] opacity-70 italic">Gestion des Masterclass, Événements & Formations Clients Sur Machine</p>
        </div>
        <div className="flex gap-4">
            <button 
                onClick={() => {
                    setImagePreview(null);
                    setModalFormationType('event');
                    setModal({ type: 'add', item: { type: 'event', is_active: 1, price: 0 } });
                }}
                className="bg-blue-600 text-white px-8 py-5 rounded-[2rem] font-black shadow-2xl shadow-blue-100 hover:bg-blue-700 transition-all flex items-center gap-3 active:scale-95"
            >
                <i className="ti ti-plus text-xl"></i> Nouvelle Formation
            </button>
        </div>
      </div>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-8 min-h-0">
        {/* COURSE LIST SIDEBAR */}
        <div className="lg:col-span-4 flex flex-col gap-4 overflow-y-auto custom-scrollbar pr-2 h-[400px] lg:h-auto">
            <div className="relative">
                <i className="ti ti-search absolute left-6 top-1/2 -translate-y-1/2 text-slate-400"></i>
                <input 
                    type="text" 
                    placeholder="Filtrer les formations par titre..." 
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    className="w-full pl-14 pr-8 py-4 bg-white border-none rounded-[2rem] outline-none font-bold shadow-sm focus:ring-4 focus:ring-blue-500/5 transition-all text-sm"
                />
            </div>

            {/* TYPE FILTER BUTTONS */}
            <div className="flex bg-slate-100 p-1.5 rounded-2xl border border-slate-200/50 gap-1 text-[10px] font-black uppercase">
              <button 
                onClick={() => setFilterType('all')}
                className={`flex-1 py-2 rounded-xl transition-all ${filterType === 'all' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}
              >
                Toutes
              </button>
              <button 
                onClick={() => setFilterType('event')}
                className={`flex-1 py-2 rounded-xl transition-all ${filterType === 'event' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}
              >
                Événements
              </button>
              <button 
                onClick={() => setFilterType('machine_training')}
                className={`flex-1 py-2 rounded-xl transition-all ${filterType === 'machine_training' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}
              >
                Par Client
              </button>
            </div>
            
            {filteredFormations.length === 0 ? (
              <div className="p-8 text-center bg-white rounded-3xl border border-slate-100 text-slate-400 font-bold text-xs">
                Aucune formation trouvée.
              </div>
            ) : filteredFormations.map(f => {
                const isMachineTraining = f.type === 'machine_training' || f.client_id;
                const clientObj = clients.find(c => c.id === f.client_id) || f.client;

                return (
                  <div 
                      key={f.id} 
                      onClick={() => handleSelectFormation(f)}
                      className={`p-6 rounded-[2.5rem] border transition-all cursor-pointer group relative overflow-hidden ${selectedFormation?.id === f.id ? 'bg-blue-600 border-blue-600 text-white shadow-xl scale-[1.02]' : 'bg-white border-slate-100 hover:border-blue-200 shadow-sm'}`}
                  >
                      <div className="flex gap-5 items-center relative z-10">
                          <div className="w-16 h-16 rounded-[1.25rem] overflow-hidden shadow-md shrink-0 border-2 border-white/20 bg-slate-50 flex items-center justify-center">
                              <img src={getFullImageUrl(f.image_url)} className="w-full h-full object-cover" alt="" />
                          </div>
                          <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                {isMachineTraining ? (
                                  <span className={`px-2.5 py-0.5 rounded-full text-[8px] font-black uppercase tracking-wider ${selectedFormation?.id === f.id ? 'bg-white/20 text-white' : 'bg-purple-50 text-purple-600'}`}>
                                    Machine Client
                                  </span>
                                ) : (
                                  <span className={`px-2.5 py-0.5 rounded-full text-[8px] font-black uppercase tracking-wider ${selectedFormation?.id === f.id ? 'bg-white/20 text-white' : 'bg-blue-50 text-blue-600'}`}>
                                    Événement Public
                                  </span>
                                )}
                              </div>
                              <h4 className="font-black text-sm truncate leading-tight mb-1.5 uppercase">{f.title}</h4>
                              
                              {clientObj && (
                                <p className={`text-[9px] font-bold truncate mb-1 ${selectedFormation?.id === f.id ? 'text-blue-100' : 'text-purple-600'}`}>
                                  <i className="ti ti-building text-xs mr-1"></i>
                                  {clientObj.name}
                                </p>
                              )}

                              <div className="flex items-center justify-between gap-2">
                                  <p className={`text-[9px] font-bold uppercase tracking-widest flex items-center gap-1 ${selectedFormation?.id === f.id ? 'text-blue-100' : 'text-slate-400'}`}>
                                      <i className="ti ti-calendar"></i> {f.start_date ? new Date(f.start_date).toLocaleDateString() : 'Non définie'}
                                  </p>
                                  <p className={`text-[9px] font-black uppercase tracking-widest ${selectedFormation?.id === f.id ? 'text-white' : 'text-blue-600'}`}>
                                      {parseFloat(f.price || 0).toLocaleString()} MAD
                                  </p>
                              </div>
                          </div>
                      </div>
                  </div>
                );
            })}
        </div>

        {/* REGISTRY MAIN VIEW */}
        <div className="lg:col-span-8 bg-white rounded-[3.5rem] border-4 border-white shadow-xl overflow-hidden flex flex-col relative">
            {!selectedFormation ? (
                <div className="flex-1 flex flex-col items-center justify-center text-center p-20 opacity-20">
                    <i className="ti ti-school text-8xl mb-6"></i>
                    <p className="font-black uppercase tracking-[8px] text-xs">Sélectionnez une session pour afficher les détails</p>
                </div>
            ) : (
                <div className="flex-1 flex flex-col min-h-0 animate-in fade-in duration-500">
                    <div className="p-8 border-b border-slate-50 flex justify-between items-center bg-slate-50/30">
                        <div className="flex items-center gap-6">
                            <div className="w-16 h-16 bg-blue-600 text-white rounded-[1.5rem] flex items-center justify-center text-3xl shadow-xl shadow-blue-100 shrink-0">
                                <i className="ti ti-users-group"></i>
                            </div>
                            <div>
                                <div className="flex items-center gap-2 mb-1">
                                  {selectedFormation.type === 'machine_training' || selectedFormation.client_id ? (
                                    <span className="px-3 py-0.5 bg-purple-100 text-purple-700 rounded-full text-[9px] font-black uppercase tracking-wider">
                                      Formation Machine Client
                                    </span>
                                  ) : (
                                    <span className="px-3 py-0.5 bg-blue-100 text-blue-700 rounded-full text-[9px] font-black uppercase tracking-wider">
                                      Événement Public
                                    </span>
                                  )}

                                  {(selectedFormation.client || selectedFormation.client_id) && (
                                    <span className="px-3 py-0.5 bg-slate-100 text-slate-700 rounded-full text-[9px] font-black uppercase tracking-wider flex items-center gap-1">
                                      <i className="ti ti-building"></i>
                                      {clients.find(c => c.id === selectedFormation.client_id)?.name || selectedFormation.client?.name || `Client #${selectedFormation.client_id}`}
                                    </span>
                                  )}
                                </div>
                                <h3 className="text-xl font-black text-slate-800 tracking-tight leading-none mb-2 uppercase">{selectedFormation.title}</h3>
                                <div className="flex items-center gap-4">
                                    <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest bg-blue-50 px-3 py-1 rounded-full">{registrations.length} Inscrits</span>
                                    <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest bg-emerald-50 px-3 py-1 rounded-full">{parseFloat(selectedFormation.price || 0).toLocaleString()} MAD / Participant</span>
                                </div>
                            </div>
                        </div>
                        <div className="group relative">
                            <button onClick={() => {
                                setImagePreview(null);
                                setModalFormationType(selectedFormation.type || 'event');
                                setModal({ type: 'edit', item: selectedFormation });
                            }} className="w-12 h-12 bg-white rounded-2xl shadow-md flex items-center justify-center text-slate-400 hover:text-blue-600 transition-all border border-slate-100 active:scale-90">
                                <i className="ti ti-edit text-xl"></i>
                            </button>
                        </div>
                    </div>

                    <div className="flex-1 overflow-y-auto custom-scrollbar">
                        <table className="w-full text-left">
                            <thead className="bg-slate-50/50 sticky top-0 z-10 backdrop-blur-md">
                                <tr className="text-[10px] font-black uppercase text-slate-400 tracking-widest border-b border-slate-100">
                                    <th className="px-8 py-5">Identité Participant</th>
                                    <th className="px-8 py-5">Statut</th>
                                    <th className="px-8 py-5 text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-50">
                                {loadingRegs ? (
                                    <tr><td colSpan={3} className="py-24 text-center"><div className="animate-spin h-10 w-10 border-t-4 border-blue-600 rounded-full mx-auto"></div></td></tr>
                                ) : registrations.length === 0 ? (
                                    <tr><td colSpan={3} className="py-20 text-center text-slate-400 font-bold text-xs uppercase tracking-wider">Aucune inscription enregistrée pour le moment.</td></tr>
                                ) : registrations.map(reg => (
                                    <tr key={reg.id} className="hover:bg-slate-50/50 transition-colors group">
                                        <td className="px-8 py-6">
                                            <div className="flex items-center gap-4">
                                                <img src={`https://ui-avatars.com/api/?name=${reg.user?.name || reg.guest_name || 'Participant'}&background=5D87FF&color=fff&bold=true`} className="w-12 h-12 rounded-2xl shadow-md border-2 border-white" alt="" />
                                                <div className="min-w-0">
                                                    <p className="font-black text-slate-800 text-sm leading-none mb-1 truncate">{reg.user?.name || reg.guest_name}</p>
                                                    <p className="text-[10px] font-bold text-slate-400 lowercase tracking-tight truncate">{reg.user?.client?.name || 'CANDIDAT LIBRE'}</p>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-8 py-6">
                                            <div className="flex items-center gap-2">
                                                <span className={`w-2.5 h-2.5 rounded-full ${REG_STATUS_FLOW.find(s => s.id === reg.status)?.color}`}></span>
                                                <span className="text-[10px] font-black uppercase tracking-widest text-slate-700">{REG_STATUS_FLOW.find(s => s.id === reg.status)?.label}</span>
                                            </div>
                                        </td>
                                        <td className="px-8 py-6 text-right">
                                            <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-all">
                                                {REG_STATUS_FLOW.map(s => (
                                                    <button 
                                                        key={s.id}
                                                        onClick={() => handleUpdateRegStatus(reg, s.id)}
                                                        className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${reg.status === s.id ? 'hidden' : 'bg-white border border-slate-200 text-slate-400 hover:text-blue-600 hover:border-blue-600 shadow-sm'}`}
                                                        title={s.tooltip}
                                                    >
                                                        <i className={`ti ${s.icon} text-lg`}></i>
                                                    </button>
                                                ))}
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
        </div>
      </div>

      {/* DYNAMIC FORM MODAL */}
      {modal.type && modal.type !== 'delete' && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[150] flex items-center justify-center p-4">
              <div className="bg-white w-full max-w-4xl rounded-[3.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 border-4 border-white flex flex-col max-h-[90vh]">
                    <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                        <div>
                            <h2 className="text-xl font-black text-slate-800 tracking-tight uppercase">{modal.type === 'add' ? 'Créer une Nouvelle' : 'Modifier la'} Formation</h2>
                            <p className="text-slate-400 font-bold text-xs mt-0.5">Configuration des paramètres de formation et attribution client</p>
                        </div>
                        <button onClick={() => setModal({ type: null, item: null })} className="w-12 h-12 flex items-center justify-center bg-white rounded-full text-slate-400 hover:text-red-500 shadow-md transition-all text-2xl font-light active:scale-90">×</button>
                    </div>
                    <form onSubmit={handleSaveFormation} className="p-10 overflow-y-auto custom-scrollbar space-y-8">
                        {/* TYPE & CLIENT SELECTOR BLOCK */}
                        <div className="space-y-4 bg-slate-50 p-6 rounded-[2rem] border border-slate-100">
                            <h4 className="text-[11px] font-black text-blue-600 uppercase tracking-wider">Type de Formation & Attribution</h4>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                              <div className="space-y-1">
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-3">Type d'Événement</label>
                                <select 
                                  name="type" 
                                  value={modalFormationType}
                                  onChange={(e: any) => setModalFormationType(e.target.value)}
                                  className="w-full px-6 py-4 bg-white border-none rounded-2xl outline-none font-bold text-sm shadow-inner"
                                  required
                                >
                                  <option value="event">Événement Public (Masterclass)</option>
                                  <option value="machine_training">Formation Sur Machine (Dédiée Client)</option>
                                </select>
                              </div>

                              {modalFormationType === 'machine_training' && (
                                <div className="space-y-1 animate-in fade-in duration-300">
                                  <label className="text-[10px] font-black text-purple-600 uppercase tracking-widest ml-3">Client Associé</label>
                                  <select 
                                    name="client_id" 
                                    defaultValue={modal.item.client_id || ''}
                                    className="w-full px-6 py-4 bg-white border-2 border-purple-200 rounded-2xl outline-none font-black text-sm shadow-inner text-purple-900"
                                    required={modalFormationType === 'machine_training'}
                                  >
                                    <option value="">-- Sélectionner un Client --</option>
                                    {clients.map(c => (
                                      <option key={c.id} value={c.id}>{c.name} {c.company_name ? `(${c.company_name})` : ''}</option>
                                    ))}
                                  </select>
                                </div>
                              )}
                            </div>
                        </div>

                        {/* CORE IDENTITY BLOCK */}
                        <div className="space-y-4">
                            <h4 className="text-[11px] font-black text-slate-800 uppercase tracking-wider border-b pb-2">Informations Générales</h4>
                            <div className="space-y-1">
                                <label htmlFor="formation_title" className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-3">Titre de la Formation</label>
                                <input 
                                    id="formation_title"
                                    name="title" 
                                    defaultValue={modal.item.title} 
                                    className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl outline-none font-black text-lg shadow-inner placeholder-slate-300 focus:ring-4 focus:ring-blue-500/5 transition-all" 
                                    required 
                                    placeholder="Ex: Formation Pratique Laser Médical V3"
                                />
                            </div>
                        </div>

                        {/* LOGISTICS & FINANCIALS BLOCK */}
                        <div className="space-y-4">
                            <h4 className="text-[11px] font-black text-indigo-600 uppercase tracking-wider border-b pb-2">Logistique & Tarification</h4>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="space-y-1">
                                    <label htmlFor="formation_venue" className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-3">Lieu / Adresse</label>
                                    <input id="formation_venue" name="location" defaultValue={modal.item.location} className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl outline-none font-bold shadow-inner" required placeholder="Ex: Showroom Casablanca" />
                                </div>
                                <div className="space-y-1">
                                    <label htmlFor="formation_date" className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-3">Date de Début</label>
                                    <input 
                                        id="formation_date" 
                                        name="start_date" 
                                        type="date" 
                                        defaultValue={formatDateForInput(modal.item.start_date)} 
                                        className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl outline-none font-bold shadow-inner" 
                                        required 
                                    />
                                </div>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="space-y-1">
                                    <label htmlFor="formation_instructor" className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-3">Instructeur / Expert</label>
                                    <input id="formation_instructor" name="instructor_name" defaultValue={modal.item.instructor_name} className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl outline-none font-bold shadow-inner" required placeholder="Ex: Dr. Alami" />
                                </div>
                                <div className="space-y-1">
                                    <label htmlFor="formation_price" className="text-[10px] font-black text-blue-600 uppercase tracking-widest ml-3">Frais d'Inscription (MAD)</label>
                                    <input id="formation_price" name="price" type="number" step="0.01" defaultValue={modal.item.price || 0} className="w-full px-6 py-4 bg-blue-50 border-none rounded-2xl outline-none font-black text-lg text-blue-700 shadow-inner" required />
                                </div>
                            </div>
                        </div>

                        {/* CONTENT & MEDIA BLOCK */}
                        <div className="space-y-4">
                            <h4 className="text-[11px] font-black text-slate-500 uppercase tracking-wider border-b pb-2">Programme & Visuel</h4>
                            <div className="space-y-1">
                                <label htmlFor="formation_description" className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-3">Programme / Description</label>
                                <textarea id="formation_description" name="description" defaultValue={modal.item.description} className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl outline-none font-medium h-32 shadow-inner leading-relaxed text-sm" placeholder="Objectifs pédagogiques et déroulé du cours..." />
                            </div>
                            <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100 flex flex-col md:flex-row items-center gap-6 shadow-inner relative overflow-hidden">
                                <div className="w-24 h-24 bg-white rounded-2xl shadow-md border-2 border-white flex items-center justify-center shrink-0 overflow-hidden">
                                    <img src={imagePreview || getFullImageUrl(modal.item.image_url)} className="w-full h-full object-cover" alt="" />
                                </div>
                                <div className="flex-1 space-y-2">
                                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Image Promotionnelle</p>
                                    <label className="w-full py-3 px-8 bg-slate-900 text-white rounded-xl font-black uppercase text-[10px] tracking-widest cursor-pointer hover:bg-blue-600 transition-all block text-center shadow-md active:scale-95">
                                        Choisir une Image
                                        <input 
                                            name="image" 
                                            type="file" 
                                            className="hidden" 
                                            accept="image/jpeg,image/png,image/jpg,image/gif,image/webp" 
                                            onChange={(e) => {
                                                const file = e.target.files?.[0];
                                                if (file) {
                                                    const url = URL.createObjectURL(file);
                                                    setImagePreview(url);
                                                }
                                            }}
                                        />
                                    </label>
                                </div>
                            </div>
                        </div>

                        <button 
                            type="submit" 
                            disabled={isSubmitting} 
                            className="w-full py-5 bg-blue-600 text-white rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl shadow-blue-500/20 active:scale-95 transition-all mt-4"
                        >
                            {isSubmitting ? 'Enregistrement en cours...' : 'Enregistrer la Formation'}
                        </button>
                    </form>
              </div>
          </div>
      )}
    </div>
  );
}
