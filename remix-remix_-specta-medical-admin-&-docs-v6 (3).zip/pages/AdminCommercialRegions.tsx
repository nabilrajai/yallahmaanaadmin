import React, { useState, useEffect, useMemo } from 'react';
import { api } from '../api';
import { useApp } from '../App';

const REGIONS_DATA = [
  {
    name: "Région Nord",
    center: "Tanger",
    cities: "Tanger, Tétouan, Chefchaouen, Larache, Al Hoceïma, Ouezzane, M'diq, Fnideq"
  },
  {
    name: "Région Centre-Ouest",
    center: "Rabat",
    cities: "Rabat, Salé, Kénitra, Khémisset, Sidi Kacem, Sidi Slimane"
  },
  {
    name: "Région Centre",
    center: "Casablanca",
    cities: "Casablanca, Mohammedia, El Jadida, Settat, Berrechid, Benslimane, Nouaceur, Khouribga"
  },
  {
    name: "Région Sud",
    center: "Marrakech",
    cities: "Marrakech, Safi, Essaouira, Agadir, Taroudant, Ouarzazate, Errachidia, Béni Mellal, Azilal, Tinghir, Guelmim, Tan-Tan, Tiznit, Laâyoune, Dakhla"
  }
];

export default function AdminCommercialRegions() {
  const { theme } = useApp();
  const [commercials, setCommercials] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  // Editing state
  const [editingCommercial, setEditingCommercial] = useState<any>(null);
  const [newRegion, setNewRegion] = useState('');
  const [savingRegion, setSavingRegion] = useState(false);

  const fetchData = async () => {
    setLoading(true);
    try {
      // We fetch all commercials with their stats
      const res = await api.payments.getCommercialStats();
      setCommercials(res.commercials || []);
    } catch (e) {
      console.error("Failed to fetch regional data", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSaveRegion = async () => {
    if (!editingCommercial) return;
    setSavingRegion(true);
    try {
      const fullUser = await api.users.show(editingCommercial.id);
      
      const payload = {
        name: fullUser.name,
        email: fullUser.email,
        role_id: fullUser.role_id,
        phone: fullUser.phone,
        is_active: fullUser.is_active ? '1' : '0',
        region: newRegion,
      };

      await api.users.update(editingCommercial.id, payload);
      await fetchData();
      setEditingCommercial(null);
    } catch (err) {
      console.error("Failed to save region:", err);
      alert("Erreur lors de la mise à jour de la région.");
    } finally {
      setSavingRegion(false);
    }
  };

  const regionalStats = useMemo(() => {
    const stats: Record<string, any> = {};

    commercials.forEach(c => {
      const region = c.region || 'Non Spécifié';
      if (!stats[region]) {
        stats[region] = {
          region,
          commercialsCount: 0,
          totalCa: 0,
          totalOrders: 0,
          totalDevis: 0,
          totalPayments: 0,
          clientsCount: 0
        };
      }

      stats[region].commercialsCount += 1;
      const s = c.stats || {};
      stats[region].totalCa += parseFloat(s.orders?.total_ttc || c.total_sales || 0);
      stats[region].totalOrders += s.orders?.count || 0;
      stats[region].totalDevis += s.devis?.count || 0;
      stats[region].totalPayments += parseFloat(s.payments?.total_paid || c.total_paid || 0);
      stats[region].clientsCount += s.clients_count || 0;
    });

    return Object.values(stats).sort((a, b) => b.totalCa - a.totalCa);
  }, [commercials]);

  const totalStats = useMemo(() => {
    return regionalStats.reduce((acc, curr) => ({
      ca: acc.ca + curr.totalCa,
      orders: acc.orders + curr.totalOrders,
      payments: acc.payments + curr.totalPayments,
      clients: acc.clients + curr.clientsCount
    }), { ca: 0, orders: 0, payments: 0, clients: 0 });
  }, [regionalStats]);

  return (
    <div className="space-y-8 pb-20 animate-in fade-in duration-700">
      <div className="bg-white p-10 rounded-[4rem] shadow-sm border border-slate-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h1 className="text-4xl font-black text-slate-800 tracking-tight">Analyse par Région</h1>
          <p className="text-slate-400 font-black uppercase text-[10px] tracking-[3px] opacity-60">Performance Commerciale & Ventes Géo-Localisées</p>
        </div>
        <div className="flex gap-4">
            <button onClick={fetchData} className="w-14 h-14 bg-slate-900 text-white rounded-full flex items-center justify-center shadow-xl active:scale-90 transition-all hover:bg-blue-600">
                <i className="ti ti-refresh text-xl"></i>
            </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard label="Chiffre d'Affaires Global" value={`${totalStats.ca.toLocaleString()} MAD`} icon="ti-world" color="bg-blue-600" />
          <StatCard label="Total Commandes" value={totalStats.orders} icon="ti-shopping-cart" color="bg-indigo-600" />
          <StatCard label="Encaissements" value={`${totalStats.payments.toLocaleString()} MAD`} icon="ti-wallet" color="bg-emerald-600" />
          <StatCard label="Portefeuille Clients" value={totalStats.clients} icon="ti-users" color="bg-amber-500" />
      </div>

      <div className={`bg-white rounded-[4rem] border border-slate-100 shadow-sm overflow-hidden`}>
        <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50 text-slate-400 border-b">
                <tr className="text-[10px] font-black uppercase tracking-widest">
                    <th className="px-10 py-6">Région</th>
                    <th className="px-10 py-6">Commerciaux</th>
                    <th className="px-10 py-6">Clients</th>
                    <th className="px-10 py-6 text-center">Volume Ventes</th>
                    <th className="px-10 py-6 text-center">Encaissement</th>
                    <th className="px-10 py-6 text-right">Performance</th>
                </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
                {regionalStats.map((r, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50 transition-all group">
                        <td className="px-10 py-8">
                            <div className="flex items-center gap-4">
                                <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center text-xl font-black shadow-inner">
                                    {r.region.charAt(0)}
                                </div>
                                <div>
                                    <p className="font-black text-slate-800 text-lg uppercase tracking-tight">{r.region}</p>
                                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mt-1">Secteur Actif</p>
                                    <p className="text-[9px] font-black text-blue-600 uppercase tracking-widest mt-1">
                                        <i className="ti ti-building-store mr-1"></i>
                                        Showroom: {r.region.includes('Nord') ? 'Tanger' : r.region.includes('Centre-Ouest') ? 'Rabat' : r.region.includes('Centre') ? 'Casablanca' : r.region.includes('Sud') ? 'Marrakech' : 'Non défini'}
                                    </p>
                                </div>
                            </div>
                        </td>
                        <td className="px-10 py-8">
                            <div className="flex -space-x-3">
                                {[...Array(Math.min(r.commercialsCount, 4))].map((_, i) => (
                                    <div key={i} className="w-10 h-10 rounded-full border-2 border-white bg-slate-200 flex items-center justify-center text-[10px] font-black text-slate-500 shadow-sm">
                                        <i className="ti ti-user"></i>
                                    </div>
                                ))}
                                {r.commercialsCount > 4 && (
                                    <div className="w-10 h-10 rounded-full border-2 border-white bg-slate-900 text-white flex items-center justify-center text-[10px] font-black shadow-sm">
                                        +{r.commercialsCount - 4}
                                    </div>
                                )}
                            </div>
                        </td>
                        <td className="px-10 py-8">
                            <p className="font-black text-slate-700">{r.clientsCount}</p>
                            <p className="text-[9px] font-bold text-slate-300 uppercase">Etablissements</p>
                        </td>
                        <td className="px-10 py-8 text-center">
                            <p className="font-black text-slate-800">{r.totalCa.toLocaleString()} MAD</p>
                            <p className="text-[9px] font-bold text-emerald-500 uppercase">{r.totalOrders} Commandes</p>
                        </td>
                        <td className="px-10 py-8 text-center">
                            <p className="font-black text-slate-800">{r.totalPayments.toLocaleString()} MAD</p>
                            <div className="w-24 h-1.5 bg-slate-100 rounded-full mx-auto mt-2 overflow-hidden">
                                <div className="h-full bg-emerald-500" style={{ width: `${r.totalCa > 0 ? (r.totalPayments / r.totalCa) * 100 : 0}%` }}></div>
                            </div>
                        </td>
                        <td className="px-10 py-8 text-right">
                            <div className="inline-flex flex-col items-end">
                                <span className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest ${r.totalCa > totalStats.ca / regionalStats.length ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>
                                    {r.totalCa > totalStats.ca / regionalStats.length ? 'Top Region' : 'Secteur Stable'}
                                </span>
                            </div>
                        </td>
                    </tr>
                ))}
                {regionalStats.length === 0 && !loading && (
                    <tr>
                        <td colSpan={6} className="py-20 text-center text-slate-300 font-black uppercase text-xs tracking-[4px] italic opacity-40">
                            Aucune donnée régionale disponible
                        </td>
                    </tr>
                )}
            </tbody>
        </table>
      </div>

      <div className="mt-12 bg-white rounded-[4rem] border border-slate-100 shadow-sm overflow-hidden p-10">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
            <div>
                <h2 className="text-2xl font-black text-slate-800 tracking-tight">Commerciaux & Affectations</h2>
                <p className="text-slate-400 font-black uppercase text-[10px] tracking-[2px] opacity-60">Gérez les régions attribuées aux membres de l'équipe</p>
            </div>
        </div>

        <div className="overflow-x-auto rounded-3xl border border-slate-100">
            <table className="w-full text-left border-collapse">
                <thead className="bg-slate-50 text-slate-400 border-b">
                    <tr className="text-[10px] font-black uppercase tracking-widest">
                        <th className="px-8 py-5">Commercial</th>
                        <th className="px-8 py-5">Région Actuelle</th>
                        <th className="px-8 py-5">Chiffre d'Affaires</th>
                        <th className="px-8 py-5 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                    {commercials.map((c, idx) => (
                        <tr key={idx} className="hover:bg-slate-50/50 transition-all">
                            <td className="px-8 py-5">
                                <p className="font-black text-slate-800">{c.name}</p>
                                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">ID: {c.id}</p>
                            </td>
                            <td className="px-8 py-5">
                                <span className={`px-3 py-1 rounded-lg text-xs font-bold ${c.region ? 'bg-indigo-50 text-indigo-600' : 'bg-slate-100 text-slate-500'}`}>
                                    {c.region || 'Non Spécifié'}
                                </span>
                            </td>
                            <td className="px-8 py-5">
                                <p className="font-black text-emerald-600">
                                    {(c.total_sales ? parseFloat(c.total_sales) : 0).toLocaleString()} MAD
                                </p>
                            </td>
                            <td className="px-8 py-5 text-right">
                                <button 
                                    onClick={() => {
                                        setEditingCommercial(c);
                                        setNewRegion(c.region || '');
                                    }}
                                    className="px-4 py-2 bg-slate-100 text-slate-600 rounded-xl text-xs font-bold hover:bg-blue-600 hover:text-white transition-colors"
                                >
                                    Modifier Région
                                </button>
                            </td>
                        </tr>
                    ))}
                    {commercials.length === 0 && !loading && (
                        <tr>
                            <td colSpan={4} className="py-10 text-center text-slate-300 font-black uppercase text-[10px] tracking-[2px]">
                                Aucun commercial trouvé
                            </td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
      </div>

      {/* Edit Region Modal */}
      {editingCommercial && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4 animate-in fade-in">
            <div className="bg-white rounded-[3rem] p-8 w-full max-w-md shadow-2xl animate-in zoom-in-95 duration-300">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="text-xl font-black text-slate-800 tracking-tight">Affecter une Région</h3>
                    <button onClick={() => setEditingCommercial(null)} className="w-10 h-10 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center hover:bg-slate-200 transition-colors">
                        <i className="ti ti-x"></i>
                    </button>
                </div>
                
                <div className="mb-6">
                    <p className="text-sm font-bold text-slate-500 mb-1">Commercial</p>
                    <p className="text-lg font-black text-slate-800">{editingCommercial.name}</p>
                </div>

                <div className="space-y-2 mb-8">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Nouvelle Région</label>
                    <select 
                        value={newRegion}
                        onChange={(e) => setNewRegion(e.target.value)}
                        className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-medium text-slate-700 focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all appearance-none"
                    >
                        <option value="">Sélectionner une région</option>
                        {REGIONS_DATA.map((r, i) => (
                            <option key={i} value={r.name}>{r.name}</option>
                        ))}
                    </select>
                    
                    {newRegion && REGIONS_DATA.find(r => r.name === newRegion) && (
                        <div className="mt-4 p-4 bg-blue-50 rounded-2xl border border-blue-100 animate-in fade-in slide-in-from-top-2">
                            <p className="text-xs font-black text-blue-800 mb-1">Centre de service: {REGIONS_DATA.find(r => r.name === newRegion)?.center}</p>
                            <p className="text-[10px] font-medium text-blue-600 leading-relaxed">
                                <span className="font-bold">Villes couvertes:</span> {REGIONS_DATA.find(r => r.name === newRegion)?.cities}
                            </p>
                        </div>
                    )}
                </div>

                <div className="flex gap-4">
                    <button 
                        onClick={() => setEditingCommercial(null)} 
                        className="flex-1 py-4 rounded-2xl font-black text-[11px] uppercase tracking-widest bg-slate-100 text-slate-600 hover:bg-slate-200 transition-colors"
                    >
                        Annuler
                    </button>
                    <button 
                        onClick={handleSaveRegion} 
                        disabled={savingRegion}
                        className="flex-1 py-4 rounded-2xl font-black text-[11px] uppercase tracking-widest bg-blue-600 text-white hover:bg-blue-700 transition-colors disabled:opacity-50"
                    >
                        {savingRegion ? 'Enregistrement...' : 'Confirmer'}
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
}

function StatCard({ label, value, icon, color }: any) {
    return (
        <div className="bg-white p-8 rounded-[3.5rem] border border-slate-100 shadow-sm flex items-center gap-6 group hover:shadow-2xl transition-all relative overflow-hidden border-b-4 border-b-slate-50">
            <div className={`w-16 h-16 rounded-[1.75rem] ${color} flex items-center justify-center text-white text-3xl shadow-xl transition-transform group-hover:rotate-12`}>
                <i className={`ti ${icon}`}></i>
            </div>
            <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-[3px] mb-1.5">{label}</p>
                <p className="text-2xl font-black text-slate-800 tracking-tighter leading-none">{value}</p>
            </div>
        </div>
    );
}
