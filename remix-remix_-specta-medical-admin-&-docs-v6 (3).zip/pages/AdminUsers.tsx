import React, { useState, useEffect } from 'react';
import { api } from '../api';
import { useApp } from '../App';
import { Permissions } from '../types';

const ROLES = [
  { id: 1, name: 'Administrateur', slug: 'admin', color: 'bg-rose-500' },
  { id: 2, name: 'Technicien', slug: 'technician', color: 'bg-blue-500' },
  { id: 3, name: 'Commercial', slug: 'commercial', color: 'bg-indigo-500' },
  { id: 5, name: 'Livreur', slug: 'driver', color: 'bg-emerald-500' },
];

const PAGES_LIST = [
  { id: 'dashboard', label: 'Tableau de bord' },
  { id: 'products', label: 'Consommables' },
  { id: 'machines', label: 'Machines' },
  { id: 'formations', label: 'Formations' },
  { id: 'orders', label: 'Commandes' },
  { id: 'devis', label: 'Devis' },
  { id: 'promotions', label: 'Promotions' },
  { id: 'reglements', label: 'Règlements' },
  { id: 'clients', label: 'Registre des Clients' },
  { id: 'commercials', label: 'Performance Commerciale' },
  { id: 'sav', label: 'SAV & Tickets' },
  { id: 'tracking', label: 'Suivi en Temps Réel' },
  { id: 'reviews', label: 'Avis Clients' },
  { id: 'reels', label: 'Gestion des Reels' },
  { id: 'notifications', label: 'Diffusion Push' },
  { id: 'staff-logs', label: 'Journaux d\'Audit' },
  { id: 'users', label: 'Personnel & Rôles' },
  { id: 'settings', label: 'Paramètres Système' }
];

export default function AdminUsers() {
  const { theme } = useApp();
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<{ type: 'add' | 'edit' | 'delete' | null, item: any }>({ type: null, item: null });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [search, setSearch] = useState('');
  const [permissions, setPermissions] = useState<Permissions>({});
  const [previewAvatar, setPreviewAvatar] = useState<string | null>(null);

  const fetchData = async () => {
    setLoading(true);
    try {
      const uRes = await api.users.list();
      const allUsers = Array.isArray(uRes.data) ? uRes.data : (Array.isArray(uRes) ? uRes : []);
      setUsers(allUsers.filter((u: any) => u.role_id !== 4));
    } catch (e) { console.error(e); } finally { setLoading(false); }
  };

  useEffect(() => { fetchData(); }, []);

  const initPermissions = (existing?: any) => {
    const defaultPerms: Permissions = {};
    PAGES_LIST.forEach(p => {
        defaultPerms[p.id] = existing?.[p.id] || { view: false, add: false, edit: false, delete: false };
    });
    setPermissions(defaultPerms);
  };

  const handleOpenModal = (type: 'add' | 'edit' | 'delete', item: any) => {
    setModal({ type, item });
    setPreviewAvatar(item.avatar_url ? (item.avatar_url.startsWith('http') ? item.avatar_url : `https://birdeye-intelligence.ma/Spetcapp/Backend/storage/app/public/${item.avatar_url}`) : null);
    if (type !== 'delete') {
        let existingPerms = null;
        try {
            existingPerms = typeof item.permissions === 'string' ? JSON.parse(item.permissions) : item.permissions;
        } catch (e) { console.warn("Invalid permissions data"); }
        initPermissions(existingPerms);
    }
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) setPreviewAvatar(URL.createObjectURL(file));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    
    formData.set('permissions', JSON.stringify(permissions));
    
    if (!formData.has('is_active')) {
        formData.set('is_active', '0');
    }

    try {
      if (modal.type === 'add') {
          await api.users.create(formData);
      } else {
          await api.users.update(modal.item.id, formData);
      }
      setModal({ type: null, item: null });
      fetchData();
    } catch (e: any) {
      alert(e.message || "Erreur lors de l'enregistrement du profil utilisateur");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async () => {
    setIsSubmitting(true);
    try {
      await api.users.delete(modal.item.id);
      setModal({ type: null, item: null });
      fetchData();
    } catch (e) { alert("Erreur lors de la suppression de l'utilisateur"); } finally { setIsSubmitting(false); }
  };

  const togglePermission = (page: string, action: keyof Permissions[string]) => {
      setPermissions(prev => ({
          ...prev,
          [page]: { ...prev[page], [action]: !prev[page][action] }
      }));
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6 bg-white p-10 rounded-[4rem] shadow-sm border border-slate-100">
        <div>
          <h1 className="text-4xl font-black text-slate-800 tracking-tight">Registre des Collaborateurs</h1>
          <p className="text-slate-400 font-black uppercase text-[10px] tracking-[3px] opacity-60">Gouvernance & Matrice de Sécurité Interne</p>
        </div>
        <div className="flex gap-4">
            <div className="relative">
                <i className="ti ti-search absolute left-5 top-1/2 -translate-y-1/2 text-blue-600"></i>
                <input 
                    type="text" 
                    placeholder="Rechercher un membre..." 
                    className="pl-12 pr-6 py-4 bg-slate-50 border-none rounded-[1.5rem] outline-none font-bold text-xs"
                    value={search}
                    onChange={e => setSearch(e.target.value)}
                />
            </div>
            <button 
              onClick={() => handleOpenModal('add', { role_id: 1, is_active: 1 })}
              className="bg-blue-600 text-white px-10 py-4 rounded-[1.5rem] font-black shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all flex items-center gap-3 active:scale-95 shrink-0"
            >
              <i className="ti ti-user-plus text-xl"></i> Créer Utilisateur
            </button>
        </div>
      </div>

      <div className={`rounded-[3rem] border overflow-hidden ${theme === 'dark' ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100 shadow-sm'}`}>
        <table className="w-full text-left border-collapse">
          <thead className="bg-slate-50 text-slate-400 border-b">
            <tr className="text-[10px] font-black uppercase tracking-widest">
              <th className="px-10 py-5">Identité du Personnel</th>
              <th className="px-10 py-5">Infos de Contact</th>
              <th className="px-10 py-5">Statut du Compte</th>
              <th className="px-10 py-5">Audit</th>
              <th className="px-10 py-5 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {users.filter(u => u.name.toLowerCase().includes(search.toLowerCase())).map(u => (
              <tr key={u.id} className="hover:bg-slate-50/50 transition-all group">
                <td className="px-10 py-6">
                  <div className="flex items-center gap-5">
                    <div className="relative">
                        <img src={u.avatar_url ? (u.avatar_url.startsWith('http') ? u.avatar_url : `https://birdeye-intelligence.ma/Spetcapp/Backend/storage/app/public/${u.avatar_url}`) : `https://ui-avatars.com/api/?name=${u.name}&background=5D87FF&color=fff&bold=true`} className="w-14 h-14 rounded-2xl shadow-lg border-2 border-white object-cover" alt="" />
                        {u.is_online && <span className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 border-2 border-white rounded-full animate-pulse shadow-sm"></span>}
                    </div>
                    <div>
                        <p className="font-black text-lg text-slate-800 leading-tight">{u.name}</p>
                        <div className="flex items-center gap-2 mt-1">
                            <span className={`px-2 py-0.5 rounded-md text-[8px] font-black uppercase tracking-widest text-white ${ROLES.find(r => r.id === u.role_id)?.color || 'bg-slate-400'}`}>
                                {ROLES.find(r => r.id === u.role_id)?.name || 'Personnel'}
                            </span>
                            <span className="text-[10px] font-bold text-slate-300 uppercase tracking-tighter">ID: #{u.id}</span>
                        </div>
                    </div>
                  </div>
                </td>
                <td className="px-10 py-6">
                    <div className="space-y-1">
                        <p className="text-xs font-black text-slate-700 uppercase tracking-tight flex items-center gap-2"><i className="ti ti-mail text-blue-500"></i> {u.email}</p>
                        <p className="text-xs font-bold text-slate-400 flex items-center gap-2"><i className="ti ti-phone text-slate-300"></i> {u.phone || 'Pas de Téléphone'}</p>
                    </div>
                </td>
                <td className="px-10 py-6">
                    <div className="flex flex-col gap-2">
                        <span className={`px-4 py-1 rounded-full text-[9px] font-black uppercase tracking-widest text-center w-fit ${u.is_active ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}>
                            {u.is_active ? 'Compte Actif' : 'Désactivé'}
                        </span>
                        {u.is_online ? (
                            <span className="text-[9px] font-black text-emerald-500 uppercase tracking-widest flex items-center gap-1"><i className="ti ti-wifi"></i> Connecté Actuellement</span>
                        ) : (
                            <span className="text-[9px] font-black text-slate-300 uppercase tracking-widest">Hors ligne</span>
                        )}
                    </div>
                </td>
                <td className="px-10 py-6">
                    <div className="space-y-1">
                        <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Dernière Connexion :</p>
                        <p className="text-[10px] font-bold text-slate-600">{u.last_login_at ? new Date(u.last_login_at).toLocaleString('fr-FR') : 'Jamais connecté'}</p>
                    </div>
                </td>
                <td className="px-10 py-6 text-right">
                    <div className="flex justify-end gap-3 opacity-0 group-hover:opacity-100 transition-all">
                        <button onClick={() => handleOpenModal('edit', u)} className="p-3 text-blue-500 bg-blue-50 rounded-xl hover:bg-blue-600 hover:text-white transition-all shadow-sm"><i className="ti ti-shield-lock text-xl"></i></button>
                        <button onClick={() => handleOpenModal('delete', u)} className="p-3 text-red-500 bg-red-50 rounded-xl hover:bg-red-600 hover:text-white transition-all shadow-sm"><i className="ti ti-trash text-xl"></i></button>
                    </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {modal.type && modal.type !== 'delete' && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[150] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-6xl rounded-[4rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 border-4 border-white flex flex-col max-h-[95vh]">
            <div className="p-8 border-b flex justify-between items-center bg-slate-50/50">
              <div>
                <h2 className="text-3xl font-black tracking-tighter uppercase leading-none">
                    {modal.type === 'edit' ? 'Modifier Utilisateur' : 'Créer Utilisateur'}
                </h2>
                <p className="text-slate-400 font-bold uppercase text-[9px] tracking-[4px] mt-1 italic">Matrice de Sécurité Interne Specta</p>
              </div>
              <button onClick={() => setModal({ type: null, item: null })} className="w-12 h-12 flex items-center justify-center bg-white rounded-full text-slate-400 hover:text-red-500 shadow-md transition-all text-2xl font-light hover:rotate-90">×</button>
            </div>

            <div className="p-10 flex-1 overflow-y-auto custom-scrollbar">
                <form onSubmit={handleSave} className="space-y-12">
                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
                        <div className="lg:col-span-4 space-y-8">
                            <div className="flex flex-col items-center gap-6 p-8 bg-slate-50 rounded-[3rem] border border-slate-100 shadow-inner text-center">
                                <div className="relative group">
                                    <img src={previewAvatar || `https://ui-avatars.com/api/?name=${modal.item.name || 'Collaborateur'}&background=F1F5F9&color=64748B&bold=true`} className="w-32 h-32 rounded-[2.5rem] object-cover shadow-2xl border-4 border-white" alt="" />
                                    <label className="absolute inset-0 flex items-center justify-center bg-black/40 text-white rounded-[2.5rem] opacity-0 group-hover:opacity-100 transition-all cursor-pointer">
                                        <i className="ti ti-camera text-3xl"></i>
                                        <input type="file" name="avatar" className="hidden" onChange={handleAvatarChange} accept="image/*" />
                                    </label>
                                </div>
                                <div>
                                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-[3px]">Carte d'Identité du Collaborateur</p>
                                    <h4 className="text-xl font-black text-slate-800 truncate">{modal.item.name || 'Nouveau Collaborateur'}</h4>
                                </div>
                                
                                <div className="w-full space-y-4 pt-4 border-t border-slate-200">
                                     <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-slate-100">
                                         <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Accès Actif</label>
                                         <input type="checkbox" name="is_active" defaultChecked={!!modal.item.is_active} value="1" className="w-5 h-5 rounded accent-blue-600 cursor-pointer" />
                                     </div>
                                     <div className="space-y-1 text-left">
                                         <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-2">Ligne Téléphonique</label>
                                         <input name="phone" type="tel" defaultValue={modal.item.phone} className="w-full px-4 py-3 bg-white rounded-xl border border-slate-200 outline-none text-xs font-bold" placeholder="+212..." />
                                     </div>
                                </div>
                            </div>
                        </div>

                        <div className="lg:col-span-8 space-y-8">
                            <h4 className="text-[11px] font-black text-blue-600 uppercase tracking-[4px] border-b pb-4">Configuration Technique</h4>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="space-y-1">
                                    <label className="text-[10px] font-black text-slate-400 uppercase ml-4 tracking-widest">Nom Complet</label>
                                    <input name="name" defaultValue={modal.item.name} className="w-full px-8 py-4 bg-slate-50 border-none rounded-[1.5rem] outline-none font-black text-lg shadow-inner" required placeholder="ex: Nabil Rajai" />
                                </div>
                                <div className="space-y-1">
                                    <label className="text-[10px] font-black text-slate-400 uppercase ml-4 tracking-widest">Email Professionnel</label>
                                    <input name="email" type="email" defaultValue={modal.item.email} className="w-full px-8 py-4 bg-slate-50 border-none rounded-[1.5rem] outline-none font-bold shadow-inner" required placeholder="nabil@company.com" />
                                </div>
                                <div className="space-y-1">
                                    <label className="text-[10px] font-black text-slate-400 uppercase ml-4 tracking-widest">Groupe de Rôle</label>
                                    <select name="role_id" defaultValue={modal.item.role_id} className="w-full px-8 py-4 bg-slate-50 border-none rounded-[1.5rem] outline-none font-black uppercase text-xs shadow-inner appearance-none cursor-pointer">
                                        {ROLES.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
                                    </select>
                                </div>
                                <div className="space-y-1">
                                    <label className="text-[10px] font-black text-slate-400 uppercase ml-4 tracking-widest">Région (Commercial)</label>
                                    <input name="region" defaultValue={modal.item.region} className="w-full px-8 py-4 bg-slate-50 border-none rounded-[1.5rem] outline-none font-bold shadow-inner" placeholder="ex: Casablanca-Settat" />
                                </div>
                                <div className="space-y-1">
                                    <label className="text-[10px] font-black text-slate-400 uppercase ml-4 tracking-widest">Mot de passe</label>
                                    <input name="password" type="password" className="w-full px-8 py-4 bg-slate-50 border-none rounded-[1.5rem] outline-none font-bold shadow-inner" required={modal.type === 'add'} placeholder={modal.type === 'edit' ? "Laissez vide pour conserver" : "••••••••"} />
                                </div>
                            </div>

                            <h4 className="text-[11px] font-black text-indigo-600 uppercase tracking-[4px] border-b pb-4 mt-8">Matrice des Permissions Applicatives</h4>
                            <div className="bg-slate-50 rounded-[2.5rem] overflow-hidden border border-slate-100 shadow-inner">
                                <table className="w-full text-left border-collapse">
                                    <thead className="bg-slate-200/50">
                                        <tr className="text-[9px] font-black uppercase text-slate-500">
                                            <th className="px-6 py-4">Module / Page</th>
                                            <th className="px-4 py-4 text-center">Voir</th>
                                            <th className="px-4 py-4 text-center">Ajouter</th>
                                            <th className="px-4 py-4 text-center">Éditer</th>
                                            <th className="px-4 py-4 text-center">Supprimer</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-slate-200">
                                        {PAGES_LIST.map(p => (
                                            <tr key={p.id} className="hover:bg-white transition-all">
                                                <td className="px-6 py-4 font-bold text-xs text-slate-700">{p.label}</td>
                                                <td className="px-4 py-4 text-center">
                                                    <input type="checkbox" checked={permissions[p.id]?.view} onChange={() => togglePermission(p.id, 'view')} className="w-4 h-4 rounded accent-blue-600 cursor-pointer" />
                                                </td>
                                                <td className="px-4 py-4 text-center">
                                                    <input type="checkbox" checked={permissions[p.id]?.add} onChange={() => togglePermission(p.id, 'add')} className="w-4 h-4 rounded accent-emerald-600 cursor-pointer" />
                                                </td>
                                                <td className="px-4 py-4 text-center">
                                                    <input type="checkbox" checked={permissions[p.id]?.edit} onChange={() => togglePermission(p.id, 'edit')} className="w-4 h-4 rounded accent-amber-600 cursor-pointer" />
                                                </td>
                                                <td className="px-4 py-4 text-center">
                                                    <input type="checkbox" checked={permissions[p.id]?.delete} onChange={() => togglePermission(p.id, 'delete')} className="w-4 h-4 rounded accent-rose-600 cursor-pointer" />
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    <button type="submit" disabled={isSubmitting} className="w-full py-6 bg-slate-900 text-white rounded-[2.5rem] font-black uppercase text-xs tracking-[5px] shadow-2xl active:scale-95 transition-all">
                        {isSubmitting ? 'Syndication du profil en cours...' : 'Enregistrer le Profil Staff'}
                    </button>
                </form>
            </div>
          </div>
        </div>
      )}

      {modal.type === 'delete' && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[160] flex items-center justify-center p-4">
             <div className="bg-white rounded-[4rem] shadow-2xl p-12 text-center max-w-sm w-full animate-in zoom-in-95 border-4 border-white">
                <div className="w-24 h-24 bg-rose-50 text-rose-500 rounded-[2.5rem] flex items-center justify-center text-5xl mx-auto mb-6 shadow-inner animate-bounce"><i className="ti ti-user-minus"></i></div>
                <h3 className="text-2xl font-black text-slate-800 mb-2 tracking-tighter uppercase">Révoquer l'accès ?</h3>
                <p className="text-slate-500 text-sm font-medium leading-relaxed mb-8 italic">Le collaborateur perdra immédiatement tout accès au portail Specta et ses sessions actives seront tuées.</p>
                <div className="flex gap-4">
                    <button onClick={() => setModal({ type: null, item: null })} className="flex-1 py-5 bg-slate-50 text-slate-400 rounded-2xl font-black text-[10px] uppercase tracking-widest active:scale-95 transition-all">Garder</button>
                    <button onClick={handleDelete} disabled={isSubmitting} className="flex-1 py-5 bg-rose-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-rose-200 active:scale-95 transition-all">Confirmer</button>
                </div>
             </div>
        </div>
      )}
    </div>
  );
}