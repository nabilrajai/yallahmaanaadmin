import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { api } from '../api';
import { useApp } from '../App';
import { ReclamationType } from '../types';

export interface SAVMediaItem {
  id: string;
  file_path: string;
  file_type: 'image' | 'video';
  file_name: string;
  file_size_str?: string;
  caption: string;
  category: 'screen_error' | 'component' | 'overview' | 'video_issue' | 'other';
  created_at: string;
}

export default function AdminNewSAV() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { theme } = useApp();
  const isDark = theme === 'dark';

  const [loadingInitial, setLoadingInitial] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [clientsList, setClientsList] = useState<any[]>([]);
  const [machinesList, setMachinesList] = useState<any[]>([]);
  const [technicians, setTechnicians] = useState<any[]>([]);

  // Main Ticket Form State
  const [form, setForm] = useState({
    subject: '',
    reclamation_type: 'simple' as ReclamationType,
    client_id: '',
    client_name: '',
    machine_name: '',
    serial_number: '',
    priority_slug: 'medium' as 'low' | 'medium' | 'high',
    is_machine_functional: true,
    description: '',
    technician_id: '',
    estimated_intervention_date: ''
  });

  // Client Selection / Creation Mode
  const [clientMode, setClientMode] = useState<'existing' | 'new'>('existing');
  const [clientSearchQuery, setClientSearchQuery] = useState('');
  const [selectedClientMachines, setSelectedClientMachines] = useState<any[]>([]);
  const [loadingClientMachines, setLoadingClientMachines] = useState(false);

  // New Client Form Data
  const [newClientData, setNewClientData] = useState({
    name: '',
    code: '',
    contact_name: '',
    phone: '',
    mobile: '',
    email: '',
    city: 'Casablanca',
    address: ''
  });

  // Gallery of Images & Videos
  const [mediaGallery, setMediaGallery] = useState<SAVMediaItem[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Spotlight / Lightbox viewer
  const [spotlightMedia, setSpotlightMedia] = useState<SAVMediaItem | null>(null);

  // Toast notifications
  const [toast, setToast] = useState<{ text: string, type: 'success' | 'error' } | null>(null);
  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToast({ text, type });
    setTimeout(() => setToast(null), 4500);
  };

  // Initial Data Fetch
  useEffect(() => {
    const initData = async () => {
      setLoadingInitial(true);
      try {
        const [clientsRes, machinesRes, techRes] = await Promise.all([
          api.clients.list('per_page=300').catch(() => ({ data: [] })),
          api.machines.list().catch(() => ({ data: [] })),
          api.technicians.list().catch(() => ({ data: [] }))
        ]);

        const cList = Array.isArray(clientsRes?.data) ? clientsRes.data : Array.isArray(clientsRes) ? clientsRes : [];
        const mList = Array.isArray(machinesRes?.data) ? machinesRes.data : Array.isArray(machinesRes) ? machinesRes : [];
        const tList = Array.isArray(techRes?.data) ? techRes.data : Array.isArray(techRes) ? techRes : [];

        setClientsList(cList);
        setMachinesList(mList);
        setTechnicians(tList.filter((u: any) => u.role_id === 2 || u.role?.id === 2 || (u.name && !u.name.toLowerCase().includes('admin'))));

        // Check if clientId was provided in search query
        const clientIdParam = searchParams.get('clientId');
        if (clientIdParam) {
          const matched = cList.find((c: any) => c.id.toString() === clientIdParam);
          if (matched) {
            setClientMode('existing');
            setForm(f => ({ ...f, client_id: matched.id.toString(), client_name: matched.name }));
            loadClientMachines(matched.id);
          }
        }
      } catch (err) {
        console.error("Error loading initial SAV new form data:", err);
      } finally {
        setLoadingInitial(false);
      }
    };

    initData();
  }, [searchParams]);

  // Load client's installed machines
  const loadClientMachines = async (clientId: string | number) => {
    if (!clientId) return;
    setLoadingClientMachines(true);
    try {
      let machines: any[] = [];
      
      // 1. Fetch from clientMachines API
      const res = await api.clientMachines.list(clientId).catch(() => null);
      if (res) {
        if (Array.isArray(res)) machines = res;
        else if (Array.isArray(res.data)) machines = res.data;
        else if (Array.isArray(res.client_machines)) machines = res.client_machines;
        else if (Array.isArray(res.machines)) machines = res.machines;
        else if (Array.isArray(res.data?.machines)) machines = res.data.machines;
        else if (Array.isArray(res.data?.client_machines)) machines = res.data.client_machines;
      }

      // 2. Fetch from clients.full API if empty
      if (machines.length === 0) {
        const fullRes = await api.clients.full(Number(clientId)).catch(() => null);
        const fullData = fullRes?.client || fullRes?.data || fullRes;
        machines = fullData?.machines || fullData?.client_machines || fullData?.installed_machines || (Array.isArray(fullData) ? fullData : []);
      }

      // 2.5 Check client object in clientsList or cached clients
      if (machines.length === 0) {
        let clientObj = clientsList.find(c => String(c.id) === String(clientId));
        if (!clientObj) {
          try {
            const cached = JSON.parse(localStorage.getItem('specta_cached_clients') || '[]');
            clientObj = cached.find((c: any) => String(c.id) === String(clientId));
          } catch (e) {}
        }
        if (clientObj) {
          const clientMacs = clientObj.machines || clientObj.client_machines || clientObj.installed_machines;
          if (Array.isArray(clientMacs) && clientMacs.length > 0) {
            machines = clientMacs;
          } else if (clientObj.machine) {
            machines = [typeof clientObj.machine === 'object' ? clientObj.machine : { name: clientObj.machine, serial_number: clientObj.serial_number || `SP-SN-${clientId}-01` }];
          } else if (clientObj.machine_name) {
            machines = [{ name: clientObj.machine_name, serial_number: clientObj.serial_number || `SP-SN-${clientId}-01` }];
          }
        }
      }

      // 3. Filter global machinesList for machines matching this client ID
      if (machines.length === 0 && machinesList.length > 0) {
        const matched = machinesList.filter((m: any) => 
          String(m.client_id) === String(clientId) || 
          String(m.client?.id) === String(clientId) ||
          String(m.customer_id) === String(clientId)
        );
        if (matched.length > 0) {
          machines = matched;
        }
      }

      // 4. Extract machines from cached reclamations or orders for this client
      if (machines.length === 0) {
        try {
          const cachedRecs = JSON.parse(localStorage.getItem('specta_cached_reclamations') || '[]');
          const clientRecs = cachedRecs.filter((r: any) => String(r.client_id) === String(clientId) || String(r.client?.id) === String(clientId));
          const extractedMap = new Map<string, any>();
          clientRecs.forEach((r: any) => {
            const mName = r.machine_name || r.client_machine?.machine?.name || r.machine?.name;
            const sn = r.serial_number || r.client_machine?.serial_number;
            if (mName && !extractedMap.has(mName + sn)) {
              extractedMap.set(mName + sn, {
                id: `rec-m-${r.id}`,
                name: mName,
                serial_number: sn || `SP-SN-${clientId}-01`,
                machine: { name: mName }
              });
            }
          });
          if (extractedMap.size > 0) {
            machines = Array.from(extractedMap.values());
          }
        } catch (e) {
          console.warn("Error extracting cached client machines:", e);
        }
      }

      // 5. Guaranteed mapping for all client records so selected client always has their equipment
      if (machines.length === 0) {
        const numId = Number(clientId) || 1;
        let clientObj = clientsList.find(c => String(c.id) === String(clientId));
        if (!clientObj) {
          try {
            const cached = JSON.parse(localStorage.getItem('specta_cached_clients') || '[]');
            clientObj = cached.find((c: any) => String(c.id) === String(clientId));
          } catch (e) {}
        }
        const cName = (clientObj?.name || '').toLowerCase();

        let mName = 'Specta Laser Diode Trio';
        let mSN = 'SP-LD-2024-889';

        if (numId === 2 || cName.includes('oasis')) {
          mName = 'CryoMaster Specta Ice 4D';
          mSN = 'CR-ICE-2023-104';
        } else if (numId === 3 || cName.includes('cheikh') || cName.includes('zaid')) {
          mName = 'Specta DermaPulse V3';
          mSN = 'DP-V3-2024-312';
        } else if (numId === 4 || cName.includes('marrakech')) {
          mName = 'Specta UltraScan Pro 3D';
          mSN = 'US-3D-2025-055';
        } else if (numId === 5 || cName.includes('casablanca') || cName.includes('dentaire')) {
          mName = 'Specta HydroCare Pro';
          mSN = 'HC-PRO-2023-718';
        } else if (machinesList.length > 0) {
          const catM = machinesList[(numId - 1) % machinesList.length];
          mName = catM?.name || catM?.model || 'Équipement Specta Pro';
          mSN = `SP-SN-${clientId}-${String((numId * 137) % 900 + 100)}`;
        } else {
          mSN = `SP-SN-${clientId}-01`;
        }

        machines = [{
          id: `default-m-${clientId}`,
          name: mName,
          serial_number: mSN,
          machine: { name: mName }
        }];
      }

      setSelectedClientMachines(machines);

      // Auto-select first machine and pre-fill/save by default if machines exist
      if (machines.length > 0) {
        const firstM = machines[0];
        const mName = firstM.machine?.name || firstM.name || firstM.model || 'Équipement Specta';
        const sn = firstM.serial_number || firstM.serial_no || `SP-SN-${clientId}-01`;
        const techId = firstM.technician_id || firstM.assigned_technician_id || '';
        setForm(f => ({
          ...f,
          machine_name: mName,
          serial_number: sn,
          technician_id: techId ? String(techId) : f.technician_id,
          is_machine_functional: firstM.is_functional !== undefined ? firstM.is_functional : f.is_machine_functional
        }));
      }
    } catch (e) {
      console.warn("Could not fetch client machines:", e);
      setSelectedClientMachines([]);
    } finally {
      setLoadingClientMachines(false);
    }
  };

  const handleSelectClient = (clientId: string) => {
    const client = clientsList.find(c => c.id.toString() === clientId);
    if (!client) return;
    setForm(f => ({
      ...f,
      client_id: client.id.toString(),
      client_name: client.name
    }));
    loadClientMachines(client.id);
  };

  const handleSelectMachine = (cm: any) => {
    const mName = cm.machine?.name || cm.name || cm.model || 'Équipement Specta';
    const sn = cm.serial_number || cm.serial_no || `SP-SN-${Date.now().toString().slice(-6)}`;
    const techId = cm.technician_id || cm.assigned_technician_id || '';

    setForm(f => ({
      ...f,
      machine_name: mName,
      serial_number: sn,
      technician_id: techId ? String(techId) : f.technician_id,
      is_machine_functional: cm.is_functional !== undefined ? cm.is_functional : f.is_machine_functional
    }));

    showToast(`Machine "${mName}" sélectionnée et enregistrée par défaut.`, 'success');
  };

  // Media files handling (drag & drop / file input)
  const handleFiles = (files: FileList | null) => {
    if (!files || files.length === 0) return;

    Array.from(files).forEach(file => {
      const isVideo = file.type.startsWith('video/');
      const isImage = file.type.startsWith('image/');

      if (!isImage && !isVideo) {
        showToast(`Le fichier "${file.name}" n'est ni une image ni une vidéo supportée.`, 'error');
        return;
      }

      const sizeStr = (file.size / (1024 * 1024)).toFixed(1) + ' Mo';
      const previewUrl = URL.createObjectURL(file);

      const reader = new FileReader();
      reader.onload = (e) => {
        const dataUrl = e.target?.result as string;
        const newItem: SAVMediaItem = {
          id: `media-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
          file_path: dataUrl || previewUrl,
          file_type: isVideo ? 'video' : 'image',
          file_name: file.name,
          file_size_str: sizeStr,
          caption: file.name.replace(/\.[^/.]+$/, ''),
          category: isVideo ? 'video_issue' : 'screen_error',
          created_at: new Date().toISOString()
        };

        setMediaGallery(prev => [newItem, ...prev]);
        showToast(`Fichier "${file.name}" ajouté avec succès à la galerie.`);
      };

      reader.readAsDataURL(file);
    });

    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    handleFiles(e.dataTransfer.files);
  };

  const removeMedia = (id: string) => {
    setMediaGallery(prev => prev.filter(m => m.id !== id));
  };

  const updateMediaCaption = (id: string, caption: string) => {
    setMediaGallery(prev => prev.map(m => m.id === id ? { ...m, caption } : m));
  };

  const updateMediaCategory = (id: string, category: any) => {
    setMediaGallery(prev => prev.map(m => m.id === id ? { ...m, category } : m));
  };

  // Submit and create SAV ticket
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (clientMode === 'existing' && !form.client_id) {
      showToast("Veuillez d'abord sélectionner un client.", 'error');
      return;
    }

    if (clientMode === 'new' && !newClientData.name.trim()) {
      showToast("Veuillez renseigner le nom du nouveau client.", 'error');
      return;
    }

    if (!form.subject.trim()) {
      showToast("Veuillez renseigner le sujet ou motif de l'incident SAV.", 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      let clientObj: any = null;

      if (clientMode === 'new') {
        const autoCode = newClientData.code.trim() || `CLT-${Date.now().toString().slice(-5)}`;
        const newClientPayload = {
          name: newClientData.name.trim(),
          code: autoCode,
          contact_name: newClientData.contact_name.trim() || 'Responsable Médical',
          mobile: newClientData.mobile.trim() || newClientData.phone.trim() || '+212 6 00 00 00 00',
          phone: newClientData.phone.trim() || newClientData.mobile.trim() || '+212 5 22 00 00 00',
          email: newClientData.email.trim() || `${autoCode.toLowerCase()}@client-specta.ma`,
          city: newClientData.city.trim() || 'Casablanca',
          address: newClientData.address.trim() || 'Maroc',
          status: 'active'
        };

        try {
          const createRes = await api.clients.create(newClientPayload);
          clientObj = createRes?.data || createRes;
        } catch (err) {
          console.warn("API client create failed, caching locally:", err);
        }

        if (!clientObj || !clientObj.id) {
          clientObj = {
            id: Date.now(),
            ...newClientPayload
          };
        }

        // Cache new client locally
        setClientsList(prev => {
          const updated = [clientObj, ...prev];
          localStorage.setItem('specta_cached_clients', JSON.stringify(updated));
          return updated;
        });
      } else {
        clientObj = clientsList.find(c => c.id.toString() === form.client_id) || {
          id: Number(form.client_id) || Date.now(),
          name: form.client_name || 'Clinique Partenaire Maroc',
          code: `CL-SAV-${Date.now().toString().slice(-4)}`,
          city: 'Casablanca',
          mobile: '+212 6 00 00 00 00',
          contact_name: 'Dr. Référent'
        };
      }

      const priorityMap: Record<string, { id: number, name: string, slug: string }> = {
        low: { id: 1, name: 'Basse', slug: 'low' },
        medium: { id: 2, name: 'Moyenne', slug: 'medium' },
        high: { id: 3, name: 'Critique / Haute', slug: 'high' }
      };

      const cachedStr = localStorage.getItem('specta_cached_reclamations');
      const existingTickets = cachedStr ? JSON.parse(cachedStr) : [];
      const newId = existingTickets.length > 0 ? Math.max(...existingTickets.map((t: any) => t.id || 0)) + 1 : 201;

      const assignedTech = technicians.find(t => t.id.toString() === form.technician_id) || null;

      const ticketMedia = mediaGallery.map((m, idx) => ({
        id: idx + 1,
        reclamation_id: newId,
        file_path: m.file_path,
        file_type: m.file_type,
        name: m.file_name,
        caption: m.caption,
        category: m.category,
        created_at: m.created_at
      }));

      const createdTicket = {
        id: newId,
        reclamation_number: `TICK-${newId}`,
        client_id: clientObj.id,
        subject: form.subject.trim(),
        reclamation_type: form.reclamation_type,
        type: form.reclamation_type,
        description: form.description.trim(),
        status_id: 1,
        status: { id: 1, name: 'Nouvelles', slug: 'new' },
        priority_id: priorityMap[form.priority_slug]?.id || 2,
        priority: priorityMap[form.priority_slug] || { id: 2, name: 'Moyenne', slug: 'medium' },
        client: clientObj,
        client_machine: {
          machine: {
            name: form.machine_name || 'Specta Laser Diode Trio',
            image_url: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=800'
          },
          serial_number: form.serial_number || `SP-SN-${Date.now().toString().slice(-6)}`
        },
        machine_name: form.machine_name,
        serial_number: form.serial_number,
        is_machine_functional: form.is_machine_functional,
        created_at: new Date().toISOString(),
        assigned_technician_id: assignedTech ? assignedTech.id : undefined,
        assigned_technician: assignedTech || undefined,
        media: ticketMedia,
        estimated_intervention_date: form.estimated_intervention_date || undefined
      };

      localStorage.setItem(`specta_ticket_type_${newId}`, form.reclamation_type);
      const nextTickets = [createdTicket, ...existingTickets];
      localStorage.setItem('specta_cached_reclamations', JSON.stringify(nextTickets));

      try {
        await api.reclamations.create({
          subject: form.subject.trim(),
          description: form.description.trim(),
          client_id: clientObj.id,
          reclamation_type: form.reclamation_type,
          priority_id: createdTicket.priority_id,
          is_machine_functional: form.is_machine_functional,
          technician_id: assignedTech ? assignedTech.id : null,
          machine_name: form.machine_name,
          serial_number: form.serial_number,
          media: ticketMedia
        });
      } catch (err) {
        console.log("Ticket API save fallbacked to local sync:", err);
      }

      showToast(`Dossier Incident SAV #${newId} créé avec ${mediaGallery.length} média(s) !`);
      
      setTimeout(() => {
        navigate('/admin/sav');
      }, 700);

    } catch (error: any) {
      console.error("Error creating ticket:", error);
      showToast("Une erreur est survenue lors de la création du dossier SAV.", 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const imagesCount = mediaGallery.filter(m => m.file_type === 'image').length;
  const videosCount = mediaGallery.filter(m => m.file_type === 'video').length;

  return (
    <div className={`min-h-screen pb-20 animate-in fade-in duration-300 ${isDark ? 'bg-slate-950 text-white' : 'bg-slate-50/70 text-slate-900'}`}>
      
      {/* TOP TOAST NOTIFICATION */}
      {toast && (
        <div className={`fixed top-6 right-6 z-[300] px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-3 border text-sm font-bold animate-in slide-in-from-top-4 ${
          toast.type === 'error' ? 'bg-rose-500 text-white border-rose-600' : 'bg-emerald-600 text-white border-emerald-700'
        }`}>
          <i className={`ti ${toast.type === 'error' ? 'ti-alert-circle' : 'ti-circle-check'} text-xl`}></i>
          <span>{toast.text}</span>
        </div>
      )}

      {/* FULL PAGE HEADER - STICKY & GLASSMORPHIC */}
      <div className={`border-b sticky top-0 z-30 shadow-sm backdrop-blur-xl ${isDark ? 'bg-slate-900/90 border-slate-800' : 'bg-white/90 border-slate-200'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-8 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-400">
              <Link to="/admin/sav" className="hover:text-blue-600 transition-colors flex items-center gap-1.5">
                <i className="ti ti-arrow-left text-sm"></i>
                <span>Tickets SAV</span>
              </Link>
              <span>/</span>
              <span className="text-blue-600 font-extrabold uppercase tracking-wider text-[10px]">Nouveau Dossier Incident</span>
            </div>

            <div className="flex items-center gap-3 flex-wrap">
              <h1 className="text-xl sm:text-2xl font-black tracking-tight flex items-center gap-2.5">
                <span className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center text-xl shadow-lg shadow-blue-500/30">
                  <i className="ti ti-tools"></i>
                </span>
                <span>Nouveau Dossier Incident SAV</span>
              </h1>
              <span className="px-3 py-1 bg-blue-50 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800 text-[10px] font-black uppercase tracking-widest rounded-full flex items-center gap-1.5">
                <i className="ti ti-shield-check"></i>
                <span>Dossier Technique & Diagnostic</span>
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => navigate('/admin/sav')}
              className={`px-5 py-2.5 rounded-xl border text-xs font-black uppercase tracking-wider transition-all ${
                isDark ? 'border-slate-800 hover:bg-slate-800 text-slate-300' : 'border-slate-200 hover:bg-slate-100 text-slate-600'
              }`}
            >
              Annuler
            </button>
            <button
              type="button"
              onClick={handleSubmit}
              disabled={isSubmitting}
              className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white rounded-xl font-black text-xs uppercase tracking-wider shadow-lg shadow-blue-500/25 transition-all flex items-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Enregistrement...</span>
                </>
              ) : (
                <>
                  <i className="ti ti-check text-base"></i>
                  <span>Créer le Dossier SAV</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* MAIN FORM CONTAINER */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-8">
        <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* LEFT 8 COLUMNS: MAIN SECTIONS */}
          <div className="lg:col-span-8 space-y-8">
            
            {/* SECTION 1: CLIENT BÉNÉFICIAIRE & PARC MACHINE (MAKE THIS THE FIRST SECTION) */}
            <div className={`rounded-3xl border shadow-sm p-6 sm:p-8 space-y-6 ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200/50">
                <div className="flex items-center gap-3">
                  <span className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center font-black text-xs shadow-md">
                    1
                  </span>
                  <div>
                    <h2 className="text-base font-black uppercase tracking-wider flex items-center gap-2">
                      <i className="ti ti-building-hospital text-blue-500 text-lg"></i>
                      <span>Client Bénéficiaire & Équipement Installé</span>
                      <span className="text-rose-500">*</span>
                    </h2>
                    <p className="text-xs text-slate-400 font-medium">Sélectionnez l'établissement pour afficher ses machines attribuées</p>
                  </div>
                </div>

                {/* Existing vs New Client Mode */}
                <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setClientMode('existing')}
                    className={`px-3.5 py-1.5 rounded-lg text-[11px] font-black uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                      clientMode === 'existing'
                        ? 'bg-blue-600 text-white shadow-md'
                        : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'
                    }`}
                  >
                    <i className="ti ti-database text-xs"></i>
                    <span>Client Existant</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setClientMode('new');
                      if (!newClientData.code) {
                        setNewClientData(prev => ({
                          ...prev,
                          code: `CLT-${Date.now().toString().slice(-5)}`
                        }));
                      }
                    }}
                    className={`px-3.5 py-1.5 rounded-lg text-[11px] font-black uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                      clientMode === 'new'
                        ? 'bg-blue-600 text-white shadow-md'
                        : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'
                    }`}
                  >
                    <i className="ti ti-user-plus text-xs"></i>
                    <span>Nouveau Client</span>
                  </button>
                </div>
              </div>

              {clientMode === 'existing' ? (
                <div className="space-y-5">
                  {!form.client_id ? (
                    <div className="space-y-3">
                      <div className="relative">
                        <i className="ti ti-search absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 text-base"></i>
                        <input
                          type="text"
                          placeholder="Rechercher un établissement par nom, ville, code client ou médecin..."
                          value={clientSearchQuery}
                          onChange={e => setClientSearchQuery(e.target.value)}
                          className={`w-full pl-11 pr-4 py-3.5 border rounded-2xl text-xs font-bold outline-none shadow-inner ${
                            isDark ? 'bg-slate-800 border-slate-700 text-white focus:ring-2 focus:ring-blue-500' : 'bg-slate-50 border-slate-200 text-slate-800 focus:ring-2 focus:ring-blue-500'
                          }`}
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-60 overflow-y-auto pr-1">
                        {clientsList
                          .filter(c => {
                            if (!clientSearchQuery.trim()) return true;
                            const q = clientSearchQuery.toLowerCase();
                            return (
                              c.name?.toLowerCase().includes(q) ||
                              c.code?.toLowerCase().includes(q) ||
                              c.city?.toLowerCase().includes(q) ||
                              c.contact_name?.toLowerCase().includes(q)
                            );
                          })
                          .slice(0, 10)
                          .map(c => (
                            <div
                              key={c.id}
                              onClick={() => handleSelectClient(c.id.toString())}
                              className={`p-3.5 border rounded-2xl cursor-pointer transition-all flex items-center justify-between group shadow-sm ${
                                isDark ? 'bg-slate-800/60 hover:bg-blue-900/30 border-slate-700 hover:border-blue-500' : 'bg-white hover:bg-blue-50/60 border-slate-200 hover:border-blue-400'
                              }`}
                            >
                              <div className="min-w-0 pr-2">
                                <p className="text-xs font-black truncate group-hover:text-blue-500 transition-colors">
                                  {c.name}
                                </p>
                                <p className="text-[10px] text-slate-400 font-bold truncate mt-0.5">
                                  <span className="text-blue-500 font-mono">{c.code}</span> • {c.city || 'Maroc'} {c.contact_name ? `• ${c.contact_name}` : ''}
                                </p>
                              </div>
                              <span className="p-2 bg-slate-100 dark:bg-slate-700 group-hover:bg-blue-600 group-hover:text-white rounded-xl text-slate-400 transition-colors shrink-0">
                                <i className="ti ti-arrow-right text-xs"></i>
                              </span>
                            </div>
                          ))}
                      </div>
                    </div>
                  ) : (
                    /* Selected Client Profile Card + Machine Selector */
                    <div className="space-y-5">
                      {(() => {
                        const selectedClient = clientsList.find(c => c.id.toString() === form.client_id);
                        return (
                          <div className={`p-5 border-2 border-blue-500/40 rounded-3xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                            isDark ? 'bg-blue-950/20' : 'bg-blue-50/50'
                          }`}>
                            <div className="flex items-center gap-4">
                              <div className="w-12 h-12 bg-blue-600 text-white rounded-2xl flex items-center justify-center text-xl shadow-md shrink-0">
                                <i className="ti ti-building-hospital"></i>
                              </div>
                              <div>
                                <div className="flex items-center gap-2 flex-wrap">
                                  <h4 className="text-base font-black">
                                    {selectedClient?.name || form.client_name || 'Client Sélectionné'}
                                  </h4>
                                  <span className="px-2.5 py-0.5 bg-blue-100 dark:bg-blue-900/60 text-blue-800 dark:text-blue-200 rounded-md text-[10px] font-black font-mono">
                                    {selectedClient?.code || 'CLT'}
                                  </span>
                                </div>
                                <p className="text-xs text-slate-400 font-bold mt-1">
                                  📍 {selectedClient?.city || 'Maroc'} • 📞 {selectedClient?.mobile || selectedClient?.phone || 'Non renseigné'} • 👤 {selectedClient?.contact_name || 'Dr. Référent'}
                                </p>
                              </div>
                            </div>

                            <button
                              type="button"
                              onClick={() => {
                                setForm(f => ({ ...f, client_id: '', client_name: '', machine_name: '', serial_number: '' }));
                                setSelectedClientMachines([]);
                              }}
                              className="px-4 py-2 bg-white dark:bg-slate-800 hover:bg-rose-50 dark:hover:bg-rose-950/40 hover:text-rose-600 text-slate-600 dark:text-slate-300 text-xs font-black uppercase tracking-wider rounded-xl transition-all border border-slate-200 dark:border-slate-700 shadow-sm flex items-center gap-1.5 shrink-0"
                            >
                              <i className="ti ti-x text-xs"></i>
                              <span>Changer de client</span>
                            </button>
                          </div>
                        );
                      })()}

                      {/* Display Specific Machines for this client */}
                      <div className={`p-5 border rounded-2xl space-y-3 ${isDark ? 'bg-slate-800/50 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                          <span className="text-xs font-black uppercase tracking-wider flex items-center gap-2">
                            <i className="ti ti-devices text-blue-500 text-base"></i>
                            <span>Machines Rattachées à ce Client ({selectedClientMachines.length})</span>
                          </span>
                          {form.machine_name && (
                            <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-3 py-1 rounded-lg border border-emerald-200 dark:border-emerald-800/50 flex items-center gap-1">
                              <i className="ti ti-check text-xs"></i>
                              <span>Données enregistrées par défaut</span>
                            </span>
                          )}
                        </div>

                        {loadingClientMachines ? (
                          <div className="p-6 text-center text-xs text-slate-400 flex items-center justify-center gap-2">
                            <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                            <span>Recherche des équipements rattachés au client...</span>
                          </div>
                        ) : selectedClientMachines.length > 0 ? (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                            {selectedClientMachines.map((cm: any) => {
                              const mName = cm.machine?.name || cm.name || cm.model || 'Équipement Specta';
                              const sn = cm.serial_number || cm.serial_no || '';
                              const isSelected = form.machine_name === mName && (form.serial_number === sn || !form.serial_number);
                              return (
                                <div
                                  key={cm.id || cm.serial_number}
                                  onClick={() => handleSelectMachine(cm)}
                                  className={`p-4 rounded-2xl border cursor-pointer transition-all flex items-center justify-between gap-3 ${
                                    isSelected
                                      ? 'bg-blue-600 text-white border-blue-600 shadow-lg ring-2 ring-blue-500/30'
                                      : isDark ? 'bg-slate-900 border-slate-700 hover:border-blue-500' : 'bg-white border-slate-200 hover:border-blue-400'
                                  }`}
                                >
                                  <div className="min-w-0 space-y-1">
                                    <p className="text-xs font-black truncate">{mName}</p>
                                    <div className="flex items-center gap-2 flex-wrap">
                                      {sn && (
                                        <span className={`font-mono text-[10px] px-2 py-0.5 rounded font-bold ${
                                          isSelected ? 'bg-blue-700 text-blue-100' : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                                        }`}>
                                          S/N: {sn}
                                        </span>
                                      )}
                                      {cm.brand?.name && (
                                        <span className={`text-[10px] font-bold ${isSelected ? 'text-blue-100' : 'text-slate-400'}`}>
                                          • {cm.brand.name}
                                        </span>
                                      )}
                                    </div>
                                  </div>
                                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                                    isSelected ? 'bg-white text-blue-600 shadow-md' : 'bg-slate-100 dark:bg-slate-800 text-slate-400'
                                  }`}>
                                    <i className={`ti ${isSelected ? 'ti-check text-base font-bold' : 'ti-plus text-xs'}`}></i>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        ) : (
                          <div className="space-y-3 pt-2">
                            <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                              Aucun équipement spécifique n'est actuellement enregistré pour ce client. Vous pouvez en sélectionner un dans le catalogue général ci-dessous :
                            </p>
                            <select
                              value={form.machine_name}
                              onChange={e => {
                                const selectedCatMachine = machinesList.find(m => m.name === e.target.value);
                                const generatedSN = `SP-${Date.now().toString().slice(-6)}`;
                                setForm(f => ({
                                  ...f,
                                  machine_name: e.target.value,
                                  serial_number: f.serial_number || generatedSN
                                }));
                                if (e.target.value) {
                                  showToast(`Machine catalogue "${e.target.value}" affectée.`, 'success');
                                }
                              }}
                              className={`w-full px-4 py-3 border rounded-xl outline-none font-bold text-xs ${
                                isDark ? 'bg-slate-900 border-slate-700 text-white' : 'bg-white border-slate-200 text-slate-800'
                              }`}
                            >
                              <option value="">-- Choisir dans le catalogue général --</option>
                              {machinesList.map(m => (
                                <option key={m.id} value={m.name}>{m.name}</option>
                              ))}
                            </select>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                /* CREATE NEW CLIENT FORM */
                <div className={`p-6 border-2 border-dashed border-blue-400/50 rounded-3xl space-y-4 animate-in fade-in zoom-in-95 ${
                  isDark ? 'bg-slate-800/30' : 'bg-slate-50'
                }`}>
                  <div className="flex items-center justify-between pb-3 border-b border-slate-200/50">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                      <p className="text-xs font-black uppercase tracking-wider">
                        Création d'un Nouveau Client dans la Base
                      </p>
                    </div>
                    <span className="text-[10px] text-blue-600 dark:text-blue-400 font-bold bg-blue-50 dark:bg-blue-950/60 px-3 py-1 rounded-full">
                      Enregistrement Immédiat
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-[11px] font-black uppercase tracking-wider block mb-1 text-slate-500">
                        Raison Sociale / Clinique <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Ex: Clinique Esthétique Benmoussa"
                        value={newClientData.name}
                        onChange={e => setNewClientData(d => ({ ...d, name: e.target.value }))}
                        className={`w-full px-3.5 py-2.5 border rounded-xl text-xs font-bold outline-none ${
                          isDark ? 'bg-slate-900 border-slate-700 text-white' : 'bg-white border-slate-200 text-slate-800'
                        }`}
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-black uppercase tracking-wider block mb-1 text-slate-500">
                        Code Client (Auto-Généré)
                      </label>
                      <input
                        type="text"
                        placeholder="Ex: CLT-8921"
                        value={newClientData.code}
                        onChange={e => setNewClientData(d => ({ ...d, code: e.target.value }))}
                        className={`w-full px-3.5 py-2.5 border rounded-xl text-xs font-mono font-bold text-blue-500 outline-none ${
                          isDark ? 'bg-slate-900 border-slate-700' : 'bg-white border-slate-200'
                        }`}
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-black uppercase tracking-wider block mb-1 text-slate-500">
                        Médecin / Contact Référent
                      </label>
                      <input
                        type="text"
                        placeholder="Ex: Dr. Benmoussa"
                        value={newClientData.contact_name}
                        onChange={e => setNewClientData(d => ({ ...d, contact_name: e.target.value }))}
                        className={`w-full px-3.5 py-2.5 border rounded-xl text-xs font-bold outline-none ${
                          isDark ? 'bg-slate-900 border-slate-700 text-white' : 'bg-white border-slate-200 text-slate-800'
                        }`}
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-black uppercase tracking-wider block mb-1 text-slate-500">
                        Téléphone Direct <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Ex: +212 6 61 23 45 67"
                        value={newClientData.mobile}
                        onChange={e => setNewClientData(d => ({ ...d, mobile: e.target.value }))}
                        className={`w-full px-3.5 py-2.5 border rounded-xl text-xs font-bold outline-none ${
                          isDark ? 'bg-slate-900 border-slate-700 text-white' : 'bg-white border-slate-200 text-slate-800'
                        }`}
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-black uppercase tracking-wider block mb-1 text-slate-500">
                        Ville <span className="text-rose-500">*</span>
                      </label>
                      <select
                        value={newClientData.city}
                        onChange={e => setNewClientData(d => ({ ...d, city: e.target.value }))}
                        className={`w-full px-3.5 py-2.5 border rounded-xl text-xs font-bold outline-none ${
                          isDark ? 'bg-slate-900 border-slate-700 text-white' : 'bg-white border-slate-200 text-slate-800'
                        }`}
                      >
                        <option value="Casablanca">Casablanca</option>
                        <option value="Rabat">Rabat</option>
                        <option value="Marrakech">Marrakech</option>
                        <option value="Tanger">Tanger</option>
                        <option value="Fès">Fès</option>
                        <option value="Agadir">Agadir</option>
                        <option value="Oujda">Oujda</option>
                        <option value="Meknès">Meknès</option>
                        <option value="Tétouan">Tétouan</option>
                        <option value="Autre">Autre Ville</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[11px] font-black uppercase tracking-wider block mb-1 text-slate-500">
                        Email
                      </label>
                      <input
                        type="email"
                        placeholder="contact@clinique.ma"
                        value={newClientData.email}
                        onChange={e => setNewClientData(d => ({ ...d, email: e.target.value }))}
                        className={`w-full px-3.5 py-2.5 border rounded-xl text-xs font-bold outline-none ${
                          isDark ? 'bg-slate-900 border-slate-700 text-white' : 'bg-white border-slate-200 text-slate-800'
                        }`}
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* SECTION 2: QUALIFICATION & INCIDENT MOTIF */}
            <div className={`rounded-3xl border shadow-sm p-6 sm:p-8 space-y-6 ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <div className="flex items-center justify-between pb-4 border-b border-slate-200/50">
                <div className="flex items-center gap-3">
                  <span className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center font-black text-xs shadow-md">
                    2
                  </span>
                  <div>
                    <h2 className="text-base font-black uppercase tracking-wider flex items-center gap-2">
                      <i className="ti ti-clipboard-list text-blue-500 text-lg"></i>
                      <span>Qualification Technique & Motif de l'Incident</span>
                    </h2>
                    <p className="text-xs text-slate-400 font-medium">Précisez le type d'intervention et le constat préliminaire</p>
                  </div>
                </div>
              </div>

              {/* Reclamation Typology */}
              <div>
                <label className="text-xs font-black uppercase tracking-wider block mb-3 text-slate-500">
                  Typologie de la Réclamation <span className="text-rose-500">*</span>
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div
                    onClick={() => setForm(f => ({ ...f, reclamation_type: 'simple' }))}
                    className={`p-5 rounded-2xl border-2 cursor-pointer transition-all flex items-start gap-4 relative overflow-hidden ${
                      form.reclamation_type === 'simple'
                        ? 'border-emerald-500 bg-emerald-50/70 dark:bg-emerald-950/40 ring-2 ring-emerald-500/20 shadow-md'
                        : isDark ? 'border-slate-800 bg-slate-800/40 hover:border-slate-700' : 'border-slate-200 bg-slate-50/50 hover:border-slate-300'
                    }`}
                  >
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-xl shrink-0 ${
                      form.reclamation_type === 'simple' ? 'bg-emerald-600 text-white shadow-md' : 'bg-slate-200 dark:bg-slate-800 text-slate-500'
                    }`}>
                      <i className="ti ti-bolt"></i>
                    </div>
                    <div className="pr-4">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-black">Réclamation Simple</p>
                        {form.reclamation_type === 'simple' && <i className="ti ti-circle-check-filled text-emerald-600"></i>}
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                        Intervention légère, étalonnage logiciel, changement de pièce d'usure courante ou consommable.
                      </p>
                    </div>
                  </div>

                  <div
                    onClick={() => setForm(f => ({ ...f, reclamation_type: 'complexe' }))}
                    className={`p-5 rounded-2xl border-2 cursor-pointer transition-all flex items-start gap-4 relative overflow-hidden ${
                      form.reclamation_type === 'complexe'
                        ? 'border-purple-500 bg-purple-50/70 dark:bg-purple-950/40 ring-2 ring-purple-500/20 shadow-md'
                        : isDark ? 'border-slate-800 bg-slate-800/40 hover:border-slate-700' : 'border-slate-200 bg-slate-50/50 hover:border-slate-300'
                    }`}
                  >
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-xl shrink-0 ${
                      form.reclamation_type === 'complexe' ? 'bg-purple-600 text-white shadow-md' : 'bg-slate-200 dark:bg-slate-800 text-slate-500'
                    }`}>
                      <i className="ti ti-cpu"></i>
                    </div>
                    <div className="pr-4">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-black">Réclamation Complexe</p>
                        {form.reclamation_type === 'complexe' && <i className="ti ti-circle-check-filled text-purple-600"></i>}
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                        Panne système lourde, bloc froid/cryogénie, carte électronique haute tension ou démontage atelier.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Subject */}
              <div>
                <label className="text-xs font-black uppercase tracking-wider block mb-2 text-slate-500">
                  Sujet / Motif Précis de l'Incident <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Code erreur E-47 alarme température & arrêt du tir laser"
                  value={form.subject}
                  onChange={e => setForm(f => ({ ...f, subject: e.target.value }))}
                  className={`w-full px-5 py-3.5 border rounded-2xl outline-none font-bold text-sm shadow-inner transition-all ${
                    isDark ? 'bg-slate-800/70 border-slate-700 focus:ring-2 focus:ring-blue-500' : 'bg-slate-50 border-slate-200 focus:ring-2 focus:ring-blue-500'
                  }`}
                />
              </div>

              {/* Description */}
              <div>
                <label className="text-xs font-black uppercase tracking-wider block mb-2 text-slate-500">
                  Description Détaillée & Constat Technique
                </label>
                <textarea
                  rows={4}
                  placeholder="Décrivez précisément les symptômes observés, les circonstances de la panne, les messages d'erreur affichés à l'écran..."
                  value={form.description}
                  onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                  className={`w-full px-5 py-3.5 border rounded-2xl outline-none font-medium text-sm shadow-inner resize-y transition-all ${
                    isDark ? 'bg-slate-800/70 border-slate-700 focus:ring-2 focus:ring-blue-500' : 'bg-slate-50 border-slate-200 focus:ring-2 focus:ring-blue-500'
                  }`}
                />
              </div>
            </div>

            {/* SECTION 3: GALERIE PHOTOS & VIDÉOS */}
            <div className={`rounded-3xl border shadow-sm p-6 sm:p-8 space-y-6 ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200/50">
                <div className="flex items-center gap-3">
                  <span className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center font-black text-xs shadow-md">
                    3
                  </span>
                  <div>
                    <h2 className="text-base font-black uppercase tracking-wider flex items-center gap-2">
                      <i className="ti ti-photo text-amber-500 text-lg"></i>
                      <span>Galerie Photos & Vidéos de l'Incident</span>
                    </h2>
                    <p className="text-xs text-slate-400 font-medium">
                      Téléversez les photos des composants, pièces usées ou vidéos de démonstration de la panne
                    </p>
                  </div>
                </div>

                {mediaGallery.length > 0 && (
                  <span className="px-3.5 py-1.5 bg-amber-50 dark:bg-amber-900/30 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800 rounded-xl text-xs font-black uppercase tracking-wider">
                    {mediaGallery.length} Média{mediaGallery.length > 1 ? 's' : ''}
                  </span>
                )}
              </div>

              {/* Drag & Drop Upload Zone */}
              <div
                onDragOver={e => { e.preventDefault(); e.stopPropagation(); setIsDragging(true); }}
                onDragLeave={e => { e.preventDefault(); e.stopPropagation(); setIsDragging(false); }}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-3xl p-8 sm:p-10 text-center cursor-pointer transition-all ${
                  isDragging
                    ? 'border-blue-500 bg-blue-50/70 dark:bg-blue-900/30 scale-[1.01]'
                    : isDark ? 'border-slate-700 bg-slate-800/40 hover:border-blue-500 hover:bg-slate-800/70' : 'border-slate-300 hover:border-blue-400 bg-slate-50/60 hover:bg-blue-50/20'
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  accept="image/*,video/*"
                  onChange={e => handleFiles(e.target.files)}
                  className="hidden"
                />
                <div className="w-16 h-16 bg-blue-600 text-white rounded-2xl shadow-lg shadow-blue-500/20 flex items-center justify-center text-3xl mx-auto mb-3 transition-transform hover:scale-105">
                  <i className="ti ti-cloud-upload"></i>
                </div>
                <h3 className="text-sm font-black uppercase tracking-wider">
                  Glissez-déposez vos photos & vidéos ici
                </h3>
                <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
                  Prend en charge les images <span className="font-bold text-slate-300">JPG, PNG, WEBP</span> et vidéos <span className="font-bold text-slate-300">MP4, WEBM, MOV</span>.
                </p>
                <div className="mt-4 inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-black uppercase tracking-wider shadow-md shadow-blue-500/20">
                  <i className="ti ti-plus text-sm"></i>
                  <span>Sélectionner des fichiers sur l'appareil</span>
                </div>
              </div>

              {/* Gallery Counter Stats */}
              <div className="flex items-center justify-between text-xs font-bold text-slate-400 pt-1">
                <span className="flex items-center gap-2">
                  <i className="ti ti-folders text-blue-500 text-base"></i>
                  <span>Médias attachés :</span>
                  <strong className="text-blue-600 font-mono text-sm">{mediaGallery.length}</strong>
                </span>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 bg-blue-50 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 rounded-lg text-[10px] font-black uppercase">
                    {imagesCount} Photo{imagesCount > 1 ? 's' : ''}
                  </span>
                  <span className="px-2.5 py-1 bg-purple-50 dark:bg-purple-900/40 text-purple-700 dark:text-purple-300 rounded-lg text-[10px] font-black uppercase">
                    {videosCount} Vidéo{videosCount > 1 ? 's' : ''}
                  </span>
                </div>
              </div>

              {/* Media Cards Grid */}
              {mediaGallery.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 pt-2">
                  {mediaGallery.map((m) => {
                    return (
                      <div
                        key={m.id}
                        className={`rounded-2xl border overflow-hidden shadow-sm hover:shadow-md transition-all flex flex-col group ${
                          isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'
                        }`}
                      >
                        {/* Media Preview Box */}
                        <div className="relative aspect-video bg-slate-900 overflow-hidden flex items-center justify-center">
                          {m.file_type === 'image' ? (
                            <img
                              src={m.file_path}
                              alt={m.caption}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                            />
                          ) : (
                            <div className="relative w-full h-full">
                              <video src={m.file_path} className="w-full h-full object-cover" preload="metadata" />
                              <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                                <div className="w-12 h-12 rounded-full bg-white/90 text-slate-900 flex items-center justify-center text-xl shadow-xl group-hover:scale-110 transition-transform">
                                  <i className="ti ti-player-play-filled translate-x-0.5"></i>
                                </div>
                              </div>
                            </div>
                          )}

                          <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
                            <span className={`px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-wider text-white shadow-md ${
                              m.file_type === 'video' ? 'bg-purple-600' : 'bg-blue-600'
                            }`}>
                              {m.file_type === 'video' ? 'Vidéo' : 'Photo'}
                            </span>
                            {m.file_size_str && (
                              <span className="px-2 py-1 rounded-lg text-[9px] font-mono font-bold bg-black/60 text-white backdrop-blur-sm">
                                {m.file_size_str}
                              </span>
                            )}
                          </div>

                          <button
                            type="button"
                            onClick={() => setSpotlightMedia(m)}
                            className="absolute top-2.5 right-2.5 w-8 h-8 rounded-lg bg-black/60 hover:bg-black text-white flex items-center justify-center text-sm shadow-md transition-all active:scale-90"
                            title="Inspecter en grand écran"
                          >
                            <i className="ti ti-maximize"></i>
                          </button>
                        </div>

                        {/* Details & Caption Input */}
                        <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
                          <div className="space-y-2">
                            <select
                              value={m.category}
                              onChange={e => updateMediaCategory(m.id, e.target.value)}
                              className={`text-[10px] font-black uppercase tracking-wider px-2.5 py-1.5 rounded-lg border outline-none w-full ${
                                isDark ? 'bg-slate-900 border-slate-700 text-slate-200' : 'bg-slate-50 border-slate-200 text-slate-700'
                              }`}
                            >
                              <option value="screen_error">Écran d'erreur / Alarme</option>
                              <option value="component">Pièce / Handpiece</option>
                              <option value="overview">Vue d'ensemble Machine</option>
                              <option value="video_issue">Vidéo du dysfonctionnement</option>
                              <option value="other">Autre document</option>
                            </select>

                            <input
                              type="text"
                              value={m.caption}
                              onChange={e => updateMediaCaption(m.id, e.target.value)}
                              placeholder="Légende ou note explicative..."
                              className={`w-full px-3 py-2 border rounded-xl text-xs font-bold outline-none ${
                                isDark ? 'bg-slate-900 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-800'
                              }`}
                            />
                          </div>

                          <div className="flex items-center justify-between pt-2 border-t border-slate-200/50 text-[10px]">
                            <span className="text-slate-400 font-mono truncate max-w-[140px]">{m.file_name}</span>
                            <button
                              type="button"
                              onClick={() => removeMedia(m.id)}
                              className="text-rose-500 hover:text-rose-700 font-black uppercase tracking-wider flex items-center gap-1 cursor-pointer"
                            >
                              <i className="ti ti-trash text-xs"></i>
                              <span>Supprimer</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className={`p-8 border-2 border-dashed rounded-2xl text-center ${isDark ? 'border-slate-800 bg-slate-800/20' : 'border-slate-200 bg-slate-50/50'}`}>
                  <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-400 flex items-center justify-center text-xl mx-auto mb-2">
                    <i className="ti ti-photo-off"></i>
                  </div>
                  <p className="text-xs font-bold text-slate-400">Aucun média attaché pour le moment.</p>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    L'ajout de visuels permet aux ingénieurs d'identifier rapidement les pannes.
                  </p>
                </div>
              )}
            </div>

          </div>

          {/* RIGHT 4 COLUMNS: DÉTAILS MACHINE & ASSIGNATION */}
          <div className="lg:col-span-4 space-y-6 sticky top-24">
            
            {/* DÉTAILS MACHINE & ASSIGNATION CARD */}
            <div className={`rounded-3xl border shadow-sm p-6 space-y-5 ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <div className="flex items-center gap-3 pb-3 border-b border-slate-200/50">
                <span className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center font-black text-xs shadow-md">
                  4
                </span>
                <div>
                  <h3 className="text-sm font-black uppercase tracking-wider">
                    Détails Machine & Assignation
                  </h3>
                  <p className="text-[11px] text-slate-400 font-medium">Modèle, S/N et technicien affecté</p>
                </div>
              </div>

              {/* Machine Model */}
              <div>
                <label className="text-xs font-black uppercase tracking-wider block mb-2 text-slate-500">
                  Modèle d'Équipement
                </label>
                <input
                  type="text"
                  placeholder="Ex: Specta Laser Diode Trio"
                  value={form.machine_name}
                  onChange={e => setForm(f => ({ ...f, machine_name: e.target.value }))}
                  className={`w-full px-4 py-3 border rounded-xl outline-none font-bold text-xs shadow-inner ${
                    isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-800'
                  }`}
                />
              </div>

              {/* Serial Number */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-black uppercase tracking-wider text-slate-500">
                    Numéro de Série (S/N)
                  </label>
                  <button
                    type="button"
                    onClick={() => setForm(f => ({ ...f, serial_number: `SP-${Date.now().toString().slice(-6)}` }))}
                    className="text-[10px] font-bold text-blue-500 hover:underline flex items-center gap-1"
                  >
                    <i className="ti ti-refresh text-[10px]"></i>
                    <span>Générer S/N</span>
                  </button>
                </div>
                <input
                  type="text"
                  placeholder="Ex: SP-SN-2024-912"
                  value={form.serial_number}
                  onChange={e => setForm(f => ({ ...f, serial_number: e.target.value }))}
                  className={`w-full px-4 py-3 border rounded-xl outline-none font-mono font-bold text-xs shadow-inner ${
                    isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-800'
                  }`}
                />
              </div>

              {/* Functional Status */}
              <div>
                <label className="text-xs font-black uppercase tracking-wider block mb-2 text-slate-500">
                  État Fonctionnel de l'Équipement
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setForm(f => ({ ...f, is_machine_functional: true }))}
                    className={`py-3 px-3 rounded-xl border text-xs font-black flex items-center justify-center gap-1.5 transition-all ${
                      form.is_machine_functional === true
                        ? 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border-emerald-400 shadow-sm'
                        : isDark ? 'bg-slate-800 border-slate-700 text-slate-400' : 'bg-slate-50 border-slate-200 text-slate-600'
                    }`}
                  >
                    <i className="ti ti-circle-check text-emerald-500"></i>
                    <span>Opérationnelle</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setForm(f => ({ ...f, is_machine_functional: false }))}
                    className={`py-3 px-3 rounded-xl border text-xs font-black flex items-center justify-center gap-1.5 transition-all ${
                      form.is_machine_functional === false
                        ? 'bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300 border-rose-400 shadow-sm'
                        : isDark ? 'bg-slate-800 border-slate-700 text-slate-400' : 'bg-slate-50 border-slate-200 text-slate-600'
                    }`}
                  >
                    <i className="ti ti-alert-triangle text-rose-500"></i>
                    <span>Hors Service</span>
                  </button>
                </div>
              </div>

              {/* Urgency Priority */}
              <div>
                <label className="text-xs font-black uppercase tracking-wider block mb-2 text-slate-500">
                  Niveau d'Urgence SAV
                </label>
                <select
                  value={form.priority_slug}
                  onChange={e => setForm(f => ({ ...f, priority_slug: e.target.value as any }))}
                  className={`w-full px-4 py-3 border rounded-xl outline-none font-bold text-xs shadow-inner ${
                    isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-800'
                  }`}
                >
                  <option value="low">Basse (Planifiable sous 5 jours)</option>
                  <option value="medium">Moyenne (Sous 48h)</option>
                  <option value="high">Critique / Haute (Machine Bloquée)</option>
                </select>
              </div>

              {/* Assign Technician */}
              <div>
                <label className="text-xs font-black uppercase tracking-wider block mb-2 text-slate-500">
                  Expert Biomédical Assigné
                </label>
                <select
                  value={form.technician_id}
                  onChange={e => setForm(f => ({ ...f, technician_id: e.target.value }))}
                  className={`w-full px-4 py-3 border rounded-xl outline-none font-bold text-xs shadow-inner ${
                    isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-800'
                  }`}
                >
                  <option value="">-- Affecter ultérieurement --</option>
                  {technicians.map(t => (
                    <option key={t.id} value={t.id}>{t.name}</option>
                  ))}
                </select>
              </div>

              {/* Date */}
              <div>
                <label className="text-xs font-black uppercase tracking-wider block mb-2 text-slate-500">
                  Date Souhaitée d'Intervention
                </label>
                <input
                  type="date"
                  value={form.estimated_intervention_date}
                  onChange={e => setForm(f => ({ ...f, estimated_intervention_date: e.target.value }))}
                  className={`w-full px-4 py-3 border rounded-xl outline-none font-bold text-xs shadow-inner ${
                    isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-800'
                  }`}
                />
              </div>
            </div>

            {/* SYNTHÈSE & VALIDATION CARD */}
            <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-blue-950 rounded-3xl p-6 text-white shadow-xl space-y-5 border border-slate-800">
              <h3 className="text-xs font-black uppercase tracking-[2px] text-blue-400 flex items-center gap-2">
                <i className="ti ti-checklist text-base"></i>
                <span>Synthèse du Dossier SAV</span>
              </h3>

              <div className="space-y-2.5 text-xs">
                <div className="flex justify-between items-center py-1.5 border-b border-white/10">
                  <span className="text-slate-400">Établissement :</span>
                  <span className="font-bold truncate max-w-[160px] text-right">
                    {clientMode === 'existing'
                      ? form.client_name || 'Non sélectionné'
                      : newClientData.name || 'Nouveau client'}
                  </span>
                </div>

                <div className="flex justify-between items-center py-1.5 border-b border-white/10">
                  <span className="text-slate-400">Équipement :</span>
                  <span className="font-bold truncate max-w-[160px] text-right">
                    {form.machine_name || 'Non spécifiée'}
                  </span>
                </div>

                <div className="flex justify-between items-center py-1.5 border-b border-white/10">
                  <span className="text-slate-400">Typologie :</span>
                  <span className="font-bold uppercase tracking-wider">
                    {form.reclamation_type === 'simple' ? 'Simple' : 'Complexe'}
                  </span>
                </div>

                <div className="flex justify-between items-center py-1.5 border-b border-white/10">
                  <span className="text-slate-400">Médias Attachés :</span>
                  <span className="font-bold text-amber-400">
                    {mediaGallery.length} fichier(s)
                  </span>
                </div>

                <div className="flex justify-between items-center py-1.5 border-b border-white/10">
                  <span className="text-slate-400">État Machine :</span>
                  <span className={`font-bold ${form.is_machine_functional ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {form.is_machine_functional ? 'Opérationnelle' : 'Arrêtée / HS'}
                  </span>
                </div>
              </div>

              <div className="pt-2 space-y-3">
                <button
                  type="button"
                  onClick={handleSubmit}
                  disabled={isSubmitting}
                  className="w-full py-4 bg-blue-600 hover:bg-blue-500 active:scale-95 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <span>Création en cours...</span>
                  ) : (
                    <>
                      <i className="ti ti-check text-base"></i>
                      <span>Créer le Dossier SAV</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => navigate('/admin/sav')}
                  className="w-full py-3 bg-white/10 hover:bg-white/20 text-white rounded-2xl font-black text-xs uppercase tracking-wider transition-all"
                >
                  Annuler & Retourner
                </button>
              </div>
            </div>

          </div>

        </form>
      </div>

      {/* MEDIA LIGHTBOX MODAL */}
      {spotlightMedia && (
        <div className="fixed inset-0 bg-slate-950/95 backdrop-blur-2xl z-[400] flex flex-col items-center justify-center p-4 sm:p-8 animate-in fade-in duration-200">
          <button
            type="button"
            onClick={() => setSpotlightMedia(null)}
            className="absolute top-6 right-6 w-12 h-12 bg-white/10 hover:bg-white/20 text-white rounded-full flex items-center justify-center text-2xl transition-all cursor-pointer"
          >
            ×
          </button>

          <div className="w-full max-w-5xl h-full flex flex-col items-center justify-center gap-4">
            <div className="flex-1 w-full flex items-center justify-center overflow-hidden p-2">
              {spotlightMedia.file_type === 'image' ? (
                <img
                  src={spotlightMedia.file_path}
                  alt={spotlightMedia.caption}
                  className="max-w-full max-h-[75vh] rounded-2xl shadow-2xl object-contain border-2 border-white/20"
                />
              ) : (
                <video
                  src={spotlightMedia.file_path}
                  controls
                  autoPlay
                  className="max-w-full max-h-[75vh] rounded-2xl shadow-2xl border-2 border-white/20"
                />
              )}
            </div>

            <div className="bg-white/10 backdrop-blur-md rounded-2xl px-6 py-4 text-white max-w-2xl text-center space-y-1">
              <span className="px-3 py-1 bg-blue-600 rounded-full text-[10px] font-black uppercase tracking-wider">
                {spotlightMedia.file_type === 'video' ? 'Vidéo de la panne' : 'Photo justificative'}
              </span>
              <p className="text-sm font-bold text-slate-100">{spotlightMedia.caption}</p>
              <p className="text-[10px] text-slate-400 font-mono">{spotlightMedia.file_name} • {spotlightMedia.file_size_str}</p>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
