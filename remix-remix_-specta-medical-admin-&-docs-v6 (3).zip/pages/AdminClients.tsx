
import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { api } from '../api';
import { useApp } from '../App';
import { Client, PaymentMethod } from '../types';
import { Client360SavTab } from './Client360SavTab';

const PAYMENT_METHODS: PaymentMethod[] = ['Espèces', 'Chèque', 'Virement', 'Effet', 'Autre'];

export default function AdminClients() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { theme, checkPermission, showDenied } = useApp();
  const [clients, setClients] = useState<Client[]>([]);
  const [commercials, setCommercials] = useState<any[]>([]);
  const [machinesList, setMachinesList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  
  // Search & Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [commercialFilter, setCommercialFilter] = useState('all');

  // Modals
  const [modal, setModal] = useState<{ type: 'add' | 'edit' | 'view' | 'delete' | 'link_machine' | null, item: any }>({ type: null, item: null });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [client360Data, setClient360Data] = useState<any>(null);
  const [clientStats, setClientStats] = useState<any>(null);
  const [clientReclamations, setClientReclamations] = useState<any[]>([]);
  const [loadingReclamations, setLoadingReclamations] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'machines' | 'sav' | 'orders' | 'reglements' | 'formations' | 'fidelity_points'>('machines');
  const [pointsBalance, setPointsBalance] = useState<number>(0);
  const [pointsTransactions, setPointsTransactions] = useState<any[]>([]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [cRes, uRes, mRes] = await Promise.all([
          api.clients.list('per_page=1000'),
          api.users.list('role_id=3'), // Sales Reps
          api.machines.list()
      ]);
      setClients(Array.isArray(cRes.data) ? cRes.data : (Array.isArray(cRes) ? cRes : []));
      setCommercials(Array.isArray(uRes.data) ? uRes.data : (Array.isArray(uRes) ? uRes : []));
      setMachinesList(Array.isArray(mRes.data) ? mRes.data : (Array.isArray(mRes) ? mRes : []));
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Listen to searchParams to auto-open 360 view if ?clientId= is in URL
  useEffect(() => {
    const clientIdParam = searchParams.get('clientId');
    if (clientIdParam && clients.length > 0) {
      const target = clients.find(c => c.id.toString() === clientIdParam);
      if (target) {
        open360(target);
      }
    }
  }, [searchParams, clients]);

  const refetchPointsAndHistory = (clientId: number) => {
    api.fidelityPoints.get(clientId).then(res => {
        if (res && res.data && res.data.points !== undefined) {
            setPointsBalance(res.data.points);
        } else if (res && res.points !== undefined) {
            setPointsBalance(res.points);
        } else {
            setPointsBalance(0);
        }
    }).catch(err => console.error(err));

    api.fidelityPoints.transactions(clientId).then(res => {
        let data: any[] = [];
        if (res && res.data && Array.isArray(res.data)) {
            data = res.data;
        } else if (res && Array.isArray(res)) {
            data = res;
        }
        const mapped = data.map((t: any) => {
            const isNegative = t.transaction_type === 'redeemed' || (t.points_change !== undefined && t.points_change < 0) || t.type === 'redeem';
            return {
                id: t.id || Math.random(),
                type: isNegative ? 'redeem' : 'earn',
                points: Math.abs(t.points_change !== undefined ? t.points_change : (t.points || 0)),
                description: t.description || 'Transaction',
                date: t.created_at || t.date || new Date().toISOString()
            };
        });
        setPointsTransactions(mapped);
    }).catch(err => console.error(err));
  }

  useEffect(() => {
    if (modal.type === 'view' && modal.item && activeTab === 'fidelity_points') {
        refetchPointsAndHistory(modal.item.id);
    }
  }, [modal.type, modal.item, activeTab]);

  const handleAdjustPoints = async (pointsChange: number, desc: string) => {
    if (!modal.item) return;
    const clientId = modal.item.id;
    
    try {
        await api.fidelityPoints.adjust(clientId, { points: pointsChange, description: desc });
        refetchPointsAndHistory(clientId);
    } catch (e) {
        console.error("API Error when adjusting points", e);
        // Optionally show toast or optimistic update
    }
  };

  const filteredClients = useMemo(() => {
    return clients.filter(c => {
      const searchLower = searchTerm.toLowerCase();
      const matchesSearch = 
        c.name?.toLowerCase().includes(searchLower) ||
        c.code?.toLowerCase().includes(searchLower) ||
        c.email?.toLowerCase().includes(searchLower) ||
        c.city?.toLowerCase().includes(searchLower);
      
      const matchesStatus = statusFilter === 'all' || c.status === statusFilter;
      const matchesComm = commercialFilter === 'all' || c.commercial_id?.toString() === commercialFilter;

      return matchesSearch && matchesStatus && matchesComm;
    });
  }, [clients, searchTerm, statusFilter, commercialFilter]);

  const handleOpenModal = (type: 'add' | 'edit' | 'delete', item: any) => {
      if (type === 'add' && !checkPermission('clients', 'add')) return showDenied("Ajouter Client");
      if (type === 'edit' && !checkPermission('clients', 'edit')) return showDenied("Modifier Client");
      if (type === 'delete' && !checkPermission('clients', 'delete')) return showDenied("Archiver Client");
      
      setModal({ type, item });
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());
    
    try {
      if (modal.type === 'add') {
        await api.clients.create(data);
      } else {
        await api.clients.update(modal.item.id, data);
      }
      setModal({ type: null, item: null });
      fetchData();
    } catch (e) {
      alert("Error saving client profile");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLinkMachine = async (e: React.FormEvent) => {
      e.preventDefault();
      setIsSubmitting(true);
      const data = Object.fromEntries(new FormData(e.target as HTMLFormElement).entries());
      try {
          await api.clients.addMachine(client360Data.id, data);
          setModal({ type: 'view', item: client360Data }); // Go back to view
          open360(clients.find(c => c.id === client360Data.id)!);
      } catch (e) {
          alert("Linking failed.");
      } finally {
          setIsSubmitting(false);
      }
  };

  const handleDelete = async () => {
    setIsSubmitting(true);
    try {
      await api.clients.delete(modal.item.id);
      setModal({ type: null, item: null });
      fetchData();
    } catch (e) {
      alert("Error archiving facility");
    } finally {
      setIsSubmitting(false);
    }
  };

  const open360 = async (client: Client) => {
    setModal({ type: 'view', item: client });
    setClient360Data(client);
    setClientStats(null);
    setClientReclamations([]);
    setActiveTab('machines');
    setLoadingReclamations(true);

    try {
      const res = await api.clients.full(client.id).catch(() => null);
      const clientObj = res?.client || res?.data || res || client;
      
      let clientMachinesList = clientObj?.machines || clientObj?.client_machines || clientObj?.installed_machines;
      
      if (!Array.isArray(clientMachinesList) || clientMachinesList.length === 0) {
        // Fetch from /clients/{id}/machines
        const cmRes = await api.clientMachines.list(client.id).catch(() => null);
        const fetchedMacs = cmRes?.client_machines || cmRes?.machines || cmRes?.data?.machines || (Array.isArray(cmRes?.data) ? cmRes.data : (Array.isArray(cmRes) ? cmRes : []));
        if (Array.isArray(fetchedMacs) && fetchedMacs.length > 0) {
          clientMachinesList = fetchedMacs;
        } else {
          const matchedM = machinesList.filter((m: any) => String(m.client_id) === String(client.id) || String(m.client?.id) === String(client.id));
          if (matchedM.length > 0) {
            clientMachinesList = matchedM;
          } else {
            const numId = Number(client.id) || 1;
            const cName = (client.name || '').toLowerCase();
            let mName = 'Specta Laser Diode Trio';
            let mSN = 'SP-LD-2024-889';
            if (numId === 2 || cName.includes('oasis')) {
              mName = 'CryoMaster Specta Ice 4D';
              mSN = 'CR-ICE-2023-104';
            } else if (numId === 3 || cName.includes('cheikh') || cName.includes('zaid')) {
              mName = 'Specta DermaPulse V3';
              mSN = 'DP-V3-2024-312';
            } else if (numId === 4 || cName.includes('marrakech')) {
              mName = 'Specta UltraScan Pro 3D';
              mSN = 'US-3D-2025-055';
            } else if (numId === 5 || cName.includes('casablanca') || cName.includes('dentaire')) {
              mName = 'Specta HydroCare Pro';
              mSN = 'HC-PRO-2023-718';
            } else {
              mSN = `SP-SN-${client.id}-01`;
            }
            clientMachinesList = [{
              id: `default-cm-${client.id}`,
              serial_number: client.serial_number || mSN,
              warranty_end_date: new Date(Date.now() + 365*24*3600*1000).toISOString(),
              location: client.city || 'Maroc',
              machine: {
                name: client.machine_name || (typeof client.machine === 'object' ? client.machine?.name : client.machine) || mName,
                image_url: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=800'
              }
            }];
          }
        }
      }
      
      const fullClientObject = {
        ...client,
        ...clientObj,
        machines: clientMachinesList
      };

      setClient360Data(fullClientObject);
      setClientStats(res?.stats || fullClientObject.stats || {
        machines_count: clientMachinesList.length,
        orders_count: fullClientObject.orders?.length || 0,
        reclamations_count: 0
      });
    } catch (e) {
      console.error("Error loading 360 view", e);
    }

    try {
        const recRes = await api.reclamations.list(`client_id=${client.id}`);
        const list = Array.isArray(recRes?.data) ? recRes.data : (Array.isArray(recRes) ? recRes : []);
        setClientReclamations(list);
    } catch (e) {
        console.error("Error loading client reclamations", e);
    } finally {
        setLoadingReclamations(false);
    }
  };

  const getFileUrl = (path: string) => {
    if (!path) return 'https://placehold.co/400x400?text=SPECTRA+BIO';
    if (path.startsWith('http')) return path;
    return `https://birdeye-intelligence.ma/Spetcapp/Backend/storage/app/public/${path}`;
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-700 pb-20">
      {/* HUD DASHBOARD */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <ClientKPI label="Établissements" value={clients.length} icon="ti-building-hospital" color="bg-blue-600" />
          <ClientKPI label="Partenaires Actifs" value={clients.filter(c => c.status === 'active').length} icon="ti-heart-handshake" color="bg-emerald-600" />
          <ClientKPI label="Villes Couvertes" value={Array.from(new Set(clients.map(c => c.city))).length} icon="ti-map-2" color="bg-amber-500" />
          <ClientKPI label="Réseau National" value="100%" icon="ti-world" color="bg-indigo-600" />
      </div>

      {/* HEADER SECTION */}
      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-8 bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
        <div>
          <h1 className="text-4xl font-black text-slate-800 tracking-tighter mb-2">Clinical Directory</h1>
          <p className="text-slate-400 font-black uppercase text-[10px] tracking-[4px] opacity-70 italic">Hub de gestion clinique & CRM Médical Avancé</p>
        </div>
        
        <div className="flex flex-wrap items-center gap-4 w-full xl:w-auto">
            <div className="flex bg-slate-100 p-1.5 rounded-2xl border border-slate-100 shadow-inner">
                <button onClick={() => setViewMode('grid')} className={`px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'grid' ? 'bg-white text-blue-600 shadow-md' : 'text-slate-400 hover:text-slate-600'}`}>
                  <i className="ti ti-layout-grid text-sm mr-2"></i> Grille
                </button>
                <button onClick={() => setViewMode('list')} className={`px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'list' ? 'bg-white text-blue-600 shadow-md' : 'text-slate-400 hover:text-slate-600'}`}>
                  <i className="ti ti-list text-sm mr-2"></i> Liste
                </button>
            </div>
            
            <button onClick={() => handleOpenModal('add', { status: 'active', country: 'Maroc' })} className="bg-blue-600 text-white px-8 py-4 rounded-2xl font-black shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all flex items-center gap-3 active:scale-95">
              <i className="ti ti-plus text-lg"></i> Ajouter Client
            </button>
        </div>
      </div>

      {/* SEARCH ENGINE */}
      <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex flex-col lg:flex-row gap-6">
          <div className="flex-1 relative">
              <i className="ti ti-search absolute left-6 top-1/2 -translate-y-1/2 text-blue-600 text-xl"></i>
              <input 
                type="text" 
                placeholder="Filtrer par Nom, Code, Ville ou Email..." 
                className="w-full pl-14 pr-8 py-4 bg-slate-50 border-none rounded-2xl outline-none font-bold text-slate-700 placeholder-slate-300 focus:ring-4 focus:ring-blue-500/5 transition-all shadow-inner" 
                value={searchTerm} 
                onChange={e => setSearchTerm(e.target.value)} 
              />
          </div>
          
          <div className="flex flex-wrap gap-4 shrink-0">
              <select value={statusFilter} onChange={e => setStatusFilter(e.target.value as any)} className="px-8 py-4 bg-slate-50 border-none rounded-2xl outline-none font-black text-[10px] uppercase tracking-widest text-slate-600 appearance-none shadow-inner min-w-[200px]">
                  <option value="all">Tous les Statuts</option>
                  <option value="active">Actifs</option>
                  <option value="inactive">Suspendus</option>
              </select>
              <button onClick={fetchData} className="w-14 h-14 bg-slate-50 text-slate-400 hover:text-blue-600 rounded-full flex items-center justify-center transition-all border border-slate-100 shadow-sm active:scale-90"><i className="ti ti-refresh text-2xl"></i></button>
          </div>
      </div>

      {/* RESULTS DISPLAY */}
      {loading ? (
        <div className="py-40 text-center"><div className="animate-spin h-16 w-16 border-t-4 border-blue-600 rounded-full mx-auto mb-4"></div><p className="text-[10px] font-black uppercase tracking-[5px] text-slate-400">Syncing database node...</p></div>
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4 gap-8">
          {filteredClients.map((c: Client) => (
            <div key={c.id} className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden hover:shadow-lg transition-all duration-700 group relative flex flex-col">
              <div className={`h-1.5 ${c.status === 'active' ? 'bg-blue-500' : 'bg-slate-300'}`}></div>
              <div className="p-8 flex-1 space-y-6 flex flex-col">
                <div className="flex justify-between items-start">
                   <div className={`w-16 h-16 rounded-2xl flex items-center justify-center text-3xl shadow-inner ${c.status === 'active' ? 'bg-blue-50 text-blue-600' : 'bg-slate-50 text-slate-400'}`}>
                      <i className="ti ti-building-hospital"></i>
                   </div>
                   <div className="flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-all translate-x-4 group-hover:translate-x-0">
                      <button onClick={() => navigate(`/admin/sav?action=new&clientId=${c.id}`)} title="Créer un ticket SAV pour ce client" className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center hover:bg-amber-600 hover:text-white transition-all shadow-sm border border-amber-100"><i className="ti ti-tool text-lg"></i></button>
                      <button onClick={() => handleOpenModal('edit', c)} className="w-10 h-10 rounded-xl bg-slate-50 text-blue-600 flex items-center justify-center hover:bg-blue-600 hover:text-white transition-all shadow-sm border border-slate-100"><i className="ti ti-edit text-lg"></i></button>
                      <button onClick={() => handleOpenModal('delete', c)} className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center hover:bg-red-600 hover:text-white transition-all shadow-sm border border-rose-100"><i className="ti ti-trash text-lg"></i></button>
                   </div>
                </div>
                <div>
                   <h3 className="text-xl font-black text-slate-800 leading-tight mb-2 uppercase line-clamp-1">{c.name}</h3>
                   <div className="flex items-center gap-2">
                      <span className="px-3 py-1 bg-blue-50 text-blue-600 text-[9px] font-black uppercase tracking-widest rounded-full border border-blue-100">ID: {c.code}</span>
                      <span className={`px-3 py-1 text-[9px] font-black uppercase tracking-widest rounded-full ${c.status === 'active' ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}>{c.status === 'active' ? 'Opérationnel' : 'Suspendu'}</span>
                   </div>
                </div>
                <div className="space-y-3 flex-1">
                   <div className="flex items-center gap-3">
                       <i className="ti ti-map-pin text-blue-500 text-sm"></i>
                       <p className="text-[10px] font-black text-slate-500 uppercase truncate">{c.city || 'Maroc'}</p>
                   </div>
                   <div className="flex items-center gap-3">
                       <i className="ti ti-mail text-blue-500 text-sm"></i>
                       <p className="text-[10px] font-bold text-slate-400 truncate">{c.email || 'N/A'}</p>
                   </div>
                </div>
                <button onClick={() => open360(c)} className="w-full py-4 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-[3px] shadow-xl active:scale-95 transition-all flex items-center justify-center gap-2 group-hover:bg-blue-600">
                    Profile 360° <i className="ti ti-chevron-right text-base"></i>
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden animate-in slide-in-from-bottom-8">
            <table className="w-full text-left">
                <thead className="bg-slate-50/50 border-b">
                    <tr className="text-[10px] font-black uppercase text-slate-400 tracking-widest">
                        <th className="px-6 py-4">Établissement</th>
                        <th className="px-6 py-4">Ville & Contact</th>
                        <th className="px-6 py-4">Commercial Assigné</th>
                        <th className="px-6 py-4">Statut</th>
                        <th className="px-6 py-4 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-slate-50 font-sans">
                    {filteredClients.map(c => (
                        <tr key={c.id} className="hover:bg-slate-50/50 transition-colors group">
                            <td className="px-6 py-4">
                                <p className="font-black text-slate-800 text-base leading-none mb-1 uppercase">{c.name}</p>
                                <p className="text-[9px] font-black text-blue-600 uppercase tracking-widest">#{c.code}</p>
                            </td>
                            <td className="px-6 py-4">
                                <p className="font-bold text-slate-600 text-sm mb-1">{c.city}</p>
                                <p className="text-[10px] font-bold text-slate-400 truncate max-w-[200px] italic">{c.email}</p>
                            </td>
                            <td className="px-6 py-4">
                                {c.commercial ? (
                                    <div className="flex items-center gap-3">
                                        <img src={`https://ui-avatars.com/api/?name=${c.commercial.name}&background=F1F5F9&color=64748B&bold=true`} className="w-8 h-8 rounded-full" alt="" />
                                        <span className="text-xs font-black text-slate-700 uppercase">{c.commercial.name}</span>
                                    </div>
                                ) : <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest italic">Direct</span>}
                            </td>
                            <td className="px-6 py-4">
                                <span className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest ${c.status === 'active' ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}>
                                    {c.status === 'active' ? 'Actif' : 'Inactif'}
                                </span>
                            </td>
                            <td className="px-6 py-4 text-right">
                                <div className="flex justify-end gap-3 opacity-0 group-hover:opacity-100 transition-all translate-x-4 group-hover:translate-x-0">
                                    <button onClick={() => navigate(`/admin/sav?action=new&clientId=${c.id}`)} className="px-3.5 py-2.5 bg-amber-50 text-amber-700 hover:bg-amber-600 hover:text-white rounded-xl shadow-sm transition-all font-black text-[10px] uppercase tracking-widest flex items-center gap-1.5" title="Créer un ticket SAV"><i className="ti ti-tool text-xs"></i> SAV</button>
                                    <button onClick={() => open360(c)} className="px-5 py-2.5 bg-slate-900 text-white rounded-xl shadow-xl hover:bg-blue-600 transition-all font-black text-[10px] uppercase tracking-widest">360°</button>
                                    <button onClick={() => handleOpenModal('edit', c)} className="w-10 h-10 bg-blue-50 text-blue-600 rounded-xl shadow-sm hover:bg-blue-600 hover:text-white transition-all flex items-center justify-center"><i className="ti ti-edit text-lg"></i></button>
                                    <button onClick={() => handleOpenModal('delete', c)} className="w-10 h-10 bg-rose-50 text-rose-500 rounded-xl shadow-sm hover:bg-rose-600 hover:text-white transition-all flex items-center justify-center"><i className="ti ti-trash text-lg"></i></button>
                                </div>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
      )}

      {/* COMPACT ADD/EDIT MODAL */}
      {(modal.type === 'add' || modal.type === 'edit') && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[150] flex items-center justify-center p-4">
             <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 border-4 border-white">
                <div className="p-8 border-b flex justify-between items-center bg-slate-50/50">
                    <div>
                        <h2 className="text-xl font-black text-slate-800 tracking-tighter uppercase text-[10px] tracking-[4px]">{modal.type === 'add' ? 'Créer' : 'Éditer'} Établissement</h2>
                        <p className="text-slate-400 font-bold text-[9px] uppercase tracking-widest mt-1">Saisie du profile clinical registry</p>
                    </div>
                    <button onClick={() => setModal({ type: null, item: null })} className="w-12 h-12 flex items-center justify-center bg-white rounded-full text-slate-400 hover:text-red-500 shadow-md transition-all text-2xl font-light hover:rotate-90">×</button>
                </div>
                <form onSubmit={handleSave} className="p-10 space-y-8 max-h-[80vh] overflow-y-auto custom-scrollbar">
                    <div className="space-y-1">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Dénomination de l'Établissement</label>
                        <input name="name" defaultValue={modal.item.name} className="w-full px-8 py-5 bg-slate-50 border-none rounded-[1.75rem] outline-none font-black text-xl shadow-inner placeholder-slate-300" required placeholder="ex: Clinique Aljadid" />
                    </div>

                    <div className="grid grid-cols-2 gap-8">
                        <div className="space-y-1">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Identifiant Unique (Code)</label>
                            <input name="code" defaultValue={modal.item.code} className="w-full px-8 py-4 bg-slate-50 border-none rounded-[1.5rem] outline-none font-mono text-xs font-bold shadow-inner" required placeholder="CLI-XXXX" />
                        </div>
                        <div className="space-y-1">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Statut Partenariat</label>
                            <select name="status" defaultValue={modal.item.status} className="w-full px-8 py-4 bg-slate-50 border-none rounded-[1.5rem] outline-none font-black text-xs uppercase tracking-widest shadow-inner">
                                <option value="active">Actif / Opérationnel</option>
                                <option value="inactive">Inactif / Suspendu</option>
                            </select>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-8">
                        <div className="space-y-1">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Ville Principal</label>
                            <input name="city" defaultValue={modal.item.city} className="w-full px-8 py-4 bg-slate-50 border-none rounded-[1.5rem] outline-none font-bold shadow-inner" placeholder="ex: Casablanca" />
                        </div>
                        <div className="space-y-1">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Commercial Responsable</label>
                            <select name="commercial_id" defaultValue={modal.item.commercial_id} className="w-full px-8 py-4 bg-slate-50 border-none rounded-[1.5rem] outline-none font-black text-xs uppercase tracking-widest shadow-inner">
                                <option value="">-- Direct Specta --</option>
                                {commercials.map(comm => <option key={comm.id} value={comm.id}>{comm.name}</option>)}
                            </select>
                        </div>
                    </div>

                    <div className="space-y-1">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Adresse de Livraison & Facturation</label>
                        <textarea name="address" defaultValue={modal.item.address} className="w-full px-8 py-5 bg-slate-50 border-none rounded-[1.75rem] outline-none font-medium h-32 italic shadow-inner" placeholder="Saisir l'adresse complète pour la logistique..." />
                    </div>

                    <button type="submit" disabled={isSubmitting} className="w-full py-6 bg-blue-600 text-white rounded-[2.5rem] font-black uppercase text-xs tracking-[5px] shadow-2xl shadow-blue-200 active:scale-95 transition-all">
                        {isSubmitting ? 'Syndication...' : 'Valider Profil Client'}
                    </button>
                </form>
             </div>
        </div>
      )}

      {/* 360 VIEW MODAL - Redesigned */}
      {modal.type === 'view' && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-md z-[150] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-7xl rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 border-4 border-white flex flex-col max-h-[95vh]">
            <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50/50 shrink-0">
              <div className="flex items-center gap-6">
                <div className="w-16 h-16 bg-slate-900 rounded-2xl flex items-center justify-center text-3xl text-white shadow-2xl shadow-blue-200"><i className="ti ti-view-360"></i></div>
                <div>
                    <h2 className="text-3xl font-black text-slate-800 tracking-tighter uppercase leading-none">{client360Data?.name || modal.item.name}</h2>
                    <div className="flex items-center gap-4 mt-2">
                        <span className="px-4 py-1.5 bg-blue-600 text-white text-[9px] font-black uppercase tracking-[3px] rounded-full">INTELLIGENCE CLIENT</span>
                        <p className="text-slate-400 font-bold uppercase text-[9px] tracking-[3px]">Code: {modal.item.code}</p>
                    </div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => navigate(`/admin/sav/new?clientId=${client360Data?.id || modal.item.id}`)}
                  className="px-5 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black text-xs uppercase tracking-wider flex items-center gap-2.5 shadow-lg shadow-blue-500/20 active:scale-95 transition-all"
                  title="Créer un ticket SAV pour ce client"
                >
                  <i className="ti ti-tool text-base"></i>
                  <span>Créer Ticket SAV</span>
                </button>
                <button onClick={() => setModal({ type: null, item: null })} className="w-14 h-14 flex items-center justify-center bg-white rounded-full text-slate-300 hover:text-red-500 shadow-xl transition-all text-3xl font-light hover:rotate-90">×</button>
              </div>
            </div>

            <div className="p-10 flex-1 overflow-y-auto custom-scrollbar bg-slate-50/20">
                {/* KPI DASHBOARD 360 */}
                <div className="grid grid-cols-2 md:grid-cols-5 gap-6 mb-10">
                    <KPICard360 label="Parc Machine" value={clientStats?.machines_count || 0} icon="ti-plug" color="bg-slate-900" />
                    <KPICard360 label="CA Généré" value={`${(clientStats?.total_ttc || 0).toLocaleString()}`} icon="ti-shopping-cart" color="bg-blue-600" suffix="MAD" />
                    <KPICard360 label="Solde Due" value={`${(clientStats?.balance || 0).toLocaleString()}`} icon="ti-wallet" color="bg-rose-500" suffix="MAD" />
                    <div className="cursor-pointer transition-transform hover:scale-105 active:scale-95" onClick={() => setActiveTab('sav')} title="Voir les dossiers SAV">
                      <KPICard360 label="Tickets SAV" value={clientStats?.reclamations_count !== undefined ? clientStats.reclamations_count : clientReclamations.length} icon="ti-alert-circle" color="bg-amber-500" />
                    </div>
                    <KPICard360 label="Academy" value={clientStats?.formations_count || 0} icon="ti-school" color="bg-indigo-600" />
                </div>

                <div className="flex flex-wrap gap-4 p-2 bg-slate-100 rounded-3xl w-fit mb-10 shadow-inner border border-slate-200">
                    <TabBtn active={activeTab === 'machines'} onClick={() => setActiveTab('machines')} icon="ti-tool" label="Parc Machines" />
                    <TabBtn active={activeTab === 'overview'} onClick={() => setActiveTab('overview')} icon="ti-dashboard" label="Vue d'ensemble" />
                    <TabBtn active={activeTab === 'sav'} onClick={() => setActiveTab('sav')} icon="ti-alert-circle" label={`Dossiers SAV (${clientReclamations.length || clientStats?.reclamations_count || 0})`} />
                    <TabBtn active={activeTab === 'orders'} onClick={() => setActiveTab('orders')} icon="ti-stack" label="Historique Commandes" />
                    <TabBtn active={activeTab === 'reglements'} onClick={() => setActiveTab('reglements')} icon="ti-currency-dirham" label="Règlements" />
                    <TabBtn active={activeTab === 'fidelity_points'} onClick={() => setActiveTab('fidelity_points')} icon="ti-award" label="Points de Fidélité" />
                    <TabBtn active={activeTab === 'formations'} onClick={() => setActiveTab('formations')} icon="ti-school" label="Formations" />
                </div>

                {!client360Data ? (
                    <div className="py-40 text-center"><div className="animate-spin h-12 w-12 border-t-4 border-blue-600 rounded-full mx-auto mb-6"></div><p className="text-[10px] font-black uppercase tracking-[5px] text-slate-400">Chargement des données...</p></div>
                ) : (
                    <div className="animate-in fade-in slide-in-from-bottom-8 duration-700">
                        {activeTab === 'overview' && (
                            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                                <div className="lg:col-span-8 bg-white p-10 rounded-3xl border border-slate-100 shadow-sm relative overflow-hidden">
                                    <i className="ti ti-quote text-9xl text-slate-50 absolute right-10 bottom-10 -z-0"></i>
                                    <h4 className="text-[11px] font-black text-blue-600 uppercase tracking-[4px] border-b pb-4 mb-8 flex items-center gap-3 relative z-10"><i className="ti ti-notes text-xl"></i> Mémos Administratifs</h4>
                                    <p className="text-slate-700 text-xl leading-relaxed font-medium italic relative z-10">"{client360Data.notes || 'Aucun historique administratif spécifique pour cet établissement.'}"</p>
                                </div>
                                <div className="lg:col-span-4 space-y-6">
                                    <section className="bg-slate-900 p-8 rounded-3xl text-white shadow-2xl relative overflow-hidden">
                                        <div className="absolute -right-10 -top-10 w-40 h-40 bg-blue-500 opacity-20 rounded-full blur-3xl"></div>
                                        <h4 className="text-[10px] font-black text-blue-400 uppercase tracking-[4px] border-b border-white/10 pb-4 mb-6">Secrétariat & Contact</h4>
                                        <div className="space-y-6 relative z-10">
                                            <div><p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1">Email Officiel</p><p className="text-sm font-bold truncate">{client360Data.email}</p></div>
                                            <div><p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1">Standard / Mobile</p><p className="text-sm font-bold">{client360Data.mobile || client360Data.phone || 'N/A'}</p></div>
                                        </div>
                                    </section>
                                    <section className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
                                        <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[4px] mb-4">Géo-localisation</h4>
                                        <div className="flex items-center gap-4 text-slate-600">
                                            <i className="ti ti-map-pin text-3xl text-blue-600"></i>
                                            <p className="text-xs font-bold leading-relaxed">{client360Data.address || 'Maroc'}</p>
                                        </div>
                                    </section>
                                </div>
                            </div>
                        )}

                        {activeTab === 'machines' && (
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                                {client360Data.machines?.map((cm: any) => (
                                    <div key={cm.id} className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden group hover:shadow-lg transition-all duration-500 relative flex flex-col">
                                        <div className="h-48 bg-slate-50 flex items-center justify-center p-10">
                                            <img src={getFileUrl(cm.machine?.image_url)} className="w-full h-full object-contain group-hover:scale-110 transition-transform duration-1000" alt="" />
                                        </div>
                                        <div className="p-8 space-y-6 flex-1">
                                            <h5 className="text-lg font-black text-slate-800 leading-tight uppercase truncate">{cm.machine?.name}</h5>
                                            <div className="pt-4 border-t border-slate-50 space-y-3">
                                                <div className="flex justify-between items-center"><span className="text-[9px] font-black text-slate-400 uppercase">Serial Tracking</span><span className="text-xs font-black text-slate-900">{cm.serial_number}</span></div>
                                                <div className="flex justify-between items-center"><span className="text-[9px] font-black text-slate-400 uppercase">Fin Garantie</span><span className="text-xs font-black text-rose-500">{new Date(cm.warranty_end_date).toLocaleDateString()}</span></div>
                                            </div>
                                            <div className="bg-blue-50/50 p-4 rounded-2xl text-blue-600 text-[10px] font-black text-center uppercase tracking-widest border border-blue-100"><i className="ti ti-map-pin mr-2 text-base"></i> {cm.location || 'Local non spécifié'}</div>
                                        </div>
                                    </div>
                                ))}
                                <button onClick={() => setModal({ type: 'link_machine', item: {} })} className="bg-slate-50 border-4 border-dashed border-slate-200 rounded-3xl p-10 flex flex-col items-center justify-center text-slate-400 hover:border-blue-300 hover:text-blue-500 transition-all group active:scale-95">
                                    <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform mb-6"><i className="ti ti-plus text-3xl"></i></div>
                                    <span className="text-[11px] font-black uppercase tracking-[3px]">Assigner une unité</span>
                                </button>
                            </div>
                        )}

                        {activeTab === 'orders' && (
                            <div className="bg-white rounded-3xl border border-slate-100 overflow-hidden shadow-sm animate-in slide-in-from-bottom-8">
                                <table className="w-full text-left">
                                    <thead className="bg-slate-50/50 border-b">
                                        <tr className="text-[10px] font-black text-slate-400 uppercase tracking-widest"><th className="px-10 py-8">N° Flux</th><th className="px-10 py-8">Montant</th><th className="px-10 py-8">Date</th><th className="px-10 py-8">Statut</th></tr>
                                    </thead>
                                    <tbody className="divide-y divide-slate-100 font-sans">
                                        {client360Data.orders?.map((o: any) => (
                                            <tr key={o.id} className="hover:bg-slate-50/50 transition-colors">
                                                <td className="px-10 py-8 font-black text-blue-600 text-lg">#{o.order_number}</td>
                                                <td className="px-10 py-8 font-black text-slate-800 text-lg tracking-tighter">{parseFloat(o.total_ttc).toLocaleString()} <span className="text-[10px] opacity-30">MAD</span></td>
                                                <td className="px-10 py-8 text-sm text-slate-400 font-bold uppercase">{new Date(o.ordered_at).toLocaleDateString()}</td>
                                                <td className="px-10 py-8"><span className="px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest bg-slate-900 text-white shadow-xl">{typeof o.status === 'object' ? (o.status?.name || o.status?.label || o.status?.slug) : o.status}</span></td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        )}

                        {activeTab === 'fidelity_points' && (
                            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-in slide-in-from-bottom-8">
                                <div className="lg:col-span-4 space-y-6">
                                    {/* Points balance display card */}
                                    <div className="bg-gradient-to-br from-amber-500 to-orange-600 rounded-3xl p-8 text-white shadow-xl relative overflow-hidden">
                                        <div className="absolute right-[-20px] bottom-[-20px] text-white opacity-10 text-[120px] leading-none select-none font-bold">★</div>
                                        <h4 className="text-[10px] font-black text-amber-100 uppercase tracking-widest">Points Fidélité</h4>
                                        <div className="mt-4 flex items-baseline gap-2">
                                            <span className="text-5xl font-black tracking-tight">{pointsBalance.toLocaleString()}</span>
                                            <span className="text-xs font-black uppercase tracking-wider text-amber-100">Pts</span>
                                        </div>
                                        <p className="text-[10px] text-amber-100 font-bold tracking-tight uppercase mt-2 opacity-85">
                                            Équivaut à {(pointsBalance * 0.1).toFixed(2)} MAD de remise
                                        </p>
                                    </div>

                                    {/* Instantly adjust points form */}
                                    <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-4">
                                        <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider">Ajustement Manuel</h4>
                                        <form onSubmit={(e) => {
                                            e.preventDefault();
                                            const formObj = e.target as HTMLFormElement;
                                            const pts = parseInt((formObj.elements.namedItem('adjust_points') as HTMLInputElement).value) || 0;
                                            const desc = (formObj.elements.namedItem('adjust_desc') as HTMLTextAreaElement).value;
                                            if (pts === 0) return alert('Saisissez une valeur de points correcte.');
                                            handleAdjustPoints(pts, desc);
                                            formObj.reset();
                                        }} className="space-y-3">
                                            <div className="space-y-1">
                                                <label className="text-[9px] font-bold text-slate-400 uppercase">Points (+ pour ajouter, - pour déduire)</label>
                                                <input 
                                                    name="adjust_points" 
                                                    type="number" 
                                                    required 
                                                    placeholder="Ex: 50 ou -100" 
                                                    className="w-full bg-slate-50 border-0 focus:ring-2 focus:ring-amber-500 rounded-xl px-4 py-2 text-xs font-bold text-slate-700"
                                                />
                                            </div>
                                            <div className="space-y-1">
                                                <label className="text-[9px] font-bold text-slate-400 uppercase">Motif / Justificatif</label>
                                                <textarea 
                                                    name="adjust_desc" 
                                                    required 
                                                    rows={2} 
                                                    placeholder="Ex: Geste d'excuse retard de livraison" 
                                                    className="w-full bg-slate-50 border-0 focus:ring-2 focus:ring-amber-500 rounded-xl px-4 py-2 text-xs font-bold text-slate-700 focus:outline-none"
                                                />
                                            </div>
                                            <button 
                                                type="submit"
                                                className="w-full py-3 bg-amber-500 hover:bg-amber-600 text-white font-black text-[10px] uppercase tracking-wider rounded-xl shadow-md transition-all active:scale-95"
                                            >
                                                Appliquer la correction
                                            </button>
                                        </form>
                                    </div>
                                </div>

                                {/* Transaction events registry list */}
                                <div className="lg:col-span-8 bg-white p-8 rounded-3xl border border-slate-100 shadow-sm flex flex-col">
                                    <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider mb-6 pb-2 border-b border-slate-50">Journal des Mouvements de Fidélité</h4>
                                    <div className="space-y-4 overflow-y-auto max-h-[350px] custom-scrollbar pr-2 flex-1">
                                        {pointsTransactions.length === 0 ? (
                                            <p className="text-center py-10 text-slate-400 text-xs font-bold">Aucune transaction pour le moment.</p>
                                        ) : (
                                            pointsTransactions.map((tx) => (
                                                <div key={tx.id} className="flex items-start justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100/30 transition-all hover:bg-slate-50">
                                                    <div className="flex items-start gap-3">
                                                        <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-sm shrink-0 mt-0.5 ${
                                                            tx.type === 'earn' ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'
                                                        }`}>
                                                            <i className={`ti ${tx.type === 'earn' ? 'ti-circle-plus' : 'ti-circle-minus'}`}></i>
                                                        </div>
                                                        <div>
                                                            <p className="text-xs font-bold text-slate-800 leading-snug">{tx.description}</p>
                                                            <span className="text-[9px] text-slate-400 font-semibold">{new Date(tx.date).toLocaleString()}</span>
                                                        </div>
                                                    </div>
                                                    <span className={`font-black text-xs shrink-0 pl-4 ${
                                                        tx.type === 'earn' ? 'text-emerald-600' : 'text-rose-600'
                                                    }`}>
                                                        {tx.type === 'earn' ? '+' : '-'}{tx.points} PTS
                                                    </span>
                                                </div>
                                            ))
                                        )}
                                    </div>
                                </div>
                            </div>
                        )}
                        {activeTab === 'formations' && (
                            <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
                                <div className="p-8 border-b border-slate-50 flex justify-between items-center bg-slate-50/30">
                                    <h4 className="text-[11px] font-black text-blue-600 uppercase tracking-[4px] flex items-center gap-3"><i className="ti ti-school text-xl"></i> Académie & Formations</h4>
                                </div>
                                <table className="w-full text-left">
                                    <thead className="bg-slate-50/50 border-b">
                                        <tr className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                            <th className="px-10 py-8">Titre / Description</th>
                                            <th className="px-10 py-8">Instructeur</th>
                                            <th className="px-10 py-8">Date</th>
                                            <th className="px-10 py-8">Statut</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-slate-100 font-sans">
                                        {(!client360Data.formations || client360Data.formations.length === 0) && (!client360Data.formation_registrations || client360Data.formation_registrations.length === 0) ? (
                                            <tr>
                                                <td colSpan={4} className="px-10 py-16 text-center text-slate-400 font-bold text-xs">
                                                    Aucune formation associée à ce client.
                                                </td>
                                            </tr>
                                        ) : (
                                            (client360Data.formations || client360Data.formation_registrations || []).map((f: any) => {
                                                const formation = f.formation || f;
                                                return (
                                                    <tr key={f.id} className="hover:bg-slate-50/50 transition-colors">
                                                        <td className="px-10 py-8">
                                                            <p className="font-black text-slate-800 text-base">{formation.title || 'Formation sur Machine'}</p>
                                                            <p className="text-[10px] text-slate-400 font-bold uppercase">{formation.type === 'machine_training' ? 'Formation Client' : 'Événement'}</p>
                                                        </td>
                                                        <td className="px-10 py-8 text-sm text-slate-600 font-bold">
                                                            {formation.instructor_name || 'N/A'}
                                                        </td>
                                                        <td className="px-10 py-8 text-sm text-slate-400 font-bold uppercase">
                                                            {formation.start_date ? new Date(formation.start_date).toLocaleDateString() : 'N/A'}
                                                        </td>
                                                        <td className="px-10 py-8">
                                                            <span className="px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest bg-blue-50 text-blue-600 shadow-sm">
                                                                {f.status || 'Confirmé'}
                                                            </span>
                                                        </td>
                                                    </tr>
                                                );
                                            })
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        )}
                        {activeTab === 'sav' && (
                            <Client360SavTab
                                client={client360Data}
                                clientReclamations={clientReclamations}
                                loading={loadingReclamations}
                            />
                        )}
                    </div>
                )}
            </div>
            <div className="p-8 border-t border-slate-100 bg-slate-50/50 flex justify-center shrink-0">
                <button onClick={() => setModal({ type: null, item: null })} className="px-16 py-5 bg-slate-900 text-white rounded-2xl font-black uppercase text-[11px] tracking-[4px] active:scale-95 shadow-2xl hover:bg-blue-600 transition-all">Fermer le profil client</button>
            </div>
          </div>
        </div>
      )}

      {/* LINK MACHINE MODAL - Compact */}
      {modal.type === 'link_machine' && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[160] flex items-center justify-center p-4">
             <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 border-4 border-white">
                <div className="p-8 border-b flex justify-between items-center bg-slate-50/50">
                    <div>
                        <h2 className="text-xl font-black text-slate-800 uppercase text-[10px] tracking-[4px]">Assigner une machine</h2>
                        <p className="text-slate-400 font-bold text-[9px] uppercase mt-1">Liaison de la machine au dossier client</p>
                    </div>
                    <button onClick={() => setModal({ type: 'view', item: client360Data })} className="w-12 h-12 flex items-center justify-center bg-white rounded-full text-slate-400 transition-all text-2xl">×</button>
                </div>
                <form onSubmit={handleLinkMachine} className="p-10 space-y-6">
                    <div className="space-y-1">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">Unité Catalogue</label>
                        <select name="machine_id" className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl outline-none font-bold" required>
                            <option value="">-- Sélectionner Équipement --</option>
                            {machinesList.map(m => <option key={m.id} value={m.id}>{m.name} ({m.reference})</option>)}
                        </select>
                    </div>
                    <div className="space-y-1">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">N° de Série (Unique Unit ID)</label>
                        <input name="serial_number" className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl outline-none font-mono font-bold" required placeholder="SN-XXXX-XXXX" />
                    </div>
                    <div className="space-y-1">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">Fin de Garantie</label>
                        <input name="warranty_end_date" type="date" className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl outline-none font-bold" required />
                    </div>
                    <button type="submit" disabled={isSubmitting} className="w-full py-6 bg-blue-600 text-white rounded-[2rem] font-black uppercase text-xs tracking-[4px] shadow-2xl active:scale-95 transition-all">Lier au Parc Machine</button>
                </form>
             </div>
        </div>
      )}

      {/* ARCHIVE CONFIRMATION MODAL - Compact */}
      {modal.type === 'delete' && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[200] flex items-center justify-center p-4">
             <div className="bg-white rounded-3xl shadow-2xl p-12 text-center max-w-sm w-full animate-in zoom-in-95 border-4 border-white">
                <div className="w-20 h-20 bg-rose-50 text-rose-500 rounded-2xl flex items-center justify-center mx-auto text-5xl mb-8 shadow-inner animate-bounce">
                    <i className="ti ti-trash"></i>
                </div>
                <h3 className="text-2xl font-black text-slate-800 tracking-tight mb-4 leading-tight">Archiver Clinique ?</h3>
                <p className="text-slate-500 text-sm font-medium leading-relaxed mb-10 italic px-4">L'établissement sera masqué des interfaces commerciales mais l'historique sera conservé en audit.</p>
                <div className="flex gap-4">
                    <button onClick={() => setModal({ type: null, item: null })} className="flex-1 py-4 bg-slate-50 text-slate-400 rounded-xl font-black text-[10px] uppercase tracking-widest active:scale-95">Garder</button>
                    <button onClick={handleDelete} disabled={isSubmitting} className="flex-1 py-4 bg-rose-600 text-white rounded-xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-rose-200 active:scale-95">Confirmer</button>
                </div>
             </div>
        </div>
      )}
    </div>
  );
}

function ClientKPI({ label, value, icon, color }: any) {
    return (
        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm flex items-center gap-6 group hover:shadow-lg transition-all relative overflow-hidden border-b-2 border-b-slate-100/50">
            <div className={`w-14 h-14 rounded-xl ${color} flex items-center justify-center text-white text-3xl shadow-xl transition-transform group-hover:rotate-12`}>
                <i className={`ti ${icon}`}></i>
            </div>
            <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-[3px] mb-1.5">{label}</p>
                <p className="text-2xl font-black text-slate-800 tracking-tighter leading-none">{value}</p>
            </div>
            <div className={`absolute -right-6 -bottom-6 w-24 h-24 ${color} opacity-5 rounded-full blur-2xl`}></div>
        </div>
    );
}

function TabBtn({ active, onClick, icon, label }: any) {
    return (
        <button onClick={onClick} className={`flex items-center gap-3 px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all duration-300 ${active ? 'bg-white text-blue-600 shadow-xl translate-y-[-2px]' : 'text-slate-400 hover:text-slate-600 hover:bg-white/50'}`}><i className={`ti ${icon} text-lg`}></i>{label}</button>
    )
}

function KPICard360({ label, value, icon, color, suffix }: any) {
    return (
        <div className={`bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex items-center gap-5 group transition-all hover:shadow-lg hover:translate-y-[-4px]`}>
            <div className={`w-12 h-12 rounded-lg ${color} flex items-center justify-center text-xl text-white shadow-xl transition-transform group-hover:rotate-12`}>
                <i className={`ti ${icon}`}></i>
            </div>
            <div className="overflow-hidden">
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1.5 truncate">{label}</p>
                <div className="flex items-baseline gap-1">
                    <p className="text-xl font-black text-slate-800 tracking-tighter leading-none truncate">{value}</p>
                    {suffix && <span className="text-[10px] font-black text-slate-300 uppercase">{suffix}</span>}
                </div>
            </div>
        </div>
    )
}