
import React from 'react';
import { useApp } from '../App';

export default function Documentation() {
  const { t } = useApp();

  const features = [
    { title: t.feature_1_title, desc: t.feature_1_desc, icon: '⚙️' },
    { title: t.feature_2_title, desc: t.feature_2_desc, icon: '🤖' },
    { title: t.feature_3_title, desc: t.feature_3_desc, icon: '🤝' },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-12 py-10">
      <section className="text-center space-y-4">
        <h1 className="text-5xl font-extrabold text-slate-900 tracking-tight">Specta Portal Documentation</h1>
        <p className="text-xl text-slate-600 leading-relaxed max-w-2xl mx-auto">
          {t.documentation_intro}
        </p>
      </section>

      <div className="grid md:grid-cols-3 gap-8">
        {features.map((f, i) => (
          <div key={i} className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
            <div className="text-4xl mb-4">{f.icon}</div>
            <h3 className="text-xl font-bold text-slate-800 mb-2">{f.title}</h3>
            <p className="text-slate-500 text-sm leading-relaxed">{f.desc}</p>
          </div>
        ))}
      </div>

      <section className="bg-blue-600 rounded-[3rem] p-12 text-white relative overflow-hidden">
        <div className="relative z-10 space-y-6">
          <h2 className="text-3xl font-bold">Technological Excellence</h2>
          <p className="text-blue-100 max-w-xl">
            Powered by React 18, Laravel Backend, and Google Gemini AI. Specta ensures your medical facility never stays offline with proactive maintenance diagnostics.
          </p>
          <div className="flex gap-4">
             <div className="px-4 py-2 bg-white/20 backdrop-blur-md rounded-full text-sm font-medium">B2B Core</div>
             <div className="px-4 py-2 bg-white/20 backdrop-blur-md rounded-full text-sm font-medium">AI Driven</div>
             <div className="px-4 py-2 bg-white/20 backdrop-blur-md rounded-full text-sm font-medium">Multilingual</div>
          </div>
        </div>
        <div className="absolute right-[-10%] top-[-10%] w-96 h-96 bg-blue-400 rounded-full opacity-20 blur-3xl"></div>
      </section>
    </div>
  );
}
