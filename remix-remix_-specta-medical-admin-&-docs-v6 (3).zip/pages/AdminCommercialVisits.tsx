import React, { useState, useEffect, useMemo } from 'react';
import { api } from '../api';
import { useApp } from '../App';
import { Link } from 'react-router-dom';
import * as XLSX from 'xlsx';

export interface CommercialVisitRequest {
  id: number;
  client_id?: number | null;
  client_name: string;
  client_type: 'Client' | 'Laboratoire' | 'Cabinet Médical' | 'Centre Dentaire' | 'Hôpital' | 'Pharmacie' | 'Autre';
  contact_name: string;
  contact_phone: string;
  contact_email?: string;
  city: string;
  address: string;
  motif: string;
  preferred_date: string;
  preferred_time_slot?: 'Matin (09h-12h)' | 'Après-midi (14h-18h)' | 'Toute la journée';
  priority: 'Normale' | 'Haute' | 'Urgente';
  status: 'en_attente' | 'assignee' | 'planifiee' | 'realisee' | 'annulee';
  // Commercial Assignment details
  commercial_id: number | null;
  commercial_name: string | null;
  commercial_phone?: string | null;
  commercial_email?: string | null;
  assigned_at?: string | null;
  notes?: string;
  equipment_of_interest?: string;
  created_at: string;
}

const STORAGE_KEY = 'specta_commercial_visit_requests';

// Initial Moroccan medical visit requests dataset
const INITIAL_VISIT_REQUESTS: CommercialVisitRequest[] = [
  {
    id: 101,
    client_id: 1,
    client_name: "Clinique Atlas Casablanca",
    client_type: "Client",
    contact_name: "Dr. Mehdi Bennani",
    contact_phone: "+212 661-458920",
    contact_email: "direction@cliniqueatlas.ma",
    city: "Casablanca",
    address: "Angle Bd Zerktouni & Rue d'Alger, Maarif",
    motif: "Démonstration Scanner Intra-Oral 3D & Devis Fauteuil Chirurgical",
    preferred_date: "2026-09-18",
    preferred_time_slot: "Matin (09h-12h)",
    priority: "Urgente",
    status: "en_attente",
    commercial_id: null,
    commercial_name: null,
    notes: "Souhaite équiper 2 nouvelles salles de soins avant la fin du trimestre. Décision rapide attendue.",
    equipment_of_interest: "Scanner 3D Specta-Pro & Fauteuil Omnia X5",
    created_at: "2026-09-15 10:30"
  },
  {
    id: 102,
    client_id: 2,
    client_name: "Laboratoire BioAnalyses Rabat",
    client_type: "Laboratoire",
    contact_name: "Dr. Salma Berrada",
    contact_phone: "+212 662-314050",
    contact_email: "s.berrada@bioanalyses.ma",
    city: "Rabat",
    address: "Avenue Allal Ben Abdellah, Hassan",
    motif: "Présentation des réactifs hématologie et conditions tarifaires volume",
    preferred_date: "2026-09-19",
    preferred_time_slot: "Après-midi (14h-18h)",
    priority: "Haute",
    status: "assignee",
    commercial_id: 12,
    commercial_name: "Yassine El Amrani",
    commercial_phone: "+212 661-998877",
    commercial_email: "yassine@specta.ma",
    assigned_at: "2026-09-15 14:00",
    notes: "Consommation mensuelle élevée de réactifs. Intéressée par contrat annuel d'approvisionnement.",
    equipment_of_interest: "Consommables & Réactifs d'Analyses",
    created_at: "2026-09-14 16:15"
  },
  {
    id: 103,
    client_id: 3,
    client_name: "Centre Dentaire Al Madina Marrakech",
    client_type: "Centre Dentaire",
    contact_name: "Dr. Amine Chraibi",
    contact_phone: "+212 663-889900",
    contact_email: "a.chraibi@almadinadental.ma",
    city: "Marrakech",
    address: "Bd Mohammed VI, Hivernage",
    motif: "Demande de visite pour audit du matériel actuel et renouvellement stérilisation",
    preferred_date: "2026-09-20",
    preferred_time_slot: "Matin (09h-12h)",
    priority: "Urgente",
    status: "en_attente",
    commercial_id: null,
    commercial_name: null,
    notes: "Autoclave défaillant, urgence de remplacement par un modèle Classe B certifié.",
    equipment_of_interest: "Autoclave Médical Classe B 24L",
    created_at: "2026-09-16 08:45"
  },
  {
    id: 104,
    client_id: 4,
    client_name: "Cabinet Médical Spécialisé Tanger",
    client_type: "Cabinet Médical",
    contact_name: "Dr. Othmane Lahlou",
    contact_phone: "+212 664-112233",
    contact_email: "cabinet.lahlou@gmail.com",
    city: "Tanger",
    address: "Place des Nations, Centre Ville",
    motif: "Présentation des nouveaux consommables d'imagerie et gels d'échographie",
    preferred_date: "2026-09-22",
    preferred_time_slot: "Après-midi (14h-18h)",
    priority: "Normale",
    status: "assignee",
    commercial_id: 14,
    commercial_name: "Fatima Zahra Tazi",
    commercial_phone: "+212 663-445566",
    commercial_email: "fz.tazi@specta.ma",
    assigned_at: "2026-09-14 11:20",
    notes: "Client régulier, demande d'échantillons de test.",
    equipment_of_interest: "Gels conducteurs & Sondes",
    created_at: "2026-09-13 14:00"
  },
  {
    id: 105,
    client_id: null,
    client_name: "Polyclinique Sud Agadir (Prospect)",
    client_type: "Client",
    contact_name: "M. Nabil Kabbaj (Dir. Achats)",
    contact_phone: "+212 665-778899",
    contact_email: "achats@polycliniquesud.ma",
    city: "Agadir",
    address: "Quartier Dakhla, Nouveau Centre Médical",
    motif: "Projet d'ouverture de 4 blocs opératoires - Appel d'offre et démonstration machines",
    preferred_date: "2026-09-24",
    preferred_time_slot: "Toute la journée",
    priority: "Urgente",
    status: "en_attente",
    commercial_id: null,
    commercial_name: null,
    notes: "Très gros potentiel de commande machines & consommables. Nécessite un commercial sénior.",
    equipment_of_interest: "Parc complet blocs opératoires & moniteurs multiparamétriques",
    created_at: "2026-09-16 09:10"
  },
  {
    id: 106,
    client_id: 5,
    client_name: "Hôpital Privé Fès Méditerranée",
    client_type: "Hôpital",
    contact_name: "Dr. Houda Idrissi",
    contact_phone: "+212 661-223344",
    contact_email: "h.idrissi@hopitalfes.ma",
    city: "Fès",
    address: "Route de Sefrou, Ville Nouvelle",
    motif: "Négociation de remise sur devis en cours DEV-2026-089",
    preferred_date: "2026-09-17",
    preferred_time_slot: "Matin (09h-12h)",
    priority: "Haute",
    status: "planifiee",
    commercial_id: 12,
    commercial_name: "Yassine El Amrani",
    commercial_phone: "+212 661-998877",
    commercial_email: "yassine@specta.ma",
    assigned_at: "2026-09-15 09:00",
    notes: "Visite confirmée pour jeudi matin à 10h00.",
    equipment_of_interest: "Équipement Réanimation & Fluides Médicaux",
    created_at: "2026-09-12 11:30"
  },
  {
    id: 107,
    client_id: 6,
    client_name: "Centre de Radiologie Zerktouni",
    client_type: "Cabinet Médical",
    contact_name: "Dr. Karim Slaoui",
    contact_phone: "+212 667-889900",
    contact_email: "k.slaoui@zerktouni-radio.ma",
    city: "Casablanca",
    address: "Boulevard Zerktouni, Val Fleuri",
    motif: "Démonstration logiciel d'archivage PACS & acquisition de capteurs",
    preferred_date: "2026-09-21",
    preferred_time_slot: "Après-midi (14h-18h)",
    priority: "Normale",
    status: "en_attente",
    commercial_id: null,
    commercial_name: null,
    notes: "Le médecin est disponible uniquement après 16h.",
    equipment_of_interest: "Capteurs numériques CMOS HD",
    created_at: "2026-09-16 02:20"
  },
  {
    id: 108,
    client_id: 7,
    client_name: "Clinique La Corniche Kénitra",
    client_type: "Client",
    contact_name: "Mme. Ghita Tlemçani",
    contact_phone: "+212 662-776655",
    contact_email: "admin@lacorniche-kenitra.ma",
    city: "Kénitra",
    address: "Bd Hassan II, Proche Gare TGV",
    motif: "Visite annuelle de revue de contrat et présentation catalogue machines 2026",
    preferred_date: "2026-09-10",
    preferred_time_slot: "Matin (09h-12h)",
    priority: "Normale",
    status: "realisee",
    commercial_id: 12,
    commercial_name: "Yassine El Amrani",
    commercial_phone: "+212 661-998877",
    commercial_email: "yassine@specta.ma",
    assigned_at: "2026-09-08 10:00",
    notes: "Visite réalisée avec succès. Devis transmis pour 2 bistouris électriques.",
    equipment_of_interest: "Bistouris Haute Fréquence",
    created_at: "2026-09-05 15:20"
  }
];

// Helper to normalize data from Route::get('commercial-visits/all', [CommercialVisitController::class, 'getAll'])
export function normalizeCommercialVisit(item: any, commercialsList: any[] = []): CommercialVisitRequest {
  let commId = item.commercial_id ?? item.user_id ?? item.commercial?.id ?? null;
  let matchedComm = commId ? commercialsList.find(c => Number(c.id) === Number(commId)) : null;
  let commName = item.commercial_name || item.commercial?.name || item.user?.name || matchedComm?.name || null;

  // Si le commercial assigné est un Super Admin, on considère que la demande n'est pas encore assignée à un vrai commercial
  if (commName && commName.toLowerCase().includes('super admin')) {
    commId = null;
    matchedComm = null;
    commName = null;
  }

  const rawStatus = String(item.status || '').toLowerCase();
  let status: CommercialVisitRequest['status'] = 'en_attente';
  if (['pending', 'en_attente', 'nouveau', 'new', 'draft', 'created'].includes(rawStatus)) {
    status = 'en_attente';
  } else if (['assigned', 'assignee', 'assignée', 'affectee', 'affectée'].includes(rawStatus)) {
    status = 'assignee';
  } else if (['planned', 'planifiee', 'planifiée', 'scheduled', 'in_progress'].includes(rawStatus)) {
    status = 'planifiee';
  } else if (['completed', 'realisee', 'réalisée', 'done', 'finished', 'closed'].includes(rawStatus)) {
    status = 'realisee';
  } else if (['cancelled', 'annulee', 'annulée', 'canceled', 'rejected'].includes(rawStatus)) {
    status = 'annulee';
  } else if (commId) {
    status = 'assignee';
  }

  const rawPrio = String(item.priority || item.urgency || '').toLowerCase();
  let priority: CommercialVisitRequest['priority'] = 'Normale';
  if (['urgent', 'urgente', 'high', 'critique'].includes(rawPrio)) {
    priority = 'Urgente';
  } else if (['haute', 'medium', 'moyenne'].includes(rawPrio)) {
    priority = 'Haute';
  }

  const clientName = item.client_name || item.client?.name || item.company_name || item.company || 'Client Professionnel';
  const contactName = item.contact_name || item.client?.contact_name || item.contact_person || item.client?.name || clientName;
  const contactPhone = item.contact_phone || item.phone || item.mobile || item.client?.phone || item.client?.mobile || '';
  const contactEmail = item.contact_email || item.email || item.client?.email || '';
  const city = item.city || item.client?.city || 'Casablanca';
  const address = item.address || item.client?.address || '';
  const motif = item.motif || item.purpose || item.reason || item.subject || item.notes || item.title || 'Demande de visite médicale';

  let preferredDate = item.preferred_date || item.visit_date || item.date;
  if (!preferredDate && item.planned_at) {
    preferredDate = String(item.planned_at).split('T')[0].split(' ')[0];
  }
  if (!preferredDate) {
    preferredDate = new Date().toISOString().split('T')[0];
  }

  const preferredTimeSlot = item.preferred_time_slot || item.time_slot || item.slot || 'Matin (09h-12h)';

  return {
    id: Number(item.id) || Date.now(),
    client_id: item.client_id ? Number(item.client_id) : (item.client?.id ? Number(item.client.id) : null),
    client_name: clientName,
    client_type: (item.client_type || item.client?.type || item.client?.category || 'Client') as any,
    contact_name: contactName,
    contact_phone: contactPhone,
    contact_email: contactEmail || undefined,
    city: city,
    address: address,
    motif: motif,
    preferred_date: preferredDate,
    preferred_time_slot: preferredTimeSlot as any,
    priority: priority,
    status: status,
    commercial_id: commId ? Number(commId) : null,
    commercial_name: commName,
    commercial_phone: commId ? (item.commercial_phone || item.commercial?.phone || item.commercial?.mobile || matchedComm?.phone || null) : null,
    commercial_email: commId ? (item.commercial_email || item.commercial?.email || matchedComm?.email || null) : null,
    assigned_at: item.assigned_at || (commId ? (item.updated_at || item.created_at || new Date().toISOString()) : null),
    notes: item.notes || item.comment || item.description || '',
    equipment_of_interest: item.equipment_of_interest || item.equipment || item.machine || '',
    created_at: item.requested_at || (item.created_at ? String(item.created_at).replace('T', ' ').substring(0, 19) : new Date().toISOString().replace('T', ' ').substring(0, 19))
  };
}

export default function AdminCommercialVisits() {
  const { user } = useApp();
  const [requests, setRequests] = useState<CommercialVisitRequest[]>([]);
  const [commercials, setCommercials] = useState<any[]>([]);
  const [clients, setClients] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [apiStatus, setApiStatus] = useState<'loading' | 'connected' | 'fallback'>('loading');
  const [lastSyncedAt, setLastSyncedAt] = useState<string | null>(null);

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [commercialAssignmentFilter, setCommercialAssignmentFilter] = useState<'all' | 'unassigned' | 'assigned'>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [cityFilter, setCityFilter] = useState<string>('all');
  const [selectedCommercialId, setSelectedCommercialId] = useState<string>('all');

  // Modals
  const [assignModal, setAssignModal] = useState<{ open: boolean; request: CommercialVisitRequest | null }>({ open: false, request: null });
  const [newRequestModal, setNewRequestModal] = useState(false);
  const [detailsModal, setDetailsModal] = useState<CommercialVisitRequest | null>(null);
  const [selectedCommercialToAssign, setSelectedCommercialToAssign] = useState<string>('');
  const [syncWithClientProfile, setSyncWithClientProfile] = useState(true);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // New Request Form state
  const [newForm, setNewForm] = useState({
    clientId: '',
    clientName: '',
    clientType: 'Client',
    contactName: '',
    contactPhone: '',
    contactEmail: '',
    city: 'Casablanca',
    address: '',
    motif: '',
    equipmentOfInterest: '',
    preferredDate: new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0],
    preferredTimeSlot: 'Matin (09h-12h)',
    priority: 'Haute',
    notes: '',
    assignedCommercialId: ''
  });

  // Load Data
  useEffect(() => {
    fetchInitialData();
  }, []);

  const fetchInitialData = async () => {
    setLoading(true);
    setApiStatus('loading');
    try {
      // 1. Fetch Commercials & Clients from API
      const [uRes, cRes] = await Promise.allSettled([
        api.users.list('role_id=3'),
        api.clients.list('per_page=1000')
      ]);

      let commList: any[] = [];
      if (uRes.status === 'fulfilled') {
        commList = Array.isArray(uRes.value?.data) ? uRes.value.data : (Array.isArray(uRes.value) ? uRes.value : []);
      }
      
      // Fallback default commercials if none found
      if (commList.length === 0) {
        commList = [
          { id: 11, name: "Karim Bennani", email: "karim@specta.ma", phone: "+212 661-123456", city: "Casablanca" },
          { id: 12, name: "Yassine El Amrani", email: "yassine@specta.ma", phone: "+212 661-998877", city: "Rabat" },
          { id: 13, name: "Hicham Mansouri", email: "hicham@specta.ma", phone: "+212 662-554433", city: "Marrakech" },
          { id: 14, name: "Fatima Zahra Tazi", email: "fz.tazi@specta.ma", phone: "+212 663-445566", city: "Tanger" }
        ];
      }
      setCommercials(commList);

      let clientList: any[] = [];
      if (cRes.status === 'fulfilled') {
        clientList = Array.isArray(cRes.value?.data) ? cRes.value.data : (Array.isArray(cRes.value) ? cRes.value : []);
      }
      setClients(clientList);

      // 2. Fetch Commercial Visits from API: Route::get('commercial-visits/all', [CommercialVisitController::class, 'getAll'])
      try {
        const vRes = await api.commercialVisits.getAll();
        
        // Handle Laravel paginated response structure: { status: true, data: { current_page: 1, data: [...] } }
        let rawVisits = null;
        if (vRes?.data?.data && Array.isArray(vRes.data.data)) {
          rawVisits = vRes.data.data;
        } else if (Array.isArray(vRes?.data)) {
          rawVisits = vRes.data;
        } else if (Array.isArray(vRes)) {
          rawVisits = vRes;
        } else if (Array.isArray(vRes?.visits)) {
          rawVisits = vRes.visits;
        }

        if (rawVisits !== null) {
          const normalized: CommercialVisitRequest[] = rawVisits.map((item: any) => normalizeCommercialVisit(item, commList));
          setRequests(normalized);
          setApiStatus('connected');
          setLastSyncedAt(new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }));
          localStorage.setItem(STORAGE_KEY, JSON.stringify(normalized));
          return;
        }
      } catch (apiErr: any) {
        console.warn("API commercial-visits/all non accessible en direct, bascule sur les données locales:", apiErr);
      }

      // If API didn't return data (e.g. unauthenticated or offline preview), fall back to local storage
      setApiStatus('fallback');
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length > 0) {
            setRequests(parsed);
            return;
          }
        } catch {
          // fallback to seed
        }
      }

      // Seed initial requests
      localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_VISIT_REQUESTS));
      setRequests(INITIAL_VISIT_REQUESTS);
    } catch {
      setApiStatus('fallback');
      setRequests(INITIAL_VISIT_REQUESTS);
    } finally {
      setLoading(false);
    }
  };

  const saveRequests = (updated: CommercialVisitRequest[]) => {
    setRequests(updated);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  };

  const showFeedback = (text: string, type: 'success' | 'error' = 'success') => {
    setFeedback({ type, text });
    setTimeout(() => setFeedback(null), 4000);
  };

  // KPIs
  const stats = useMemo(() => {
    const total = requests.length;
    const unassigned = requests.filter(r => !r.commercial_id).length;
    const assigned = requests.filter(r => !!r.commercial_id).length;
    const planned = requests.filter(r => r.status === 'planifiee').length;
    const completed = requests.filter(r => r.status === 'realisee').length;
    const urgent = requests.filter(r => r.priority === 'Urgente' && !r.commercial_id).length;

    return { total, unassigned, assigned, planned, completed, urgent };
  }, [requests]);

  // Unique cities list for filter
  const citiesList = useMemo(() => {
    const set = new Set<string>();
    requests.forEach(r => { if (r.city) set.add(r.city); });
    return Array.from(set).sort();
  }, [requests]);

  // Filtered List
  const filteredRequests = useMemo(() => {
    return requests.filter(req => {
      // 1. Search
      if (searchTerm) {
        const term = searchTerm.toLowerCase();
        const matches = 
          req.client_name.toLowerCase().includes(term) ||
          req.contact_name.toLowerCase().includes(term) ||
          req.city.toLowerCase().includes(term) ||
          req.contact_phone.includes(term) ||
          req.motif.toLowerCase().includes(term) ||
          (req.commercial_name && req.commercial_name.toLowerCase().includes(term));
        if (!matches) return false;
      }

      // 2. Commercial Assignment Filter
      if (commercialAssignmentFilter === 'unassigned' && req.commercial_id !== null) return false;
      if (commercialAssignmentFilter === 'assigned' && req.commercial_id === null) return false;

      // 3. Status Filter
      if (statusFilter !== 'all' && req.status !== statusFilter) return false;

      // 4. Priority Filter
      if (priorityFilter !== 'all' && req.priority !== priorityFilter) return false;

      // 5. City Filter
      if (cityFilter !== 'all' && req.city !== cityFilter) return false;

      // 6. Specific Commercial Filter
      if (selectedCommercialId !== 'all') {
        if (selectedCommercialId === 'unassigned' && req.commercial_id !== null) return false;
        if (selectedCommercialId !== 'unassigned' && String(req.commercial_id) !== selectedCommercialId) return false;
      }

      return true;
    });
  }, [requests, searchTerm, commercialAssignmentFilter, statusFilter, priorityFilter, cityFilter, selectedCommercialId]);

  // Handle Assign Commercial
  const handleConfirmAssignment = async () => {
    if (!assignModal.request) return;
    
    const req = assignModal.request;
    const commId = selectedCommercialToAssign ? Number(selectedCommercialToAssign) : null;
    const comm = commercials.find(c => c.id === commId);

    const updated = requests.map(r => {
      if (r.id === req.id) {
        return {
          ...r,
          commercial_id: commId,
          commercial_name: comm ? comm.name : null,
          commercial_phone: comm?.phone || null,
          commercial_email: comm?.email || null,
          assigned_at: commId ? new Date().toISOString().replace('T', ' ').substring(0, 16) : null,
          status: commId ? (r.status === 'en_attente' ? 'assignee' : r.status) : 'en_attente'
        } as CommercialVisitRequest;
      }
      return r;
    });

    saveRequests(updated);

    // Sync with API
    try {
      if (commId) {
        await api.commercialVisits.assign(req.id, { commercial_id: commId, notes: req.notes });
      } else {
        await api.commercialVisits.update(req.id, { commercial_id: null, status: 'en_attente' });
      }
    } catch {
      // Continue gracefully
    }

    // Sync with client profile if requested and client exists
    if (syncWithClientProfile && req.client_id && commId) {
      try {
        const client = clients.find(c => Number(c.id) === Number(req.client_id));
        if (client) {
          await api.clients.update(req.client_id, {
            ...client,
            commercial_id: commId
          });
        }
      } catch (err: any) {
        console.error("Erreur lors de la synchronisation du client:", err);
      }
    }

    setAssignModal({ open: false, request: null });
    showFeedback(
      commId 
        ? `Visite pour "${req.client_name}" attribuée avec succès au commercial ${comm?.name} !` 
        : `L'affectation a été retirée. La demande est passée en "Sans Commercial".`
    );
  };

  // Quick Status Update
  const handleStatusChange = async (id: number, newStatus: CommercialVisitRequest['status']) => {
    const updated = requests.map(r => r.id === id ? { ...r, status: newStatus } : r);
    saveRequests(updated);
    try {
      await api.commercialVisits.updateStatus(id, newStatus);
    } catch {
      // Fallback
    }
    showFeedback(`Statut de la demande #${id} mis à jour avec succès.`);
  };

  // Handle Delete Request
  const handleDelete = async (id: number) => {
    if (!window.confirm(`Êtes-vous sûr de vouloir supprimer cette demande de visite ?`)) return;
    const updated = requests.filter(r => r.id !== id);
    saveRequests(updated);
    try {
      await api.commercialVisits.delete(id);
    } catch {
      // Fallback
    }
    showFeedback(`Demande de visite #${id} supprimée.`);
  };

  // Autofill client in new request modal
  const handleSelectClient = (clientIdStr: string) => {
    const clientId = Number(clientIdStr);
    const client = clients.find(c => c.id === clientId);
    if (client) {
      setNewForm(prev => ({
        ...prev,
        clientId: String(client.id),
        clientName: client.name || '',
        clientType: (client.type || client.category || 'Client') as any,
        contactName: client.contact_name || client.name || '',
        contactPhone: client.phone || '',
        contactEmail: client.email || '',
        city: client.city || 'Casablanca',
        address: client.address || '',
        assignedCommercialId: client.commercial_id ? String(client.commercial_id) : ''
      }));
    } else {
      setNewForm(prev => ({ ...prev, clientId: '' }));
    }
  };

  // Submit New Request
  const handleCreateRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newForm.clientName.trim() || !newForm.contactPhone.trim() || !newForm.motif.trim()) {
      alert("Veuillez renseigner au moins le nom du client, son téléphone et le motif de la visite.");
      return;
    }

    const assignedComm = newForm.assignedCommercialId ? commercials.find(c => c.id === Number(newForm.assignedCommercialId)) : null;

    let newId = Date.now();
    const payload = {
      client_id: newForm.clientId ? Number(newForm.clientId) : null,
      client_name: newForm.clientName.trim(),
      client_type: newForm.clientType as any,
      contact_name: newForm.contactName.trim() || newForm.clientName.trim(),
      contact_phone: newForm.contactPhone.trim(),
      contact_email: newForm.contactEmail.trim() || undefined,
      city: newForm.city || 'Casablanca',
      address: newForm.address.trim(),
      motif: newForm.motif.trim(),
      equipment_of_interest: newForm.equipmentOfInterest.trim() || undefined,
      priority: newForm.priority as any,
      status: assignedComm ? 'assignee' : 'en_attente',
      commercial_id: assignedComm ? assignedComm.id : null,
      notes: newForm.notes.trim() || undefined
    };

    try {
      const res = await api.commercialVisits.create(payload);
      if (res?.data?.id || res?.id) {
        newId = Number(res?.data?.id || res?.id);
      }
    } catch {
      // Offline fallback
    }

    const newRequest: CommercialVisitRequest = {
      ...payload,
      id: newId,
      preferred_date: new Date().toISOString().split('T')[0],
      preferred_time_slot: 'Matin (09h-12h)' as any,
      commercial_name: assignedComm ? assignedComm.name : null,
      commercial_phone: assignedComm?.phone || null,
      commercial_email: assignedComm?.email || null,
      assigned_at: assignedComm ? new Date().toISOString().replace('T', ' ').substring(0, 16) : null,
      created_at: new Date().toISOString().replace('T', ' ').substring(0, 16)
    };

    const updated = [newRequest, ...requests];
    saveRequests(updated);
    setNewRequestModal(false);
    showFeedback(`Nouvelle demande de visite pour "${newRequest.client_name}" enregistrée !`);

    // Reset form
    setNewForm({
      clientId: '',
      clientName: '',
      clientType: 'Client',
      contactName: '',
      contactPhone: '',
      contactEmail: '',
      city: 'Casablanca',
      address: '',
      motif: '',
      equipmentOfInterest: '',
      preferredDate: new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0],
      preferredTimeSlot: 'Matin (09h-12h)',
      priority: 'Haute',
      notes: '',
      assignedCommercialId: ''
    });
  };

  // Export to Excel
  const handleExportExcel = () => {
    const exportData = filteredRequests.map(r => ({
      "ID": r.id,
      "Client": r.client_name,
      "Type Établissement": r.client_type,
      "Contact": r.contact_name,
      "Téléphone": r.contact_phone,
      "Email": r.contact_email || '',
      "Ville": r.city,
      "Adresse": r.address,
      "Motif de la Visite": r.motif,
      "Matériel ciblé": r.equipment_of_interest || '',
      "Date de Demande": r.created_at,
      "Priorité": r.priority,
      "Statut": r.status,
      "Commercial Assigné": r.commercial_name || "SANS COMMERCIAL",
      "ID Commercial": r.commercial_id || "NON ASSIGNÉ",
      "Date Affectation": r.assigned_at || '',
      "Notes": r.notes || '',
      "Date Demande": r.created_at
    }));

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Demandes de Visite");
    XLSX.writeFile(workbook, `Demandes_Visite_Specta_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-16">
      {/* 1. TOP HEADER */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 bg-white p-8 rounded-3xl border border-slate-100 shadow-sm relative overflow-hidden">
        <div className="space-y-2">
          <div className="flex flex-wrap items-center gap-3">
            <span className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center text-xl shadow-inner border border-blue-100">
              <i className="ti ti-calendar-event"></i>
            </span>
            <span className="text-[10px] font-black text-blue-600 uppercase tracking-[2px] bg-blue-50 px-3 py-1 rounded-full border border-blue-100">
              Pôle Commercial & Terrain
            </span>
            <div className="flex items-center gap-2 px-3 py-1 bg-slate-50 border border-slate-200 rounded-full text-[10px] font-bold text-slate-600 shadow-xs">
              <span className={`w-2 h-2 rounded-full ${apiStatus === 'connected' ? 'bg-emerald-500 animate-pulse' : (apiStatus === 'loading' ? 'bg-amber-400 animate-spin' : 'bg-emerald-500')}`}></span>
              <span className="font-mono">commercial-visits/all</span>
              {lastSyncedAt && <span className="text-slate-400 font-normal">({lastSyncedAt})</span>}
            </div>
          </div>
          <h1 className="text-2xl lg:text-3xl font-black text-slate-900 tracking-tight flex items-center gap-2.5">
            <span>Demandes de Visite Clients</span>
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse shrink-0 inline-block shadow-sm" title="Flux actif de demandes de visite"></span>
          </h1>
          <p className="text-slate-500 text-sm max-w-2xl font-medium">
            Supervisez toutes les sollicitations de visite des établissements de santé. Détectez immédiatement les demandes sans commercial pour leur assigner un responsable de secteur.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={fetchInitialData}
            disabled={loading}
            className="px-4 py-3 bg-slate-50 hover:bg-slate-100 text-slate-600 rounded-2xl border border-slate-200 text-xs font-bold transition-all flex items-center gap-2 active:scale-95 disabled:opacity-50"
            title="Rafraîchir depuis l'API"
          >
            <i className={`ti ti-refresh ${loading ? 'animate-spin' : ''}`}></i>
            <span>Actualiser</span>
          </button>

          <button
            onClick={handleExportExcel}
            className="px-4 py-3 bg-slate-50 hover:bg-slate-100 text-slate-700 rounded-2xl border border-slate-200 text-xs font-bold transition-all flex items-center gap-2 active:scale-95"
          >
            <i className="ti ti-file-spreadsheet text-emerald-600 text-base"></i>
            <span>Exporter Excel</span>
          </button>

          <button
            onClick={() => setNewRequestModal(true)}
            className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl text-xs font-black uppercase tracking-wider transition-all shadow-lg shadow-blue-600/20 flex items-center gap-2 active:scale-95"
          >
            <i className="ti ti-plus text-base"></i>
            <span>Nouvelle Demande</span>
          </button>
        </div>
      </div>

      {/* FEEDBACK TOAST */}
      {feedback && (
        <div className={`p-4 rounded-2xl border flex items-center justify-between text-xs font-bold shadow-sm animate-in slide-in-from-top duration-300 ${
          feedback.type === 'success' ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-rose-50 text-rose-800 border-rose-200'
        }`}>
          <div className="flex items-center gap-3">
            <i className={`ti ${feedback.type === 'success' ? 'ti-check text-emerald-600' : 'ti-alert-circle text-rose-600'} text-lg`}></i>
            <span>{feedback.text}</span>
          </div>
          <button onClick={() => setFeedback(null)} className="text-slate-400 hover:text-slate-600">
            <i className="ti ti-x"></i>
          </button>
        </div>
      )}

      {/* 2. STATS / KPI CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Total Demandes */}
        <div 
          onClick={() => setCommercialAssignmentFilter('all')}
          className={`bg-white p-6 rounded-3xl border shadow-sm cursor-pointer transition-all hover:shadow-md ${
            commercialAssignmentFilter === 'all' ? 'border-blue-500 ring-2 ring-blue-500/10' : 'border-slate-100'
          }`}
        >
          <div className="flex items-center justify-between mb-4">
            <span className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center text-xl shadow-inner border border-blue-100">
              <i className="ti ti-calendar-stats"></i>
            </span>
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Global</span>
          </div>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Total Sollicitations</p>
          <div className="flex items-baseline gap-2">
            <h3 className="text-3xl font-black text-slate-900 tracking-tight">{stats.total}</h3>
            <span className="text-xs text-slate-400 font-semibold">demandes</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-2 font-medium">Flux complet de demandes de visite</p>
        </div>

        {/* SANS COMMERCIAL - HIGHLIGHTED WARNING CARD */}
        <div 
          onClick={() => setCommercialAssignmentFilter('unassigned')}
          className={`p-6 rounded-3xl border shadow-sm cursor-pointer transition-all hover:shadow-md relative overflow-hidden ${
            commercialAssignmentFilter === 'unassigned' 
              ? 'bg-rose-50/80 border-rose-500 ring-2 ring-rose-500/20' 
              : 'bg-rose-50/40 border-rose-200 hover:bg-rose-50/70'
          }`}
        >
          <div className="flex items-center justify-between mb-4">
            <span className="w-12 h-12 rounded-2xl bg-rose-600 text-white flex items-center justify-center text-xl shadow-lg shadow-rose-600/20 animate-pulse">
              <i className="ti ti-user-x"></i>
            </span>
            <span className="px-2.5 py-1 rounded-full bg-rose-100 border border-rose-200 text-rose-700 text-[10px] font-black uppercase tracking-wider flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-600 animate-ping"></span>
              À Affecter
            </span>
          </div>
          <p className="text-[10px] font-black text-rose-800 uppercase tracking-widest mb-1">Sans Commercial Attribué</p>
          <div className="flex items-baseline gap-2">
            <h3 className="text-3xl font-black text-rose-600 tracking-tight">{stats.unassigned}</h3>
            <span className="text-xs text-rose-700 font-bold">clients en attente</span>
          </div>
          <p className="text-[11px] text-rose-700 mt-2 font-medium">
            {stats.urgent > 0 ? `⚠️ Dont ${stats.urgent} demande(s) urgente(s) !` : "Cliquez pour filtrer les visites orphelines"}
          </p>
        </div>

        {/* AVEC COMMERCIAL */}
        <div 
          onClick={() => setCommercialAssignmentFilter('assigned')}
          className={`bg-white p-6 rounded-3xl border shadow-sm cursor-pointer transition-all hover:shadow-md ${
            commercialAssignmentFilter === 'assigned' ? 'border-emerald-500 ring-2 ring-emerald-500/10' : 'border-slate-100'
          }`}
        >
          <div className="flex items-center justify-between mb-4">
            <span className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-xl shadow-inner border border-emerald-100">
              <i className="ti ti-user-check"></i>
            </span>
            <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">
              {stats.total > 0 ? `${Math.round((stats.assigned / stats.total) * 100)}%` : '0%'}
            </span>
          </div>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Avec Commercial Assigné</p>
          <div className="flex items-baseline gap-2">
            <h3 className="text-3xl font-black text-slate-900 tracking-tight">{stats.assigned}</h3>
            <span className="text-xs text-slate-400 font-semibold">suivis par un délégué</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-2 font-medium">Prise en charge active par la force de vente</p>
        </div>

        {/* VISITES RÉALISÉES */}
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <span className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-xl shadow-inner border border-indigo-100">
              <i className="ti ti-checkbox"></i>
            </span>
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Terrain</span>
          </div>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Visites Concrétisées</p>
          <div className="flex items-baseline gap-2">
            <h3 className="text-3xl font-black text-slate-900 tracking-tight">{stats.completed}</h3>
            <span className="text-xs text-slate-400 font-semibold">réalisées</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-2 font-medium">{stats.planned} visite(s) déjà planifiées</p>
        </div>
      </div>

      {/* 3. QUICK SEGMENT TABS & DETAILED FILTERS */}
      <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-6">
        {/* Quick Segment Filter Buttons */}
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setCommercialAssignmentFilter('all')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                commercialAssignmentFilter === 'all'
                  ? 'bg-slate-900 text-white shadow-md'
                  : 'bg-slate-50 hover:bg-slate-100 text-slate-600'
              }`}
            >
              <span>Toutes les Demandes</span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                commercialAssignmentFilter === 'all' ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-700'
              }`}>
                {stats.total}
              </span>
            </button>

            <button
              onClick={() => setCommercialAssignmentFilter('unassigned')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                commercialAssignmentFilter === 'unassigned'
                  ? 'bg-rose-600 text-white shadow-md shadow-rose-600/20'
                  : 'bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200'
              }`}
            >
              <i className="ti ti-alert-triangle text-sm"></i>
              <span>🚨 Sans Commercial (À Attribuer)</span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                commercialAssignmentFilter === 'unassigned' ? 'bg-white/20 text-white' : 'bg-rose-200 text-rose-800'
              }`}>
                {stats.unassigned}
              </span>
            </button>

            <button
              onClick={() => setCommercialAssignmentFilter('assigned')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                commercialAssignmentFilter === 'assigned'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200'
              }`}
            >
              <i className="ti ti-check text-sm"></i>
              <span>Avec Commercial Assigné</span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                commercialAssignmentFilter === 'assigned' ? 'bg-white/20 text-white' : 'bg-emerald-200 text-emerald-800'
              }`}>
                {stats.assigned}
              </span>
            </button>
          </div>

          {/* Result counter */}
          <div className="text-xs font-bold text-slate-400">
            Affichage de <span className="text-slate-800 font-black">{filteredRequests.length}</span> sur {requests.length} demandes
          </div>
        </div>

        {/* Detailed Filters Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Search Box */}
          <div className="relative">
            <i className="ti ti-search absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 text-sm"></i>
            <input
              type="text"
              placeholder="Rechercher client, ville, motif, commercial..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-blue-500 focus:bg-white transition-all"
            />
            {searchTerm && (
              <button 
                onClick={() => setSearchTerm('')} 
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs"
              >
                <i className="ti ti-x"></i>
              </button>
            )}
          </div>

          {/* Filter by Specific Commercial */}
          <div>
            <select
              value={selectedCommercialId}
              onChange={(e) => setSelectedCommercialId(e.target.value)}
              className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-blue-500 focus:bg-white transition-all"
            >
              <option value="all">Tous les Commerciaux</option>
              <option value="unassigned">🚨 Sans commercial (Non assigné)</option>
              {commercials.map(c => (
                <option key={c.id} value={String(c.id)}>👤 {c.name}</option>
              ))}
            </select>
          </div>

          {/* Filter by City */}
          <div>
            <select
              value={cityFilter}
              onChange={(e) => setCityFilter(e.target.value)}
              className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-blue-500 focus:bg-white transition-all"
            >
              <option value="all">Toutes les Villes</option>
              {citiesList.map(city => (
                <option key={city} value={city}>{city}</option>
              ))}
            </select>
          </div>

          {/* Filter by Status */}
          <div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-blue-500 focus:bg-white transition-all"
            >
              <option value="all">Tous les Statuts</option>
              <option value="en_attente">⏳ En attente</option>
              <option value="assignee">👤 Assignée au commercial</option>
              <option value="planifiee">📅 Visite Planifiée</option>
              <option value="realisee">✅ Visite Réalisée</option>
              <option value="annulee">❌ Annulée</option>
            </select>
          </div>
        </div>
      </div>

      {/* 4. TABLE VIEW OF VISIT REQUESTS */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        {loading ? (
          <div className="p-16 text-center text-slate-400 font-bold flex flex-col items-center gap-3">
            <i className="ti ti-loader animate-spin text-3xl text-blue-600"></i>
            <span>Chargement des demandes de visite...</span>
          </div>
        ) : filteredRequests.length === 0 ? (
          <div className="p-16 text-center space-y-4">
            <div className="w-16 h-16 rounded-3xl bg-slate-50 text-slate-400 flex items-center justify-center text-3xl mx-auto">
              <i className="ti ti-calendar-off"></i>
            </div>
            <h3 className="text-base font-black text-slate-700">Aucune demande de visite trouvée</h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto font-medium">
              Aucun résultat ne correspond aux filtres sélectionnés. Essayez de réinitialiser la recherche ou créez une nouvelle demande.
            </p>
            <button
              onClick={() => {
                setSearchTerm('');
                setCommercialAssignmentFilter('all');
                setStatusFilter('all');
                setCityFilter('all');
                setSelectedCommercialId('all');
              }}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold"
            >
              Réinitialiser tous les filtres
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/60 text-[10px] font-black text-slate-400 uppercase tracking-wider">
                  <th className="px-6 py-4">Établissement & Client</th>
                  <th className="px-6 py-4">Contact & Coordonnées</th>
                  <th className="px-6 py-4">Commercial Responsable</th>
                  <th className="px-6 py-4">Objet de la Visite</th>
                  <th className="px-6 py-4">Date de Demande</th>
                  <th className="px-6 py-4">Statut</th>
                  <th className="px-6 py-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {filteredRequests.map((req) => {
                  const hasCommercial = !!req.commercial_id;

                  return (
                    <tr 
                      key={req.id} 
                      className={`hover:bg-slate-50/80 transition-colors group ${
                        !hasCommercial ? 'bg-rose-50/20' : ''
                      }`}
                    >
                      {/* 1. Client & Établissement */}
                      <td className="px-6 py-4">
                        <div className="space-y-1 max-w-xs">
                          <div className="flex items-center gap-2">
                            <span className="font-black text-slate-900 text-sm truncate" title={req.client_name}>
                              {req.client_name}
                            </span>
                            {req.priority === 'Urgente' && (
                              <span className="px-2 py-0.5 rounded-md bg-rose-100 text-rose-700 text-[9px] font-black uppercase tracking-wider border border-rose-200 shrink-0 animate-pulse">
                                Urgent
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-2 text-[11px] text-slate-500 font-medium">
                            <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-600 text-[10px] font-bold">
                              {req.client_type}
                            </span>
                            <span className="flex items-center gap-1 text-slate-400">
                              <i className="ti ti-map-pin text-xs"></i>
                              {req.city}
                            </span>
                          </div>
                          {req.address && (
                            <p className="text-[10px] text-slate-400 truncate max-w-[220px]" title={req.address}>
                              {req.address}
                            </p>
                          )}
                        </div>
                      </td>

                      {/* 2. Contact & Téléphone */}
                      <td className="px-6 py-4">
                        <div className="space-y-1">
                          <p className="font-bold text-slate-800">{req.contact_name}</p>
                          <div className="flex items-center gap-2">
                            <a 
                              href={`tel:${req.contact_phone}`} 
                              className="text-blue-600 hover:text-blue-800 font-bold flex items-center gap-1 text-xs"
                            >
                              <i className="ti ti-phone text-xs"></i>
                              {req.contact_phone}
                            </a>
                            <a
                              href={`https://wa.me/${req.contact_phone.replace(/[^0-9]/g, '')}`}
                              target="_blank"
                              rel="noreferrer"
                              className="w-5 h-5 rounded-md bg-emerald-100 text-emerald-700 hover:bg-emerald-200 flex items-center justify-center transition-colors"
                              title="Discuter sur WhatsApp"
                            >
                              <i className="ti ti-brand-whatsapp text-xs"></i>
                            </a>
                          </div>
                          {req.contact_email && (
                            <p className="text-[10px] text-slate-400 truncate max-w-[180px]">{req.contact_email}</p>
                          )}
                        </div>
                      </td>

                      {/* 3. COMMERCIAL ASSIGNÉ (CORE OF THE REQUEST) */}
                      <td className="px-6 py-4">
                        {hasCommercial ? (
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <div className="w-7 h-7 rounded-full bg-blue-100 text-blue-700 font-black text-xs flex items-center justify-center border border-blue-200">
                                {req.commercial_name ? req.commercial_name.charAt(0) : 'C'}
                              </div>
                              <div>
                                <span className="font-black text-slate-900 block text-xs">
                                  {req.commercial_name}
                                </span>
                                <span className="text-[10px] text-emerald-600 font-bold flex items-center gap-1">
                                  <i className="ti ti-check text-xs"></i>
                                  Assigné
                                </span>
                              </div>
                            </div>
                            <button
                              onClick={() => {
                                setSelectedCommercialToAssign(String(req.commercial_id || ''));
                                setAssignModal({ open: true, request: req });
                              }}
                              className="text-[10px] font-bold text-slate-400 hover:text-blue-600 flex items-center gap-1 transition-colors"
                            >
                              <i className="ti ti-arrows-exchange"></i>
                              Changer de commercial
                            </button>
                          </div>
                        ) : (
                          <div className="space-y-2">
                            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-rose-100 text-rose-800 text-[11px] font-black border border-rose-200 animate-pulse">
                              <i className="ti ti-alert-triangle text-xs text-rose-600"></i>
                              <span>SANS COMMERCIAL</span>
                            </div>
                            <div>
                              <button
                                onClick={() => {
                                  setSelectedCommercialToAssign('');
                                  setAssignModal({ open: true, request: req });
                                }}
                                className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-[10px] font-black uppercase tracking-wider transition-all shadow-sm flex items-center gap-1.5 active:scale-95"
                              >
                                <i className="ti ti-user-plus text-xs"></i>
                                <span>Affecter un Commercial</span>
                              </button>
                            </div>
                          </div>
                        )}
                      </td>

                      {/* 4. Objet de la Visite */}
                      <td className="px-6 py-4">
                        <div className="space-y-1 max-w-xs">
                          <p className="font-bold text-slate-800 leading-snug line-clamp-2">
                            {req.motif}
                          </p>
                          {req.equipment_of_interest && (
                            <span className="inline-block px-2 py-0.5 rounded bg-blue-50 text-blue-700 text-[10px] font-bold border border-blue-100">
                              🎯 {req.equipment_of_interest}
                            </span>
                          )}
                        </div>
                      </td>

                      {/* 5. Date Souhaitée */}
                      <td className="px-6 py-4">
                        <div className="space-y-1">
                          <div className="flex items-center gap-1.5 font-black text-slate-800">
                            <i className="ti ti-calendar text-slate-400 text-sm"></i>
                            <span>{req.created_at}</span>
                          </div>
                        </div>
                      </td>

                      {/* 6. Statut */}
                      <td className="px-6 py-4">
                        <div className="space-y-1.5">
                          <select
                            value={req.status}
                            onChange={(e) => handleStatusChange(req.id, e.target.value as any)}
                            className={`px-3 py-1.5 rounded-xl text-[11px] font-black border focus:outline-none transition-all ${
                              req.status === 'realisee'
                                ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                                : req.status === 'planifiee'
                                ? 'bg-blue-50 text-blue-700 border-blue-200'
                                : req.status === 'assignee'
                                ? 'bg-indigo-50 text-indigo-700 border-indigo-200'
                                : req.status === 'annulee'
                                ? 'bg-slate-100 text-slate-500 border-slate-200'
                                : 'bg-amber-50 text-amber-700 border-amber-200'
                            }`}
                          >
                            <option value="en_attente">⏳ En attente</option>
                            <option value="assignee">👤 Assignée</option>
                            <option value="planifiee">📅 Planifiée</option>
                            <option value="realisee">✅ Réalisée</option>
                            <option value="annulee">❌ Annulée</option>
                          </select>
                        </div>
                      </td>

                      {/* 7. Actions */}
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => setDetailsModal(req)}
                            className="p-2 hover:bg-blue-50 text-slate-400 hover:text-blue-600 rounded-xl transition-colors"
                            title="Voir la fiche détaillée"
                          >
                            <i className="ti ti-eye text-base"></i>
                          </button>

                          <Link
                            to={`/admin/devis`}
                            className="p-2 hover:bg-emerald-50 text-slate-400 hover:text-emerald-600 rounded-xl transition-colors"
                            title="Établir un devis pour ce client"
                          >
                            <i className="ti ti-file-invoice text-base"></i>
                          </Link>

                          <button
                            onClick={() => handleDelete(req.id)}
                            className="p-2 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded-xl transition-colors"
                            title="Supprimer la demande"
                          >
                            <i className="ti ti-trash text-base"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ================= MODALS ================= */}

      {/* MODAL 1: ASSIGNER UN COMMERCIAL */}
      {assignModal.open && assignModal.request && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-8 shadow-2xl border border-slate-100 space-y-6 animate-in zoom-in-95">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center text-xl">
                  <i className="ti ti-user-check"></i>
                </span>
                <div>
                  <h3 className="text-lg font-black text-slate-900">Affectation du Commercial</h3>
                  <p className="text-xs text-slate-400 font-medium">Attribuer cette demande de visite terrain</p>
                </div>
              </div>
              <button 
                onClick={() => setAssignModal({ open: false, request: null })}
                className="p-2 text-slate-400 hover:text-slate-600"
              >
                <i className="ti ti-x text-lg"></i>
              </button>
            </div>

            {/* Request Summary Card */}
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/80 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-black text-slate-800 text-sm">{assignModal.request.client_name}</span>
                <span className="px-2 py-0.5 rounded bg-slate-200 text-slate-700 text-[10px] font-bold">
                  {assignModal.request.city}
                </span>
              </div>
              <p className="text-xs text-slate-600 font-medium">{assignModal.request.motif}</p>
              <div className="flex items-center gap-3 text-[11px] text-slate-400">
                <span>Contact: {assignModal.request.contact_name}</span>
                <span>•</span>
                <span>Tél: {assignModal.request.contact_phone}</span>
              </div>
            </div>

            {/* Commercial Selector */}
            <div className="space-y-3">
              <label className="text-xs font-black text-slate-700 uppercase tracking-wider block">
                Sélectionner le Commercial Responsable
              </label>
              <select
                value={selectedCommercialToAssign}
                onChange={(e) => setSelectedCommercialToAssign(e.target.value)}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold text-slate-800 focus:outline-none focus:border-blue-500 focus:bg-white"
              >
                <option value="">-- Aucun commercial (Laisser non assigné) --</option>
                {commercials.map(comm => (
                  <option key={comm.id} value={String(comm.id)}>
                    {comm.name} {comm.city ? `(${comm.city})` : ''} - {comm.phone || comm.email}
                  </option>
                ))}
              </select>
            </div>

            {/* Synchronize with client option */}
            {assignModal.request.client_id && (
              <label className="flex items-start gap-3 p-3 rounded-2xl bg-blue-50/50 border border-blue-100 cursor-pointer">
                <input
                  type="checkbox"
                  checked={syncWithClientProfile}
                  onChange={(e) => setSyncWithClientProfile(e.target.checked)}
                  className="mt-0.5 rounded text-blue-600 focus:ring-blue-500"
                />
                <span className="text-xs text-slate-700 font-medium">
                  Mettre également à jour le commercial référent dans la fiche permanente du client.
                </span>
              </label>
            )}

            {/* Action Buttons */}
            <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setAssignModal({ open: false, request: null })}
                className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl text-xs font-bold"
              >
                Annuler
              </button>
              <button
                type="button"
                onClick={handleConfirmAssignment}
                className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-black uppercase tracking-wider shadow-lg shadow-blue-600/20"
              >
                Confirmer l'affectation
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: NOUVELLE DEMANDE DE VISITE */}
      {newRequestModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-8 shadow-2xl border border-slate-100 space-y-6 max-h-[90vh] overflow-y-auto animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div className="flex items-center gap-3">
                <span className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center text-xl">
                  <i className="ti ti-calendar-plus"></i>
                </span>
                <div>
                  <h3 className="text-lg font-black text-slate-900">Nouvelle Demande de Visite</h3>
                  <p className="text-xs text-slate-400 font-medium">Enregistrer une requête de visite client ou prospect</p>
                </div>
              </div>
              <button 
                onClick={() => setNewRequestModal(false)}
                className="p-2 text-slate-400 hover:text-slate-600"
              >
                <i className="ti ti-x text-lg"></i>
              </button>
            </div>

            <form onSubmit={handleCreateRequest} className="space-y-6">
              {/* Client Selection (existing or prospect) */}
              <div className="space-y-2">
                <label className="text-xs font-black text-slate-700 uppercase tracking-wider block">
                  Établissement / Client (Sélectionnez ou saisissez)
                </label>
                <select
                  value={newForm.clientId}
                  onChange={(e) => handleSelectClient(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold text-slate-800 focus:outline-none focus:border-blue-500 focus:bg-white mb-2"
                >
                  <option value="">-- Nouveau Prospect ou saisie manuelle --</option>
                  {clients.map(c => (
                    <option key={c.id} value={String(c.id)}>
                      {c.name} ({c.city || 'Maroc'}) {c.commercial?.name ? `[Comm: ${c.commercial.name}]` : '[Sans Commercial]'}
                    </option>
                  ))}
                </select>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <input
                      type="text"
                      placeholder="Nom de l'établissement *"
                      value={newForm.clientName}
                      onChange={(e) => setNewForm({ ...newForm, clientName: e.target.value })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-blue-500 focus:bg-white"
                      required
                    />
                  </div>
                  <div>
                    <select
                      value={newForm.clientType}
                      onChange={(e) => setNewForm({ ...newForm, clientType: e.target.value })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-blue-500 focus:bg-white"
                    >
                      <option value="Client">Client</option>
                      <option value="Laboratoire">Laboratoire</option>
                      <option value="Cabinet Médical">Cabinet Médical</option>
                      <option value="Centre Dentaire">Centre Dentaire</option>
                      <option value="Hôpital">Hôpital</option>
                      <option value="Pharmacie">Pharmacie</option>
                      <option value="Autre">Autre établissement</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Coordonnées */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block mb-1">Contact Référent</label>
                  <input
                    type="text"
                    placeholder="Dr. / Responsable *"
                    value={newForm.contactName}
                    onChange={(e) => setNewForm({ ...newForm, contactName: e.target.value })}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-blue-500 focus:bg-white"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block mb-1">Téléphone *</label>
                  <input
                    type="tel"
                    placeholder="+212 6..."
                    value={newForm.contactPhone}
                    onChange={(e) => setNewForm({ ...newForm, contactPhone: e.target.value })}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-blue-500 focus:bg-white"
                    required
                  />
                </div>
                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block mb-1">Ville</label>
                  <input
                    type="text"
                    placeholder="Ex: Casablanca"
                    value={newForm.city}
                    onChange={(e) => setNewForm({ ...newForm, city: e.target.value })}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-blue-500 focus:bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block mb-1">Adresse Complète</label>
                <input
                  type="text"
                  placeholder="Rue, quartier, étage..."
                  value={newForm.address}
                  onChange={(e) => setNewForm({ ...newForm, address: e.target.value })}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-blue-500 focus:bg-white"
                />
              </div>

              {/* Motif & Matériel */}
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                    Objet / Motif de la visite *
                  </label>
                  <input
                    type="text"
                    placeholder="Ex: Démonstration Scanner 3D, Devis renouvellement consommables..."
                    value={newForm.motif}
                    onChange={(e) => setNewForm({ ...newForm, motif: e.target.value })}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-blue-500 focus:bg-white"
                    required
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block mb-1">
                    Équipements ou Produits Ciblés
                  </label>
                  <input
                    type="text"
                    placeholder="Ex: Autoclaves, Fauteuils, Réactifs hématologie..."
                    value={newForm.equipmentOfInterest}
                    onChange={(e) => setNewForm({ ...newForm, equipmentOfInterest: e.target.value })}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-blue-500 focus:bg-white"
                  />
                </div>
              </div>

              {/* Planning & Priorité */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block mb-1">Priorité</label>
                  <select
                    value={newForm.priority}
                    onChange={(e) => setNewForm({ ...newForm, priority: e.target.value })}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-blue-500 focus:bg-white"
                  >
                    <option value="Normale">Normale</option>
                    <option value="Haute">Haute</option>
                    <option value="Urgente">Urgente</option>
                  </select>
                </div>
              </div>

              {/* Commercial Assignment (optional) */}
              <div className="p-4 rounded-2xl bg-blue-50/50 border border-blue-100 space-y-2">
                <label className="text-xs font-black text-blue-900 uppercase tracking-wider block">
                  Affecter immédiatement à un commercial (Optionnel)
                </label>
                <select
                  value={newForm.assignedCommercialId}
                  onChange={(e) => setNewForm({ ...newForm, assignedCommercialId: e.target.value })}
                  className="w-full px-4 py-2.5 bg-white border border-blue-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:border-blue-500"
                >
                  <option value="">-- Laisser Sans Commercial (À affecter plus tard) --</option>
                  {commercials.map(c => (
                    <option key={c.id} value={String(c.id)}>
                      {c.name} {c.city ? `(${c.city})` : ''}
                    </option>
                  ))}
                </select>
                <p className="text-[11px] text-slate-500 font-medium">
                  Si aucun commercial n'est sélectionné, la demande apparaîtra immédiatement dans la liste des sollicitations <strong>« Sans Commercial »</strong>.
                </p>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setNewRequestModal(false)}
                  className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl text-xs font-bold"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-black uppercase tracking-wider shadow-lg shadow-blue-600/20"
                >
                  Enregistrer la Demande
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: FICHE VISITE 360 DÉTAILLÉE */}
      {detailsModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full p-8 shadow-2xl border border-slate-100 space-y-6 animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div className="flex items-center gap-3">
                <span className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center text-xl">
                  <i className="ti ti-file-text"></i>
                </span>
                <div>
                  <h3 className="text-base font-black text-slate-900">Détails de la Sollicitation #{detailsModal.id}</h3>
                  <p className="text-xs text-slate-400 font-medium">Reçue le {detailsModal.created_at}</p>
                </div>
              </div>
              <button 
                onClick={() => setDetailsModal(null)}
                className="p-2 text-slate-400 hover:text-slate-600"
              >
                <i className="ti ti-x text-lg"></i>
              </button>
            </div>

            <div className="space-y-4">
              {/* Client Card */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-slate-900 text-base">{detailsModal.client_name}</h4>
                  <span className="px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[10px] font-black">
                    {detailsModal.client_type}
                  </span>
                </div>
                <p className="text-xs text-slate-500 flex items-center gap-1.5">
                  <i className="ti ti-map-pin text-slate-400"></i>
                  {detailsModal.address}, {detailsModal.city}
                </p>
                <div className="flex items-center gap-4 text-xs font-bold pt-2 border-t border-slate-200/60 text-slate-700">
                  <span>👤 {detailsModal.contact_name}</span>
                  <a href={`tel:${detailsModal.contact_phone}`} className="text-blue-600 hover:underline">
                    📞 {detailsModal.contact_phone}
                  </a>
                </div>
              </div>

              {/* Commercial Assignment status */}
              <div className={`p-4 rounded-2xl border flex items-center justify-between ${
                detailsModal.commercial_id ? 'bg-emerald-50/60 border-emerald-200' : 'bg-rose-50/60 border-rose-200'
              }`}>
                <div>
                  <p className="text-[10px] font-black uppercase tracking-wider text-slate-400 mb-0.5">Commercial Assigné</p>
                  {detailsModal.commercial_id ? (
                    <p className="text-sm font-black text-slate-900">
                      ✅ {detailsModal.commercial_name}
                      {detailsModal.assigned_at && <span className="text-xs font-normal text-slate-500 block">Affecté le {detailsModal.assigned_at}</span>}
                    </p>
                  ) : (
                    <p className="text-sm font-black text-rose-600">
                      🚨 Aucun commercial attribué pour le moment
                    </p>
                  )}
                </div>
                <button
                  onClick={() => {
                    const req = detailsModal;
                    setDetailsModal(null);
                    setSelectedCommercialToAssign(String(req.commercial_id || ''));
                    setAssignModal({ open: true, request: req });
                  }}
                  className="px-4 py-2 bg-white text-slate-800 rounded-xl text-xs font-black border border-slate-200 shadow-sm hover:bg-slate-50 transition-all"
                >
                  {detailsModal.commercial_id ? 'Modifier' : 'Affecter'}
                </button>
              </div>

              {/* Motif & Details */}
              <div className="space-y-2">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-wider">Motif & Intérêt</p>
                <p className="text-xs font-bold text-slate-800 bg-slate-50 p-3 rounded-xl border border-slate-100">
                  {detailsModal.motif}
                </p>
                {detailsModal.equipment_of_interest && (
                  <p className="text-xs text-blue-700 font-medium">
                    🎯 <strong>Matériel concerné :</strong> {detailsModal.equipment_of_interest}
                  </p>
                )}
                {detailsModal.notes && (
                  <p className="text-xs text-slate-500 italic bg-amber-50/50 p-3 rounded-xl border border-amber-100">
                    📝 {detailsModal.notes}
                  </p>
                )}
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
              <Link
                to="/admin/devis"
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black uppercase tracking-wider shadow-md shadow-emerald-600/20 flex items-center gap-2"
              >
                <i className="ti ti-file-invoice"></i>
                <span>Générer un Devis</span>
              </Link>
              <button
                onClick={() => setDetailsModal(null)}
                className="px-5 py-2.5 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
