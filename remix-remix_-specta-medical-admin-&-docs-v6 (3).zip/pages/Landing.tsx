
import React from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../App';

export default function Landing() {
  const { t } = useApp();

  return (
    <div className="bg-white min-h-screen">
      <nav className="max-w-7xl mx-auto px-6 h-24 flex items-center justify-between">
        <img src="https://specta.ma/images/Specta_logo.webp" className="h-10" alt="Specta Logo" />
        <div className="flex gap-8 items-center font-semibold text-slate-600">
          <Link to="/" className="text-blue-600 border-b-2 border-blue-600 py-1">{t.home}</Link>
          <a href="#features" className="hover:text-blue-600 transition-colors">{t.docs}</a>
          <Link to="/login" className="bg-blue-600 text-white px-6 py-2.5 rounded-full hover:bg-blue-700 transition-all shadow-xl shadow-blue-100">
            {t.login}
          </Link>
        </div>
      </nav>

      <main>
        <section className="max-w-7xl mx-auto px-6 py-24 grid lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8 animate-in fade-in slide-in-from-left-4 duration-700">
            <span className="bg-blue-50 text-blue-600 px-4 py-1.5 rounded-full text-sm font-black uppercase tracking-widest">Specta Ecosystem v2.0</span>
            <h1 className="text-6xl font-black text-slate-900 leading-[1.1]">{t.hero_title}</h1>
            <p className="text-xl text-slate-500 max-w-lg leading-relaxed">{t.hero_subtitle}</p>
            <div className="flex gap-4">
              <Link to="/login" className="bg-blue-600 text-white px-10 py-4 rounded-2xl font-bold hover:bg-blue-700 transition-all shadow-2xl shadow-blue-200 transform hover:-translate-y-1">
                {t.get_started}
              </Link>
              <a href="#features" className="border border-slate-200 px-10 py-4 rounded-2xl font-bold hover:bg-slate-50 transition-all">
                {t.learn_more}
              </a>
            </div>
          </div>
          <div className="relative animate-in zoom-in-95 duration-1000">
             <div className="absolute inset-0 bg-blue-600 rounded-[3rem] rotate-3 opacity-10"></div>
             <img src="https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&q=80&w=1200" className="rounded-[3rem] shadow-2xl relative z-10 grayscale hover:grayscale-0 transition-all duration-700 cursor-pointer" alt="Medical Tech" />
          </div>
        </section>

        <section id="features" className="bg-slate-50 py-32">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center space-y-4 mb-20">
              <h2 className="text-4xl font-black text-slate-900">One Platform, Endless Possibilities</h2>
              <p className="text-slate-500 max-w-2xl mx-auto">Specta Medical integrates everything clinical managers need into a single fluid digital experience.</p>
            </div>
            <div className="grid md:grid-cols-3 gap-10">
              <FeatureCard icon="🤖" title={t.feature_sav_title} desc={t.feature_sav_desc} />
              <FeatureCard icon="🛍️" title={t.feature_orders_title} desc={t.feature_orders_desc} />
              <FeatureCard icon="🎓" title={t.feature_academy_title} desc={t.feature_academy_desc} />
            </div>
          </div>
        </section>
      </main>

      <footer className="py-20 border-t border-slate-100 text-center">
        <img src="https://specta.ma/images/Specta_logo.webp" className="h-8 mx-auto mb-6 opacity-30" />
        <p className="text-slate-400 font-medium">&copy; 2024 Specta Medical Solutions. All rights reserved.</p>
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, desc }: any) {
  return (
    <div className="bg-white p-10 rounded-[2.5rem] shadow-sm hover:shadow-xl transition-all duration-500 group border border-transparent hover:border-blue-100">
      <div className="text-5xl mb-6 bg-slate-50 w-20 h-20 flex items-center justify-center rounded-3xl group-hover:bg-blue-600 group-hover:rotate-12 transition-all duration-500">{icon}</div>
      <h3 className="text-2xl font-bold text-slate-800 mb-4">{title}</h3>
      <p className="text-slate-500 leading-relaxed">{desc}</p>
    </div>
  );
}
