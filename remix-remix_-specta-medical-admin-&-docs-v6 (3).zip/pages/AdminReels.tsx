
import React, { useState, useEffect } from 'react';
import { api } from '../api';
import { useApp } from '../App';

export default function AdminReels() {
  const { t, theme } = useApp();
  const [reels, setReels] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<{ type: 'add' | 'delete' | null, item: any }>({ type: null, item: null });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [videoPreview, setVideoPreview] = useState<string | null>(null);

  const fetchReels = async () => {
    setLoading(true);
    try {
      const res = await api.reels.list();
      setReels(Array.isArray(res.data) ? res.data : []);
    } catch (e) {
      console.error(e);
      setReels([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchReels(); }, []);

  const handleVideoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          const url = URL.createObjectURL(file);
          setVideoPreview(url);
      }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    
    try {
      await api.reels.create(formData);
      setModal({ type: null, item: null });
      setVideoPreview(null);
      fetchReels();
    } catch (e: any) {
      alert(e.message || "Erreur de Téléversement");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleToggleStatus = async (id: number, current: boolean) => {
      try {
          await api.reels.updateStatus(id, !current);
          fetchReels();
      } catch (e) {
          alert("Erreur de Synchronisation du Statut");
      }
  };

  const handleDelete = async () => {
    setIsSubmitting(true);
    try {
      await api.reels.delete(modal.item.id);
      setModal({ type: null, item: null });
      fetchReels();
    } catch (e) {
      alert("Erreur de Suppression");
    } finally {
      setIsSubmitting(false);
    }
  };

  const getFullUrl = (path: string) => {
    if (!path) return '';
    if (path.startsWith('http')) return path;
    return `https://birdeye-intelligence.ma/Spetcapp/Backend/storage/app/public/${path}`;
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-700 pb-20">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6">
        <div>
          <h1 className="text-4xl font-black tracking-tight">Gestion des Reels</h1>
          <p className="text-slate-400 font-black uppercase text-[10px] tracking-[3px] opacity-60">Marketing Vidéo Court pour l'Application Clinique</p>
        </div>
        <button 
          onClick={() => { setModal({ type: 'add', item: null }); setVideoPreview(null); }}
          className="bg-blue-600 text-white px-10 py-4 rounded-[1.5rem] font-black shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all flex items-center gap-3 active:scale-95"
        >
          <i className="ti ti-video-plus text-xl"></i> Publier un Nouveau Reel
        </button>
      </div>

      {loading && reels.length === 0 ? (
        <div className="py-40 text-center"><div className="animate-spin h-16 w-16 border-t-4 border-blue-600 rounded-full mx-auto"></div></div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
           {reels.map(reel => (
             <div key={reel.id} className={`group relative bg-slate-900 rounded-[2.5rem] aspect-[9/16] overflow-hidden border-4 transition-all ${reel.is_active ? 'border-emerald-500 shadow-2xl' : 'border-slate-800 opacity-60 hover:opacity-100'}`}>
                <video 
                    poster={getFullUrl(reel.thumbnail_url)} 
                    className="w-full h-full object-cover" 
                    muted loop playsInline
                    onMouseEnter={(e) => {
                        const playPromise = e.currentTarget.play();
                        if (playPromise !== undefined) {
                            playPromise.catch(() => { /* Playback was interrupted or blocked */ });
                        }
                    }}
                    onMouseLeave={(e) => { 
                        e.currentTarget.pause(); 
                        e.currentTarget.currentTime = 0; 
                    }}
                >
                    <source src={getFullUrl(reel.video_url)} type="video/mp4" />
                </video>
                
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none"></div>

                 <div className="absolute top-4 right-4 flex flex-col gap-2 z-10 opacity-0 group-hover:opacity-100 transition-all">
                    <button onClick={() => handleToggleStatus(reel.id, reel.is_active)} className={`w-10 h-10 rounded-xl flex items-center justify-center shadow-lg transition-all ${reel.is_active ? 'bg-emerald-50 text-white' : 'bg-slate-700 text-white'}`} title={reel.is_active ? 'Désactiver' : 'Activer'}>
                        <i className={`ti ${reel.is_active ? 'ti-player-pause' : 'ti-player-play'}`}></i>
                    </button>
                    <button onClick={() => setModal({ type: 'delete', item: reel })} className="w-10 h-10 rounded-xl bg-rose-500 text-white flex items-center justify-center shadow-lg hover:bg-rose-600 transition-all">
                        <i className="ti ti-trash"></i>
                    </button>
                </div>

                <div className="absolute bottom-6 left-6 right-6 pointer-events-none">
                    <h5 className="text-white font-black text-sm line-clamp-2 leading-tight mb-1">{reel.title || 'Contenu Specta'}</h5>
                    <p className="text-[9px] text-white/50 font-bold uppercase tracking-widest">{reel.is_active ? 'Publié' : 'Masqué'}</p>
                </div>
             </div>
           ))}
           {reels.length === 0 && (
               <div className="col-span-full py-40 text-center border-4 border-dashed border-slate-100 dark:border-slate-800 rounded-[4rem]">
                   <i className="ti ti-video-off text-8xl text-slate-200 mb-4 block"></i>
                   <p className="text-slate-400 font-black uppercase text-xs tracking-[5px]">La galerie est actuellement vide</p>
               </div>
           )}
        </div>
      )}

      {/* UPLOAD MODAL */}
      {modal.type === 'add' && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[100] flex items-center justify-center p-4">
             <div className={`bg-white w-full max-w-4xl rounded-[4rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 border-4 border-white ${theme === 'dark' ? 'bg-slate-900 border-slate-800' : ''}`}>
                <div className="p-8 border-b border-slate-100 flex justify-between items-center">
                    <h2 className="text-2xl font-black tracking-tighter uppercase text-[10px] tracking-[4px]">Téléversement Direct Studio</h2>
                    <button onClick={() => setModal({ type: null, item: null })} className="w-12 h-12 flex items-center justify-center bg-slate-50 dark:bg-slate-800 rounded-full text-slate-400">×</button>
                </div>
                <form onSubmit={handleUpload} className="p-10 flex flex-col lg:flex-row gap-10">
                    <div className="flex-1 space-y-6">
                        <div className="space-y-1">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Titre du Reel</label>
                            <input name="title" className={`w-full px-8 py-5 border-none rounded-[1.75rem] outline-none font-black text-lg shadow-inner ${theme === 'dark' ? 'bg-slate-800 text-white' : 'bg-slate-50'}`} placeholder="Titre accrocheur..." />
                        </div>
                        <div className="space-y-1">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Description / Sous-titre</label>
                            <textarea name="description" className={`w-full px-8 py-5 border-none rounded-[1.75rem] outline-none font-medium h-32 shadow-inner ${theme === 'dark' ? 'bg-slate-800 text-white' : 'bg-slate-50'}`} placeholder="Fournir du contexte pour les utilisateurs cliniques..." />
                        </div>
                        
                        <div className="grid grid-cols-2 gap-6">
                            <div className="space-y-2">
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Fichier Vidéo (MP4/MOV)</label>
                                <label className="w-full h-16 flex items-center justify-center gap-3 px-6 bg-blue-50 dark:bg-blue-900/20 border-2 border-dashed border-blue-200 dark:border-blue-800 rounded-[1.5rem] cursor-pointer hover:bg-blue-100 transition-all">
                                    <i className="ti ti-movie text-blue-600"></i>
                                    <span className="text-[10px] font-black uppercase text-blue-600">Sélectionner une Vidéo</span>
                                    <input name="video" type="file" required accept="video/*" onChange={handleVideoChange} className="hidden" />
                                </label>
                            </div>
                            <div className="space-y-2">
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Image de Couverture (Optionnel)</label>
                                <label className="w-full h-16 flex items-center justify-center gap-3 px-6 bg-slate-50 dark:bg-slate-800 border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-[1.5rem] cursor-pointer hover:bg-slate-100 transition-all">
                                    <i className="ti ti-photo text-slate-400"></i>
                                    <span className="text-[10px] font-black uppercase text-slate-400">Sélectionner une Image</span>
                                    <input name="thumbnail" type="file" accept="image/*" className="hidden" />
                                </label>
                            </div>
                        </div>

                        <button 
                            disabled={isSubmitting}
                            className="w-full py-6 bg-blue-600 text-white rounded-[2.5rem] font-black uppercase text-xs tracking-[5px] shadow-2xl active:scale-95 transition-all flex items-center justify-center gap-4 disabled:opacity-50"
                        >
                            {isSubmitting ? <div className="animate-spin h-5 w-5 border-2 border-white/30 border-t-white rounded-full"></div> : <i className="ti ti-cloud-upload text-xl"></i>}
                            {isSubmitting ? 'Syndication des Médias...' : 'Publier dans l\'Écosystème'}
                        </button>
                    </div>

                    <div className="w-full lg:w-72 flex flex-col gap-4">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Aperçu Vertical</p>
                        <div className="flex-1 bg-slate-900 rounded-[3rem] border-8 border-slate-800 overflow-hidden relative shadow-2xl aspect-[9/16]">
                            {videoPreview ? (
                                <video src={videoPreview} className="w-full h-full object-cover" controls muted />
                            ) : (
                                <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center gap-4">
                                    <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center animate-pulse">
                                        <i className="ti ti-player-play text-white/20 text-3xl"></i>
                                    </div>
                                    <p className="text-[10px] text-white/20 font-black uppercase tracking-widest">En attente du fichier source</p>
                                </div>
                            )}
                        </div>
                    </div>
                </form>
             </div>
        </div>
      )}

      {/* DELETE MODAL */}
      {modal.type === 'delete' && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[110] flex items-center justify-center p-4">
             <div className="bg-white rounded-[4rem] shadow-2xl p-12 text-center max-w-sm w-full animate-in zoom-in-95">
                <div className="w-20 h-20 bg-rose-50 text-rose-500 rounded-3xl flex items-center justify-center text-4xl mx-auto mb-6 shadow-inner animate-bounce">
                    <i className="ti ti-video-minus"></i>
                </div>
                <h3 className="text-2xl font-black text-slate-800 tracking-tight mb-2">Purger le Contenu ?</h3>
                <p className="text-slate-500 text-sm font-medium leading-relaxed mb-8">Cela supprimera définitivement le fichier vidéo du cloud du serveur.</p>
                <div className="flex gap-4">
                    <button onClick={() => setModal({ type: null, item: null })} className="flex-1 py-4 bg-slate-50 text-slate-400 rounded-2xl font-black text-[10px] uppercase tracking-widest">Garder</button>
                    <button onClick={handleDelete} disabled={isSubmitting} className="flex-1 py-4 bg-rose-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-rose-200">
                        {isSubmitting ? 'Suppression...' : 'Purger'}
                    </button>
                </div>
             </div>
        </div>
      )}
    </div>
  );
}
