
import React, { useState, useEffect, useMemo } from 'react';
import { api } from '../api';
import { useApp } from '../App';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie, Legend
} from 'recharts';

const PAYMENT_METHODS = [
  { id: 'Espèces', label: 'Espèces (Cash)' },
  { id: 'Chèque', label: 'Chèque' },
  { id: 'Virement', label: 'Virement' },
  { id: 'Effet', label: 'Effet' },
  { id: 'Autre', label: 'Autre' }
];

const STATUS_LABELS = {
    paid: { label: 'Payé', color: 'bg-emerald-100 text-emerald-600', icon: 'ti-checkbox' },
    pending: { label: 'En attente', color: 'bg-amber-100 text-amber-600', icon: 'ti-clock' },
    unpaid: { label: 'Impayé', color: 'bg-rose-100 text-rose-600', icon: 'ti-alert-circle' }
};

const COLORS = ['#5D87FF', '#13DEB9', '#FFAE1F', '#FA896B', '#39B69A'];

export default function AdminReglements() {
  const { theme } = useApp();
  const [payments, setPayments] = useState<any[]>([]);
  const [clients, setClients] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedClientId, setSelectedClientId] = useState<string>('all');
  
  // Modals
  const [modal, setModal] = useState<{ type: 'add' | 'edit' | 'delete' | null, item: any }>({ type: null, item: null });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fetchData = async () => {
    setLoading(true);
    try {
        const [pRes, cRes] = await Promise.all([
            api.payments.list('per_page=500'),
            api.clients.list('per_page=500')
        ]);
        setPayments(pRes?.data || pRes || []);
        setClients(cRes?.data || cRes || []);
    } catch (e) {
        console.error(e);
    } finally {
        setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  // Filtered logic for KPIs and Table
  const filteredPayments = useMemo(() => {
    return payments.filter(p => {
        const matchesClient = selectedClientId === 'all' || p.client_id?.toString() === selectedClientId;
        const matchesSearch = p.client?.name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
                             p.reference?.toLowerCase().includes(searchTerm.toLowerCase());
        return matchesClient && matchesSearch;
    });
  }, [payments, selectedClientId, searchTerm]);

  // Derived KPIs
  const stats = useMemo(() => {
      const total = filteredPayments.reduce((acc, p) => acc + parseFloat(p.amount || 0), 0);
      const paid = filteredPayments.filter(p => p.status === 'paid').reduce((acc, p) => acc + parseFloat(p.amount || 0), 0);
      const pending = filteredPayments.filter(p => p.status === 'pending').reduce((acc, p) => acc + parseFloat(p.amount || 0), 0);
      const unpaid = filteredPayments.filter(p => p.status === 'unpaid').reduce((acc, p) => acc + parseFloat(p.amount || 0), 0);
      
      // Breakdown by method
      const methodData = PAYMENT_METHODS.map(m => ({
          name: m.id,
          value: filteredPayments.filter(p => p.method === m.id).reduce((acc, p) => acc + parseFloat(p.amount || 0), 0)
      })).filter(d => d.value > 0);

      return { total, paid, pending, unpaid, methodData };
  }, [filteredPayments]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());

    try {
      if (modal.type === 'add') {
          await api.payments.create(data);
      } else {
          await api.payments.update(modal.item.id, data);
      }
      setModal({ type: null, item: null });
      fetchData();
    } catch (e: any) {
      alert(e.message || "Erreur de synchronisation financière.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async () => {
    setIsSubmitting(true);
    try {
      await api.payments.delete(modal.item.id);
      setModal({ type: null, item: null });
      fetchData();
    } catch (e) {
      alert("Erreur lors de la suppression.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-8 pb-20 animate-in fade-in duration-700">
      {/* HEADER & GLOBAL CLIENT FILTER */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-8 bg-white p-10 rounded-[4rem] shadow-sm border border-slate-100">
        <div>
          <h1 className="text-4xl font-black text-slate-800 tracking-tighter mb-1">Financial Oversight</h1>
          <p className="text-slate-400 font-black uppercase text-[10px] tracking-[4px] opacity-70 italic">Payment Flow Analytics & Transaction Ledger</p>
        </div>
        <div className="flex flex-wrap gap-4 items-center">
            <div className="relative">
                <i className="ti ti-filter absolute left-6 top-1/2 -translate-y-1/2 text-blue-600"></i>
                <select 
                    value={selectedClientId}
                    onChange={(e) => setSelectedClientId(e.target.value)}
                    className="pl-14 pr-8 py-4 bg-slate-50 border-none rounded-[1.5rem] outline-none font-black text-[10px] uppercase tracking-widest shadow-inner appearance-none min-w-[240px]"
                >
                    <option value="all">Tous les Clients (Global)</option>
                    {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
            </div>
            <button onClick={fetchData} className="w-14 h-14 bg-slate-50 text-slate-400 rounded-full flex items-center justify-center hover:bg-blue-600 hover:text-white transition-all border border-slate-100 shadow-sm"><i className="ti ti-refresh text-2xl"></i></button>
            <button 
                onClick={() => setModal({ type: 'add', item: { payment_date: new Date().toISOString().split('T')[0], method: 'Virement', status: 'paid' } })}
                className="bg-blue-600 text-white px-10 py-5 rounded-[2rem] font-black shadow-2xl shadow-blue-100 hover:bg-blue-700 transition-all flex items-center gap-3 active:scale-95"
            >
                <i className="ti ti-plus text-xl"></i> Saisir Encaissement
            </button>
        </div>
      </div>

      {/* CORE PAYMENT KPIs (WIDGETS) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <FinanceWidget label="Total Encaissé" value={stats.paid} color="bg-emerald-500" icon="ti-currency-dirham" />
          <FinanceWidget label="En Attente (Chèques/Effets)" value={stats.pending} color="bg-amber-500" icon="ti-clock-bolt" />
          <FinanceWidget label="Total Impayés" value={stats.unpaid} color="bg-rose-500" icon="ti-alert-triangle" />
          <FinanceWidget label="Volume Global" value={stats.total} color="bg-slate-900" icon="ti-chart-dots" />
      </div>

      {/* ANALYTICS ROW */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-7 bg-white p-10 rounded-[4rem] border border-slate-100 shadow-sm group hover:shadow-xl transition-all duration-500">
              <h3 className="text-xl font-black text-slate-800 mb-8 tracking-tighter uppercase text-[11px] tracking-[4px] opacity-40">Performance de Recouvrement (MAD)</h3>
              <div className="h-80 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={[
                          { name: 'Payé', amount: stats.paid, fill: '#13DEB9' },
                          { name: 'En Attente', amount: stats.pending, fill: '#FFAE1F' },
                          { name: 'Impayé', amount: stats.unpaid, fill: '#FA896B' }
                      ]}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                          <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 'bold'}} />
                          <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10}} />
                          <Tooltip 
                            contentStyle={{ borderRadius: '24px', border: 'none', boxShadow: '0 20px 40px -10px rgba(0,0,0,0.1)', fontWeight: 'bold' }} 
                            cursor={{fill: '#f8fafc'}}
                            formatter={(v: any) => v.toLocaleString() + ' MAD'}
                          />
                          <Bar dataKey="amount" radius={[10, 10, 0, 0]} barSize={60}>
                              <Cell fill="#13DEB9" />
                              <Cell fill="#FFAE1F" />
                              <Cell fill="#FA896B" />
                          </Bar>
                      </BarChart>
                  </ResponsiveContainer>
              </div>
          </div>

          <div className="lg:col-span-5 bg-white p-10 rounded-[4rem] border border-slate-100 shadow-sm flex flex-col items-center group hover:shadow-xl transition-all duration-500">
              <h3 className="text-xl font-black text-slate-800 self-start mb-8 tracking-tighter uppercase text-[11px] tracking-[4px] opacity-40">Canaux d'Encaissement</h3>
              <div className="h-80 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                          <Pie 
                            data={stats.methodData} 
                            innerRadius={70} 
                            outerRadius={100} 
                            paddingAngle={8} 
                            dataKey="value"
                          >
                              {stats.methodData.map((entry, index) => (
                                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                              ))}
                          </Pie>
                          <Tooltip 
                            contentStyle={{ borderRadius: '24px', border: 'none', boxShadow: '0 20px 40px -10px rgba(0,0,0,0.1)', fontWeight: 'bold' }}
                            formatter={(v: any) => v.toLocaleString() + ' MAD'}
                          />
                          <Legend iconType="circle" verticalAlign="bottom" wrapperStyle={{ fontSize: '10px', fontWeight: 'bold', textTransform: 'uppercase', letterSpacing: '1px', paddingTop: '20px' }} />
                      </PieChart>
                  </ResponsiveContainer>
              </div>
          </div>
      </div>

      {/* LEDGER VIEW */}
      <div className="bg-white rounded-[3rem] border border-slate-100 overflow-hidden shadow-sm relative">
          <div className="p-8 border-b border-slate-50 flex flex-col md:flex-row justify-between items-start md:items-center gap-6 bg-slate-50/30">
              <div className="flex-1 w-full max-w-md relative">
                <i className="ti ti-search absolute left-6 top-1/2 -translate-y-1/2 text-slate-400"></i>
                <input 
                    type="text" 
                    placeholder="Filtrer le grand livre par client ou réf..." 
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    className="w-full pl-14 pr-8 py-4 bg-white border border-slate-100 rounded-[1.5rem] outline-none font-bold text-sm shadow-sm focus:ring-4 focus:ring-blue-500/5 transition-all"
                />
              </div>
              <div className="flex gap-4">
                <div className="px-8 py-3 bg-emerald-50 text-emerald-600 rounded-full text-[10px] font-black uppercase tracking-widest border border-emerald-100">
                    {filteredPayments.length} Transactions affichées
                </div>
              </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
                <thead className="bg-slate-50/80 sticky top-0 z-10 backdrop-blur-md">
                    <tr className="text-[10px] font-black uppercase text-slate-400 tracking-widest border-b">
                        <th className="px-10 py-6">Date & Ref</th>
                        <th className="px-10 py-6">Établissement</th>
                        <th className="px-10 py-6">Canal & Statut</th>
                        <th className="px-10 py-6">Montant</th>
                        <th className="px-10 py-6 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                    {filteredPayments.map(p => (
                        <tr key={p.id} className="hover:bg-slate-50/50 transition-colors group">
                            <td className="px-10 py-6">
                                <p className="font-bold text-slate-800 text-sm">{new Date(p.payment_date).toLocaleDateString()}</p>
                                <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest mt-0.5">{p.reference || 'REF-N/A'}</p>
                            </td>
                            <td className="px-10 py-6">
                                <p className="font-black text-slate-700 leading-none mb-1">{p.client?.name || 'Inconnu'}</p>
                                <span className="text-[9px] font-black text-blue-500 uppercase tracking-widest">{p.client?.commercial?.name || 'Direct'}</span>
                            </td>
                            <td className="px-10 py-6">
                                <div className="flex flex-col gap-1 items-start">
                                    <span className="px-4 py-1.5 bg-slate-100 rounded-full text-[9px] font-black uppercase tracking-widest text-slate-500 inline-block">{p.method}</span>
                                    <span className={`px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest flex items-center gap-1.5 ${STATUS_LABELS[p.status as keyof typeof STATUS_LABELS]?.color || 'bg-slate-100'}`}>
                                        <i className={`ti ${STATUS_LABELS[p.status as keyof typeof STATUS_LABELS]?.icon}`}></i>
                                        {STATUS_LABELS[p.status as keyof typeof STATUS_LABELS]?.label || p.status}
                                    </span>
                                </div>
                            </td>
                            <td className="px-10 py-6">
                                <p className="font-black text-emerald-600 text-lg tracking-tight">{parseFloat(p.amount || 0).toLocaleString()} <span className="text-[10px]">MAD</span></p>
                            </td>
                            <td className="px-10 py-6 text-right">
                                <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-all">
                                    <button onClick={() => setModal({ type: 'edit', item: p })} className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center hover:bg-blue-600 hover:text-white transition-all shadow-sm"><i className="ti ti-edit"></i></button>
                                    <button onClick={() => setModal({ type: 'delete', item: p })} className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center hover:bg-red-600 hover:text-white transition-all shadow-sm"><i className="ti ti-trash"></i></button>
                                </div>
                            </td>
                        </tr>
                    ))}
                    {filteredPayments.length === 0 && !loading && (
                        <tr><td colSpan={5} className="py-20 text-center text-slate-300 font-black uppercase text-xs tracking-widest italic opacity-40">Aucune transaction trouvée</td></tr>
                    )}
                </tbody>
            </table>
          </div>
      </div>

      {/* ADD/EDIT MODAL */}
      {modal.type && modal.type !== 'delete' && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[150] flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-2xl rounded-[4rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 border-4 border-white flex flex-col max-h-[90vh]">
                <div className="p-10 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                    <div>
                        <h2 className="text-2xl font-black text-slate-800 tracking-tighter uppercase text-[10px] tracking-[4px]">{modal.type} Règlement</h2>
                        <p className="text-slate-400 font-bold uppercase text-[8px] tracking-[2px] mt-1">Enregistrement dans le grand livre financier</p>
                    </div>
                    <button onClick={() => setModal({ type: null, item: null })} className="w-12 h-12 flex items-center justify-center bg-white rounded-full text-slate-400 hover:text-red-500 shadow-md transition-all text-2xl font-light">×</button>
                </div>
                <form onSubmit={handleSave} className="p-10 space-y-8 overflow-y-auto custom-scrollbar">
                    <div className="space-y-1">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Établissement Client</label>
                        <select name="client_id" defaultValue={modal.item.client_id} className="w-full px-8 py-5 bg-slate-50 border-none rounded-[1.75rem] outline-none font-black text-lg shadow-inner appearance-none" required>
                            <option value="">-- Choisir un Établissement --</option>
                            {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                        </select>
                    </div>

                    <div className="grid grid-cols-2 gap-8">
                        <div className="space-y-1">
                            <label className="text-[10px] font-black text-blue-600 uppercase tracking-widest ml-6">Montant du Règlement (MAD)</label>
                            <input name="amount" type="number" step="0.01" defaultValue={modal.item.amount} className="w-full px-8 py-5 bg-blue-50 border-none rounded-[1.75rem] outline-none font-black text-2xl text-blue-700 shadow-inner" required />
                        </div>
                        <div className="space-y-1">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Date de Valeur</label>
                            <input name="payment_date" type="date" defaultValue={modal.item.payment_date} className="w-full px-8 py-5 bg-slate-50 border-none rounded-[1.75rem] outline-none font-bold shadow-inner" required />
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-8">
                        <div className="space-y-1">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Canal de Paiement</label>
                            <select name="method" defaultValue={modal.item.method} className="w-full px-8 py-5 bg-slate-50 border-none rounded-[1.75rem] outline-none font-black text-xs uppercase tracking-widest shadow-inner appearance-none">
                                {PAYMENT_METHODS.map(m => <option key={m.id} value={m.id}>{m.label}</option>)}
                            </select>
                        </div>
                        <div className="space-y-1">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">État Actuel</label>
                            <select name="status" defaultValue={modal.item.status || 'paid'} className={`w-full px-8 py-5 border-none rounded-[1.75rem] outline-none font-black text-[10px] uppercase tracking-widest shadow-inner appearance-none ${modal.item.status === 'paid' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>
                                <option value="paid">Payé / Encaissé</option>
                                <option value="pending">En attente / Provision</option>
                                <option value="unpaid">Rejeté / Impayé</option>
                            </select>
                        </div>
                    </div>

                    <div className="space-y-1">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Référence Transactionnelle</label>
                        <textarea name="reference" defaultValue={modal.item.reference || modal.item.notes} className="w-full px-8 py-5 bg-slate-50 border-none rounded-[1.75rem] outline-none font-medium h-32 italic shadow-inner" placeholder="Numéro de chèque, ID virement, ou mémo de suivi..." />
                    </div>

                    <button type="submit" disabled={isSubmitting} className="w-full py-6 bg-slate-900 text-white rounded-[2.5rem] font-black uppercase text-xs tracking-[5px] shadow-2xl active:scale-95 transition-all">
                        {isSubmitting ? 'Syndication...' : 'Confirmer la Transaction'}
                    </button>
                </form>
            </div>
        </div>
      )}

      {/* DELETE MODAL */}
      {modal.type === 'delete' && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[160] flex items-center justify-center p-4">
             <div className="bg-white rounded-[4rem] shadow-2xl p-12 text-center max-w-sm w-full animate-in zoom-in-95">
                <div className="w-20 h-20 bg-rose-50 text-rose-500 rounded-3xl flex items-center justify-center text-4xl mx-auto mb-6 shadow-inner animate-bounce"><i className="ti ti-trash"></i></div>
                <h3 className="text-2xl font-black text-slate-800 mb-2">Annuler le règlement ?</h3>
                <p className="text-slate-500 text-sm font-medium leading-relaxed mb-8">Cette action retirera le montant du solde client et supprimera définitivement l'entrée.</p>
                <div className="flex gap-4">
                    <button onClick={() => setModal({ type: null, item: null })} className="flex-1 py-4 bg-slate-50 text-slate-400 rounded-2xl font-black text-[10px] uppercase tracking-widest">Garder</button>
                    <button onClick={handleDelete} disabled={isSubmitting} className="flex-1 py-4 bg-rose-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-rose-200">Supprimer</button>
                </div>
             </div>
        </div>
      )}
    </div>
  );
}

function FinanceWidget({ label, value, color, icon }: any) {
    const isCurrency = icon === 'DH' || icon === 'MAD' || icon === 'ti-currency-dirham';
    return (
        <div className="bg-white p-8 rounded-[3.5rem] border border-slate-100 shadow-sm group hover:shadow-2xl transition-all duration-700 relative overflow-hidden border-b-4 border-b-slate-100">
            <div className={`absolute -right-8 -bottom-8 w-32 h-32 ${color} rounded-full opacity-5 scale-150`}></div>
            <div className="relative z-10">
                <div className={`w-14 h-14 rounded-2xl ${color} text-white flex items-center justify-center text-2xl shadow-lg transition-transform group-hover:rotate-12 mb-6 select-none`}>
                    {isCurrency ? (
                        <span className="font-black text-xl tracking-tight leading-none text-white">DH</span>
                    ) : (
                        <i className={`ti ${icon}`}></i>
                    )}
                </div>
                <div>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-[3px] mb-2">{label}</p>
                    <p className="text-2xl font-black text-slate-800 tracking-tighter leading-none">{Number(value || 0).toLocaleString()} <span className="text-[10px] opacity-30">MAD</span></p>
                </div>
            </div>
        </div>
    )
}
