
import React, { useState, useEffect, useRef } from 'react';
import { api } from '../api';
import { useApp } from '../App';
import { Machine, Brand, Category } from '../types';

export default function AdminMachines() {
  const { t, checkPermission, showDenied } = useApp();
  const [machines, setMachines] = useState<Machine[]>([]);
  const [brands, setBrands] = useState<Brand[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<{ type: 'add' | 'edit' | 'view' | 'delete' | null, item: any }>({ type: null, item: null });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [filters, setFilters] = useState({ search: '', category_id: '', brand_id: '', status: '' });
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  
  // Doc Upload State
  const [isUploadingDoc, setIsUploadingDoc] = useState(false);
  const [docTitle, setDocTitle] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchData = async () => {
    setLoading(true);
    try {
      const query = `search=${filters.search}&category_id=${filters.category_id}&brand_id=${filters.brand_id}&status=${filters.status}`;
      const [mRes, bRes, cRes] = await Promise.all([
        api.machines.list(query),
        api.brands.list('per_page=100'),
        api.categories.list('per_page=100')
      ]);
      setMachines(mRes.data || mRes || []);
      setBrands(bRes.data || bRes || []);
      setCategories(cRes.data || cRes || []);
    } catch (e) { console.error(e); } finally { setLoading(false); }
  };

  useEffect(() => {
    const timer = setTimeout(fetchData, 300);
    return () => clearTimeout(timer);
  }, [filters]);

  const handleOpenModal = (type: 'add' | 'edit' | 'delete' | 'view', item: any) => {
      if (type === 'add' && !checkPermission('machines', 'add')) return showDenied("Register Asset");
      if (type === 'edit' && !checkPermission('machines', 'edit')) return showDenied("Modifier Asset");
      if (type === 'delete' && !checkPermission('machines', 'delete')) return showDenied("Archiver Asset");
      
      setModal({ type, item });
      if (type === 'edit' || type === 'view') {
          setPreviewUrl(getFullImageUrl(item.image_url));
      } else if (type === 'add') {
          setPreviewUrl(null);
      }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);

    // Convert TTC Inputs back to HT for API (TTC / 1.2)
    const ttcPrice = formData.get('price_ht');
    const ttcMinPrice = formData.get('min_price_ht');
    if (ttcPrice) formData.set('price_ht', (parseFloat(ttcPrice as string) / 1.2).toFixed(2));
    if (ttcMinPrice) formData.set('min_price_ht', (parseFloat(ttcMinPrice as string) / 1.2).toFixed(2));

    try {
      if (modal.type === 'add') await api.machines.create(formData);
      else await api.machines.update(modal.item.id, formData);
      setModal({ type: null, item: null });
      fetchData();
    } catch (e) { alert("Error saving asset"); } finally { setIsSubmitting(false); }
  };

  const handleUploadDocument = async () => {
    if (!selectedFile || !modal.item) return;
    setIsUploadingDoc(true);
    const formData = new FormData();
    formData.append('document', selectedFile);
    formData.append('title', docTitle || selectedFile.name);
    
    // Assign correct file_type enum
    let fType = 'other';
    if (selectedFile.type.includes('pdf')) fType = 'pdf';
    else if (selectedFile.type.startsWith('image/')) fType = 'image';
    formData.append('file_type', fType);

    try {
        await api.machines.uploadDocument(modal.item.id, formData);
        const refreshed = await api.machines.show(modal.item.id);
        setModal({ ...modal, item: refreshed.data || refreshed });
        setSelectedFile(null); 
        setDocTitle('');
    } catch (e: any) { alert(e.message || "Failed to upload."); } finally { setIsUploadingDoc(false); }
  };

  const handleDeleteDoc = async (docId: number) => {
    if (!confirm("Supprimer ce document ?")) return;
    try {
        await api.machines.deleteDocument(modal.item.id, docId);
        const refreshed = await api.machines.show(modal.item.id);
        setModal({ ...modal, item: refreshed.data || refreshed });
    } catch (e) { alert("Failed to delete."); }
  };

  const getFullImageUrl = (path: string) => {
    if (!path) return 'https://placehold.co/600x400?text=SPECTRA+ASSET';
    if (path.startsWith('http')) return path;
    return `https://birdeye-intelligence.ma/Spetcapp/Backend/storage/app/public/${path}`;
  };

  const formatPriceTTC = (ht: any) => {
      const val = parseFloat(ht || 0);
      return (val * 1.2).toLocaleString();
  };

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-700">
      {/* COMPACT KPI */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <CompactKPI label="Parc Total" value={machines.length} icon="ti-device-analytics" color="bg-blue-600" />
          <CompactKPI label="Valeur TTC" value={`${Math.round(machines.reduce((acc, m) => acc + (parseFloat(m.price_ht?.toString() || '0') * 1.2), 0)).toLocaleString()} MAD`} icon="ti-wallet" color="bg-emerald-600" />
          <CompactKPI label="Marques" value={brands.length} icon="ti-award" color="bg-amber-500" />
          <CompactKPI label="SLA Global" value="98%" icon="ti-shield-check" color="bg-indigo-600" />
      </div>

      {/* HEADER SECTION */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 bg-white p-8 rounded-[3rem] shadow-sm border border-slate-100">
        <div>
          <h1 className="text-3xl font-black text-slate-800 tracking-tight mb-1">Fleet Assets</h1>
          <p className="text-slate-400 font-black uppercase text-[9px] tracking-[3px] opacity-70">Clinical Inventory & Technical Documentation</p>
        </div>
        <button onClick={() => handleOpenModal('add', { is_active: 1 })} className="bg-blue-600 text-white px-8 py-4 rounded-[1.5rem] font-black shadow-lg hover:bg-blue-700 transition-all flex items-center gap-2 active:scale-95 text-[11px] uppercase tracking-widest">
            <i className="ti ti-plus text-lg"></i> Ajouter Machine
        </button>
      </div>

      {/* COMPACT FILTER */}
      <div className="bg-white p-4 rounded-[2rem] border border-slate-100 flex flex-wrap gap-4 items-center">
        <div className="flex-1 relative min-w-[200px]">
            <i className="ti ti-search absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
            <input type="text" placeholder="Rechercher REF, S/N..." className="w-full pl-10 pr-4 py-3 bg-slate-50 border-none rounded-2xl outline-none font-bold text-xs" value={filters.search} onChange={e => setFilters({...filters, search: e.target.value})} />
        </div>
        <select className="px-4 py-3 bg-slate-50 border-none rounded-2xl font-black text-[10px] uppercase" value={filters.brand_id} onChange={e => setFilters({...filters, brand_id: e.target.value})}>
            <option value="">Toutes Marques</option>
            {brands.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
        </select>
        <button onClick={fetchData} className="w-10 h-10 bg-slate-50 text-slate-400 rounded-full flex items-center justify-center border border-slate-100 active:scale-90"><i className="ti ti-refresh text-lg"></i></button>
      </div>

      {/* DENSE MACHINE GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {machines.map((m: any) => (
          <div key={m.id} className="bg-white rounded-[2.5rem] shadow-sm border border-slate-100 overflow-hidden hover:shadow-xl transition-all duration-500 group relative flex flex-col h-full">
              <div className="h-44 bg-slate-50 relative overflow-hidden shrink-0 flex items-center justify-center border-b border-slate-50">
                  <img src={getFullImageUrl(m.image_url)} className="w-full h-full object-contain p-6 group-hover:scale-110 transition-transform duration-700" alt="" />
                  <div className="absolute top-4 left-4 flex flex-col gap-1.5">
                      <div className="bg-white/90 px-3 py-1 rounded-full text-[8px] font-black text-blue-600 shadow-sm uppercase tracking-widest border border-blue-100">REF: {m.reference}</div>
                      <div className="bg-slate-900 px-3 py-1 rounded-full text-[8px] font-black text-white shadow-sm uppercase tracking-widest">S/N: {m.serial_no}</div>
                  </div>
                  <div className="absolute top-4 right-4 flex flex-col gap-1.5 opacity-0 group-hover:opacity-100 transition-all translate-x-2 group-hover:translate-x-0">
                      <button onClick={() => handleOpenModal('edit', m)} className="w-9 h-9 rounded-xl bg-white text-blue-600 flex items-center justify-center shadow-lg hover:bg-blue-600 hover:text-white transition-all"><i className="ti ti-edit"></i></button>
                      <button onClick={() => handleOpenModal('delete', m)} className="w-9 h-9 rounded-xl bg-white text-red-600 flex items-center justify-center shadow-lg hover:bg-red-600 hover:text-white transition-all"><i className="ti ti-trash"></i></button>
                  </div>
              </div>
              <div className="p-6 space-y-4 flex-1 flex flex-col">
                  <div className="space-y-1">
                      <div className="flex justify-between items-start gap-2">
                          <h3 className="text-base font-black text-slate-800 tracking-tight leading-tight truncate">{m.name}</h3>
                          <div className="text-right shrink-0">
                              <span className="text-blue-600 font-black text-sm tracking-tighter block leading-none">{formatPriceTTC(m.price_ht)}</span>
                              <span className="text-[7px] font-black text-slate-400 uppercase tracking-widest">MAD TTC</span>
                          </div>
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                         <span className="px-2 py-0.5 bg-slate-100 text-slate-500 rounded text-[8px] font-black uppercase tracking-tighter">{m.brand?.name || 'Specta'}</span>
                         <span className="px-2 py-0.5 bg-blue-50 text-blue-500 rounded text-[8px] font-black uppercase tracking-tighter">MOD: {m.model || 'Univ.'}</span>
                      </div>
                  </div>
                  
                  <div className="bg-slate-50 p-4 rounded-2xl space-y-3 flex-1 border border-slate-100/50">
                      <div className="grid grid-cols-1 gap-2">
                          <div className="flex justify-between items-center border-b border-slate-200/50 pb-1.5">
                              <p className="text-[7px] font-bold text-slate-400 uppercase tracking-widest">S/N Tracking</p>
                              <p className="text-[9px] font-black text-slate-700 truncate ml-2">{m.serial_no}</p>
                          </div>
                          <div className="pt-1">
                              <p className="text-[7px] font-bold text-slate-400 uppercase mb-1">Accessoires</p>
                              <p className="text-[9px] font-bold text-blue-600 line-clamp-1 italic leading-tight">
                                {m.accessories ? m.accessories.split('\n').filter(Boolean).join(', ') : 'Standard Config'}
                              </p>
                          </div>
                      </div>
                  </div>

                  <button onClick={() => handleOpenModal('view', m)} className="w-full py-3.5 bg-slate-900 text-white rounded-xl font-black text-[9px] uppercase tracking-[2px] active:scale-95 transition-all flex items-center justify-center gap-2 shadow-sm">
                      <i className="ti ti-file-certificate text-base text-blue-400"></i> Passeport Tech
                  </button>
              </div>
          </div>
        ))}
      </div>

      {modal.type && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[150] flex items-center justify-center p-4">
          <div className={`bg-white w-full ${modal.type === 'view' ? 'max-w-6xl' : 'max-w-4xl'} rounded-[3rem] shadow-2xl overflow-hidden animate-in zoom-in-95 border-4 border-white flex flex-col max-h-[90vh]`}>
            <div className="p-6 border-b flex justify-between items-center bg-slate-50/50 shrink-0">
              <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-blue-600 text-white rounded-xl flex items-center justify-center text-xl shadow-lg shadow-blue-100"><i className="ti ti-device-analytics"></i></div>
                  <h2 className="text-xl font-black uppercase text-[10px] tracking-[4px]">{modal.type} Asset Protocol</h2>
              </div>
              <button onClick={() => setModal({ type: null, item: null })} className="w-10 h-10 flex items-center justify-center bg-white rounded-full text-slate-400 hover:text-red-500 shadow-md transition-all text-xl font-light">×</button>
            </div>

            <div className="p-8 overflow-y-auto custom-scrollbar flex-1">
              {modal.type === 'view' ? (
                <div className="space-y-8">
                    <div className="flex flex-col md:flex-row gap-8 items-center bg-slate-50 p-6 rounded-[2.5rem] border border-slate-100 shadow-inner">
                        <div className="w-40 h-40 bg-white rounded-3xl overflow-hidden shadow-sm p-4 shrink-0 flex items-center justify-center border-2 border-white">
                            <img src={getFullImageUrl(modal.item.image_url)} className="w-full h-full object-contain" alt="" />
                        </div>
                        <div className="space-y-3 flex-1 min-w-0">
                            <div>
                                <h3 className="text-3xl font-black text-slate-800 tracking-tighter truncate leading-none mb-1">{modal.item.name}</h3>
                                <p className="text-xs font-bold text-blue-600 uppercase tracking-widest">{modal.item.brand?.name} • {modal.item.model || 'Universal Specification'}</p>
                            </div>
                            <div className="flex flex-wrap gap-3">
                                <DetailBadge label="REF" value={modal.item.reference} />
                                <DetailBadge label="S/N" value={modal.item.serial_no} dark />
                                <DetailBadge label="PRICE TTC" value={`${formatPriceTTC(modal.item.price_ht)} MAD`} blue />
                            </div>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                        <div className="lg:col-span-2 space-y-10">
                            <section className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm relative overflow-hidden">
                                <h4 className="text-[10px] font-black text-blue-600 uppercase tracking-[4px] border-b pb-3 mb-6 flex items-center gap-2"><i className="ti ti-plug text-lg"></i> Pièces à Main Incluses</h4>
                                <div className="p-6 bg-slate-50 rounded-[1.5rem] border border-slate-100 shadow-inner min-h-[80px] flex items-center">
                                    <p className="text-slate-700 font-bold text-sm leading-relaxed italic">
                                        {modal.item.accessories ? (
                                            modal.item.accessories.split('\n').filter(Boolean).join(', ')
                                        ) : (
                                            <span className="text-slate-300 uppercase tracking-widest text-[10px]">Aucun accessoire répertorié.</span>
                                        )}
                                    </p>
                                </div>
                            </section>

                            <section>
                                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[3px] px-4 border-b pb-2 mb-6">Fathometer Documentation (Technical Cloud)</h4>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    {modal.item.documents?.map((doc: any) => (
                                        <div key={doc.id} className="p-4 bg-white border border-slate-100 rounded-2xl flex items-center justify-between group hover:shadow-lg transition-all border-l-4 border-l-blue-500">
                                            <div className="flex items-center gap-3 min-w-0">
                                                <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center text-blue-600"><i className={`ti ti-file-text text-xl`}></i></div>
                                                <div className="min-w-0"><p className="font-black text-slate-800 text-[11px] truncate">{doc.title}</p></div>
                                            </div>
                                            <div className="flex gap-1.5">
                                                <a href={`https://birdeye-intelligence.ma/Spetcapp/Backend/storage/app/public/${doc.file_path}`} target="_blank" className="w-9 h-9 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center hover:bg-blue-600 hover:text-white transition-all shadow-sm"><i className="ti ti-eye"></i></a>
                                                <button onClick={() => handleDeleteDoc(doc.id)} className="w-9 h-9 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center hover:bg-rose-600 hover:text-white transition-all shadow-sm"><i className="ti ti-trash"></i></button>
                                            </div>
                                        </div>
                                    ))}
                                    {(!modal.item.documents || modal.item.documents.length === 0) && (
                                        <div className="col-span-full py-10 text-center border-2 border-dashed border-slate-100 rounded-3xl opacity-30 italic text-xs uppercase tracking-widest">No cloud documents</div>
                                    )}
                                </div>
                            </section>
                        </div>

                        <div className="space-y-6">
                            <div className="bg-slate-900 p-8 rounded-[2.5rem] text-white space-y-6 shadow-2xl">
                                <h4 className="text-[9px] font-black text-blue-400 uppercase tracking-[4px]">Data Ingestion Portal</h4>
                                <div className="space-y-4">
                                    <input type="text" placeholder="Document Title..." value={docTitle} onChange={e => setDocTitle(e.target.value)} className="w-full px-5 py-4 bg-white/5 border border-white/10 rounded-2xl outline-none text-[10px] font-bold text-white shadow-inner" />
                                    <label className={`w-full py-6 border-2 border-dashed rounded-2xl font-black uppercase text-[9px] tracking-[2px] transition-all flex flex-col items-center justify-center gap-2 cursor-pointer ${selectedFile ? 'bg-blue-600 border-white' : 'bg-white/5 border-white/20 text-blue-200'}`}>
                                        <i className="ti ti-cloud-upload text-3xl mb-1"></i>
                                        {selectedFile ? 'File Synced' : 'Select PDF/Image'}
                                        <input ref={fileInputRef} type="file" className="hidden" onChange={e => setSelectedFile(e.target.files?.[0] || null)} />
                                    </label>
                                    {selectedFile && <button onClick={handleUploadDocument} disabled={isUploadingDoc} className="w-full py-4 bg-white text-slate-900 rounded-xl font-black uppercase text-[10px] tracking-[2px] shadow-2xl active:scale-95 transition-all">Upload Now</button>}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
              ) : (
                <form onSubmit={handleSave} className="space-y-6 animate-in slide-in-from-bottom-4">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                        <div className="space-y-6">
                            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[4px] border-b pb-2">Identification Node</h4>
                            <div className="space-y-4">
                                <FormInput label="Asset Commercial Name" name="name" defaultValue={modal.item.name} required />
                                <div className="grid grid-cols-2 gap-4">
                                    <FormInput label="Model / Spec" name="model" defaultValue={modal.item.model} />
                                    <FormInput label="Internal REF" name="reference" defaultValue={modal.item.reference} required />
                                </div>
                                <FormInput label="Machine Serial Number (S/N)" name="serial_no" defaultValue={modal.item.serial_no} required />
                                
                                <div className="space-y-1.5">
                                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-4">Accessories Checklist (One per line)</label>
                                    <textarea name="accessories" defaultValue={modal.item.accessories} placeholder="E.g: Laser head 6mm&#10;Water pump module..." className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl outline-none font-bold shadow-inner h-24 text-[11px]" />
                                </div>
                                
                                <div className="flex items-center gap-4 pt-4 bg-slate-50 p-4 rounded-2xl border border-slate-100 shadow-inner">
                                    <div className="w-16 h-16 rounded-2xl bg-white border-2 border-white shadow-md overflow-hidden shrink-0 flex items-center justify-center">
                                        {previewUrl ? <img src={previewUrl} className="w-full h-full object-contain" /> : <i className="ti ti-photo text-slate-200 text-2xl"></i>}
                                    </div>
                                    <label className="flex-1 px-4 py-3 bg-blue-600 text-white rounded-xl font-black text-[9px] uppercase tracking-[1px] cursor-pointer hover:bg-blue-700 transition-all text-center shadow-lg active:scale-95">
                                        Update Asset Photo
                                        <input name="image" type="file" className="hidden" accept="image/*" onChange={e => {
                                            const file = e.target.files?.[0];
                                            if (file) setPreviewUrl(URL.createObjectURL(file));
                                        }} />
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div className="space-y-6">
                            <h4 className="text-[10px] font-black text-blue-600 uppercase tracking-[4px] border-b pb-2">Financial Matrix (TTC Interface)</h4>
                            <div className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                    <FormInput 
                                        label="Prix Catalogue TTC" 
                                        name="price_ht" 
                                        type="number" 
                                        step="0.01" 
                                        defaultValue={modal.item.price_ht ? (modal.item.price_ht * 1.2).toFixed(2) : ''} 
                                        required 
                                    />
                                    <FormInput 
                                        label="Prix Plancher TTC" 
                                        name="min_price_ht" 
                                        type="number" 
                                        step="0.01" 
                                        defaultValue={modal.item.min_price_ht ? (modal.item.min_price_ht * 1.2).toFixed(2) : ''} 
                                        required 
                                    />
                                </div>
                                <div className="space-y-1">
                                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-4">Brand / Manufacturer</label>
                                    <select name="brand_id" defaultValue={modal.item.brand_id} className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl outline-none font-bold shadow-inner text-xs">
                                        <option value="">-- Choose Brand --</option>
                                        {brands.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                                    </select>
                                </div>
                                <div className="space-y-1">
                                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-4">Maintenance Notes (Internal)</label>
                                    <textarea name="description" defaultValue={modal.item.description} className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl outline-none font-medium h-32 shadow-inner text-[11px]" placeholder="Specific technical requirements..." />
                                </div>
                            </div>
                        </div>
                    </div>
                    <button type="submit" disabled={isSubmitting} className="w-full py-6 bg-slate-900 text-white rounded-[2rem] font-black uppercase text-[11px] tracking-[4px] shadow-2xl active:scale-95 transition-all">Syndicate Asset Passport</button>
                </form>
              )}
            </div>
            <div className="p-6 border-t bg-slate-50 flex justify-center shrink-0">
                <button onClick={() => setModal({ type: null, item: null })} className="px-16 py-4 bg-white border border-slate-200 text-slate-500 rounded-2xl font-black uppercase text-[9px] tracking-[4px] active:scale-95 transition-all shadow-sm">Close Protocol</button>
            </div>
          </div>
        </div>
      )}

      {/* COMPACT DELETE */}
      {modal.type === 'delete' && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[200] flex items-center justify-center p-4">
             <div className="bg-white rounded-[2.5rem] shadow-2xl p-10 text-center max-w-sm w-full animate-in zoom-in-95 border-4 border-white">
                <div className="w-16 h-16 bg-rose-50 text-rose-500 rounded-2xl flex items-center justify-center text-3xl mx-auto mb-6 shadow-inner"><i className="ti ti-trash"></i></div>
                <h3 className="text-xl font-black text-slate-800 tracking-tight mb-2">Retirer du Parc?</h3>
                <p className="text-slate-500 text-[10px] font-medium leading-relaxed mb-8 italic uppercase tracking-wider">This action isolates the asset from future commercial quotes.</p>
                <div className="flex gap-3">
                    <button onClick={() => setModal({ type: null, item: null })} className="flex-1 py-4 bg-slate-50 text-slate-400 rounded-xl font-black text-[9px] uppercase tracking-widest active:scale-95">Discard</button>
                    <button onClick={async () => { try { setIsSubmitting(true); await api.machines.delete(modal.item.id); setModal({ type: null, item: null }); fetchData(); } catch(e){ alert("Error archiving"); } finally { setIsSubmitting(false); } }} className="flex-1 py-4 bg-rose-600 text-white rounded-xl font-black text-[9px] uppercase tracking-widest shadow-lg active:scale-95">Archiver</button>
                </div>
             </div>
        </div>
      )}
    </div>
  );
}

function FormInput({ label, name, defaultValue, type = "text", required = false, step = "any" }: any) {
    return (
        <div className="space-y-1">
            <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-4">{label}</label>
            <input name={name} type={type} step={step} defaultValue={defaultValue} className="w-full px-6 py-3.5 bg-slate-50 border-none rounded-2xl outline-none font-bold shadow-inner text-xs" required={required} />
        </div>
    )
}

function CompactKPI({ label, value, icon, color }: any) {
    return (
        <div className="bg-white p-4 rounded-[1.75rem] border border-slate-100 shadow-sm flex items-center gap-4 group transition-all hover:shadow-lg">
            <div className={`w-10 h-10 rounded-xl ${color} flex items-center justify-center text-white text-xl shadow-md transition-transform group-hover:rotate-6`}>
                <i className={`ti ${icon}`}></i>
            </div>
            <div className="min-w-0">
                <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-0.5 truncate">{label}</p>
                <p className="text-sm font-black text-slate-800 tracking-tight truncate leading-none">{value}</p>
            </div>
        </div>
    );
}

function DetailBadge({ label, value, blue, dark }: any) {
    return (
        <div className={`px-4 py-2 rounded-2xl text-[9px] font-black uppercase tracking-widest shadow-sm ${
            blue ? 'bg-blue-600 text-white' : 
            dark ? 'bg-slate-800 text-white' : 
            'bg-white text-slate-500 border border-slate-100'
        }`}>
            {label}: <span className={blue || dark ? 'text-white/80' : 'text-slate-800'}>{value}</span>
        </div>
    );
}
