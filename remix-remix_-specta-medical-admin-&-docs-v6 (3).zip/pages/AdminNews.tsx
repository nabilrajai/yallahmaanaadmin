
import React, { useState, useEffect } from 'react';
import { api } from '../api';
import { useApp } from '../App';

export default function AdminNews() {
  const { theme } = useApp();
  const [news, setNews] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<{ type: 'add' | 'edit' | 'delete' | null, item: any }>({ type: null, item: null });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const fetchNews = async () => {
    setLoading(true);
    try {
      const res = await api.news.list();
      setNews(Array.isArray(res.data) ? res.data : (Array.isArray(res) ? res : []));
    } catch (e) {
      console.error(e);
      setNews([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchNews(); }, []);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          setImagePreview(URL.createObjectURL(file));
      }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    
    try {
      if (modal.type === 'add') {
        await api.news.create(formData);
      } else {
        await api.news.update(modal.item.id, formData);
      }
      setModal({ type: null, item: null });
      setImagePreview(null);
      fetchNews();
    } catch (e: any) {
      alert(e.message || "Erreur de sauvegarde.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleToggle = async (id: number) => {
      try {
          await api.news.toggle(id);
          fetchNews();
      } catch (e) {
          alert("Erreur lors du changement de visibilité.");
      }
  };

  const handleDelete = async () => {
    setIsSubmitting(true);
    try {
      await api.news.delete(modal.item.id);
      setModal({ type: null, item: null });
      fetchNews();
    } catch (e) {
      alert("Erreur de suppression.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const getFullUrl = (path: string) => {
    if (!path) return 'https://placehold.co/600x400?text=SPECTA+NEWS';
    if (path.startsWith('http')) return path;
    return `https://birdeye-intelligence.ma/Spetcapp/Backend/storage/app/public/${path}`;
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-700 pb-20">
      {/* KPI SECTION */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <NewsKPI label="Total Actualités" value={news.length} icon="ti-news" color="bg-blue-600" />
          <NewsKPI label="En Ligne (Actifs)" value={news.filter(n => n.is_active).length} icon="ti-eye" color="bg-emerald-600" />
          <NewsKPI label="Articles Masqués" value={news.filter(n => !n.is_active).length} icon="ti-eye-off" color="bg-slate-400" />
          <NewsKPI label="Dernière Publication" value={news[0] ? new Date(news[0].created_at).toLocaleDateString() : 'N/A'} icon="ti-calendar-event" color="bg-indigo-600" />
      </div>

      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-8 bg-white p-10 rounded-[4rem] shadow-sm border border-slate-100">
        <div>
          <h1 className="text-4xl font-black text-slate-800 tracking-tighter mb-1">Actualités Mobile</h1>
          <p className="text-slate-400 font-black uppercase text-[10px] tracking-[4px] opacity-70 italic">Gestion de contenu dynamique pour l'App Specta</p>
        </div>
        <button 
          onClick={() => { setModal({ type: 'add', item: { is_active: 1 } }); setImagePreview(null); }}
          className="bg-blue-600 text-white px-10 py-5 rounded-[2rem] font-black shadow-2xl shadow-blue-100 hover:bg-blue-700 transition-all flex items-center gap-3 active:scale-95"
        >
          <i className="ti ti-plus text-xl"></i> Nouvel Article
        </button>
      </div>

      {loading && news.length === 0 ? (
        <div className="py-40 text-center"><div className="animate-spin h-16 w-16 border-t-4 border-blue-600 rounded-full mx-auto"></div></div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
           {news.map(item => (
             <div key={item.id} className={`group bg-white rounded-[3.5rem] overflow-hidden border border-slate-100 shadow-sm hover:shadow-2xl transition-all duration-700 relative flex flex-col ${!item.is_active ? 'opacity-60' : ''}`}>
                <div className="h-64 overflow-hidden relative">
                    <img src={getFullUrl(item.image_url)} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" alt="" />
                    <div className={`absolute top-6 left-6 px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest shadow-xl border-2 border-white ${item.is_active ? 'bg-emerald-500 text-white' : 'bg-slate-400 text-white'}`}>
                        {item.is_active ? 'Public' : 'Masqué'}
                    </div>
                </div>

                <div className="p-10 space-y-6 flex-1 flex flex-col">
                    <div className="space-y-2">
                        <p className="text-[9px] font-black text-blue-600 uppercase tracking-widest leading-none flex items-center gap-2">
                           <i className="ti ti-calendar"></i> {new Date(item.created_at).toLocaleDateString()}
                        </p>
                        <h4 className="text-xl font-black text-slate-800 leading-tight line-clamp-2">{item.title}</h4>
                    </div>
                    
                    <p className="text-slate-500 text-sm font-medium leading-relaxed line-clamp-3 italic flex-1">
                        "{item.description}"
                    </p>

                    <div className="pt-6 border-t border-slate-50 flex items-center justify-between">
                        <div className="flex gap-2">
                            <button onClick={() => handleToggle(item.id)} className={`w-11 h-11 rounded-xl flex items-center justify-center shadow-sm transition-all ${item.is_active ? 'bg-amber-50 text-amber-600 hover:bg-amber-500 hover:text-white' : 'bg-emerald-50 text-emerald-600 hover:bg-emerald-500 hover:text-white'}`} title={item.is_active ? 'Désactiver' : 'Activer'}>
                                <i className={`ti ${item.is_active ? 'ti-eye-off' : 'ti-eye'} text-xl`}></i>
                            </button>
                            <button onClick={() => { setModal({ type: 'edit', item }); setImagePreview(getFullUrl(item.image_url)); }} className="w-11 h-11 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center hover:bg-blue-600 hover:text-white transition-all shadow-sm">
                                <i className="ti ti-edit text-xl"></i>
                            </button>
                        </div>
                        <button onClick={() => setModal({ type: 'delete', item })} className="w-11 h-11 bg-rose-50 text-rose-600 rounded-xl flex items-center justify-center hover:bg-red-600 hover:text-white transition-all shadow-sm">
                            <i className="ti ti-trash text-xl"></i>
                        </button>
                    </div>
                </div>
             </div>
           ))}
           {news.length === 0 && (
               <div className="col-span-full py-40 text-center border-4 border-dashed border-slate-100 rounded-[4rem] opacity-30">
                   <i className="ti ti-news text-8xl mb-4 block"></i>
                   <p className="font-black uppercase text-xs tracking-[5px]">Aucune actualité enregistrée</p>
               </div>
           )}
        </div>
      )}

      {/* FORM MODAL */}
      {(modal.type === 'add' || modal.type === 'edit') && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[150] flex items-center justify-center p-4">
             <div className="bg-white w-full max-w-4xl rounded-[4rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 border-4 border-white flex flex-col max-h-[90vh]">
                <div className="p-10 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                    <div>
                        <h2 className="text-2xl font-black text-slate-800 tracking-tighter uppercase text-[10px] tracking-[4px]">{modal.type === 'add' ? 'Publier' : 'Mettre à jour'} un Article</h2>
                        <p className="text-slate-400 font-bold text-[9px] uppercase tracking-widest mt-1">Éditeur de Contenu Mobile</p>
                    </div>
                    <button onClick={() => setModal({ type: null, item: null })} className="w-12 h-12 flex items-center justify-center bg-white rounded-full text-slate-400 hover:text-red-500 shadow-md transition-all text-2xl font-light hover:rotate-90">×</button>
                </div>
                <form onSubmit={handleSave} className="p-10 lg:p-12 flex flex-col lg:flex-row gap-12 overflow-y-auto custom-scrollbar">
                    <div className="flex-1 space-y-8">
                        <div className="space-y-1">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Titre de l'Actualité</label>
                            <input name="title" defaultValue={modal.item.title} className="w-full px-8 py-5 bg-slate-50 border-none rounded-[1.75rem] outline-none font-black text-xl shadow-inner placeholder-slate-300" placeholder="Le nouveau Laser Specta V3 est arrivé..." required />
                        </div>
                        <div className="space-y-1">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Description / Corps du texte</label>
                            <textarea name="description" defaultValue={modal.item.description} className="w-full px-8 py-5 bg-slate-50 border-none rounded-[1.75rem] outline-none font-medium h-48 shadow-inner leading-relaxed italic" placeholder="Détails de l'annonce pour les clients..." required />
                        </div>
                        
                        <div className="grid grid-cols-2 gap-6">
                            <div className="space-y-1">
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Date de Publication</label>
                                <input name="created_at" type="date" defaultValue={modal.item.created_at ? new Date(modal.item.created_at).toISOString().split('T')[0] : new Date().toISOString().split('T')[0]} className="w-full px-8 py-4 bg-slate-50 border-none rounded-[1.5rem] outline-none font-bold" />
                            </div>
                            <div className="space-y-1">
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Visibilité Immédiate</label>
                                <select name="is_active" defaultValue={modal.item.is_active ? 1 : 0} className="w-full px-8 py-4 bg-slate-50 border-none rounded-[1.5rem] outline-none font-black uppercase text-[10px] tracking-widest">
                                    <option value={1}>Activée (Public)</option>
                                    <option value={0}>Désactivée (Brouillon)</option>
                                </select>
                            </div>
                        </div>

                        <button 
                            disabled={isSubmitting}
                            className="w-full py-7 bg-blue-600 text-white rounded-[3rem] font-black uppercase text-xs tracking-[5px] shadow-2xl active:scale-95 transition-all flex items-center justify-center gap-4 disabled:opacity-50"
                        >
                            {isSubmitting ? <div className="animate-spin h-5 w-5 border-2 border-white/30 border-t-white rounded-full"></div> : <i className="ti ti-cloud-upload text-2xl"></i>}
                            {isSubmitting ? 'Syndication en cours...' : 'Déployer sur l\'Application'}
                        </button>
                    </div>

                    <div className="w-full lg:w-80 space-y-6">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Visuel de Couverture</p>
                        <div className="aspect-[3/4] bg-slate-100 rounded-[3rem] border-4 border-slate-50 overflow-hidden relative shadow-inner flex items-center justify-center group">
                            {imagePreview ? (
                                <img src={imagePreview} className="w-full h-full object-cover" alt="" />
                            ) : (
                                <div className="text-center p-8 space-y-4">
                                    <i className="ti ti-photo-plus text-6xl text-slate-200"></i>
                                    <p className="text-[9px] text-slate-300 font-black uppercase tracking-widest">Aucune Image Sélectionnée</p>
                                </div>
                            )}
                            <label className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-all flex flex-col items-center justify-center text-white gap-2 cursor-pointer backdrop-blur-sm">
                                <i className="ti ti-camera text-4xl"></i>
                                <span className="font-black uppercase text-[10px] tracking-widest">Changer l'image</span>
                                <input name="image" type="file" className="hidden" accept="image/*" onChange={handleImageChange} />
                            </label>
                        </div>
                    </div>
                </form>
             </div>
        </div>
      )}

      {/* DELETE MODAL */}
      {modal.type === 'delete' && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[200] flex items-center justify-center p-4">
             <div className="bg-white rounded-[4rem] shadow-2xl p-14 text-center max-w-sm w-full animate-in zoom-in-95 border-4 border-white">
                <div className="w-24 h-24 bg-rose-50 text-rose-500 rounded-[3rem] flex items-center justify-center mx-auto text-5xl mb-10 shadow-inner animate-bounce">
                    <i className="ti ti-trash"></i>
                </div>
                <h3 className="text-3xl font-black text-slate-800 tracking-tight mb-4 leading-tight">Supprimer cet article ?</h3>
                <p className="text-slate-500 text-sm font-medium leading-relaxed mb-12 italic px-4">L'article sera définitivement retiré du flux mobile de tous les clients.</p>
                <div className="flex gap-4">
                    <button onClick={() => setModal({ type: null, item: null })} className="flex-1 py-6 bg-slate-50 text-slate-400 rounded-2xl font-black text-[10px] uppercase tracking-widest active:scale-95 transition-all">Garder</button>
                    <button onClick={handleDelete} disabled={isSubmitting} className="flex-1 py-6 bg-rose-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-rose-200 active:scale-95 transition-all">
                        {isSubmitting ? '...' : 'Supprimer'}
                    </button>
                </div>
             </div>
        </div>
      )}
    </div>
  );
}

function NewsKPI({ label, value, icon, color }: any) {
    return (
        <div className="bg-white p-8 rounded-[3.5rem] border border-slate-100 shadow-sm flex items-center gap-6 group hover:shadow-2xl transition-all relative overflow-hidden">
            <div className={`w-16 h-16 rounded-[1.75rem] ${color} flex items-center justify-center text-white text-3xl shadow-xl transition-transform group-hover:rotate-12`}>
                <i className={`ti ${icon}`}></i>
            </div>
            <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-[3px] mb-1">{label}</p>
                <p className="text-2xl font-black text-slate-800 tracking-tighter leading-none">{value}</p>
            </div>
            <div className={`absolute -right-6 -bottom-6 w-24 h-24 ${color} opacity-5 rounded-full`}></div>
        </div>
    );
}
