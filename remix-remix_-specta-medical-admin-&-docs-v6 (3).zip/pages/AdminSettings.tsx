
import React, { useState, useEffect } from 'react';
import { api } from '../api';
import { useApp } from '../App';

export default function AdminSettings() {
  const { theme, setTheme, primaryColor, setPrimaryColor } = useApp();
  const [config, setConfig] = useState<any>({});
  const [isSaving, setIsSaving] = useState(false);

  const fetchConfig = async () => {
      try {
          const res = await api.request('/settings');
          // Format as object
          const map: any = {};
          (res.data || res || []).forEach((s: any) => map[s.key] = s.value);
          setConfig(map);
      } catch (e) { console.error(e); }
  };

  useEffect(() => { fetchConfig(); }, []);

  const handleSaveConfig = async (e: React.FormEvent) => {
      e.preventDefault();
      setIsSaving(true);
      try {
          await api.request('/settings/bulk', {
              method: 'POST',
              body: JSON.stringify({ settings: config })
          });
          alert("Configuration d'entreprise synchronisée.");
      } catch (e) { alert("Échec de la synchronisation."); } finally { setIsSaving(false); }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-10 animate-in fade-in slide-in-from-bottom-6 duration-700 pb-20">
      <div className="text-center lg:text-left space-y-2">
        <h1 className="text-5xl font-black tracking-tighter">Paramètres Globaux</h1>
        <p className="text-slate-400 font-black uppercase text-[10px] tracking-[4px] opacity-60">Identité d'Entreprise & Règles de Flux</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <section className="p-10 bg-white rounded-[4rem] border border-slate-100 shadow-xl shadow-slate-200/50">
            <h3 className="text-xl font-black tracking-tight mb-8 flex items-center gap-3"><i className="ti ti-brush text-blue-600"></i> Système d'Identité</h3>
            <div className="grid grid-cols-3 gap-4">
                {['#2563eb', '#0d9488', '#4f46e5', '#e11d48', '#334155', '#166534'].map(c => (
                    <button key={c} onClick={() => setPrimaryColor(c)} className={`h-16 rounded-3xl border-4 ${primaryColor === c ? 'border-slate-900 scale-105 shadow-2xl' : 'border-transparent'}`} style={{ backgroundColor: c }} />
                ))}
            </div>
            <div className="mt-8 flex p-1.5 bg-slate-100 rounded-[2.5rem]">
                <button onClick={() => setTheme('light')} className={`flex-1 py-3 rounded-3xl text-[10px] font-black uppercase tracking-widest transition-all ${theme === 'light' ? 'bg-white text-blue-600 shadow-lg' : 'text-slate-400'}`}>Clair</button>
                <button onClick={() => setTheme('dark')} className={`flex-1 py-3 rounded-3xl text-[10px] font-black uppercase tracking-widest transition-all ${theme === 'dark' ? 'bg-white text-blue-600 shadow-lg' : 'text-slate-400'}`}>Sombre</button>
            </div>
        </section>

        <section className="p-10 bg-slate-900 rounded-[4rem] text-white shadow-2xl">
            <h3 className="text-xl font-black tracking-tight mb-8 flex items-center gap-3"><i className="ti ti-file-text text-blue-400"></i> Structure des Docs</h3>
            <div className="space-y-4">
                <div className="space-y-1">
                    <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest ml-4">Préfixe Devis</label>
                    <input 
                        value={config.quote_prefix || ''} 
                        onChange={e => setConfig({...config, quote_prefix: e.target.value})}
                        className="w-full px-6 py-4 bg-white/5 border border-white/10 rounded-2xl outline-none font-bold text-blue-400" placeholder="DEV-" 
                    />
                </div>
                <div className="space-y-1">
                    <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest ml-4">Préfixe Commande</label>
                    <input 
                        value={config.order_prefix || ''} 
                        onChange={e => setConfig({...config, order_prefix: e.target.value})}
                        className="w-full px-6 py-4 bg-white/5 border border-white/10 rounded-2xl outline-none font-bold text-blue-400" placeholder="CMD-" 
                    />
                </div>
            </div>
        </section>
      </div>

      <form onSubmit={handleSaveConfig} className="p-12 bg-white rounded-[4rem] border border-slate-100 shadow-sm space-y-8">
          <h3 className="text-2xl font-black tracking-tight border-b pb-6">Informations de l'Entreprise (Utilisées dans les PDFs)</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <InputBox label="Nom Officiel de l'Entreprise" value={config.company_name} onChange={v => setConfig({...config, company_name: v})} />
              <InputBox label="Email de Support" value={config.company_email} onChange={v => setConfig({...config, company_email: v})} />
              <InputBox label="Téléphone Direct" value={config.company_phone} onChange={v => setConfig({...config, company_phone: v})} />
              <InputBox label="Adresse Physique Complète" value={config.company_address} onChange={v => setConfig({...config, company_address: v})} />
          </div>
          <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">Pied de page standard / Conditions de Devis</label>
              <textarea 
                value={config.quote_footer} 
                onChange={e => setConfig({...config, quote_footer: e.target.value})}
                className="w-full px-8 py-5 bg-slate-50 border-none rounded-[2rem] outline-none h-32 italic font-medium" 
              />
          </div>
          <button type="submit" disabled={isSaving} className="w-full py-6 bg-blue-600 text-white rounded-[2.5rem] font-black uppercase text-xs tracking-[5px] shadow-2xl active:scale-95 transition-all">
              {isSaving ? 'Synchronisation Cloud...' : "Mettre à jour l'Identité de l'Entreprise"}
          </button>
      </form>
    </div>
  );
}

function InputBox({ label, value, onChange }: any) {
    return (
        <div className="space-y-1">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">{label}</label>
            <input value={value || ''} onChange={e => onChange(e.target.value)} className="w-full px-8 py-4 bg-slate-50 border-none rounded-[1.75rem] outline-none font-bold text-slate-700 shadow-inner" />
        </div>
    )
}
