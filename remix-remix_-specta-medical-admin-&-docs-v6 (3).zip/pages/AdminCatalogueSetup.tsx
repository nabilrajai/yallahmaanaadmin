
import React, { useState, useEffect } from 'react';
import { api } from '../api';
import { useApp } from '../App';
import { Category, Brand } from '../types';

export default function AdminCatalogueSetup() {
  const { t, theme } = useApp();
  const [activeTab, setActiveTab] = useState<'categories' | 'brands'>('categories');
  const [categories, setCategories] = useState<Category[]>([]);
  const [brands, setBrands] = useState<Brand[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<{ type: 'add' | 'edit' | 'delete' | null, item: any, mode: 'category' | 'brand' }>({ type: null, item: null, mode: 'category' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [search, setSearch] = useState('');

  const fetchData = async () => {
    setLoading(true);
    try {
      const [cRes, bRes] = await Promise.all([
        api.categories.list('per_page=200'),
        api.brands.list('per_page=200')
      ]);
      setCategories(Array.isArray(cRes.data) ? cRes.data : (Array.isArray(cRes) ? cRes : []));
      setBrands(Array.isArray(bRes.data) ? bRes.data : (Array.isArray(bRes) ? bRes : []));
    } catch (e) {
      console.error("Fetch Error:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    const form = e.target as HTMLFormElement;
    const data = Object.fromEntries(new FormData(form).entries());
    
    try {
      const targetApi = modal.mode === 'category' ? api.categories : api.brands;
      if (modal.type === 'add') {
        await targetApi.create(data);
      } else {
        await targetApi.update(modal.item.id, data);
      }
      setModal({ type: null, item: null, mode: 'category' });
      fetchData();
    } catch (e: any) {
      alert(e.message || "Operation failed");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async () => {
    setIsSubmitting(true);
    try {
      const targetApi = modal.mode === 'category' ? api.categories : api.brands;
      await targetApi.delete(modal.item.id);
      setModal({ type: null, item: null, mode: 'category' });
      fetchData();
    } catch (e) {
      alert("Delete failed");
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredData = activeTab === 'categories' 
    ? categories.filter(c => c.name.toLowerCase().includes(search.toLowerCase()))
    : brands.filter(b => b.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-8 pb-20 animate-in fade-in duration-700">
      {/* KPI DASHBOARD */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <RegistryKPI label="Global Brands" value={brands.length} icon="ti-award" color="bg-blue-600" />
          <RegistryKPI label="Active Categories" value={categories.filter(c => c.is_active).length} icon="ti-category" color="bg-emerald-600" />
          <RegistryKPI label="Registry Load" value={`${categories.length + brands.length} Items`} icon="ti-database-import" color="bg-amber-500" />
          <RegistryKPI label="Sync Status" value="Online" icon="ti-cloud-check" color="bg-indigo-600" />
      </div>

      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-8 bg-white p-10 rounded-[4rem] shadow-sm border border-slate-100">
        <div>
          <h1 className="text-4xl font-black text-slate-800 tracking-tighter mb-1">Catalogue Intelligence</h1>
          <p className="text-slate-400 font-black uppercase text-[10px] tracking-[4px] opacity-70 italic">Taxonomy Control, Global Brands & Product Classes</p>
        </div>
        <div className="flex gap-4 p-2 bg-slate-100 rounded-[2.5rem] border border-slate-100">
            <button 
                onClick={() => setActiveTab('categories')} 
                className={`px-8 py-3 rounded-[2rem] text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'categories' ? 'bg-white text-blue-600 shadow-xl scale-105' : 'text-slate-400 hover:text-slate-600'}`}
            >
                Classification
            </button>
            <button 
                onClick={() => setActiveTab('brands')} 
                className={`px-8 py-3 rounded-[2rem] text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'brands' ? 'bg-white text-blue-600 shadow-xl scale-105' : 'text-slate-400 hover:text-slate-600'}`}
            >
                Brand Registry
            </button>
        </div>
      </div>

      <div className="bg-white p-6 rounded-[3.5rem] shadow-sm border border-slate-100 flex flex-col md:flex-row gap-6 items-center">
        <div className="flex-1 relative w-full">
            <i className="ti ti-search absolute left-6 top-1/2 -translate-y-1/2 text-slate-400"></i>
            <input 
                type="text" 
                placeholder={`Search ${activeTab}...`} 
                className="w-full pl-14 pr-8 py-5 bg-slate-50 border-none rounded-[1.75rem] outline-none font-bold" 
                value={search}
                onChange={e => setSearch(e.target.value)}
            />
        </div>
        <button 
            onClick={() => setModal({ type: 'add', item: { is_active: 1 }, mode: activeTab === 'categories' ? 'category' : 'brand' })}
            className="w-full md:w-auto bg-blue-600 text-white px-10 py-5 rounded-[2rem] font-black shadow-2xl shadow-blue-200 hover:bg-blue-700 transition-all flex items-center justify-center gap-3 active:scale-95"
        >
            <i className="ti ti-plus text-xl"></i> Add {activeTab === 'categories' ? 'Category' : 'Brand'}
        </button>
      </div>

      <div className="bg-white rounded-[4rem] shadow-sm border border-slate-100 overflow-hidden">
          <table className="w-full text-left">
              <thead className="bg-slate-50/80 border-b border-slate-100">
                  <tr className="text-[10px] font-black text-slate-400 uppercase tracking-[2px]">
                      <th className="px-10 py-6">Identity</th>
                      <th className="px-10 py-6">Unique Slug</th>
                      <th className="px-10 py-6">Global Visibility</th>
                      <th className="px-10 py-6 text-right">Registry Actions</th>
                  </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                  {loading ? (
                    <tr><td colSpan={4} className="py-20 text-center"><div className="animate-spin h-10 w-10 border-t-2 border-blue-600 rounded-full mx-auto"></div></td></tr>
                  ) : filteredData.map((item: any) => (
                      <tr key={item.id} className="hover:bg-slate-50/50 transition-all group">
                          <td className="px-10 py-6">
                              <div className="flex items-center gap-4">
                                  <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center text-xl font-black shadow-inner">
                                      {item.name.charAt(0).toUpperCase()}
                                  </div>
                                  <div>
                                      <p className="font-black text-slate-800 text-lg tracking-tight leading-none mb-1">{item.name}</p>
                                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{activeTab.slice(0,-1)} registry entry</p>
                                  </div>
                              </div>
                          </td>
                          <td className="px-10 py-6 font-mono text-xs font-bold text-slate-400 uppercase tracking-wider">{item.slug}</td>
                          <td className="px-10 py-6">
                              <span className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest ${item.is_active ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
                                  {item.is_active ? 'System Active' : 'System Hidden'}
                              </span>
                          </td>
                          <td className="px-10 py-6 text-right">
                              <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-all">
                                  <button 
                                    onClick={() => setModal({ type: 'edit', item, mode: activeTab === 'categories' ? 'category' : 'brand' })}
                                    className="p-3 text-blue-600 bg-blue-50 rounded-xl hover:bg-blue-600 hover:text-white transition-all shadow-sm"
                                  >
                                      <i className="ti ti-edit text-xl"></i>
                                  </button>
                                  <button 
                                    onClick={() => setModal({ type: 'delete', item, mode: activeTab === 'categories' ? 'category' : 'brand' })}
                                    className="p-3 text-red-600 bg-red-50 rounded-xl hover:bg-red-600 hover:text-white transition-all shadow-sm"
                                  >
                                      <i className="ti ti-trash text-xl"></i>
                                  </button>
                              </div>
                          </td>
                      </tr>
                  ))}
                  {filteredData.length === 0 && !loading && (
                      <tr><td colSpan={4} className="py-20 text-center text-slate-300 font-black uppercase tracking-[4px] italic opacity-40">No entries found in registry</td></tr>
                  )}
              </tbody>
          </table>
      </div>

      {modal.type && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[150] flex items-center justify-center p-4">
              <div className="bg-white w-full max-w-xl rounded-[4rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 border-4 border-white">
                  <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                      <div>
                        <h2 className="text-2xl font-black text-slate-800 tracking-tighter uppercase text-[10px] tracking-[4px]">{modal.type} {modal.mode} Record</h2>
                        <p className="text-slate-400 font-bold uppercase text-[8px] tracking-[2px] mt-1">Registry Synchronization Node</p>
                      </div>
                      <button onClick={() => setModal({ type: null, item: null, mode: 'category' })} className="w-12 h-12 flex items-center justify-center bg-white rounded-full text-slate-400 hover:text-red-500 shadow-md transition-all text-2xl font-light">×</button>
                  </div>
                  <div className="p-10">
                      {modal.type === 'delete' ? (
                          <div className="text-center space-y-6">
                              <div className="w-24 h-24 bg-rose-50 text-rose-500 rounded-[3rem] flex items-center justify-center mx-auto text-4xl shadow-inner animate-bounce"><i className="ti ti-trash"></i></div>
                              <h3 className="text-2xl font-black text-slate-800 tracking-tight">Purge <span className="text-blue-600 underline">{modal.item.name}</span>?</h3>
                              <p className="text-slate-500 font-medium text-sm px-10">This action will permanently detach this label from the clinical database.</p>
                              <div className="flex gap-4 pt-4">
                                  <button onClick={() => setModal({ type: null, item: null, mode: 'category' })} className="flex-1 py-5 bg-slate-100 rounded-[2rem] font-black text-xs uppercase tracking-widest">Abandon</button>
                                  <button onClick={handleDelete} className="flex-1 py-5 bg-rose-600 text-white rounded-[2rem] font-black text-xs uppercase tracking-widest shadow-2xl active:scale-95 transition-all">Confirm Purge</button>
                              </div>
                          </div>
                      ) : (
                          <form onSubmit={handleSave} className="space-y-6">
                              <div className="space-y-1">
                                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Display Designation</label>
                                  <input 
                                    name="name" 
                                    defaultValue={modal.item.name} 
                                    className="w-full px-8 py-5 bg-slate-50 border-none rounded-[1.75rem] outline-none font-black text-lg shadow-inner" 
                                    required 
                                    placeholder={`e.g. Clinical ${modal.mode}...`}
                                  />
                              </div>
                              <div className="grid grid-cols-2 gap-6">
                                  <div className="space-y-1">
                                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Unique Slug (URL)</label>
                                      <input 
                                        name="slug" 
                                        defaultValue={modal.item.slug} 
                                        className="w-full px-8 py-4 bg-slate-50 border-none rounded-[1.5rem] outline-none font-mono text-xs font-bold shadow-inner" 
                                        required 
                                        placeholder="lowercase-no-spaces"
                                      />
                                  </div>
                                  <div className="space-y-1">
                                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Registry Status</label>
                                      <select 
                                        name="is_active" 
                                        defaultValue={modal.item.is_active ? 1 : 0} 
                                        className="w-full px-8 py-4 bg-slate-50 border-none rounded-[1.5rem] outline-none font-black text-xs uppercase tracking-widest"
                                      >
                                          <option value={1}>Public / Active</option>
                                          <option value={0}>Hidden / Draft</option>
                                      </select>
                                  </div>
                              </div>
                              <div className="space-y-1">
                                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Meta Description (Internal)</label>
                                  <textarea 
                                    name="description" 
                                    defaultValue={modal.item.description} 
                                    className="w-full px-8 py-5 bg-slate-50 border-none rounded-[1.75rem] outline-none font-medium h-32 italic shadow-inner" 
                                    placeholder="Internal classification notes..." 
                                  />
                              </div>
                              <button 
                                type="submit" 
                                disabled={isSubmitting} 
                                className="w-full py-6 bg-slate-900 text-white rounded-[2.5rem] font-black uppercase text-xs tracking-[5px] shadow-2xl active:scale-95 transition-all mt-4"
                              >
                                  {isSubmitting ? 'Syndicating Database...' : 'Commit to Registry'}
                              </button>
                          </form>
                      )}
                  </div>
              </div>
          </div>
      )}
    </div>
  );
}

function RegistryKPI({ label, value, icon, color }: any) {
    return (
        <div className="bg-white p-8 rounded-[3.5rem] border border-slate-100 shadow-sm flex items-center gap-6 group hover:shadow-2xl transition-all relative overflow-hidden">
            <div className={`w-16 h-16 rounded-[1.75rem] ${color} flex items-center justify-center text-white text-3xl shadow-xl transition-transform group-hover:rotate-12`}>
                <i className={`ti ${icon}`}></i>
            </div>
            <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-[3px] mb-1.5">{label}</p>
                <p className="text-3xl font-black text-slate-800 tracking-tighter leading-none">{value}</p>
            </div>
            <div className={`absolute -right-6 -bottom-6 w-24 h-24 ${color} opacity-5 rounded-full`}></div>
        </div>
    );
}
