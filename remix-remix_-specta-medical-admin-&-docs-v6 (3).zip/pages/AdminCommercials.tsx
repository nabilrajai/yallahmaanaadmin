import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api';
import { useApp } from '../App';

export default function AdminCommercials() {
  const { user } = useApp();
  const [registryList, setRegistryList] = useState<any[]>([]); 
  const [selectedCommData, setSelectedCommData] = useState<any>(null); 
  const [selectedCommId, setSelectedCommId] = useState<string>('');
  const [loading, setLoading] = useState(true);
  
  // Advanced Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  // Secondary Data
  const [quotes, setQuotes] = useState<any[]>([]);
  const [reviews, setReviews] = useState<any[]>([]);
  const [statusBreakdown, setStatusBreakdown] = useState<any[]>([]);

  const [activeTab, setActiveTab] = useState<'clients' | 'quotes' | 'reviews'>('clients');

  const isManagement = user?.role_id === 1;
  const isCommercial = user?.role_id === 3;

  // 1. Initialize Registry
  useEffect(() => {
    const init = async () => {
        try {
            const res = await api.payments.getCommercialStats();
            setRegistryList(res.commercials || []);
            
            if (isCommercial && user?.id) {
                setSelectedCommId(user.id.toString());
            } else if (isManagement && res.commercials?.length > 0) {
                const firstId = res.commercials[0]?.id;
                if (firstId) setSelectedCommId(firstId.toString());
            }
        } catch (e) {
            console.error("Commercial Registry Sync Failed", e);
        }
    };
    init();
  }, [user, isManagement, isCommercial]);

  // 2. Fetch Performance Node
  const fetchCommData = async () => {
    if (!selectedCommId) return;
    setLoading(true);
    try {
        const queryParams = `commercial_id=${selectedCommId}&start_date=${startDate}&end_date=${endDate}`;
        
        const [fullRes, qRes, rRes, sRes] = await Promise.all([
            api.payments.getCommercialFullStats(queryParams),
            api.devis.list(`${queryParams}&per_page=100`),
            api.reviews.list(queryParams),
            api.payments.getAdvancedStats(queryParams)
        ]);

        const fullDataArray = fullRes?.data || [];
        setSelectedCommData(fullDataArray.length > 0 ? fullDataArray[0] : null);
        setQuotes(Array.isArray(qRes.data) ? qRes.data : (Array.isArray(qRes) ? qRes : []));
        setReviews(Array.isArray(rRes.data?.data) ? rRes.data.data : (Array.isArray(rRes) ? rRes : []));
        setStatusBreakdown(sRes.status_breakdown || []);
    } catch (e) {
        console.error("Commercial Deep Dive Failed", e);
    } finally {
        setLoading(false);
    }
  };

  useEffect(() => {
    fetchCommData();
  }, [selectedCommId, startDate, endDate]);

  // Enhanced Analytics Extraction
  const metrics = useMemo(() => {
    if (!selectedCommData) return { ca: 0, enc: 0, balance: 0, clients: 0, name: '...', email: '...', orders: 0, devisCount: 0, devisTotal: 0, conv: 0, avgTicket: 0 };
    const s = selectedCommData.stats;
    const c = selectedCommData.commercial;
    
    const ca = parseFloat(s?.orders?.total_ttc || 0);
    const orders = s?.orders?.count || 0;
    const devis = s?.devis?.count || 0;

    return {
        ca,
        enc: parseFloat(s?.payments?.total_paid || 0),
        balance: parseFloat(s?.balance || 0),
        clients: s?.clients_count || 0,
        orders,
        devisCount: devis,
        devisTotal: parseFloat(s?.devis?.total_ttc || 0),
        // @ts-ignore
        conv: devis > 0 ? parseFloat(((orders / devis) * 100).toFixed(1)) : 0,
        avgTicket: orders > 0 ? Math.round(ca / orders) : 0,
        name: c?.name || '...',
        email: c?.email || '...'
    };
  }, [selectedCommData]);

  // Tab Filtering logic
  const filteredClients = useMemo(() => {
    if (!selectedCommData?.clients) return [];
    return selectedCommData.clients.filter((c: any) => 
        c.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.city?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.code?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [selectedCommData, searchTerm]);

  const filteredQuotes = useMemo(() => {
    return quotes.filter((q: any) => 
        q.quote_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        q.client?.name?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [quotes, searchTerm]);

  return (
    <div className="space-y-8 pb-20 animate-in fade-in duration-700">
      {/* COMMAND BAR & FILTERS */}
      <div className="bg-white p-8 lg:p-10 rounded-[4rem] shadow-sm border border-slate-100 space-y-8">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-8">
            <div className="flex items-center gap-6">
                <div className="relative">
                    <img src={`https://ui-avatars.com/api/?name=${metrics.name}&background=5D87FF&color=fff&bold=true`} className="w-20 h-20 rounded-[2rem] shadow-2xl border-4 border-white object-cover" alt="" />
                    <span className="absolute -bottom-1 -right-1 w-6 h-6 bg-emerald-500 border-4 border-white rounded-full"></span>
                </div>
                <div>
                    <h1 className="text-3xl font-black text-slate-800 tracking-tighter leading-none mb-1 uppercase">{metrics.name}</h1>
                    <p className="text-slate-400 font-black uppercase text-[10px] tracking-[4px]">{metrics.email} • ID: {selectedCommId || 'N/A'}</p>
                </div>
            </div>

            <div className="flex flex-wrap items-center gap-4">
                {isManagement && (
                    <div className="relative">
                        <i className="ti ti-users-group absolute left-5 top-1/2 -translate-y-1/2 text-blue-600"></i>
                        <select 
                            value={selectedCommId}
                            onChange={e => setSelectedCommId(e.target.value)}
                            className="pl-14 pr-8 py-4 bg-slate-50 border-none rounded-[1.5rem] outline-none font-black text-[10px] uppercase tracking-widest shadow-inner appearance-none min-w-[260px] focus:ring-2 focus:ring-blue-500/20"
                        >
                            {registryList.map((c: any) => (
                                <option key={c.id} value={c.id}>{c.name}</option>
                            ))}
                        </select>
                    </div>
                )}
                <Link 
                    to="/admin/commercial-team" 
                    className="px-6 py-4 bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white rounded-[1.5rem] font-black text-[10px] uppercase tracking-widest transition-all flex items-center gap-2 shadow-sm"
                >
                    <i className="ti ti-users"></i> Annuaire & Leads
                </Link>
                <button onClick={fetchCommData} className="w-14 h-14 bg-slate-900 text-white rounded-full flex items-center justify-center shadow-xl active:scale-90 transition-all hover:bg-blue-600">
                    <i className="ti ti-refresh text-xl"></i>
                </button>
            </div>
        </div>

        {/* ADVANCED FILTER TOOLBAR */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 pt-8 border-t border-slate-50">
            <div className="md:col-span-5 relative group">
                <i className="ti ti-search absolute left-6 top-1/2 -translate-y-1/2 text-blue-600 text-lg group-focus-within:scale-110 transition-transform"></i>
                <input 
                    type="text" 
                    placeholder="Chercher un client, une ville ou un n° de devis..." 
                    className="w-full pl-14 pr-8 py-5 bg-slate-50 border-none rounded-[2rem] outline-none font-bold text-sm shadow-inner focus:ring-4 focus:ring-blue-500/5 transition-all"
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                />
            </div>
            <div className="md:col-span-7 flex flex-wrap lg:flex-nowrap gap-4">
                <div className="flex-1 flex items-center bg-slate-50 rounded-[2rem] px-6 shadow-inner">
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest mr-4">DE</span>
                    <input 
                        type="date" 
                        value={startDate} 
                        onChange={e => setStartDate(e.target.value)}
                        className="bg-transparent border-none outline-none font-black text-[10px] uppercase text-slate-700 py-5 w-full cursor-pointer"
                    />
                </div>
                <div className="flex-1 flex items-center bg-slate-50 rounded-[2rem] px-6 shadow-inner">
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest mr-4">À</span>
                    <input 
                        type="date" 
                        value={endDate} 
                        onChange={e => setEndDate(e.target.value)}
                        className="bg-transparent border-none outline-none font-black text-[10px] uppercase text-slate-700 py-5 w-full cursor-pointer"
                    />
                </div>
                {(startDate || endDate || searchTerm) && (
                    <button 
                        onClick={() => { setStartDate(''); setEndDate(''); setSearchTerm(''); }}
                        className="px-6 bg-rose-50 text-rose-500 rounded-[2rem] font-black text-[10px] uppercase tracking-widest hover:bg-rose-500 hover:text-white transition-all"
                    >
                        Reset
                    </button>
                )}
            </div>
        </div>
      </div>

      {/* DETAILED KPI DASHBOARD */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <KPICard label="Volume de Ventes" value={`${metrics.ca.toLocaleString()} MAD`} icon="DH" color="bg-blue-600" subValue={`${metrics.orders} Commandes validées`} />
          <KPICard label="Conversion Devis" value={`${metrics.conv}%`} icon="ti-chart-pie" color="bg-indigo-600" subValue={`${metrics.devisCount} Devis émis`} />
          <KPICard label="Panier Moyen" value={`${Number(metrics.avgTicket).toLocaleString()} MAD`} icon="ti-shopping-cart" color="bg-emerald-600" subValue="Valeur moyenne / commande" />
          <KPICard label="Encaissements" value={`${metrics.enc.toLocaleString()} MAD`} icon="ti-wallet" color="bg-amber-500" subValue={`${metrics.balance.toLocaleString()} MAD en attente`} />
      </div>

      {/* CORE PERFORMANCE VIEW */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-8 flex flex-col gap-8">
                <div className="flex gap-4 p-2 bg-slate-100 rounded-[2.5rem] w-fit shadow-inner border border-slate-200">
                    <TabBtn active={activeTab === 'clients'} onClick={() => setActiveTab('clients')} icon="ti-users" label="Clinical Portfolio" />
                    <TabBtn active={activeTab === 'quotes'} onClick={() => setActiveTab('quotes')} icon="ti-file-invoice" label="Pipeline Devis" />
                    <TabBtn active={activeTab === 'reviews'} onClick={() => setActiveTab('reviews')} icon="ti-message-star" label="Feedback Clients" />
                </div>

                <div className="bg-white rounded-[4rem] border border-slate-100 shadow-sm overflow-hidden flex-1 min-h-[650px] flex flex-col">
                    {loading ? (
                        <div className="flex-1 flex flex-col items-center justify-center p-20 opacity-20">
                            <i className="ti ti-refresh text-8xl mb-6 animate-spin"></i>
                            <p className="font-black uppercase tracking-[8px] text-xs">Syncing Performance Node...</p>
                        </div>
                    ) : (
                        <div className="animate-in fade-in duration-500">
                            {activeTab === 'clients' && (
                                <table className="w-full text-left">
                                    <thead className="bg-slate-50/80 sticky top-0 border-b">
                                        <tr className="text-[10px] font-black uppercase text-slate-400 tracking-widest">
                                            <th className="px-10 py-8">Établissement</th>
                                            <th className="px-10 py-8">Ville & Contact</th>
                                            <th className="px-10 py-8 text-right">Statut</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-slate-50">
                                        {filteredClients.map((c: any) => (
                                            <tr key={c.id} className="hover:bg-slate-50/50 transition-all group">
                                                <td className="px-10 py-8">
                                                    <p className="font-black text-slate-800 text-base leading-none mb-1 uppercase">{c.name}</p>
                                                    <p className="text-[9px] font-black text-blue-600 uppercase tracking-widest">#{c.code}</p>
                                                </td>
                                                <td className="px-10 py-8">
                                                    <p className="font-bold text-slate-500 text-sm mb-1">{c.city}</p>
                                                    <p className="text-[10px] font-bold text-slate-300 flex items-center gap-2"><i className="ti ti-phone"></i> {c.mobile || c.phone || 'N/A'}</p>
                                                </td>
                                                <td className="px-10 py-8 text-right">
                                                    <span className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest ${c.status === 'active' ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}>
                                                        {typeof c.status === 'object' ? (c.status?.name || c.status?.slug) : c.status}
                                                    </span>
                                                </td>
                                            </tr>
                                        ))}
                                        {filteredClients.length === 0 && (
                                            <tr><td colSpan={3} className="py-20 text-center text-slate-300 font-black uppercase text-xs italic tracking-widest opacity-40">Aucun client ne correspond aux filtres</td></tr>
                                        )}
                                    </tbody>
                                </table>
                            )}

                            {activeTab === 'quotes' && (
                                <table className="w-full text-left">
                                    <thead className="bg-slate-50/80 sticky top-0 border-b">
                                        <tr className="text-[10px] font-black uppercase text-slate-400 tracking-widest">
                                            <th className="px-10 py-8">Référence</th>
                                            <th className="px-10 py-8">Client</th>
                                            <th className="px-10 py-8">Statut Workflow</th>
                                            <th className="px-10 py-8 text-right">Valeur TTC</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-slate-50">
                                        {filteredQuotes.map((q: any) => (
                                            <tr key={q.id} className="hover:bg-slate-50/50 transition-all group">
                                                <td className="px-10 py-8">
                                                    <p className="font-black text-blue-600 text-lg">#{q.quote_number}</p>
                                                    <p className="text-[8px] font-black text-slate-300 uppercase tracking-widest">{new Date(q.created_at).toLocaleDateString()}</p>
                                                </td>
                                                <td className="px-10 py-8 font-bold text-slate-800 text-sm uppercase">{q.client?.name}</td>
                                                <td className="px-10 py-8">
                                                    <span className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest ${q.status === 'accepted' || q.status === 'validated' ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-50 text-slate-400'}`}>
                                                        {typeof q.status === 'object' ? (q.status?.name || q.status?.slug) : q.status}
                                                    </span>
                                                </td>
                                                <td className="px-10 py-8 text-right font-black text-slate-700">{parseFloat(q.total_ttc || 0).toLocaleString()} MAD</td>
                                            </tr>
                                        ))}
                                        {filteredQuotes.length === 0 && (
                                            <tr><td colSpan={4} className="py-20 text-center text-slate-300 font-black uppercase text-xs italic tracking-widest opacity-40">Aucun devis trouvé</td></tr>
                                        )}
                                    </tbody>
                                </table>
                            )}

                            {activeTab === 'reviews' && (
                                <div className="p-10 space-y-6">
                                    {reviews.map((r: any) => (
                                        <div key={r.id} className="p-8 bg-slate-50/50 rounded-[3rem] border border-slate-100 flex gap-8 items-start hover:bg-white transition-all shadow-sm group">
                                            <div className="w-16 h-16 rounded-[1.5rem] bg-white shadow-inner flex flex-col items-center justify-center text-amber-500 font-black shrink-0 group-hover:rotate-12 transition-transform">
                                                <span className="text-2xl leading-none">{r.rating}</span>
                                                <span className="text-[8px] opacity-50 uppercase">/5</span>
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <h5 className="font-black text-slate-800 text-lg uppercase leading-none mb-4">{r.client?.name}</h5>
                                                <p className="text-slate-600 italic leading-relaxed text-sm bg-white/40 p-4 rounded-2xl">"{r.comment || 'Sans commentaire.'}"</p>
                                            </div>
                                        </div>
                                    ))}
                                    {reviews.length === 0 && (
                                        <div className="py-24 text-center opacity-20"><i className="ti ti-mood-empty text-8xl mb-4"></i><p className="font-black uppercase text-xs">Aucun retour enregistré</p></div>
                                    )}
                                </div>
                            )}
                        </div>
                    )}
                </div>
          </div>

          <div className="lg:col-span-4 space-y-8">
                {/* PERFORMANCE DNA SIDEBAR */}
                <section className="bg-slate-900 p-10 rounded-[4rem] text-white shadow-2xl relative overflow-hidden group">
                    <div className="absolute -right-10 -top-10 w-40 h-40 bg-blue-500 opacity-20 rounded-full blur-[80px]"></div>
                    <h4 className="text-[11px] font-black text-blue-400 uppercase tracking-[6px] border-b border-white/10 pb-6 mb-8 flex items-center gap-3 relative z-10"><i className="ti ti-dna text-2xl"></i> Performance DNA</h4>
                    
                    <div className="space-y-10 relative z-10">
                        <div className="space-y-3">
                            <p className="text-[9px] font-black text-slate-500 uppercase tracking-[4px]">Efficacité Commerciale</p>
                            <ScoreBar label="Taux de Closing" value={metrics.conv} color="bg-blue-500" />
                            <ScoreBar label="Ratio Liquidité" value={metrics.ca > 0 ? Math.round((metrics.enc / metrics.ca) * 100) : 0} color="bg-emerald-500" />
                        </div>

                        <div className="pt-8 border-t border-white/10 space-y-4">
                            <p className="text-[9px] font-black text-slate-500 uppercase tracking-[4px]">Résumé d'Activité</p>
                            <div className="grid grid-cols-2 gap-4">
                                <ActivityMetric label="Clients" value={metrics.clients} />
                                <ActivityMetric label="Commandes" value={metrics.orders} />
                                <ActivityMetric label="Devis" value={metrics.devisCount} />
                                <ActivityMetric label="Avg ticket" value={`${(metrics.avgTicket / 1000).toFixed(1)}k`} />
                            </div>
                        </div>
                    </div>
                </section>

                <section className="bg-white p-10 rounded-[4rem] border border-slate-100 shadow-sm space-y-10">
                    <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-[6px] border-b pb-6 mb-8 flex items-center gap-3"><i className="ti ti-wallet text-blue-600 text-xl"></i> Santé Financière</h4>
                    <div className="space-y-6">
                        {statusBreakdown.map((s: any, idx: number) => (
                            <div key={idx} className="space-y-2">
                                <div className="flex justify-between items-center text-[9px] font-black uppercase tracking-[2px]">
                                    <span className="text-slate-500">{s.status === 'paid' ? 'Collecté' : 'Impayé / Partiel'}</span>
                                    <span className="text-slate-800">{parseFloat(s.total || 0).toLocaleString()} MAD</span>
                                </div>
                                <div className="h-1.5 bg-slate-50 rounded-full overflow-hidden">
                                    <div className={`h-full ${s.status === 'paid' ? 'bg-emerald-500' : 'bg-rose-400'} transition-all duration-1000`} style={{ width: `${metrics.ca > 0 ? (parseFloat(s.total || 0) / metrics.ca) * 100 : 0}%` }}></div>
                                </div>
                            </div>
                        ))}
                    </div>
                    
                    <div className="pt-6 border-t">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-6">Priority Recouvrement</p>
                        <div className="space-y-4">
                            {/* Showing debtors from the clients list who have a balance */}
                            {filteredClients
                                .filter((c: any) => parseFloat(c.orders_sum_total_ttc || 0) > 0)
                                .slice(0, 5)
                                .map((c: any) => (
                                <div key={c.id} className="flex justify-between items-center bg-slate-50 p-4 rounded-2xl border border-slate-100 group hover:bg-white hover:shadow-lg transition-all">
                                    <div className="min-w-0 flex-1 mr-4">
                                        <p className="text-[10px] font-black text-slate-700 truncate uppercase">{c.name}</p>
                                        <p className="text-[8px] font-bold text-slate-400 uppercase">{c.city}</p>
                                    </div>
                                    <span className="text-[11px] font-black text-rose-500 whitespace-nowrap">{(parseFloat(c.orders_sum_total_ttc || 0) - parseFloat(c.payments_sum_amount || 0)).toLocaleString()} <span className="text-[7px]">MAD</span></span>
                                </div>
                            ))}
                            {filteredClients.filter((c: any) => parseFloat(c.orders_sum_total_ttc || 0) > 0).length === 0 && (
                                <p className="text-[9px] text-slate-300 font-bold uppercase text-center py-4 italic">Aucun retard détecté</p>
                            )}
                        </div>
                    </div>
                </section>
          </div>
      </div>
    </div>
  );
}

function KPICard({ label, value, icon, color, subValue }: any) {
    const isCurrency = icon === 'DH' || icon === 'MAD' || icon === 'ti-currency-dirham';
    return (
        <div className="bg-white p-8 rounded-[3.5rem] border border-slate-100 shadow-sm flex items-center gap-6 group hover:shadow-2xl transition-all relative overflow-hidden border-b-4 border-b-slate-50">
            <div className={`w-16 h-16 rounded-[1.75rem] ${color} flex items-center justify-center text-white shadow-xl transition-transform group-hover:rotate-12 select-none`}>
                {isCurrency ? (
                    <span className="font-black text-2xl tracking-tight text-white leading-none">DH</span>
                ) : (
                    <i className={`ti ${icon} text-3xl`}></i>
                )}
            </div>
            <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-[3px] mb-1.5">{label}</p>
                <p className="text-2xl font-black text-slate-800 tracking-tighter leading-none mb-1.5">{value}</p>
                {subValue && <p className="text-[9px] font-bold text-slate-300 uppercase tracking-widest">{subValue}</p>}
            </div>
        </div>
    );
}

function ActivityMetric({ label, value }: any) {
    return (
        <div className="bg-white/5 p-4 rounded-2xl border border-white/5 shadow-inner">
            <p className="text-[7px] font-black text-slate-500 uppercase tracking-widest mb-1">{label}</p>
            <p className="text-base font-black text-white leading-none">{value}</p>
        </div>
    )
}

function TabBtn({ active, onClick, icon, label }: any) {
    return (
        <button onClick={onClick} className={`flex items-center gap-3 px-8 py-3.5 rounded-[2rem] text-[10px] font-black uppercase tracking-widest transition-all duration-300 ${active ? 'bg-white text-blue-600 shadow-xl translate-y-[-2px]' : 'text-slate-400 hover:text-slate-600 hover:bg-white/50'}`}><i className={`ti ${icon} text-lg`}></i>{label}</button>
    )
}

function ScoreBar({ label, value, color }: any) {
    return (
        <div className="space-y-2">
            <div className="flex justify-between items-center text-[9px] font-black uppercase tracking-[2px]">
                <span className="text-slate-400">{label}</span>
                <span className="text-white">{value}%</span>
            </div>
            <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                <div className={`h-full ${color} transition-all duration-1000`} style={{ width: `${value}%` }}></div>
            </div>
        </div>
    )
}