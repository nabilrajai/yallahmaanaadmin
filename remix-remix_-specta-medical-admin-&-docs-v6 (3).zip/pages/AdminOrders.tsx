import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { api } from '../api';
import { useApp } from '../App';
import { Order, Status } from '../types';

const ORDER_STATUS_FLOW: { id: Status; label: string; color: string; bg: string; text: string; icon: string; tooltip: string }[] = [
  { id: 'pending', label: 'En Attente', color: 'bg-slate-400', bg: 'bg-slate-50', text: 'text-slate-600', icon: 'ti-clock-pause', tooltip: 'Commande en attente de validation' },
  { id: 'validated', label: 'Validée', color: 'bg-blue-500', bg: 'bg-blue-50', text: 'text-blue-600', icon: 'ti-checkbox', tooltip: 'Paiement ou commande validée' },
  { id: 'preparing', label: 'Préparation', color: 'bg-indigo-500', bg: 'bg-indigo-50', text: 'text-indigo-600', icon: 'ti-package', tooltip: 'En cours de préparation au dépôt' },
  { id: 'shipped', label: 'Expédiée', color: 'bg-amber-500', bg: 'bg-amber-50', text: 'text-amber-600', icon: 'ti-truck-delivery', tooltip: 'En transit vers le client' },
  { id: 'completed', label: 'Livrée', color: 'bg-emerald-500', bg: 'bg-emerald-50', text: 'text-emerald-600', icon: 'ti-circle-check', tooltip: 'Livraison effectuée avec succès' },
  { id: 'cancelled', label: 'Annulée', color: 'bg-rose-600', bg: 'bg-rose-50', text: 'text-rose-600', icon: 'ti-circle-x', tooltip: 'Commande annulée' }
];

const CARRIERS = ["Specta Internal Fleet", "DHL Medical Express", "FedEx HealthCare", "Aramex", "Amana", "UPS Morocco"];

export const isMachineOrder = (order: any): boolean => {
  if (!order) return false;

  // 1. Explicit order type or type field
  const orderType = String(order.order_type || order.type || '').toLowerCase();
  if (orderType === 'machine' || orderType === 'devis' || orderType === 'quote') {
    return true;
  }

  // 2. Order number prefix (e.g. DEV-..., QUO-..., MAC-...)
  const orderNumber = String(order.order_number || '').toUpperCase();
  if (orderNumber.startsWith('DEV') || orderNumber.startsWith('QUO') || orderNumber.startsWith('MAC')) {
    return true;
  }

  // 3. Inspection of order items
  if (Array.isArray(order.items) && order.items.length > 0) {
    const hasMachineItem = order.items.some((item: any) => {
      if (item?.machine || item?.machine_id) return true;
      if (item?.type === 'machine') return true;
      if (item?.product?.type === 'machine' || item?.product?.category?.slug?.includes('machine')) return true;
      const itemName = String(item?.machine?.name || item?.product?.name || item?.name || '').toLowerCase();
      if (
        itemName.includes('machine') || 
        itemName.includes('scanner') || 
        itemName.includes('laser') || 
        itemName.includes('échographe') || 
        itemName.includes('echographe') ||
        itemName.includes('fauteuil') || 
        itemName.includes('autoclave') || 
        itemName.includes('analyseur') ||
        itemName.includes('panoramique') ||
        itemName.includes('capteur')
      ) {
        return true;
      }
      return false;
    });
    if (hasMachineItem) return true;
  }

  // 4. Notes inspection
  if (typeof order.notes === 'string') {
    const n = order.notes.toLowerCase();
    if (n.includes('devis') || n.includes('machine') || n.includes('equipement') || n.includes('équipement')) {
      return true;
    }
  }

  return false;
};

export const getOrderTypeInfo = (order: any) => {
  const isMachine = isMachineOrder(order);
  if (isMachine) {
    return {
      type: 'machine' as const,
      label: 'Demande Devis',
      badgeText: 'Demande Devis',
      fullTitle: 'Demande de Devis (Machine)',
      category: 'Machine / Équipement',
      badgeBg: 'bg-amber-50',
      badgeTextCol: 'text-amber-800',
      badgeBorder: 'border-amber-200',
      icon: 'ti-file-invoice',
      cardBorder: 'border-l-4 border-l-amber-500',
      chipBg: 'bg-amber-100 text-amber-900 border border-amber-300'
    };
  }
  return {
    type: 'consumable' as const,
    label: 'Commande Normale',
    badgeText: 'Commande Normale',
    fullTitle: 'Commande Normale (Consommables)',
    category: 'Consommable / Produit',
    badgeBg: 'bg-blue-50',
    badgeTextCol: 'text-blue-800',
    badgeBorder: 'border-blue-200',
    icon: 'ti-package',
    cardBorder: 'border-l-4 border-l-blue-600',
    chipBg: 'bg-blue-100 text-blue-900 border border-blue-300'
  };
};

interface AdminOrdersProps {
  forcedType?: 'consumable' | 'machine';
}

export default function AdminOrders({ forcedType }: AdminOrdersProps = {}) {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { t, checkPermission, showDenied } = useApp();

  const queryType = searchParams.get('type') as 'consumable' | 'machine' | null;
  const activeForced = forcedType || queryType;

  const [orders, setOrders] = useState<Order[]>([]);
  const [drivers, setDrivers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'kanban' | 'list'>('kanban');
  const [typeFilter, setTypeFilter] = useState<'all' | 'machine' | 'consumable'>(activeForced || 'all');
  const [modal, setModal] = useState<{ type: 'view' | 'delete' | null, item: any }>({ type: null, item: null });
  const [isUpdating, setIsUpdating] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [dragOverColumn, setDragOverColumn] = useState<string | null>(null);

  useEffect(() => {
    if (activeForced) {
      setTypeFilter(activeForced);
    }
  }, [activeForced]);

  const handleCreateDevisFromOrder = (order: any, e?: React.MouseEvent) => {
    if (e) {
      e.stopPropagation();
    }
    if (!order) return;

    const clientId = String(order.client?.id || order.client_id || '');
    
    // Extract items
    const rawItems = Array.isArray(order.items) ? order.items : [];
    const items = rawItems.map((itm: any) => {
      const asset = itm.machine || itm.product;
      const isMach = Boolean(itm.machine || itm.machine_id || itm.type === 'machine' || isMachineOrder(order));
      const itemId = itm.machine?.id || itm.machine_id || itm.product?.id || itm.product_id || itm.id || 1;
      const name = asset?.name || itm.name || (isMach ? 'Équipement Médical' : 'Article Consommable');
      const imageUrl = asset?.image_url || itm.image_url || '';
      const unitPrice = parseFloat(asset?.price_ht || itm.unit_price || itm.price || 0);
      const minPrice = parseFloat(asset?.min_price_ht || 0);
      const quantity = parseInt(itm.quantity) || 1;

      return {
        id: itemId,
        type: isMach ? 'machine' : 'product',
        name,
        image_url: imageUrl,
        unit_price: unitPrice,
        min_price_ht: minPrice,
        quantity,
        tax_rate: 20,
        discount_type: 'percent',
        discount_value: 0
      };
    });

    const prefillData = {
      client_id: clientId,
      client: order.client ? {
        id: order.client.id,
        name: order.client.name,
        city: order.client.city || '',
        code: order.client.code || '',
        address: order.client.address || ''
      } : null,
      items: items.length > 0 ? items : [],
      notes: `Devis établi suite à la demande de devis #${order.order_number}${order.notes ? ` - ${order.notes}` : ''}`,
      sourceOrderNumber: order.order_number,
      sourceOrderId: order.id
    };

    try {
      sessionStorage.setItem('specta_prefill_devis', JSON.stringify(prefillData));
    } catch (err) {
      console.warn('Session storage error:', err);
    }

    navigate('/admin/devis', { state: { prefillDevis: prefillData } });
  };
  
  const [logistics, setLogistics] = useState({
      assigned_driver_id: '',
      shipping_company: 'Specta Internal Fleet',
      tracking_url: '',
      delivery_date: ''
  });

  const fetchData = async () => {
    setLoading(true);
    try {
      const [oRes, uRes] = await Promise.all([
        api.orders.list('per_page=500'),
        api.users.list('role_id=5') 
      ]);
      setOrders(Array.isArray(oRes.data) ? oRes.data : (Array.isArray(oRes) ? oRes : []));
      setDrivers(Array.isArray(uRes.data) ? uRes.data : (Array.isArray(uRes) ? uRes : []));
    } catch (e) { 
        console.error(e); 
        setOrders([]);
    } finally { setLoading(false); }
  };

  useEffect(() => { fetchData(); }, []);

  const filteredOrders = useMemo(() => {
    return orders.filter(o => {
      const matchesSearch = 
        o.order_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        o.client?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        o.items?.some((i: any) => (i?.machine?.name || i?.product?.name || i?.name)?.toLowerCase().includes(searchTerm.toLowerCase()));

      if (!matchesSearch) return false;

      if (typeFilter === 'machine') return isMachineOrder(o);
      if (typeFilter === 'consumable') return !isMachineOrder(o);
      return true;
    });
  }, [orders, searchTerm, typeFilter]);

  const stats = useMemo(() => {
    const machineOrders = orders.filter(o => isMachineOrder(o));
    const consumableOrders = orders.filter(o => !isMachineOrder(o));
    return {
      total: orders.length,
      machineCount: machineOrders.length,
      consumableCount: consumableOrders.length,
      pending: orders.filter(o => o.status === 'pending' || o.status === 'validated').length,
      shipped: orders.filter(o => o.status === 'shipped').length,
      completed: orders.filter(o => o.status === 'completed').length
    };
  }, [orders]);

  const handleOpenOrder = (order: any) => {
      setModal({ type: 'view', item: order });
      setLogistics({
          assigned_driver_id: order.assigned_driver_id?.toString() || '',
          shipping_company: order.shipping_company || 'Specta Internal Fleet',
          tracking_url: order.tracking_url || '',
          delivery_date: order.delivery_date ? new Date(order.delivery_date).toISOString().split('T')[0] : ''
      });
  };

  const handleUpdateStatus = async (id: string, status: string) => {
    if (!checkPermission('orders', 'edit')) return showDenied("Modifier Statut");
    setIsUpdating(true);
    try {
      await api.orders.updateStatus(parseInt(id), status);
      fetchData();
      if (modal.item?.id.toString() === id) setModal(prev => ({ ...prev, item: { ...prev.item, status } }));
    } catch (e) { alert("Sync Error"); } finally { setIsUpdating(false); }
  };

  const handleSaveLogistics = async () => {
    if (!checkPermission('orders', 'edit')) return showDenied("Expédition");
    setIsUpdating(true);
    try {
        await api.orders.updateLogistics(modal.item.id, {
            ...logistics,
            status: 'shipped'
        });
        setModal({ type: null, item: null });
        fetchData();
    } catch (e) { alert("Check API route"); } finally { setIsUpdating(false); }
  };

  // Drag and Drop Logic
  const onDragStart = (e: React.DragEvent, orderId: number) => {
    e.dataTransfer.setData('orderId', orderId.toString());
    e.dataTransfer.effectAllowed = 'move';
  };

  const onDragOver = (e: React.DragEvent, statusId: string) => {
    e.preventDefault();
    if (dragOverColumn !== statusId) setDragOverColumn(statusId);
  };

  const onDrop = async (e: React.DragEvent, targetStatus: string) => {
    e.preventDefault();
    setDragOverColumn(null);
    const orderId = e.dataTransfer.getData('orderId');
    if (!orderId) return;

    const order = orders.find(o => o.id === parseInt(orderId));
    if (order && order.status !== targetStatus) {
      // FIX: Pass string id to handleUpdateStatus
      handleUpdateStatus(orderId, targetStatus);
    }
  };

  const getFullImageUrl = (path: string) => {
    if (!path) return 'https://placehold.co/100x100?text=BIO';
    if (path.startsWith('http')) return path;
    return `https://birdeye-intelligence.ma/Spetcapp/Backend/storage/app/public/${path}`;
  };

  return (
    <div className="space-y-10 pb-20 animate-in fade-in duration-700">
      {/* GLOBAL HUD */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {activeForced === 'consumable' ? (
          <>
            <LogKPI 
              label="Total Consommables" 
              subtitle="Commandes produits enregistrées"
              value={stats.consumableCount} 
              icon="ti-package" 
              color="bg-blue-600" 
              badge="Consommable"
            />
            <LogKPI 
              label="En Attente" 
              subtitle="À valider ou préparer"
              value={orders.filter(o => !isMachineOrder(o) && (o.status === 'pending' || o.status === 'validated')).length} 
              icon="ti-clock-pause" 
              color="bg-amber-500" 
            />
            <LogKPI 
              label="Transit Actif" 
              subtitle="En cours de livraison"
              value={orders.filter(o => !isMachineOrder(o) && o.status === 'shipped').length} 
              icon="ti-truck-delivery" 
              color="bg-indigo-500" 
            />
            <LogKPI 
              label="Livrées avec Succès" 
              subtitle="Commandes finalisées"
              value={orders.filter(o => !isMachineOrder(o) && o.status === 'completed').length} 
              icon="ti-circle-check" 
              color="bg-emerald-500" 
            />
          </>
        ) : activeForced === 'machine' ? (
          <>
            <LogKPI 
              label="Demandes Devis Machines" 
              subtitle="Équipements demandés"
              value={stats.machineCount} 
              icon="ti-file-invoice" 
              color="bg-amber-500" 
              badge="Demande Devis"
            />
            <LogKPI 
              label="En Attente" 
              subtitle="Nécessite chiffrage & devis"
              value={orders.filter(o => isMachineOrder(o) && (o.status === 'pending' || o.status === 'validated')).length} 
              icon="ti-clock-pause" 
              color="bg-rose-500" 
            />
            <LogKPI 
              label="En Négociation" 
              subtitle="Devis en cours d'élaboration"
              value={orders.filter(o => isMachineOrder(o) && o.status === 'preparing').length} 
              icon="ti-file-pencil" 
              color="bg-indigo-500" 
            />
            <LogKPI 
              label="Traitées / Conclues" 
              subtitle="Devis envoyés ou finalisés"
              value={orders.filter(o => isMachineOrder(o) && (o.status === 'completed' || o.status === 'shipped')).length} 
              icon="ti-circle-check" 
              color="bg-emerald-500" 
            />
          </>
        ) : (
          <>
            <LogKPI 
              label="Demande Devis (Machines)" 
              subtitle="Équipements & Devis"
              value={stats.machineCount} 
              icon="ti-file-invoice" 
              color="bg-amber-500" 
              active={typeFilter === 'machine'}
              onClick={() => setTypeFilter(prev => prev === 'machine' ? 'all' : 'machine')}
              badge="Machine"
            />
            <LogKPI 
              label="Commande Normale" 
              subtitle="Consommables & Produits"
              value={stats.consumableCount} 
              icon="ti-package" 
              color="bg-blue-600" 
              active={typeFilter === 'consumable'}
              onClick={() => setTypeFilter(prev => prev === 'consumable' ? 'all' : 'consumable')}
              badge="Consommable"
            />
            <LogKPI 
              label="Transit Actif" 
              subtitle="En cours d'acheminement"
              value={stats.shipped} 
              icon="ti-truck-delivery" 
              color="bg-indigo-500" 
            />
            <LogKPI 
              label="Flux Global Total" 
              subtitle="Toutes commandes & devis"
              value={stats.total} 
              icon="ti-stack-2" 
              color="bg-slate-900" 
              active={typeFilter === 'all'}
              onClick={() => setTypeFilter('all')}
            />
          </>
        )}
      </div>

      {/* HEADER COMMAND SECTION */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-8 bg-white p-10 rounded-[4rem] shadow-sm border border-slate-100 relative overflow-hidden group">
        <div className="absolute right-0 top-0 w-80 h-80 bg-blue-50 rounded-full -translate-y-1/2 translate-x-1/2 opacity-10 group-hover:scale-110 transition-transform duration-1000"></div>
        <div className="relative z-10">
          <h1 className="text-4xl lg:text-5xl font-black text-slate-800 tracking-tighter mb-2">
            {activeForced === 'consumable' ? 'Commandes Consommables' : (activeForced === 'machine' ? 'Commandes Machines' : 'Logistics Control')}
          </h1>
          <p className="text-slate-400 font-black uppercase text-[10px] tracking-[3px] opacity-70">
            {activeForced === 'consumable' 
              ? 'Suivi logistique et expédition des commandes de consommables' 
              : (activeForced === 'machine' 
                ? 'Demandes de devis pour équipements médicaux — Génération de devis directs' 
                : 'Synchronisation des Flux Hospitaliers & Livraison')}
          </p>
        </div>
        
        <div className="flex flex-wrap items-center gap-4 relative z-10">
            {/* TYPE FILTER SWITCHER (only when not forced) */}
            {!activeForced && (
              <div className="flex bg-slate-100 p-1.5 rounded-[2.25rem] border border-slate-200/60 shadow-inner">
                  <button 
                    onClick={() => setTypeFilter('all')} 
                    className={`px-4 py-2 rounded-[1.75rem] text-[10px] font-black uppercase tracking-wider transition-all flex items-center gap-1.5 ${typeFilter === 'all' ? 'bg-white text-slate-900 shadow-md' : 'text-slate-500 hover:text-slate-800'}`}
                  >
                    Tous <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-slate-200/80 font-bold">{stats.total}</span>
                  </button>
                  <button 
                    onClick={() => setTypeFilter('machine')} 
                    className={`px-4 py-2 rounded-[1.75rem] text-[10px] font-black uppercase tracking-wider transition-all flex items-center gap-1.5 ${typeFilter === 'machine' ? 'bg-amber-500 text-white shadow-md' : 'text-amber-800 hover:bg-amber-100/60'}`}
                  >
                    <i className="ti ti-file-invoice text-xs"></i> Demande Devis <span className={`text-[9px] px-1.5 py-0.2 rounded-full font-bold ${typeFilter === 'machine' ? 'bg-white/20 text-white' : 'bg-amber-100 text-amber-900'}`}>{stats.machineCount}</span>
                  </button>
                  <button 
                    onClick={() => setTypeFilter('consumable')} 
                    className={`px-4 py-2 rounded-[1.75rem] text-[10px] font-black uppercase tracking-wider transition-all flex items-center gap-1.5 ${typeFilter === 'consumable' ? 'bg-blue-600 text-white shadow-md' : 'text-blue-800 hover:bg-blue-100/60'}`}
                  >
                    <i className="ti ti-package text-xs"></i> Commande Normale <span className={`text-[9px] px-1.5 py-0.2 rounded-full font-bold ${typeFilter === 'consumable' ? 'bg-white/20 text-white' : 'bg-blue-100 text-blue-900'}`}>{stats.consumableCount}</span>
                  </button>
              </div>
            )}

            <div className="flex bg-slate-100 p-1.5 rounded-[2.25rem] border border-slate-100 shadow-inner">
                <button onClick={() => setViewMode('kanban')} className={`px-5 py-2 rounded-[1.75rem] text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'kanban' ? 'bg-white text-blue-600 shadow-lg' : 'text-slate-400 hover:text-slate-600'}`}>
                  <i className="ti ti-layout-kanban text-sm mr-1.5"></i> Kanban
                </button>
                <button onClick={() => setViewMode('list')} className={`px-5 py-2 rounded-[1.75rem] text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'list' ? 'bg-white text-blue-600 shadow-lg' : 'text-slate-400 hover:text-slate-600'}`}>
                  <i className="ti ti-list text-sm mr-1.5"></i> Liste
                </button>
            </div>
            
            <div className="flex items-center gap-3 bg-white p-2 rounded-[2.25rem] border border-slate-100 shadow-sm">
                <i className="ti ti-search text-blue-600 ml-3"></i>
                <input 
                  type="text" 
                  placeholder="Rechercher CMD ou article..." 
                  className="bg-transparent border-none outline-none font-bold text-xs py-1.5 w-44 xl:w-56" 
                  value={searchTerm} 
                  onChange={e => setSearchTerm(e.target.value)} 
                />
                {searchTerm && (
                  <button onClick={() => setSearchTerm('')} className="text-slate-300 hover:text-slate-500 mr-2 text-xs font-bold">×</button>
                )}
            </div>
            <button onClick={fetchData} title="Rafraîchir" className="w-12 h-12 bg-slate-900 text-white rounded-full flex items-center justify-center shadow-xl active:scale-95 hover:bg-blue-600 transition-all cursor-pointer">
              <i className="ti ti-refresh text-xl"></i>
            </button>
        </div>
      </div>

      {/* SPECIAL MACHINE CALLOUT BANNER FOR MACHINE ORDERS */}
      {activeForced === 'machine' && (
        <div className="bg-amber-50 border border-amber-200/80 p-5 rounded-[2.5rem] flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xs animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-amber-500 text-white flex items-center justify-center text-xl shadow-md shrink-0">
              <i className="ti ti-file-invoice"></i>
            </div>
            <div>
              <h4 className="text-sm font-black text-amber-950">Module Demandes de Devis pour Machines & Équipements</h4>
              <p className="text-xs font-medium text-amber-800/80 mt-0.5">
                Cliquez sur le bouton <strong>« Créer Devis »</strong> sur n'importe quelle commande pour basculer vers le formulaire de devis pré-rempli avec le client, l'équipement et les prix modifiables.
              </p>
            </div>
          </div>
          <button
            onClick={() => navigate('/admin/devis')}
            className="px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-2xl text-[10px] font-black uppercase tracking-wider shadow-sm flex items-center gap-2 shrink-0 cursor-pointer transition-all"
          >
            <i className="ti ti-arrow-right text-xs"></i>
            <span>Aller à Devis & Offres</span>
          </button>
        </div>
      )}

      {/* ACTIVE TYPE FILTER BANNER (when in general view) */}
      {!activeForced && typeFilter !== 'all' && (
        <div className="flex items-center justify-between bg-slate-50 border border-slate-200/80 px-6 py-3.5 rounded-[2rem] shadow-xs animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center gap-3">
            <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">Filtrage typologique actif :</span>
            {typeFilter === 'machine' ? (
              <span className="px-3.5 py-1.5 rounded-full text-xs font-black bg-amber-100 text-amber-800 border border-amber-300 flex items-center gap-2 shadow-xs">
                <i className="ti ti-file-invoice"></i> Affichage exclusif : Demande Devis (Machines & Équipements)
                <button onClick={() => setTypeFilter('all')} className="hover:text-black ml-1 text-sm font-bold leading-none">×</button>
              </span>
            ) : (
              <span className="px-3.5 py-1.5 rounded-full text-xs font-black bg-blue-100 text-blue-800 border border-blue-300 flex items-center gap-2 shadow-xs">
                <i className="ti ti-package"></i> Affichage exclusif : Commande Normale (Consommables & Produits)
                <button onClick={() => setTypeFilter('all')} className="hover:text-black ml-1 text-sm font-bold leading-none">×</button>
              </span>
            )}
          </div>
          <button onClick={() => setTypeFilter('all')} className="text-slate-400 hover:text-rose-600 text-[10px] font-black uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-1">
            <i className="ti ti-x text-xs"></i> Tout réinitialiser
          </button>
        </div>
      )}

      {/* VIEWPORT AREA */}
      {loading ? (
        <div className="py-40 text-center space-y-4">
            <div className="animate-spin h-16 w-16 border-t-4 border-blue-600 rounded-full mx-auto"></div>
            <p className="text-[10px] font-black uppercase tracking-[5px] text-slate-400">Scanning Supply Chain...</p>
        </div>
      ) : viewMode === 'kanban' ? (
        <div className="flex gap-6 overflow-x-auto pb-8 custom-scrollbar min-h-[700px]">
          {ORDER_STATUS_FLOW.map(col => {
            const colOrders = filteredOrders.filter(o => o.status === col.id);
            const isOver = dragOverColumn === col.id;
            return (
              <div 
                key={col.id} 
                onDragOver={(e) => onDragOver(e, col.id)}
                onDragLeave={() => setDragOverColumn(null)}
                onDrop={(e) => onDrop(e, col.id)}
                className={`w-85 min-w-[340px] rounded-[3.5rem] p-6 flex flex-col gap-6 border transition-all duration-300 shrink-0 ${isOver ? 'bg-blue-50 border-blue-300 shadow-inner scale-[1.01]' : 'bg-slate-100/40 border-slate-200/50'}`}
              >
                <div className="flex items-center justify-between px-4">
                    <div className="flex items-center gap-3">
                        <div className={`w-3 h-3 rounded-full ${col.color}`}></div>
                        <h3 className="text-[11px] font-black uppercase tracking-[3px] text-slate-500">{col.label}</h3>
                    </div>
                    <span className="bg-white px-3 py-1 rounded-full text-[10px] font-black shadow-sm text-slate-400">
                      {colOrders.length}
                    </span>
                </div>

                <div className="flex-1 space-y-5 overflow-y-auto pr-1 custom-scrollbar">
                    {colOrders.map(order => {
                        const isMachine = isMachineOrder(order);
                        const typeInfo = getOrderTypeInfo(order);
                        return (
                          <div 
                              key={order.id} 
                              draggable="true"
                              onDragStart={(e) => onDragStart(e, order.id)}
                              onClick={() => handleOpenOrder(order)}
                              className={`bg-white p-6 rounded-[2.5rem] shadow-sm border border-slate-200 hover:border-blue-400 hover:shadow-xl hover:-translate-y-1 transition-all cursor-grab active:cursor-grabbing group relative overflow-hidden ${typeInfo.cardBorder}`}
                          >
                              <div className="flex justify-between items-start mb-3 relative z-10 gap-2">
                                  <div className="flex flex-wrap items-center gap-1.5">
                                      <span className="text-[10px] font-black text-blue-600 bg-blue-50 px-3 py-1 rounded-full border border-blue-100">#{order.order_number}</span>
                                      <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider ${typeInfo.badgeBg} ${typeInfo.badgeTextCol} border ${typeInfo.badgeBorder} flex items-center gap-1 shadow-xs`}>
                                          <i className={`ti ${typeInfo.icon} text-xs`}></i> {typeInfo.badgeText}
                                      </span>
                                  </div>
                                  <div className="text-right shrink-0">
                                      <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest">{new Date(order.ordered_at).toLocaleDateString()}</p>
                                  </div>
                              </div>

                              <div className="space-y-3 relative z-10">
                                  <div>
                                      <h4 className="font-black text-slate-800 text-base leading-tight group-hover:text-blue-600 transition-colors line-clamp-1">{order.client?.name}</h4>
                                      <div className="flex items-center justify-between mt-1">
                                          <p className="text-[10px] font-bold text-slate-400 italic uppercase flex items-center gap-1">
                                              <i className="ti ti-map-pin"></i> {order.client?.city || 'Maroc'}
                                          </p>
                                          <span className={`text-[9px] font-bold ${isMachine ? 'text-amber-700' : 'text-blue-700'}`}>
                                              {isMachine ? 'Équipement Machine' : 'Consommables'}
                                          </span>
                                      </div>
                                  </div>

                                  <div className="pt-3 border-t border-slate-50 flex justify-between items-end">
                                      <div>
                                          <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">
                                            {isMachine ? 'Valeur Estimée' : 'Montant TTC'}
                                          </p>
                                          <p className="text-lg font-black text-slate-700 tracking-tighter">
                                              {parseFloat(order.total_ttc || 0).toLocaleString()} <span className="text-[10px] opacity-40">MAD</span>
                                          </p>
                                      </div>
                                      <div className="flex -space-x-2">
                                          {order.items?.slice(0, 3).map((itm: any, i: number) => {
                                              const asset = itm.machine || itm.product;
                                              const itmIsMachine = Boolean(itm.machine || itm.machine_id || itm.type === 'machine');
                                              return (
                                                  <div key={i} className="relative group/thumb" title={`${asset?.name || 'Article'} (${itmIsMachine ? 'Machine' : 'Consommable'})`}>
                                                      <img 
                                                        src={getFullImageUrl(asset?.image_url)} 
                                                        className={`w-8 h-8 rounded-lg bg-slate-50 border-2 shadow-sm object-contain p-1 ${itmIsMachine ? 'border-amber-300' : 'border-blue-200'}`} 
                                                      />
                                                      <span className={`absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full ${itmIsMachine ? 'bg-amber-500' : 'bg-blue-500'} border border-white`}></span>
                                                  </div>
                                              );
                                          })}
                                          {(order.items?.length || 0) > 3 && (
                                              <div className="w-8 h-8 rounded-lg bg-slate-100 border-2 border-white flex items-center justify-center text-[10px] font-black text-slate-400 shadow-sm">
                                                  +{order.items!.length - 3}
                                              </div>
                                          )}
                                      </div>
                                  </div>

                                  {isMachine && (
                                      <div className="pt-3 border-t border-amber-100/80">
                                          <button
                                              type="button"
                                              onClick={(e) => handleCreateDevisFromOrder(order, e)}
                                              className="w-full py-2.5 px-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white rounded-2xl font-black text-[10px] uppercase tracking-wider flex items-center justify-center gap-2 shadow-sm hover:shadow-md transition-all active:scale-95 cursor-pointer z-20"
                                              title="Ouvrir le devis directement pour ce client et cette machine"
                                          >
                                              <i className="ti ti-file-invoice text-sm"></i>
                                              Créer Devis Machine
                                              <i className="ti ti-arrow-right text-xs ml-auto"></i>
                                          </button>
                                      </div>
                                  )}
                              </div>
                              
                              {/* DRAG INDICATOR */}
                              <div className="absolute top-2 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-20 transition-opacity">
                                  <i className="ti ti-grip-horizontal text-lg"></i>
                              </div>

                              {/* HOVER ACTION OVERLAY */}
                              <div className="absolute top-4 right-4 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-all translate-x-4 group-hover:translate-x-0 z-30">
                                  {isMachine && (
                                      <button 
                                          type="button"
                                          onClick={(e) => handleCreateDevisFromOrder(order, e)}
                                          title="Créer Devis Direct"
                                          className="w-10 h-10 rounded-xl bg-amber-500 hover:bg-amber-600 text-white flex items-center justify-center shadow-xl transition-all"
                                      >
                                          <i className="ti ti-file-invoice text-lg"></i>
                                      </button>
                                  )}
                                  <button className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xl"><i className="ti ti-chart-arrows text-lg"></i></button>
                              </div>
                          </div>
                        );
                    })}
                    {colOrders.length === 0 && (
                        <div className="py-20 text-center opacity-20 flex flex-col items-center">
                            <i className={`${col.icon} text-5xl mb-4`}></i>
                            <p className="text-[10px] font-black uppercase tracking-[4px]">Vide</p>
                        </div>
                    )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-white rounded-[4rem] border border-slate-100 shadow-sm overflow-hidden animate-in slide-in-from-bottom-8 duration-700">
            <table className="w-full text-left">
                <thead className="bg-slate-50/50 border-b">
                    <tr className="text-[10px] font-black uppercase text-slate-400 tracking-widest">
                        <th className="px-8 py-8">CMD Identity</th>
                        <th className="px-8 py-8">Typologie / Nature</th>
                        <th className="px-8 py-8">Medical Entity</th>
                        <th className="px-8 py-8">Articles & Matériel</th>
                        <th className="px-8 py-8">Dispatch Logic</th>
                        <th className="px-8 py-8">Commercial Value</th>
                        <th className="px-8 py-8 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-slate-50 font-sans">
                    {filteredOrders.map(o => {
                        const isMachine = isMachineOrder(o);
                        const typeInfo = getOrderTypeInfo(o);
                        return (
                          <tr key={o.id} className="hover:bg-slate-50/50 transition-colors group">
                              <td className="px-8 py-8">
                                  <p className="text-blue-600 font-black text-sm mb-1">#{o.order_number}</p>
                                  <p className="text-[9px] font-bold text-slate-300 uppercase">{new Date(o.ordered_at).toLocaleDateString()}</p>
                              </td>
                              <td className="px-8 py-8">
                                  <div className="flex flex-col gap-1">
                                      <span className={`px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-wider ${typeInfo.badgeBg} ${typeInfo.badgeTextCol} border ${typeInfo.badgeBorder} flex items-center gap-1.5 w-fit shadow-xs`}>
                                          <i className={`ti ${typeInfo.icon} text-sm`}></i> {typeInfo.badgeText}
                                      </span>
                                      <span className="text-[10px] font-bold text-slate-400 italic">
                                          {isMachine ? 'Équipement Machine' : 'Consommable / Produit'}
                                      </span>
                                  </div>
                              </td>
                              <td className="px-8 py-8">
                                  <p className="font-black text-slate-800 text-lg leading-none mb-2">{o.client?.name}</p>
                                  <p className="text-[10px] font-bold text-slate-400 truncate max-w-[240px] italic">{o.client?.city || 'Maroc'}</p>
                              </td>
                              <td className="px-8 py-8">
                                  <div className="flex items-center gap-2">
                                      <div className="flex -space-x-2">
                                          {o.items?.slice(0, 3).map((itm: any, idx: number) => {
                                              const asset = itm.machine || itm.product;
                                              const itmIsMachine = Boolean(itm.machine || itm.machine_id || itm.type === 'machine');
                                              return (
                                                  <img 
                                                    key={idx} 
                                                    src={getFullImageUrl(asset?.image_url)} 
                                                    className={`w-8 h-8 rounded-lg bg-slate-50 border-2 shadow-sm object-contain p-1 ${itmIsMachine ? 'border-amber-300' : 'border-blue-200'}`} 
                                                    title={asset?.name} 
                                                  />
                                              );
                                          })}
                                      </div>
                                      <div className="text-[11px] font-bold text-slate-600 truncate max-w-[180px]">
                                          {o.items?.[0] ? (o.items[0].machine?.name || o.items[0].product?.name || `${o.items.length} article(s)`) : '---'}
                                          {(o.items?.length || 0) > 1 && <span className="text-slate-400 ml-1 font-normal">(+{o.items!.length - 1})</span>}
                                      </div>
                                  </div>
                              </td>
                              <td className="px-8 py-8">
                                  <div className="flex flex-col gap-2">
                                      <span className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest w-fit flex items-center gap-2 ${ORDER_STATUS_FLOW.find(s => s.id === o.status)?.color || 'bg-slate-400'} text-white shadow-lg`}>
                                          <i className={`ti ${ORDER_STATUS_FLOW.find(s => s.id === o.status)?.icon || 'ti-package'}`}></i>
                                          {ORDER_STATUS_FLOW.find(s => s.id === o.status)?.label || o.status}
                                      </span>
                                      {o.shipping_company && <p className="text-[10px] font-black text-blue-600 uppercase flex items-center gap-1"><i className="ti ti-truck-delivery"></i> {o.shipping_company}</p>}
                                  </div>
                              </td>
                              <td className="px-8 py-8">
                                  <p className="font-black text-slate-700 text-xl tracking-tighter">{parseFloat(o.total_ttc || 0).toLocaleString()} <span className="text-[10px] opacity-40 uppercase">MAD</span></p>
                              </td>
                              <td className="px-8 py-8 text-right">
                                  <div className="flex justify-end gap-3 opacity-0 group-hover:opacity-100 transition-all translate-x-4 group-hover:translate-x-0">
                                      {isMachine && (
                                          <button 
                                              onClick={(e) => handleCreateDevisFromOrder(o, e)} 
                                              className="px-5 py-3 bg-amber-500 hover:bg-amber-600 text-white rounded-2xl shadow-xl transition-all font-black text-[10px] uppercase tracking-widest flex items-center gap-2 cursor-pointer"
                                              title="Créer un devis directement pour ce client avec cette machine"
                                          >
                                              <i className="ti ti-file-invoice text-base"></i> Créer Devis
                                          </button>
                                      )}
                                      <button onClick={() => handleOpenOrder(o)} className="px-6 py-3 bg-slate-900 text-white rounded-2xl shadow-xl hover:bg-blue-600 transition-all font-black text-[10px] uppercase tracking-widest flex items-center gap-2">
                                          <i className="ti ti-chart-arrows text-lg"></i> Dispatch
                                      </button>
                                      <button onClick={() => setModal({ type: 'delete', item: o })} className="w-12 h-12 bg-rose-50 text-rose-500 rounded-2xl shadow-sm hover:bg-rose-600 hover:text-white transition-all flex items-center justify-center"><i className="ti ti-trash text-xl"></i></button>
                                  </div>
                              </td>
                          </tr>
                        );
                    })}
                    {filteredOrders.length === 0 && (
                        <tr>
                            <td colSpan={7} className="py-40 text-center">
                                <div className="opacity-20 flex flex-col items-center">
                                    <i className="ti ti-shopping-cart-off text-8xl mb-4"></i>
                                    <p className="text-xs font-black uppercase tracking-[8px]">Aucune commande trouvée</p>
                                </div>
                            </td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
      )}

      {/* DISPATCH PROTOCOL MODAL */}
      {modal.type === 'view' && modal.item && (
          <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-md z-[150] flex items-center justify-center p-4">
              <div className="bg-white w-full max-w-7xl rounded-[4rem] shadow-2xl overflow-hidden border-4 border-white flex flex-col max-h-[95vh] animate-in zoom-in-95">
                  <div className="p-10 border-b flex justify-between items-center bg-slate-50/50 shrink-0">
                      <div className="flex items-center gap-8">
                          <div className={`w-20 h-20 rounded-[2.5rem] flex items-center justify-center text-4xl shadow-2xl text-white ${ORDER_STATUS_FLOW.find(s => s.id === modal.item.status)?.color || 'bg-slate-400'}`}>
                              <i className={`ti ${ORDER_STATUS_FLOW.find(s => s.id === modal.item.status)?.icon || 'ti-package'}`}></i>
                          </div>
                          <div>
                              <div className="flex flex-wrap items-center gap-3 mb-1">
                                  <h2 className="text-4xl font-black text-slate-800 tracking-tighter leading-none">Dispatch Protocol #{modal.item.order_number}</h2>
                                  {isMachineOrder(modal.item) ? (
                                      <span className="px-3.5 py-1 rounded-full text-[11px] font-black uppercase tracking-wider bg-amber-100 text-amber-900 border border-amber-300 flex items-center gap-1.5 shadow-xs">
                                          <i className="ti ti-file-invoice"></i> Demande Devis (Machine)
                                      </span>
                                  ) : (
                                      <span className="px-3.5 py-1 rounded-full text-[11px] font-black uppercase tracking-wider bg-blue-100 text-blue-900 border border-blue-300 flex items-center gap-1.5 shadow-xs">
                                          <i className="ti ti-package"></i> Commande Normale (Consommable)
                                      </span>
                                  )}
                              </div>
                              <p className="text-slate-400 font-black uppercase text-[10px] tracking-[4px]">
                                  Typologie: <span className="font-bold text-slate-700">{isMachineOrder(modal.item) ? 'Demande de Devis Machine' : 'Commande Normale Consommables'}</span> • Paiement: <span className="text-blue-600">{modal.item.payment_status?.toUpperCase() || 'STANDARD'}</span>
                              </p>
                          </div>
                      </div>
                      <div className="flex items-center gap-4">
                          {isMachineOrder(modal.item) && (
                              <button 
                                  onClick={() => handleCreateDevisFromOrder(modal.item)}
                                  className="px-6 py-4 bg-amber-500 hover:bg-amber-600 text-white rounded-2xl font-black text-xs uppercase tracking-wider shadow-lg flex items-center gap-2 transition-all active:scale-95 cursor-pointer"
                              >
                                  <i className="ti ti-file-invoice text-base"></i> Créer Devis
                              </button>
                          )}
                          <button onClick={() => setModal({ type: null, item: null })} className="w-16 h-16 flex items-center justify-center bg-white rounded-full text-slate-300 hover:text-red-500 shadow-xl text-3xl font-light hover:rotate-90 transition-all">×</button>
                      </div>
                  </div>

                  <div className="flex-1 overflow-y-auto p-12 bg-slate-50/20 custom-scrollbar">
                      {isMachineOrder(modal.item) && (
                          <div className="mb-10 bg-gradient-to-r from-amber-500 via-amber-600 to-amber-700 text-white rounded-[3rem] p-8 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl shadow-amber-200/50">
                              <div className="flex items-center gap-6">
                                  <div className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-[2rem] flex items-center justify-center text-3xl shrink-0 p-4 border border-white/20">
                                      <i className="ti ti-file-certificate"></i>
                                  </div>
                                  <div>
                                      <div className="flex items-center gap-2 mb-1.5">
                                          <span className="px-3 py-0.5 rounded-full bg-white/20 text-white text-[9px] font-black uppercase tracking-wider">
                                              Demande de Devis Machine
                                          </span>
                                          <span className="text-amber-100 text-xs font-semibold">
                                              Passerelle Devis Directe
                                          </span>
                                      </div>
                                      <h3 className="text-2xl font-black tracking-tight leading-snug text-white">
                                          Créer le Devis pour {modal.item.client?.name || 'ce client'}
                                      </h3>
                                      <p className="text-amber-100 text-xs mt-1 max-w-xl leading-relaxed">
                                          Redirige vers la page Devis avec ce client et la machine pré-remplis. Vous pourrez ajuster le prix unitaire, modifier la quantité et ajouter l'offre en un clic.
                                      </p>
                                  </div>
                              </div>
                              <button
                                  onClick={() => handleCreateDevisFromOrder(modal.item)}
                                  className="px-8 py-5 bg-white text-amber-900 hover:bg-amber-50 rounded-[2rem] font-black text-xs uppercase tracking-[2px] shadow-2xl transition-all active:scale-95 flex items-center gap-3 shrink-0 cursor-pointer"
                              >
                                  <i className="ti ti-file-plus text-xl text-amber-600"></i>
                                  Créer Devis & Ajuster Prix
                                  <i className="ti ti-arrow-right text-base"></i>
                              </button>
                          </div>
                      )}

                      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
                          {/* LOGISTICS PANEL */}
                          <div className="lg:col-span-4 space-y-8">
                              <section className="bg-slate-900 p-10 rounded-[3.5rem] text-white shadow-2xl space-y-8 relative overflow-hidden">
                                  <div className="absolute -right-10 -top-10 w-40 h-40 bg-blue-500 opacity-20 rounded-full blur-3xl"></div>
                                  <h4 className="text-[11px] font-black text-blue-400 uppercase tracking-[5px] border-b border-white/10 pb-4 flex items-center gap-3 relative z-10"><i className="ti ti-truck-delivery"></i> Dispatch Authority</h4>
                                  <div className="space-y-6 relative z-10">
                                      <div className="space-y-2">
                                          <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest ml-4">Classification Transport</label>
                                          <select value={logistics.shipping_company} onChange={e => setLogistics({...logistics, shipping_company: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 outline-none font-bold text-sm text-white appearance-none focus:border-blue-500 transition-all">
                                              {CARRIERS.map(c => <option key={c} value={c} className="text-slate-900">{c}</option>)}
                                          </select>
                                      </div>
                                      {logistics.shipping_company === 'Specta Internal Fleet' ? (
                                          <div className="space-y-2">
                                              <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest ml-4">Staff Livreur Assigné</label>
                                              <select value={logistics.assigned_driver_id} onChange={e => setLogistics({...logistics, assigned_driver_id: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 outline-none font-bold text-sm text-white appearance-none focus:border-blue-500 transition-all">
                                                  <option value="" className="text-slate-900">-- Choisir un livreur --</option>
                                                  {drivers.map(d => <option key={d.id} value={d.id} className="text-slate-900">{d.name}</option>)}
                                              </select>
                                          </div>
                                      ) : (
                                          <div className="space-y-2">
                                              <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest ml-4">Tracking URL / ID</label>
                                              <input type="url" value={logistics.tracking_url} onChange={e => setLogistics({...logistics, tracking_url: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 outline-none font-bold text-xs text-blue-400 placeholder-slate-600" placeholder="https://tracking-system.com/..." />
                                          </div>
                                      )}
                                      <div className="space-y-2">
                                          <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest ml-4">Date Estimée Livraison</label>
                                          <input type="date" value={logistics.delivery_date} onChange={e => setLogistics({...logistics, delivery_date: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 outline-none font-bold text-sm text-white" />
                                      </div>
                                      <button onClick={handleSaveLogistics} disabled={isUpdating} className="w-full py-5 bg-blue-600 text-white rounded-[2rem] font-black uppercase text-[10px] tracking-[4px] shadow-2xl active:scale-95 transition-all hover:bg-blue-700">Autoriser Expédition</button>
                                  </div>
                              </section>
                              
                              <section className="bg-white p-8 rounded-[3.5rem] border border-slate-100 shadow-sm relative group overflow-hidden">
                                  <div className="absolute -right-8 -top-8 w-24 h-24 bg-slate-50 rounded-full group-hover:scale-150 transition-transform duration-700"></div>
                                  <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4 border-b pb-2 relative z-10">Client Profile</h4>
                                  <div className="relative z-10">
                                      <p className="text-slate-800 font-black text-sm uppercase">{modal.item.client?.name}</p>
                                      <p className="text-slate-500 text-[10px] font-bold mt-2 italic leading-relaxed">"{modal.item.client?.address || 'Pas d\'adresse enregistrée'}"</p>
                                      <div className="mt-4 pt-4 border-t border-slate-50 flex items-center gap-3">
                                          <div className="w-8 h-8 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center"><i className="ti ti-phone"></i></div>
                                          <span className="text-[10px] font-black text-slate-400">{modal.item.client?.mobile || '---'}</span>
                                      </div>
                                  </div>
                              </section>
                          </div>

                          {/* MANIFEST & STATUS PANEL */}
                          <div className="lg:col-span-8 space-y-12">
                              <section>
                                  <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-[5px] flex items-center gap-3 mb-8"><i className="ti ti-list-details text-blue-600 text-xl"></i> Manifest Articles</h4>
                                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                      {modal.item.items?.map((itm: any, idx: number) => {
                                          const asset = itm.machine || itm.product;
                                          const itmIsMachine = Boolean(itm.machine || itm.machine_id || itm.type === 'machine');
                                          if (!asset) return null;
                                          return (
                                              <div key={idx} className={`bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm flex items-center gap-6 group hover:shadow-xl transition-all border-l-4 ${itmIsMachine ? 'border-l-amber-500' : 'border-l-blue-600'}`}>
                                                  <div className="w-20 h-20 bg-slate-50 rounded-[1.5rem] overflow-hidden shrink-0 p-2 flex items-center justify-center group-hover:scale-105 transition-transform">
                                                      <img src={getFullImageUrl(asset.image_url)} className="w-full h-full object-contain" alt="" />
                                                  </div>
                                                  <div className="min-w-0 flex-1">
                                                      <div className="flex items-center gap-2 mb-1">
                                                          <span className={`text-[8px] font-black uppercase px-2 py-0.5 rounded ${itmIsMachine ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'}`}>
                                                              {itmIsMachine ? 'Machine Médicale (Devis)' : 'Consommable'}
                                                          </span>
                                                      </div>
                                                      <h5 className="font-black text-slate-800 text-sm truncate uppercase tracking-tight">{asset.name}</h5>
                                                      <div className="flex justify-between items-center mt-3 pt-3 border-t border-slate-50">
                                                          <span className="text-[10px] font-black text-blue-600 bg-blue-50 px-2 py-0.5 rounded">UNIT: {itm.quantity}</span>
                                                          <span className="font-black text-slate-700 text-xs">{(parseFloat(itm.unit_price_ht || itm.unit_price || 0) * itm.quantity).toLocaleString()} MAD</span>
                                                      </div>
                                                  </div>
                                              </div>
                                          );
                                      })}
                                  </div>
                              </section>
                              
                              <section className="bg-white p-10 rounded-[4rem] border border-slate-100 shadow-sm">
                                  <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-[5px] border-b pb-6 mb-8 flex items-center gap-3"><i className="ti ti-stack-2 text-blue-600"></i> Transition du Flux Opérationnel</h4>
                                  <div className="flex flex-wrap gap-4 bg-slate-100 p-2 rounded-[3.5rem]">
                                      {ORDER_STATUS_FLOW.map(s => (
                                          <div key={s.id} className="group/btn relative flex-1">
                                              <button 
                                                // FIX: Pass string id to handleUpdateStatus
                                                onClick={() => handleUpdateStatus(modal.item.id.toString(), s.id)} 
                                                disabled={isUpdating} 
                                                className={`w-full py-5 rounded-[2.25rem] text-[10px] font-black uppercase tracking-widest transition-all ${modal.item.status === s.id ? 'bg-white text-blue-600 shadow-2xl scale-[1.05]' : 'text-slate-400 hover:text-slate-600 hover:bg-white/50'}`}
                                              >
                                                {s.label}
                                              </button>
                                              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 px-3 py-2 bg-slate-900 text-white text-[8px] font-black uppercase tracking-[2px] rounded-lg opacity-0 group-hover/btn:opacity-100 transition-all pointer-events-none whitespace-nowrap z-50">
                                                  {s.tooltip}
                                                  <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-slate-900"></div>
                                              </div>
                                          </div>
                                      ))}
                                  </div>
                              </section>
                          </div>
                      </div>
                  </div>
                  
                  {/* MODAL FOOTER */}
                  <div className="p-10 border-t bg-slate-50 flex flex-col sm:flex-row justify-between items-center gap-6 shrink-0">
                      <div className="flex items-center gap-6">
                          <div>
                              <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">Total à Recouvrer</p>
                              <p className="text-4xl font-black text-slate-800 tracking-tighter">{parseFloat(modal.item.total_ttc || 0).toLocaleString()} <span className="text-[11px] opacity-30 uppercase ml-1">MAD</span></p>
                          </div>
                          <div className="h-10 w-px bg-slate-200"></div>
                          <div className="flex items-center gap-2">
                              <span className={`w-3 h-3 rounded-full ${ORDER_STATUS_FLOW.find(s => s.id === modal.item.status)?.color}`}></span>
                              <span className="text-[10px] font-black uppercase text-slate-600">{modal.item.status?.toUpperCase()}</span>
                          </div>
                      </div>
                      <button onClick={() => setModal({ type: null, item: null })} className="px-16 py-6 bg-slate-900 text-white rounded-[2.25rem] font-black uppercase text-[11px] tracking-[5px] active:scale-95 shadow-2xl hover:bg-slate-800 transition-all">Quitter l'Axe Logistique</button>
                  </div>
              </div>
          </div>
      )}

      {/* DELETE CONFIRMATION */}
      {modal.type === 'delete' && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[200] flex items-center justify-center p-4">
             <div className="bg-white rounded-[4rem] shadow-2xl p-14 text-center max-w-sm w-full animate-in zoom-in-95 border-4 border-white">
                <div className="w-24 h-24 bg-rose-50 text-rose-500 rounded-[3rem] flex items-center justify-center mx-auto text-5xl mb-10 shadow-inner animate-bounce">
                    <i className="ti ti-trash"></i>
                </div>
                <h3 className="text-3xl font-black text-slate-800 tracking-tight mb-4">Annuler CMD ?</h3>
                <p className="text-slate-500 text-sm font-medium leading-relaxed mb-12 italic">Cette action est irréversible et retirera la commande du pipeline commercial.</p>
                <div className="flex gap-4">
                    <button onClick={() => setModal({ type: null, item: null })} className="flex-1 py-5 bg-slate-50 text-slate-400 rounded-2xl font-black text-[10px] uppercase tracking-widest active:scale-95">Garder</button>
                    <button onClick={async () => { try { setIsUpdating(true); await api.orders.delete(modal.item.id); setModal({ type: null, item: null }); fetchData(); } catch(e){alert("Error");} finally {setIsUpdating(false);}}} className="flex-1 py-5 bg-rose-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-rose-200 active:scale-95">Confirmer</button>
                </div>
             </div>
        </div>
      )}
    </div>
  );
}

function LogKPI({ label, value, icon, color }: any) {
    return (
        <div className="bg-white p-8 rounded-[3.5rem] border border-slate-100 shadow-sm flex items-center gap-6 group hover:shadow-2xl transition-all relative overflow-hidden border-b-4 border-b-slate-100/50">
            <div className={`w-16 h-16 rounded-[1.75rem] ${color} flex items-center justify-center text-white text-3xl shadow-xl transition-transform group-hover:rotate-12`}>
                <i className={`ti ${icon}`}></i>
            </div>
            <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-[3px] mb-1.5">{label}</p>
                <p className="text-3xl font-black text-slate-800 tracking-tighter leading-none">{value}</p>
            </div>
            <div className={`absolute -right-6 -bottom-6 w-24 h-24 ${color} opacity-5 rounded-full blur-2xl`}></div>
        </div>
    );
}