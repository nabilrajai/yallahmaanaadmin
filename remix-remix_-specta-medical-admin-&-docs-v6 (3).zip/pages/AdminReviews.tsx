
import React, { useState, useEffect, useMemo } from 'react';
import { api } from '../api';
import { useApp } from '../App';

export default function AdminReviews() {
  const { theme } = useApp();
  const [reviews, setReviews] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error404, setError404] = useState(false);
  const [ratingFilter, setRatingFilter] = useState('all');

  // Reclamation Detail Modal State
  const [viewRecId, setViewRecId] = useState<number | null>(null);
  const [recData, setRecData] = useState<any>(null);
  const [loadingRec, setLoadingRec] = useState(false);

  const fetchData = async () => {
    setLoading(true);
    setError404(false);
    try {
        let query = ratingFilter !== 'all' ? `rating=${ratingFilter}` : '';
        const res = await api.reviews.list(query);
        
        let reviewsArray: any[] = [];
        if (res) {
            if (Array.isArray(res)) {
                let flattened = [...res];
                while (flattened.length > 0 && Array.isArray(flattened[0])) {
                    flattened = flattened.flat();
                }
                reviewsArray = flattened;
            } else if (res.data) {
                if (Array.isArray(res.data)) {
                    reviewsArray = res.data;
                } else if (res.data.data && Array.isArray(res.data.data)) {
                    reviewsArray = res.data.data;
                }
            }
        }
        
        setReviews(reviewsArray);
    } catch (e: any) { 
        if (e.message === 'ROUTE_NOT_FOUND' || e.status === 404) {
            setError404(true);
        } else {
            console.error("Reviews fetch error:", e);
        }
    } finally {
        setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, [ratingFilter]);

  // Fetch Reclamation Detail when viewRecId is set
  useEffect(() => {
    if (viewRecId) {
        const fetchRec = async () => {
            setLoadingRec(true);
            try {
                const res = await api.reclamations.show(viewRecId);
                setRecData(res.data || res);
            } catch (e) {
                console.error("Error fetching reclamation info", e);
            } finally {
                setLoadingRec(false);
            }
        };
        fetchRec();
    } else {
        setRecData(null);
    }
  }, [viewRecId]);

  const localStats = useMemo(() => {
    if (reviews.length === 0) return { avg: "0.0", total: 0, positivity: 0 };
    const total = reviews.length;
    const sum = reviews.reduce((acc, r) => acc + (parseInt(r.rating) || 0), 0);
    const avg = (sum / total).toFixed(1);
    const positiveCount = reviews.filter(r => (parseInt(r.rating) || 0) >= 4).length;
    const positivity = Math.round((positiveCount / total) * 100);
    return { avg, total, positivity };
  }, [reviews]);

  const formatComment = (text: string) => {
      if (!text) return 'Sans commentaire.';
      return text.replace(/\\u00c9/g, 'É').split('\n').map((line, i) => (
          <span key={i} className="block mb-1">{line}</span>
      ));
  };

  const getFileUrl = (path: string) => {
    if (!path) return 'https://placehold.co/400x400?text=SPECTRA+BIO';
    if (path.startsWith('http')) return path;
    return `https://birdeye-intelligence.ma/Spetcapp/Backend/storage/app/public/${path}`;
  };

  if (error404) {
      return (
          <div className="h-full flex flex-col items-center justify-center p-10 animate-in fade-in duration-700">
              <div className="bg-white p-20 rounded-[4rem] shadow-2xl border-4 border-white text-center max-w-2xl space-y-8">
                  <div className="w-32 h-32 bg-amber-50 text-amber-500 rounded-[3rem] flex items-center justify-center text-6xl mx-auto shadow-inner animate-pulse">
                      <i className="ti ti-tool"></i>
                  </div>
                  <div className="space-y-4">
                      <h2 className="text-4xl font-black text-slate-800 tracking-tighter uppercase">Module Satisfaction en Sync</h2>
                      <p className="text-slate-500 text-lg font-medium leading-relaxed italic">
                          L'interface est prête. Veuillez vérifier que la route <code className="bg-slate-100 px-2 py-1 rounded text-rose-500">api/reviews</code> est active sur votre serveur.
                      </p>
                  </div>
                  <div className="pt-6">
                      <button onClick={fetchData} className="px-10 py-5 bg-slate-900 text-white rounded-[2rem] font-black uppercase text-xs tracking-[4px] shadow-2xl active:scale-95 transition-all flex items-center justify-center gap-3 mx-auto">
                          <i className="ti ti-refresh text-xl"></i> Re-tester la connexion
                      </button>
                  </div>
              </div>
          </div>
      );
  }

  return (
    <div className="space-y-8 pb-20 animate-in fade-in duration-700">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-8 bg-white p-10 rounded-[4rem] shadow-sm border border-slate-100">
        <div>
          <h1 className="text-4xl font-black text-slate-800 tracking-tighter mb-1">Qualité & Satisfaction</h1>
          <p className="text-slate-400 font-black uppercase text-[10px] tracking-[4px] opacity-70 italic">Audit de performance technique et retours cliniques</p>
        </div>
        <div className="flex bg-slate-100 p-1.5 rounded-[2rem] border border-slate-100">
            <button onClick={() => setRatingFilter('all')} className={`px-8 py-3 rounded-[1.75rem] text-[10px] font-black uppercase tracking-widest transition-all ${ratingFilter === 'all' ? 'bg-white text-blue-600 shadow-lg' : 'text-slate-400'}`}>Tous les avis</button>
            <button onClick={() => setRatingFilter('5')} className={`px-8 py-3 rounded-[1.75rem] text-[10px] font-black uppercase tracking-widest transition-all ${ratingFilter === '5' ? 'bg-white text-indigo-600 shadow-lg' : 'text-slate-400'}`}>Excellence (5*)</button>
            <button onClick={() => setRatingFilter('1')} className={`px-8 py-3 rounded-[1.75rem] text-[10px] font-black uppercase tracking-widest transition-all ${ratingFilter === '1' ? 'bg-white text-rose-600 shadow-lg' : 'text-slate-400'}`}>Critiques (1*)</button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <RatingStat label="Score CSAT Moyen" value={localStats.avg} total="5.0" icon="ti-star" color="text-amber-500" />
          <RatingStat label="Volume Total" value={localStats.total} total="avis" icon="ti-message-share" color="text-blue-500" />
          <RatingStat label="Sentiment Positif" value={localStats.positivity} total="%" icon="ti-mood-happy" color="text-emerald-500" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
          {loading ? (
              <div className="col-span-full py-20 text-center"><div className="animate-spin h-12 w-12 border-t-2 border-blue-600 rounded-full mx-auto"></div></div>
          ) : reviews.map((r: any) => (
              <ReviewCard 
                key={r.id} 
                r={r} 
                formatComment={formatComment} 
                setViewRecId={setViewRecId} 
              />
          ))}
          {!loading && reviews.length === 0 && (
              <div className="col-span-full py-32 text-center">
                  <div className="w-24 h-24 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-6 text-slate-200 text-5xl shadow-inner"><i className="ti ti-mood-empty"></i></div>
                  <p className="text-slate-300 font-black uppercase text-xs tracking-[5px]">Aucune évaluation correspondante</p>
              </div>
          )}
      </div>

      {/* RECLAMATION DETAIL MODAL */}
      {viewRecId && (
          <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-md z-[200] flex items-center justify-center p-4 animate-in fade-in duration-300">
              <div className="bg-white w-full max-w-4xl rounded-[4rem] shadow-2xl overflow-hidden border-4 border-white flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200">
                  <div className="p-10 border-b flex justify-between items-center bg-slate-50/50">
                      <div className="flex items-center gap-6">
                          <div className="w-16 h-16 bg-blue-600 text-white rounded-[1.5rem] flex items-center justify-center text-3xl shadow-xl">
                              <i className="ti ti-file-search"></i>
                          </div>
                          <div>
                              <h2 className="text-3xl font-black text-slate-800 tracking-tighter uppercase leading-none">Dossier Technique #{viewRecId}</h2>
                              <p className="text-[10px] font-black text-slate-400 uppercase tracking-[4px] mt-2">Détails de l'incident lié à cet avis</p>
                          </div>
                      </div>
                      <button onClick={() => setViewRecId(null)} className="w-14 h-14 flex items-center justify-center bg-white rounded-full text-slate-300 hover:text-red-500 shadow-xl text-3xl font-light hover:rotate-90 transition-all">×</button>
                  </div>

                  <div className="flex-1 overflow-y-auto p-10 lg:p-12 custom-scrollbar space-y-10">
                      {loadingRec ? (
                          <div className="py-20 text-center"><div className="animate-spin h-12 w-12 border-t-2 border-blue-600 rounded-full mx-auto"></div></div>
                      ) : recData ? (
                          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 animate-in slide-in-from-bottom-4">
                               {/* Left Side: General Info */}
                               <div className="space-y-8">
                                    <section>
                                        <h4 className="text-[10px] font-black text-blue-500 uppercase tracking-[4px] mb-4">Sujet & Urgence</h4>
                                        <div className="bg-slate-50 p-6 rounded-[2rem] border border-slate-100">
                                            <p className="text-xl font-black text-slate-800 uppercase mb-3">{recData.subject}</p>
                                            <div className="flex gap-2">
                                                <span className={`px-4 py-1 rounded-full text-[9px] font-black uppercase tracking-widest ${(typeof recData.priority === 'object' ? recData.priority?.slug : recData.priority) === 'high' ? 'bg-rose-100 text-rose-600' : 'bg-blue-100 text-blue-600'}`}>
                                                    Priorité: {typeof recData.priority === 'object' ? (recData.priority?.name || recData.priority?.slug || 'Standard') : (recData.priority || 'Standard')}
                                                </span>
                                                <span className="px-4 py-1 rounded-full text-[9px] font-black uppercase tracking-widest bg-slate-900 text-white">
                                                    Statut: {typeof recData.status === 'object' ? (recData.status?.name || recData.status?.label || recData.status?.slug || 'Nouveau') : (recData.status || 'Nouveau')}
                                                </span>
                                            </div>
                                        </div>
                                    </section>

                                    <section>
                                        <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[4px] mb-4">Signalement Praticien</h4>
                                        <div className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm italic text-slate-600 text-sm leading-relaxed">
                                            "{recData.description || 'Pas de description textuelle.'}"
                                        </div>
                                    </section>

                                    <div className="flex items-center gap-4 bg-emerald-50 p-6 rounded-[2rem] border border-emerald-100">
                                        <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-emerald-600 text-xl shadow-sm"><i className="ti ti-calendar-check"></i></div>
                                        <div>
                                            <p className="text-[9px] font-black text-emerald-600 uppercase tracking-widest leading-none mb-1">Date d'Incident</p>
                                            <p className="text-sm font-black text-slate-800">{new Date(recData.created_at).toLocaleString('fr-FR')}</p>
                                        </div>
                                    </div>
                               </div>

                               {/* Right Side: Assets & People */}
                               <div className="space-y-8">
                                    <section className="bg-slate-900 p-8 rounded-[3rem] text-white shadow-2xl relative overflow-hidden">
                                        <div className="absolute -right-10 -top-10 w-40 h-40 bg-blue-500 opacity-10 rounded-full blur-3xl"></div>
                                        <h4 className="text-[10px] font-black text-blue-400 uppercase tracking-[4px] border-b border-white/10 pb-4 mb-6">Passeport Machine</h4>
                                        <div className="flex gap-6 items-center">
                                            <div className="w-24 h-24 bg-white/5 rounded-2xl flex items-center justify-center p-3 border border-white/10 shrink-0">
                                                <img src={getFileUrl(recData.client_machine?.machine?.image_url)} className="w-full h-full object-contain" alt="" />
                                            </div>
                                            <div className="min-w-0">
                                                <h5 className="text-xl font-black uppercase truncate leading-none mb-2">{recData.client_machine?.machine?.name || 'Asset Inconnu'}</h5>
                                                <p className="text-[10px] font-bold text-slate-400 mb-4 tracking-widest">S/N: {recData.client_machine?.serial_number || 'N/A'}</p>
                                                <div className="flex gap-2">
                                                    <span className="px-2 py-0.5 bg-blue-500/20 text-blue-400 rounded text-[8px] font-black uppercase tracking-widest">{recData.client_machine?.machine?.brand?.name}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </section>

                                    <section>
                                        <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[4px] mb-4">Établissement & Intervenant</h4>
                                        <div className="space-y-4">
                                            <div className="flex items-center gap-4 p-4 bg-white border border-slate-100 rounded-2xl shadow-sm">
                                                <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center text-xl"><i className="ti ti-building-hospital"></i></div>
                                                <p className="font-black text-slate-800 uppercase text-xs truncate">{recData.client?.name}</p>
                                            </div>
                                            <div className="flex items-center gap-4 p-4 bg-white border border-slate-100 rounded-2xl shadow-sm">
                                                <div className="w-10 h-10 bg-emerald-50 text-emerald-600 rounded-lg flex items-center justify-center text-xl"><i className="ti ti-user-check"></i></div>
                                                <p className="font-black text-slate-800 uppercase text-xs truncate">{recData.assigned_technician?.name || 'En attente d\'affectation'}</p>
                                            </div>
                                        </div>
                                    </section>
                               </div>
                          </div>
                      ) : (
                          <div className="text-center py-20 italic text-slate-400">Données indisponibles.</div>
                      )}
                  </div>
                  <div className="p-8 border-t bg-slate-50/50 flex justify-center shrink-0">
                      <button onClick={() => setViewRecId(null)} className="px-16 py-5 bg-slate-900 text-white rounded-[2.5rem] font-black uppercase text-[11px] tracking-[5px] active:scale-95 shadow-2xl">Fermer le dossier</button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
}

function RatingStat({ label, value, total, icon, color }: any) {
    return (
        <div className="bg-white p-8 rounded-[3.5rem] border border-slate-100 shadow-sm flex items-center gap-6 group hover:shadow-2xl transition-all">
            <div className={`w-16 h-16 rounded-[1.75rem] bg-slate-50 flex items-center justify-center text-3xl ${color} shadow-inner group-hover:scale-110 transition-transform`}>
                <i className={`ti ${icon}`}></i>
            </div>
            <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">{label}</p>
                <p className="text-3xl font-black text-slate-800 tracking-tighter leading-none">{value}<span className="text-sm opacity-30 ml-1"> {total}</span></p>
            </div>
        </div>
    )
}

const parseSurveyText = (text: string) => {
  const sections: Array<{
    title: string;
    items: Array<{ question: string; score: number; label: string }>;
  }> = [];
  let comments = '';
  
  if (!text) return { sections, comments };
  
  const lines = text.split('\n');
  let currentSection: { title: string; items: Array<{ question: string; score: number; label: string }> } | null = null;
  
  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line) continue;
    
    if (line.toUpperCase().startsWith('[COMMENTAIRES]:') || line.toUpperCase().startsWith('[COMMENTAIRES] :')) {
      const idx = line.indexOf(':');
      comments = line.substring(idx + 1).trim();
      continue;
    }
    
    if (line.startsWith('[') && line.endsWith(']')) {
      const title = line.substring(1, line.length - 1);
      currentSection = { title, items: [] };
      sections.push(currentSection);
    } else if (line.startsWith('-') && currentSection) {
      const itemText = line.substring(1).trim();
      const colonIndex = itemText.lastIndexOf(':');
      if (colonIndex !== -1) {
        const question = itemText.substring(0, colonIndex).trim();
        const scorePart = itemText.substring(colonIndex + 1).trim();
        
        let score = 0;
        let label = scorePart;
        
        const scoreMatch = scorePart.match(/^([0-5])\/5/);
        if (scoreMatch) {
          score = parseInt(scoreMatch[1], 10);
          const parenMatch = scorePart.match(/\(([^)]+)\)/);
          if (parenMatch) {
            label = parenMatch[1];
          } else {
            label = scorePart.replace(scoreMatch[0], '').trim();
          }
        }
        currentSection.items.push({ question, score, label });
      } else {
        currentSection.items.push({ question: itemText, score: 0, label: '' });
      }
    } else if (!line.startsWith('---') && !line.startsWith('[')) {
      if (comments) {
        comments += '\n' + line;
      } else {
        comments = line;
      }
    }
  }
  
  return { sections, comments };
};

function ReviewCard({ r, formatComment, setViewRecId }: any) {
  const [showSurveyDetails, setShowSurveyDetails] = useState(false);
  const isSurvey = typeof r.comment === 'string' && (r.comment.includes('--- ENQUÊTE') || r.comment.includes('[Général]'));

  const getScoreColor = (score: number) => {
    if (score >= 5) return { text: 'text-emerald-500', bg: 'bg-emerald-500' };
    if (score === 4) return { text: 'text-teal-500', bg: 'bg-teal-500' };
    if (score === 3) return { text: 'text-amber-500', bg: 'bg-amber-500' };
    if (score === 2) return { text: 'text-orange-500', bg: 'bg-orange-500' };
    return { text: 'text-rose-500', bg: 'bg-rose-500' };
  };

  const { sections, comments } = isSurvey ? parseSurveyText(r.comment) : { sections: [], comments: r.comment };

  return (
    <div className="bg-white p-8 rounded-[3.5rem] border border-slate-100 shadow-sm hover:shadow-xl transition-all duration-500 flex flex-col h-full relative overflow-hidden group">
      <div className="absolute -right-4 -top-4 w-24 h-24 bg-slate-50 rounded-full opacity-0 group-hover:opacity-100 transition-all scale-0 group-hover:scale-100 animate-in fade-in zoom-in duration-300"></div>
      
      <div className="flex items-center gap-4 mb-6">
          <div className="w-14 h-14 rounded-2xl bg-blue-50 flex items-center justify-center text-2xl text-blue-600 shrink-0 shadow-inner">
              <i className="ti ti-building-hospital"></i>
          </div>
          <div className="min-w-0">
              <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">Avis de l'établissement</p>
              <h5 className="font-black text-slate-800 truncate uppercase tracking-tight">{r.client?.name || 'Client Inconnu'}</h5>
          </div>
      </div>

      <div className="flex gap-1.5 mb-6">
          {[1, 2, 3, 4, 5].map(star => (
              <i key={star} className={`ti ti-star-filled text-xl ${star <= r.rating ? 'text-amber-400' : 'text-slate-100'}`}></i>
          ))}
      </div>

      <div className="flex-1 bg-slate-50/50 p-6 rounded-[2rem] border border-slate-100 mb-6 italic text-slate-600 text-[11px] leading-relaxed relative font-medium">
          <i className="ti ti-quote text-4xl text-slate-200/50 absolute top-2 right-4"></i>
          {isSurvey ? (
            <div className="not-italic space-y-2">
              <p className="text-[8px] font-black uppercase text-slate-400 tracking-widest leading-none mb-1">Commentaire</p>
              <p className="italic text-[11px] leading-relaxed text-slate-600">
                {comments ? `"${comments}"` : "Aucun commentaire écrit additionnel."}
              </p>
            </div>
          ) : (
            formatComment(r.comment)
          )}
      </div>

      {isSurvey && (
        <div className="mb-6">
          <button 
            onClick={() => setShowSurveyDetails(!showSurveyDetails)}
            className="w-full py-3 bg-blue-50 hover:bg-blue-100 text-blue-600 font-extrabold uppercase text-[9px] tracking-wider rounded-2xl transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <i className={`ti ${showSurveyDetails ? 'ti-chevron-up' : 'ti-award'} text-xs`}></i>
            {showSurveyDetails ? "Masquer les Détails" : "Voir les Notes Détaillées"}
          </button>
          
          {showSurveyDetails && (
            <div className="mt-4 p-4 bg-slate-50 rounded-2xl space-y-3 border border-slate-100 divide-y divide-slate-100/60 max-h-60 overflow-y-auto text-left animate-in slide-in-from-top-4 duration-300">
              {sections.map((sec: any, sIdx: number) => (
                <div key={sIdx} className="pt-2 first:pt-0">
                  <h6 className="text-[9px] font-black uppercase text-slate-500 tracking-wider mb-2 flex items-center gap-1.5">
                    <i className="ti ti-point-filled text-blue-500 text-xxs"></i> {sec.title}
                  </h6>
                  <div className="space-y-1.5">
                    {sec.items.map((item: any, iIdx: number) => {
                      const colors = getScoreColor(item.score);
                      return (
                        <div key={iIdx} className="flex justify-between items-center text-[10px] text-slate-600 gap-4">
                          <span className="truncate font-semibold text-slate-500">{item.question}</span>
                          <span className={`px-1.5 py-0.5 rounded-lg text-[9px] font-black shrink-0 ${colors.text}`}>
                            {item.score}/5
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      <div className="pt-6 border-t border-slate-50 space-y-4">
          <div className="flex items-center gap-3">
              <img src={`https://ui-avatars.com/api/?name=${r.technician?.name || 'T'}&background=F1F5F9&color=64748B&bold=true`} className="w-9 h-9 rounded-xl shadow-sm" alt="" />
              <div>
                  <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">Expert Assigné</p>
                  <p className="text-xs font-black text-slate-700">{r.technician?.name || 'Technicien'}</p>
              </div>
          </div>
          <button 
            onClick={() => setViewRecId(r.reclamation_id)}
            className="w-full flex justify-between items-center bg-slate-50 px-4 py-2 rounded-xl hover:bg-blue-50 transition-colors border border-transparent hover:border-blue-100 group/badge cursor-pointer"
          >
              <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest group-hover/badge:text-blue-400">Réclamation ID</span>
              <span className="text-[10px] font-black text-blue-600 bg-blue-50 px-2 rounded-lg">#{r.reclamation_id}</span>
          </button>
          <div className="text-right">
             <p className="text-[9px] font-bold text-slate-300 uppercase tracking-widest">{new Date(r.created_at).toLocaleDateString('fr-FR')}</p>
          </div>
      </div>
    </div>
  );
}
