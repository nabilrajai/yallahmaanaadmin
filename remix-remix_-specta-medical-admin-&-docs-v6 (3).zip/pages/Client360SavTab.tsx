import React from 'react';
import { useNavigate } from 'react-router-dom';

interface Client360SavTabProps {
  client: any;
  clientReclamations: any[];
  loading: boolean;
}

export const Client360SavTab: React.FC<Client360SavTabProps> = ({
  client,
  clientReclamations,
  loading
}) => {
  const navigate = useNavigate();

  return (
    <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden animate-in slide-in-from-bottom-8">
      <div className="p-8 border-b border-slate-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-slate-50/40">
        <div>
          <h4 className="text-[11px] font-black text-amber-600 uppercase tracking-[4px] flex items-center gap-3">
            <i className="ti ti-tool text-xl"></i> Historique des Dossiers SAV & Réclamations
          </h4>
          <p className="text-xs text-slate-400 font-bold mt-1">
            Incidents techniques, pannes et interventions pour {client?.name}
          </p>
        </div>
        <button
          type="button"
          onClick={() => navigate(`/admin/sav/new?clientId=${client?.id}`)}
          className="px-6 py-3 bg-amber-500 hover:bg-amber-600 text-white rounded-2xl font-black text-[11px] uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-amber-500/20 active:scale-95 transition-all cursor-pointer"
        >
          <i className="ti ti-plus text-base"></i>
          <span>Nouveau Ticket SAV</span>
        </button>
      </div>

      {loading ? (
        <div className="p-16 text-center">
          <div className="animate-spin h-10 w-10 border-t-4 border-amber-500 rounded-full mx-auto mb-4"></div>
          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Chargement des dossiers SAV...</p>
        </div>
      ) : clientReclamations.length === 0 ? (
        <div className="p-16 text-center">
          <div className="w-20 h-20 bg-amber-50 text-amber-500 rounded-3xl flex items-center justify-center text-3xl mx-auto mb-4 shadow-inner">
            <i className="ti ti-tool"></i>
          </div>
          <h5 className="text-lg font-black text-slate-700 uppercase mb-2">Aucun Dossier SAV</h5>
          <p className="text-xs text-slate-400 font-medium max-w-md mx-auto mb-6">
            Cet établissement n'a aucun ticket de panne ou réclamation technique enregistré pour le moment.
          </p>
          <button
            type="button"
            onClick={() => navigate(`/admin/sav/new?clientId=${client?.id}`)}
            className="px-6 py-3 bg-slate-900 hover:bg-amber-600 text-white rounded-2xl font-black text-[11px] uppercase tracking-widest shadow-xl active:scale-95 transition-all inline-flex items-center gap-2 cursor-pointer"
          >
            <i className="ti ti-plus text-base"></i>
            <span>Déclarer le premier incident SAV</span>
          </button>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50/50 border-b">
              <tr className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                <th className="px-8 py-5">Ticket / Objet</th>
                <th className="px-8 py-5">Équipement</th>
                <th className="px-8 py-5">Type / Priorité</th>
                <th className="px-8 py-5">Technicien</th>
                <th className="px-8 py-5">Statut</th>
                <th className="px-8 py-5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-sans">
              {clientReclamations.map((rec: any) => {
                const statusSlug = typeof rec.status === 'string'
                  ? rec.status
                  : (rec.status?.slug || rec.status?.name || rec.status?.label || 'new');

                const statusLabel = typeof rec.status === 'string'
                  ? rec.status.replace(/_/g, ' ')
                  : (rec.status?.name || rec.status?.label || rec.status?.slug || 'Nouveau');

                const statusBadgeColor = 
                  ['resolue', 'cloturee', 'resolved', 'closed'].includes(statusSlug) ? 'bg-emerald-50 text-emerald-600 border-emerald-200' :
                  ['en_cours', 'diagnostic', 'in_progress'].includes(statusSlug) ? 'bg-blue-50 text-blue-600 border-blue-200' :
                  'bg-amber-50 text-amber-600 border-amber-200';
                
                const prioSlug = typeof rec.priority === 'string'
                  ? rec.priority.toLowerCase()
                  : (rec.priority?.slug || rec.priority?.name || rec.priority?.label || '').toLowerCase();

                const priorityColor =
                  prioSlug.includes('urgent') || prioSlug.includes('critique') || prioSlug.includes('high') ? 'text-rose-500 font-black' :
                  prioSlug.includes('haute') || prioSlug.includes('medium') ? 'text-amber-500 font-black' : 'text-slate-500 font-bold';

                const priorityLabel = typeof rec.priority === 'object' && rec.priority !== null
                  ? (rec.priority.name || rec.priority.label || rec.priority.slug || 'Normale')
                  : (rec.priority || 'Normale');

                return (
                  <tr key={rec.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-mono text-xs font-black text-blue-600">#{rec.reclamation_number || rec.id}</span>
                        <span className="text-[10px] text-slate-400 font-bold">
                          {rec.created_at ? new Date(rec.created_at).toLocaleDateString() : 'N/A'}
                        </span>
                      </div>
                      <p className="font-black text-slate-800 text-sm">{rec.subject || 'Réclamation technique'}</p>
                      {rec.description && (
                        <p className="text-xs text-slate-400 line-clamp-1 mt-0.5">{rec.description}</p>
                      )}
                    </td>
                    <td className="px-8 py-6">
                      <p className="font-bold text-slate-700 text-xs">
                        {rec.client_machine?.machine?.name || rec.machine_name || 'Machine non spécifiée'}
                      </p>
                      {(rec.client_machine?.serial_number || rec.serial_number) && (
                        <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                          S/N: {rec.client_machine?.serial_number || rec.serial_number}
                        </p>
                      )}
                    </td>
                    <td className="px-8 py-6">
                      <div className="flex flex-col gap-1">
                        <span className="text-[10px] font-black uppercase tracking-wider text-slate-600">
                          {rec.reclamation_type === 'complexe' || rec.type === 'complexe' ? '⚡ Complexe' : '⚙️ Simple'}
                        </span>
                        <span className={`text-[10px] uppercase tracking-wider ${priorityColor}`}>
                          {priorityLabel}
                        </span>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      {(rec.technician || rec.assigned_technician) ? (
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-full bg-slate-200 flex items-center justify-center text-[10px] font-black text-slate-600 uppercase">
                            {((typeof rec.technician === 'object' ? rec.technician?.name : rec.technician) || (typeof rec.assigned_technician === 'object' ? rec.assigned_technician?.name : rec.assigned_technician) || 'T').charAt(0)}
                          </div>
                          <span className="text-xs font-bold text-slate-700">
                            {(typeof rec.technician === 'object' ? rec.technician?.name : rec.technician) || (typeof rec.assigned_technician === 'object' ? rec.assigned_technician?.name : rec.assigned_technician)}
                          </span>
                        </div>
                      ) : (
                        <span className="text-[10px] font-bold text-slate-400 italic">Non assigné</span>
                      )}
                    </td>
                    <td className="px-8 py-6">
                      <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border ${statusBadgeColor}`}>
                        {statusLabel}
                      </span>
                    </td>
                    <td className="px-8 py-6 text-right">
                      <button
                        type="button"
                        onClick={() => navigate('/admin/sav')}
                        className="px-4 py-2 bg-slate-900 hover:bg-amber-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-md transition-all inline-flex items-center gap-1.5 cursor-pointer"
                      >
                        <span>Ouvrir SAV</span>
                        <i className="ti ti-arrow-up-right text-xs"></i>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
