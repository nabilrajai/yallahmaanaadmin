
import React, { useState, useEffect } from 'react';
import { api } from '../api';
import { useApp } from '../App';

export default function AdminStaffLogs() {
  const { theme } = useApp();
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [roleFilter, setRoleFilter] = useState('2'); // 2 = Technician default

  const fetchLogs = async () => {
    setLoading(true);
    try {
        // Fetching activity logs (this would normally be its own endpoint)
        const res = await api.request(`/activity-logs?role_id=${roleFilter}`);
        setLogs(Array.isArray(res?.data) ? res.data : (Array.isArray(res) ? res : []));
    } catch (e) {
        setLogs([]);
    } finally {
        setLoading(false);
    }
  };

  useEffect(() => { fetchLogs(); }, [roleFilter]);

  return (
    <div className="space-y-8 pb-20 animate-in fade-in duration-700">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-8 bg-white p-10 rounded-[4rem] shadow-sm border border-slate-100">
        <div>
          <h1 className="text-4xl font-black text-slate-800 tracking-tighter mb-1">Audit des Ressources Humaines</h1>
          <p className="text-slate-400 font-black uppercase text-[10px] tracking-[4px] opacity-70 italic">Journaux d'Activité du Personnel & Suivi des Performances</p>
        </div>
        <div className="flex bg-slate-100 p-1.5 rounded-[2rem] border border-slate-200">
            <button onClick={() => setRoleFilter('2')} className={`px-8 py-3 rounded-[1.75rem] text-[10px] font-black uppercase tracking-widest transition-all ${roleFilter === '2' ? 'bg-white text-blue-600 shadow-lg' : 'text-slate-400 hover:text-slate-600'}`}>Techniciens</button>
            <button onClick={() => setRoleFilter('3')} className={`px-8 py-3 rounded-[1.75rem] text-[10px] font-black uppercase tracking-widest transition-all ${roleFilter === '3' ? 'bg-white text-indigo-600 shadow-lg' : 'text-slate-400 hover:text-slate-600'}`}>Commerciaux</button>
            <button onClick={() => setRoleFilter('5')} className={`px-8 py-3 rounded-[1.75rem] text-[10px] font-black uppercase tracking-widest transition-all ${roleFilter === '5' ? 'bg-white text-emerald-600 shadow-lg' : 'text-slate-400 hover:text-slate-600'}`}>Livreurs</button>
        </div>
      </div>

      <div className="bg-white rounded-[3rem] border border-slate-100 overflow-hidden shadow-sm">
          <table className="w-full text-left">
              <thead className="bg-slate-50 border-b border-slate-100">
                  <tr className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                      <th className="px-8 py-5">Date & Heure</th>
                      <th className="px-8 py-5">Membre du Personnel</th>
                      <th className="px-8 py-5">Opération</th>
                      <th className="px-8 py-5">Contexte</th>
                      <th className="px-8 py-5">IP d'Authentification</th>
                  </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                  {loading ? (
                      <tr><td colSpan={5} className="py-20 text-center"><div className="animate-spin h-8 w-8 border-t-2 border-blue-600 rounded-full mx-auto"></div></td></tr>
                  ) : logs.map((log: any) => (
                      <tr key={log?.id || Math.random()} className="hover:bg-slate-50 transition-colors group">
                          <td className="px-8 py-5 text-slate-400 font-mono text-[10px]">{log?.created_at ? new Date(log.created_at).toLocaleString('fr-FR') : '---'}</td>
                          <td className="px-8 py-5">
                              <div className="flex items-center gap-3">
                                  <div className="w-8 h-8 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center font-black text-[10px] uppercase">
                                      {log?.user?.name ? log.user.name.charAt(0) : '?'}
                                  </div>
                                  <span className="font-black text-slate-700 text-sm">{log?.user?.name || 'Personnel Inconnu'}</span>
                              </div>
                          </td>
                          <td className="px-8 py-5">
                              <span className={`px-4 py-1 rounded-full text-[9px] font-black uppercase tracking-widest ${(log?.action || '').includes('delete') ? 'bg-rose-50 text-rose-600' : 'bg-blue-50 text-blue-600'}`}>
                                  {log?.action || 'Interaction'}
                              </span>
                          </td>
                          <td className="px-8 py-5 font-bold text-slate-500 text-xs italic">{log?.description || 'Interaction Système'}</td>
                          <td className="px-8 py-5 font-mono text-[10px] text-slate-300">{log?.ip_address || '---'}</td>
                      </tr>
                  ))}
                  {!loading && logs.length === 0 && (
                      <tr><td colSpan={5} className="py-20 text-center text-slate-300 font-black uppercase text-xs tracking-widest">Aucune activité enregistrée pour ce rôle</td></tr>
                  )}
              </tbody>
          </table>
      </div>
    </div>
  );
}
