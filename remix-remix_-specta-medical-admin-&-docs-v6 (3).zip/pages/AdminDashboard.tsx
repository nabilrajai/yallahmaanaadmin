
import React, { useState, useEffect } from 'react';
import { api } from '../api';
import { useApp } from '../App';
import { 
  BarChart, Bar, 
  PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend 
} from 'recharts';

export default function AdminDashboard() {
  const { t } = useApp();
  const [filter, setFilter] = useState<'today' | 'week' | 'month' | 'all' | 'range'>('today');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const [data, setData] = useState<any>(null);
  const [sparePartsList, setSparePartsList] = useState<any[]>([]);
  const [priceRequestsList, setPriceRequestsList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeModalTable, setActiveModalTable] = useState<'spare_parts' | 'price_requests' | null>(null);
  const [lookups, setLookups] = useState<{ products: any, clients: any, users: any, machines: any }>({
    products: {},
    clients: {},
    users: {},
    machines: {}
  });

  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const fetchData = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      let queryParams = `filter=${filter}`;
      if (filter === 'range' && startDate && endDate) {
        queryParams += `&start_date=${startDate}&end_date=${endDate}`;
      }

      // Fetch KPIs, metadata, spare parts & price requests in parallel with safe error isolation
      const [kpiRes, prodRes, clientRes, partsRes, requestsRes, machinesRes] = await Promise.all([
        api.dashboard.getKpis(queryParams).catch(err => {
          console.error("Dashboard KPI fetch error:", err);
          return null;
        }),
        api.products.list('per_page=200').catch(err => {
          console.error("Products lookup fetch error:", err);
          return null;
        }),
        api.clients.list('per_page=200').catch(err => {
          console.error("Clients lookup fetch error:", err);
          return null;
        }),
        api.spareParts.list('per_page=200').catch(err => {
          console.error("Spare parts fetch error:", err);
          return null;
        }),
        api.partPriceRequests.list('per_page=200').catch(err => {
          console.error("Price requests fetch error:", err);
          return null;
        }),
        api.machines.list('per_page=200').catch(err => {
          console.error("Machines lookup fetch error:", err);
          return null;
        })
      ]);

      // Build lookup maps
      const pMap: any = {};
      const cMap: any = {};
      const mMap: any = {};
      
      const products = prodRes?.data?.data || prodRes?.data || (Array.isArray(prodRes) ? prodRes : []);
      if (Array.isArray(products)) {
        products.forEach((p: any) => {
          if (p && p.id) pMap[p.id] = p.name;
        });
      }
      
      const clients = clientRes?.data || (Array.isArray(clientRes) ? clientRes : []);
      if (Array.isArray(clients)) {
        clients.forEach((c: any) => {
          if (c && c.id) cMap[c.id] = c.name;
        });
      }

      const machines = machinesRes?.data?.data || machinesRes?.data || (Array.isArray(machinesRes) ? machinesRes : []);
      if (Array.isArray(machines)) {
        machines.forEach((m: any) => {
          if (m && m.id) mMap[m.id] = m.model || m.name || m.serial_number;
        });
      }

      const partsData = partsRes?.data || (Array.isArray(partsRes) ? partsRes : []);
      const reqsData = requestsRes?.data || (Array.isArray(requestsRes) ? requestsRes : []);

      setSparePartsList(Array.isArray(partsData) ? partsData : []);
      setPriceRequestsList(Array.isArray(reqsData) ? reqsData : []);
      setLookups({ products: pMap, clients: cMap, users: {}, machines: mMap });

      if (kpiRes) {
        setData(kpiRes);
      } else {
        setErrorMsg("Le serveur de données est temporairement indisponible. Veuillez réessayer.");
      }
    } catch (e: any) {
      console.error("Dashboard Load Error:", e);
      setErrorMsg(e?.message || "Erreur lors du chargement du tableau de bord.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (filter !== 'range' || (startDate && endDate)) {
      fetchData();
    }
  }, [filter, startDate, endDate]);

  if (loading) return (
    <div className="flex flex-col items-center justify-center h-96 gap-4">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-blue-600"></div>
      <p className="text-slate-400 font-bold text-xs uppercase tracking-widest">Chargement des données du tableau de bord...</p>
    </div>
  );

  if (errorMsg || !data) return (
    <div className="flex flex-col items-center justify-center min-h-[400px] p-8 bg-white rounded-[3rem] border border-slate-100 shadow-sm text-center">
      <div className="w-16 h-16 bg-rose-50 text-rose-500 rounded-2xl flex items-center justify-center text-3xl mb-4">
        <i className="ti ti-database-exclamation"></i>
      </div>
      <h3 className="text-xl font-black text-slate-800 mb-2">Erreur de Connexion au Serveur</h3>
      <p className="text-slate-500 max-w-md text-sm font-bold mb-6">
        {errorMsg || "Impossible de charger les indicateurs de performance en ce moment."}
      </p>
      <button 
        onClick={fetchData}
        className="px-8 py-3.5 bg-blue-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-500/20 hover:bg-blue-700 active:scale-95 transition-all flex items-center gap-2"
      >
        <i className="ti ti-refresh text-lg"></i>
        Réessayer
      </button>
    </div>
  );

  const getOrderValue = () => {
    switch(filter) {
        case 'week': return data.orders?.week || 0;
        case 'month': return data.orders?.month || 0;
        default: return data.orders?.today || 0;
    }
  }

  const formatMoney = (val: number) => `${(val || 0).toLocaleString()} MAD`;

  const formatDelay = (minutes: number) => {
    if (!minutes || minutes <= 0) return '0 min';
    if (minutes < 60) return `${Math.round(minutes)} min`;
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = Math.round(minutes % 60);
    if (hours < 24) {
      return remainingMinutes > 0 ? `${hours}h ${remainingMinutes}m` : `${hours}h`;
    }
    const days = Math.floor(hours / 24);
    const remainingHours = hours % 24;
    return remainingHours > 0 ? `${days}j ${remainingHours}h` : `${days}j`;
  };

  const savPieData = [
    { name: t.status_in_progress, value: data.sav?.in_progress || 0, color: '#ffae1f' },
    { name: t.status_resolved, value: data.sav?.resolved || 0, color: '#13deb9' }
  ];

  // Map IDs to Names for charts with strict null checks
  const commRankingData = (data.ranking?.commercials || [])
    .filter((c: any) => c !== null)
    .map((c: any) => ({
      name: c?.name || `Rep #${c?.commercial_id || '?'}`,
      ca: parseFloat(c?.total_ca || 0)
    }));

  const productsData = (data.top_products || [])
    .filter((p: any) => p !== null && p.product_id !== null)
    .map((p: any) => ({
      name: p?.product?.name || lookups.products[p?.product_id] || `SKU: ${p?.product_id}`,
      qty: parseInt(p?.total_qty || 0)
    }));

  const machinesData = (data.top_machines || [])
    .filter((m: any) => m !== null && m.machine_id !== null)
    .map((m: any) => ({
      name: m?.machine?.model || m?.machine?.name || lookups.machines?.[m?.machine_id] || `Mach #${m?.machine_id}`,
      qty: parseInt(m?.total_qty || 0)
    }));

  const clientsData = (data.top_clients || [])
    .filter((c: any) => c !== null && c.client_id !== null)
    .map((c: any) => ({
      name: lookups.clients[c?.client_id] || `Client #${c?.client_id}`,
      ca: parseFloat(c?.total_ca || 0)
    }));

  return (
    <div className="space-y-8 pb-10 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* HEADER */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-slate-800 mb-1 tracking-tighter">Specta Intelligence</h1>
          <p className="text-slate-400 font-bold uppercase text-[10px] tracking-[3px] opacity-60">Indicateurs de Performance Globaux (Période: {filter === 'today' ? "AUJOURD'HUI" : filter === 'week' ? "CETTE SEMAINE" : filter === 'month' ? "CE MOIS" : filter === 'all' ? "TOUT LE TEMPS" : "PÉRIODE"})</p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          {/* Quick Filter Buttons */}
          <div className="flex bg-slate-100 p-1 rounded-2xl border border-slate-200/40 shadow-inner gap-1">
            <button 
              onClick={() => setFilter('today')} 
              className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all duration-200 ${filter === 'today' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-500 hover:text-slate-800'}`}
            >
              Aujourd'hui
            </button>
            <button 
              onClick={() => setFilter('week')} 
              className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all duration-200 ${filter === 'week' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-500 hover:text-slate-800'}`}
            >
              Cette Semaine
            </button>
            <button 
              onClick={() => setFilter('month')} 
              className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all duration-200 ${filter === 'month' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-500 hover:text-slate-800'}`}
            >
              Ce Mois
            </button>
            <button 
              onClick={() => setFilter('all')} 
              className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all duration-200 ${filter === 'all' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-500 hover:text-slate-800'}`}
            >
              Tout le Temps
            </button>
            <button 
              onClick={() => setFilter('range')} 
              className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all duration-200 ${filter === 'range' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-500 hover:text-slate-800'}`}
            >
              Période
            </button>
          </div>

          {filter === 'range' && (
            <div className="flex items-center gap-2 bg-white p-1 rounded-2xl border shadow-sm animate-in fade-in slide-in-from-left-4 duration-300">
              <input 
                type="date" 
                value={startDate} 
                onChange={(e) => setStartDate(e.target.value)} 
                className="px-3 py-1 bg-transparent text-[11px] font-bold text-slate-700 outline-none w-28"
              />
              <span className="text-[10px] font-black text-slate-300 uppercase">au</span>
              <input 
                type="date" 
                value={endDate} 
                onChange={(e) => setEndDate(e.target.value)} 
                className="px-3 py-1 bg-transparent text-[11px] font-bold text-slate-700 outline-none w-28"
              />
            </div>
          )}

          <button 
            onClick={fetchData}
            className="flex items-center gap-2 w-11 h-11 bg-white hover:bg-slate-50 text-slate-400 hover:text-blue-600 rounded-full justify-center transition-all border shadow-sm active:scale-90"
            title={t.refresh || 'Synchroniser'}
          >
            <i className="ti ti-refresh text-lg"></i>
          </button>
        </div>
      </div>

      {/* ROW 1: CORE REVENUE & ORDERS */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        <StatCard 
          icon="DH" 
          label="CA Machines (TTC)" 
          value={formatMoney(data.turnover?.ca_machines || 0)} 
          subLabel="Revenu Équipements" 
          color="bg-emerald-50 text-emerald-600" 
        />
        <StatCard 
          icon="DH" 
          label="CA Consommables (TTC)" 
          value={formatMoney(data.turnover?.ca_consommables || 0)} 
          subLabel="Revenu Produits" 
          color="bg-teal-50 text-teal-600" 
        />
        <StatCard 
          icon="ti-shopping-cart" 
          label={`Commandes (${filter === 'today' ? "Aujourd'hui" : filter === 'week' ? "Semaine" : filter === 'month' ? "Mois" : filter === 'all' ? "Global" : "Période"})`} 
          value={getOrderValue()} 
          subLabel={`Auj: ${data.orders?.today || 0} / S: ${data.orders?.week || 0} / M: ${data.orders?.month || 0}`} 
          color="bg-blue-50 text-blue-600"
        />
        <StatCard 
          icon="ti-clock-bolt" 
          label="Délai Moyen de Réponse (SLA)" 
          value={formatDelay(data.sla?.avg_response_minutes || 0)} 
          subLabel="Latence Support Client" 
          color="bg-amber-50 text-amber-600"
        />
        <StatCard 
          icon="ti-checkbox" 
          label="Temps Moyen de Résolution" 
          value={formatDelay(data.sla?.avg_resolution_minutes || 0)} 
          subLabel="Taux de Clôture SAV" 
          color="bg-rose-50 text-rose-600"
        />
      </div>

      {/* ROW 1.5: SPARE PARTS & PRICE REQUESTS KPIS */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex items-center justify-between hover:shadow-md transition-all">
          <div className="flex items-center gap-5">
            <div className="w-14 h-14 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-3xl shadow-inner">
              <i className="ti ti-settings-2"></i>
            </div>
            <div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-[3px] mb-1">Pièces de Rechange</p>
              <p className="text-3xl font-black text-slate-800 tracking-tighter">{sparePartsList.length} <span className="text-xs font-bold text-slate-400">références</span></p>
            </div>
          </div>
          <button 
            onClick={() => setActiveModalTable('spare_parts')}
            className="px-5 py-3 bg-indigo-50 text-indigo-700 hover:bg-indigo-600 hover:text-white rounded-2xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-2 active:scale-95 shadow-sm"
          >
            <i className="ti ti-table text-lg"></i>
            Voir la Table
          </button>
        </div>

        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex items-center justify-between hover:shadow-md transition-all">
          <div className="flex items-center gap-5">
            <div className="w-14 h-14 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center text-3xl shadow-inner">
              <i className="ti ti-receipt"></i>
            </div>
            <div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-[3px] mb-1">Demandes de Prix</p>
              <p className="text-3xl font-black text-slate-800 tracking-tighter">{priceRequestsList.length} <span className="text-xs font-bold text-slate-400">demandes</span></p>
            </div>
          </div>
          <button 
            onClick={() => setActiveModalTable('price_requests')}
            className="px-5 py-3 bg-amber-50 text-amber-700 hover:bg-amber-600 hover:text-white rounded-2xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-2 active:scale-95 shadow-sm"
          >
            <i className="ti ti-table text-lg"></i>
            Voir la Table
          </button>
        </div>
      </div>

      {/* ROW 2: SAV TICKETS BREAKDOWN */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard small label="Total Tickets SAV" value={data.sav?.total || 0} color="bg-slate-50 text-slate-600" icon="ti-alert-circle" />
        <StatCard small label="SAV En Cours" value={data.sav?.in_progress || 0} color="bg-amber-50 text-amber-600" icon="ti-settings-automation" />
        <StatCard small label="SAV Résolu" value={data.sav?.resolved || 0} color="bg-emerald-50 text-emerald-600" icon="ti-circle-check" />
        <StatCard small label="Délai Moyen Réclamation" value={formatDelay(data.sav?.avg_resolution_minutes || data.sla?.avg_resolution_minutes || 1440)} color="bg-purple-50 text-purple-600" icon="ti-clock-bolt" />
      </div>

      {/* ROW 3: SAV STATUS & COMMERCIALS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-5 bg-white p-8 rounded-3xl shadow-sm border border-slate-100 flex flex-col items-center group transition-all duration-500 hover:shadow-lg hover:shadow-slate-200/50">
          <h3 className="text-lg font-black text-slate-800 self-start mb-6 tracking-tighter uppercase text-[10px] tracking-[3px] opacity-40">Répartition des Tickets SAV</h3>
          <div className="h-64 w-full relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={savPieData} innerRadius={60} outerRadius={90} paddingAngle={5} dataKey="value">
                  {savPieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} strokeWidth={0} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)', fontWeight: 'bold' }}
                />
                <Legend iconType="circle" verticalAlign="bottom" wrapperStyle={{ fontSize: '10px', fontWeight: '900', textTransform: 'uppercase', letterSpacing: '1px', paddingTop: '20px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="lg:col-span-7 bg-white p-8 rounded-3xl shadow-sm border border-slate-100 hover:shadow-lg hover:shadow-slate-200/50 transition-all duration-500">
          <h3 className="text-lg font-black text-slate-800 mb-6 tracking-tighter uppercase text-[10px] tracking-[3px] opacity-40">Classement des Commerciaux (CA)</h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart layout="vertical" data={commRankingData}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                <XAxis type="number" hide />
                <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 11, fontWeight: 'bold'}} width={120} />
                <Tooltip 
                   formatter={(v: any) => formatMoney(v)}
                   contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
                />
                <Bar dataKey="ca" fill="#5D87FF" radius={[0, 10, 10, 0]} barSize={20} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* ROW 4: MACHINES & PRODUCTS & CLIENTS */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 hover:shadow-lg hover:shadow-slate-200/50 transition-all duration-500">
          <h3 className="text-lg font-black text-slate-800 mb-8 tracking-tighter uppercase text-[10px] tracking-[3px] opacity-40">Top Machines Vendues</h3>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={machinesData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                    dataKey="name" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{fill: '#94a3b8', fontSize: 9, fontWeight: 'bold'}} 
                    height={80} 
                    interval={0} 
                    angle={-30} 
                    textAnchor="end" 
                />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10}} />
                <Tooltip 
                    contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)', fontWeight: 'bold' }} 
                    cursor={{fill: '#f8fafc'}}
                />
                <Bar dataKey="qty" fill="#13deb9" radius={[10, 10, 0, 0]} barSize={30} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 hover:shadow-lg hover:shadow-slate-200/50 transition-all duration-500">
          <h3 className="text-lg font-black text-slate-800 mb-8 tracking-tighter uppercase text-[10px] tracking-[3px] opacity-40">Top Consommables Vendus</h3>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={productsData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                    dataKey="name" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{fill: '#94a3b8', fontSize: 9, fontWeight: 'bold'}} 
                    height={80} 
                    interval={0} 
                    angle={-30} 
                    textAnchor="end" 
                />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10}} />
                <Tooltip 
                    contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)', fontWeight: 'bold' }} 
                    cursor={{fill: '#f8fafc'}}
                />
                <Bar dataKey="qty" fill="#49BEFF" radius={[10, 10, 0, 0]} barSize={30} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 hover:shadow-lg hover:shadow-slate-200/50 transition-all duration-500">
          <h3 className="text-lg font-black text-slate-800 mb-8 tracking-tighter uppercase text-[10px] tracking-[3px] opacity-40">Meilleurs Clients par Chiffre d'Affaires</h3>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={clientsData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                    dataKey="name" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{fill: '#94a3b8', fontSize: 9, fontWeight: 'bold'}} 
                    height={80} 
                    interval={0} 
                    angle={-30} 
                    textAnchor="end" 
                />
                <YAxis hide />
                <Tooltip 
                  formatter={(v: any) => formatMoney(v)}
                  contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)', fontWeight: 'bold' }} 
                />
                <Bar dataKey="ca" fill="#13DEB9" radius={[10, 10, 0, 0]} barSize={30} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* TABLE MODAL: PIÈCES DE RECHANGE */}
      {activeModalTable === 'spare_parts' && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[150] flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-5xl rounded-[3rem] shadow-2xl overflow-hidden border-4 border-white flex flex-col max-h-[85vh]">
            <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-2xl">
                  <i className="ti ti-settings-2"></i>
                </div>
                <div>
                  <h2 className="text-xl font-black text-slate-800 tracking-tight">Registre des Pièces de Rechange</h2>
                  <p className="text-slate-400 font-bold text-xs">Inventaire complet des pièces de remplacement</p>
                </div>
              </div>
              <button 
                onClick={() => setActiveModalTable(null)}
                className="w-12 h-12 flex items-center justify-center bg-white rounded-full text-slate-400 hover:text-red-500 shadow-md text-2xl font-light active:scale-90"
              >
                ×
              </button>
            </div>
            <div className="p-6 overflow-y-auto custom-scrollbar flex-1">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="text-[10px] font-black uppercase text-slate-400 tracking-widest border-b border-slate-100">
                    <th className="pb-4 px-4">Référence / Pièce</th>
                    <th className="pb-4 px-4">Modèle Machine</th>
                    <th className="pb-4 px-4">Prix Unitaire</th>
                    <th className="pb-4 px-4">Stock</th>
                    <th className="pb-4 px-4 text-right">Statut</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {sparePartsList.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-12 text-center text-slate-400 font-bold">
                        Aucune pièce de rechange trouvée dans la base.
                      </td>
                    </tr>
                  ) : sparePartsList.map((part: any) => (
                    <tr key={part.id} className="hover:bg-slate-50/60 transition-colors">
                      <td className="py-4 px-4 font-black text-slate-800">
                        {part.name || part.part_number || `Pièce #${part.id}`}
                        {part.reference && <span className="block text-xs font-bold text-slate-400">Réf: {part.reference}</span>}
                      </td>
                      <td className="py-4 px-4 text-slate-600 font-bold">
                        {part.machine_model || part.machine?.name || 'Universel'}
                      </td>
                      <td className="py-4 px-4 font-black text-blue-600">
                        {formatMoney(parseFloat(part.price || 0))}
                      </td>
                      <td className="py-4 px-4 font-bold text-slate-700">
                        {part.stock ?? part.stock_quantity ?? 'Dispo'}
                      </td>
                      <td className="py-4 px-4 text-right">
                        <span className="px-3 py-1 bg-emerald-50 text-emerald-600 rounded-full text-[10px] font-black uppercase tracking-wider">
                          En Stock
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TABLE MODAL: DEMANDES DE PRIX */}
      {activeModalTable === 'price_requests' && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[150] flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-5xl rounded-[3rem] shadow-2xl overflow-hidden border-4 border-white flex flex-col max-h-[85vh]">
            <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center text-2xl">
                  <i className="ti ti-receipt"></i>
                </div>
                <div>
                  <h2 className="text-xl font-black text-slate-800 tracking-tight">Demandes de Prix de Pièces</h2>
                  <p className="text-slate-400 font-bold text-xs">Historique et statut des cotations demandées</p>
                </div>
              </div>
              <button 
                onClick={() => setActiveModalTable(null)}
                className="w-12 h-12 flex items-center justify-center bg-white rounded-full text-slate-400 hover:text-red-500 shadow-md text-2xl font-light active:scale-90"
              >
                ×
              </button>
            </div>
            <div className="p-6 overflow-y-auto custom-scrollbar flex-1">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="text-[10px] font-black uppercase text-slate-400 tracking-widest border-b border-slate-100">
                    <th className="pb-4 px-4">Client / Demandeur</th>
                    <th className="pb-4 px-4">Pièce / Description</th>
                    <th className="pb-4 px-4">Prix Proposé</th>
                    <th className="pb-4 px-4 text-right">Statut</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {priceRequestsList.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="py-12 text-center text-slate-400 font-bold">
                        Aucune demande de prix enregistrée.
                      </td>
                    </tr>
                  ) : priceRequestsList.map((req: any) => (
                    <tr key={req.id} className="hover:bg-slate-50/60 transition-colors">
                      <td className="py-4 px-4 font-black text-slate-800">
                        {req.client?.name || req.user?.name || `Client #${req.client_id || '?'}`}
                        <span className="block text-xs font-bold text-slate-400">{req.created_at ? new Date(req.created_at).toLocaleDateString() : 'Récemment'}</span>
                      </td>
                      <td className="py-4 px-4 font-bold text-slate-700">
                        {req.part_name || req.spare_part?.name || req.description || 'Pièce de rechange'}
                      </td>
                      <td className="py-4 px-4 font-black text-blue-600">
                        {req.quoted_price ? formatMoney(parseFloat(req.quoted_price)) : 'En attente de chiffrage'}
                      </td>
                      <td className="py-4 px-4 text-right">
                        <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                          req.status === 'approved' || req.status === 'quoted' ? 'bg-emerald-50 text-emerald-600' :
                          req.status === 'rejected' ? 'bg-rose-50 text-rose-600' :
                          'bg-amber-50 text-amber-600'
                        }`}>
                          {req.status === 'approved' ? 'Approuvé' : req.status === 'quoted' ? 'Chiffré' : req.status === 'rejected' ? 'Rejeté' : 'En Attente'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function StatCard({ icon, label, value, subLabel, color, small = false }: any) {
  const isCurrency = icon === 'DH' || icon === 'MAD' || icon === 'ti-currency-dirham' || icon === 'morocco-currency';

  if (small) {
    return (
      <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4 hover:shadow-lg transition-all duration-500">
        <div className={`w-12 h-12 rounded-xl ${color} flex items-center justify-center text-2xl shadow-inner select-none`}>
          {isCurrency ? (
            <span className="font-black text-base tracking-tight leading-none">DH</span>
          ) : (
            <i className={`ti ${icon}`}></i>
          )}
        </div>
        <div>
          <p className="text-[9px] font-black text-slate-400 uppercase tracking-[2px] leading-none mb-1">{label}</p>
          <p className="text-xl font-black text-slate-800 tracking-tighter leading-none">{value}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 group hover:shadow-lg hover:shadow-blue-500/10 transition-all duration-700 relative overflow-hidden border-b-2 border-b-slate-100">
      <div className={`absolute -right-8 -bottom-8 w-32 h-32 ${color.split(' ')[0]} rounded-full opacity-0 group-hover:opacity-100 transition-all duration-1000 scale-0 group-hover:scale-150`}></div>
      <div className="relative z-10 space-y-8">
        <div className={`w-14 h-14 rounded-2xl ${color} flex items-center justify-center shadow-inner group-hover:rotate-6 transition-transform duration-500 select-none`}>
          {isCurrency ? (
            <span className="font-black text-xl tracking-tight leading-none">DH</span>
          ) : (
            <i className={`ti ${icon} text-3xl`}></i>
          )}
        </div>
        <div>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-[3px] mb-2 group-hover:text-slate-600 transition-colors">{label}</p>
          <p className="text-2xl font-black text-slate-800 mb-3 tracking-tighter">{value}</p>
          <p className="text-[11px] font-bold text-slate-400 flex items-center gap-2 opacity-60 group-hover:opacity-100 transition-opacity">
            <i className="ti ti-trending-up text-lg text-emerald-500"></i> {subLabel}
          </p>
        </div>
      </div>
    </div>
  );
}