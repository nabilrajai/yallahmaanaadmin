
import React, { useState } from 'react';
import { useApp } from '../App';
import { Client } from '../types';

const MOCK_CLIENTS: Client[] = [
  { id: 1, code: 'CL001', name: 'Clinique Aljadid', contact_name: 'Dr. Karimi', email: 'karimi@aljadid.ma', city: 'Casablanca', status: 'active' },
  { id: 2, code: 'CL002', name: 'Centre Medical Oasis', contact_name: 'Mme. Alaoui', email: 'alaoui@oasis.ma', city: 'Rabat', status: 'active' },
  { id: 3, code: 'CL003', name: 'Hopital Cheikh Zaid', contact_name: 'Directeur SAV', email: 'cheikhzaid@biomed.ma', city: 'Rabat', status: 'inactive' },
  { id: 4, code: 'CL004', name: 'Esthetique Center Marrakech', contact_name: 'Dr. Nassiri', email: 'nassiri@beauty.ma', city: 'Marrakech', status: 'active' },
];

export default function Clients() {
  const { t } = useApp();
  const [clients] = useState(MOCK_CLIENTS);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-slate-800">{t.nav_clients}</h1>
        <button className="px-6 py-2.5 bg-blue-600 text-white rounded-xl font-semibold shadow-md shadow-blue-200 hover:bg-blue-700 transition-all">
          + Add Client
        </button>
      </div>

      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-50 flex items-center gap-4">
           <div className="relative flex-1">
              <input 
                type="text" 
                placeholder={t.search} 
                className="w-full pl-10 pr-4 py-2 bg-slate-50 border-none rounded-xl text-sm focus:ring-2 focus:ring-blue-500 transition-all"
              />
              <svg className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
           </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50/50">
              <tr className="text-slate-500 text-xs uppercase tracking-wider font-semibold">
                <th className="px-6 py-4">Code</th>
                <th className="px-6 py-4">Name</th>
                <th className="px-6 py-4">City</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {clients.map(c => (
                <tr key={c.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-6 py-4 font-mono text-sm font-bold text-blue-600">{c.code}</td>
                  <td className="px-6 py-4">
                    <p className="font-semibold text-slate-800">{c.name}</p>
                    <p className="text-xs text-slate-400">{c.email}</p>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-600">{c.city}</td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-tight ${
                      c.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-500'
                    }`}>
                      {typeof c.status === 'object' ? (c.status?.name || c.status?.slug) : c.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button className="text-slate-400 hover:text-blue-600 p-1">
                      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                      </svg>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
