import React, { useState, useEffect } from 'react';
import { api } from '../api';
import { useApp } from '../App';
import { Client } from '../types';

const STAFF_ROLES = [
  { id: 1, name: 'Administrateur' },
  { id: 2, name: 'Technicien' },
  { id: 3, name: 'Commercial' },
  { id: 4, name: 'Utilisateur Client' },
  { id: 5, name: 'Livreur' },
];

const HISTORY = [
    { id: 1, title: 'Maintenance Programmée', message: 'Le portail sera indisponible dimanche de 02h à 04h.', target_summary: 'Tous les utilisateurs', sent_at: '2024-05-15 10:30', status: 'delivered' },
    { id: 2, title: 'Congrès Médical', message: 'Inscrivez-vous pour le séminaire Laser V3 à Casablanca.', target_summary: 'Rôle: Client', sent_at: '2024-05-14 15:45', status: 'delivered' },
];

export default function AdminNotifications() {
  const { theme } = useApp();
  const [clients, setClients] = useState<Client[]>([]);
  const [cities, setCities] = useState<string[]>([]);
  
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [role_id, setRoleId] = useState('');
  const [client_id, setClientId] = useState('');
  const [city, setCity] = useState('');
  const [is_active, setIsActive] = useState('');

  const [isSending, setIsSending] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const clientRes = await api.clients.list('per_page=1000');
        const clientData = clientRes.data || clientRes || [];
        setClients(clientData);
        const uniqueCities = [...new Set(clientData.map((c: Client) => c.city).filter(Boolean))] as string[];
        setCities(uniqueCities.sort());
      } catch (e) {
        console.error("Failed to fetch data for notification filters", e);
      }
    };
    fetchData();
  }, []);

  const handleLaunch = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSending(true);
    setError('');
    setShowSuccess(false);

    const payload: any = { title, message };
    if (role_id) payload.role_id = role_id;
    if (client_id) payload.client_id = client_id;
    if (city) payload.city = city;
    if (is_active !== '') payload.is_active = is_active;

    try {
      await api.notifications.send(payload);
      setIsSending(false);
      setShowSuccess(true);
      setTitle('');
      setMessage('');
      setTimeout(() => setShowSuccess(false), 4000);
    } catch (err: any) {
      setIsSending(false);
      setError(err.message || 'Échec de l\'envoi de la notification. Vérifiez la réponse de l\'API.');
      console.error(err);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-700 pb-20">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6">
        <div>
          <h1 className="text-4xl font-black tracking-tight">Centre de Diffusion</h1>
          <p className="text-slate-400 font-black uppercase text-[10px] tracking-[3px] opacity-60 italic">Lancer des Notifications Push en Temps Réel pour les Cliniques & Médecins</p>
        </div>
        <div className="flex items-center gap-4">
             <div className="px-4 py-2 bg-emerald-50 text-emerald-600 rounded-full text-[10px] font-black uppercase tracking-widest border border-emerald-100 flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span> Passerelle Firebase : Active
             </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* COMPOSER */}
        <div className="lg:col-span-7 space-y-8">
            <form onSubmit={handleLaunch} className={`p-8 sm:p-10 rounded-[3.5rem] border shadow-sm space-y-8 ${theme === 'dark' ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'}`}>
                <div className="space-y-6">
                    <h3 className="text-xl font-black tracking-tight flex items-center gap-3">
                        <i className="ti ti-pencil-plus text-blue-600 text-2xl"></i> Rédiger la Notification
                    </h3>
                    <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Titre de la Notification</label>
                        <input type="text" value={title} onChange={e => setTitle(e.target.value)} className={`w-full px-8 py-5 border-none rounded-[1.75rem] outline-none font-bold text-lg shadow-inner ${theme === 'dark' ? 'bg-slate-800 text-white' : 'bg-slate-50'}`} placeholder="Ex: Maintenance programmée ce soir" required />
                    </div>
                    <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Contenu du Message</label>
                        <textarea value={message} onChange={e => setMessage(e.target.value)} className={`w-full px-8 py-5 border-none rounded-[1.75rem] outline-none font-medium h-32 shadow-inner leading-relaxed ${theme === 'dark' ? 'bg-slate-800 text-white' : 'bg-slate-50'}`} placeholder="Détails du message pour vos utilisateurs..." required />
                    </div>
                </div>

                <div className="space-y-6 pt-6 border-t border-slate-100">
                    <h3 className="text-xl font-black tracking-tight flex items-center gap-3"><i className="ti ti-filter text-blue-600 text-2xl"></i> Ciblage Avancé</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <FilterSelect label="Rôle Utilisateur" value={role_id} onChange={setRoleId}>
                            <option value="">Tous les Rôles</option>
                            {STAFF_ROLES.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
                        </FilterSelect>
                        <FilterSelect label="Client Spécifique" value={client_id} onChange={setClientId}>
                            <option value="">Tous les Clients</option>
                            {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                        </FilterSelect>
                        <FilterSelect label="Filtrer par Ville" value={city} onChange={setCity}>
                            <option value="">Toutes les Villes</option>
                            {cities.map(c => <option key={c} value={c}>{c}</option>)}
                        </FilterSelect>
                        <FilterSelect label="Statut du Compte" value={is_active} onChange={setIsActive}>
                            <option value="">Tous les Statuts</option>
                            <option value="1">Actif Uniquement</option>
                            <option value="0">Inactif Uniquement</option>
                        </FilterSelect>
                    </div>
                </div>
                
                {error && <div className="bg-rose-50 border border-rose-100 text-rose-600 text-xs font-bold p-4 rounded-2xl">{error}</div>}

                <button disabled={isSending} className="w-full py-6 bg-blue-600 text-white rounded-[2.5rem] font-black uppercase text-xs tracking-[5px] shadow-2xl shadow-blue-200 active:scale-95 transition-all disabled:opacity-50 flex items-center justify-center gap-4">
                    {isSending ? <div className="animate-spin h-5 w-5 border-2 border-white/30 border-t-white rounded-full"></div> : <i className="ti ti-rocket text-xl"></i>}
                    {isSending ? 'Envoi de la diffusion...' : 'Lancer la Notification'}
                </button>
            </form>
        </div>

        {/* MOBILE PREVIEW */}
        <div className="lg:col-span-5 sticky top-28 hidden md:block">
            <div className="relative mx-auto w-[320px] h-[640px] bg-slate-900 rounded-[3.5rem] border-[8px] border-slate-800 shadow-[0_50px_100px_-20px_rgba(0,0,0,0.5)] overflow-hidden">
                <div className="absolute inset-0 z-0"><img src="https://images.unsplash.com/photo-1614850523296-d8c1af93d400?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover brightness-50" alt="" /></div>
                <div className="relative z-10 p-4 pt-20 space-y-4">
                    <div className="bg-white/10 backdrop-blur-2xl border border-white/10 p-5 rounded-[2rem] shadow-2xl animate-in slide-in-from-top-10 duration-700">
                        <div className="flex justify-between items-center mb-2">
                            <div className="flex items-center gap-2">
                                <img src="https://specta.ma/images/Specta_logo.webp" className="w-4 h-4 rounded brightness-0 invert" alt="" />
                                <span className="text-[9px] font-bold text-white uppercase tracking-widest">Specta App</span>
                            </div>
                            <span className="text-[9px] text-white/40">À l'instant</span>
                        </div>
                        <h4 className="text-white font-black text-sm mb-1 leading-tight">{title || 'Aperçu du Titre'}</h4>
                        <p className="text-white/70 text-xs leading-relaxed line-clamp-2">{message || 'Ceci est un aperçu de la notification envoyée. Rédigez votre message dans le compositeur...'}</p>
                    </div>
                </div>
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-slate-800 rounded-b-2xl"></div>
            </div>
            <div className="mt-8 text-center px-10"><p className="text-[10px] font-black text-slate-400 uppercase tracking-[4px] opacity-40">Aperçu Natif</p></div>
        </div>
      </div>

      {/* SUCCESS POPUP */}
      {showSuccess && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 animate-in fade-in duration-300">
            <div className="bg-slate-900/40 backdrop-blur-md absolute inset-0"></div>
            <div className="bg-white rounded-[3rem] shadow-[0_50px_100px_-20px_rgba(0,0,0,0.3)] p-12 text-center max-w-sm w-full relative z-10 animate-in zoom-in-95">
                <div className="w-20 h-20 bg-emerald-50 text-emerald-500 rounded-3xl flex items-center justify-center text-4xl mx-auto mb-6 shadow-inner animate-bounce"><i className="ti ti-check"></i></div>
                <h3 className="text-2xl font-black text-slate-800 tracking-tight mb-2">Diffusion Réussie !</h3>
                <p className="text-slate-500 font-medium text-sm leading-relaxed mb-8">La notification a été envoyée aux serveurs Firebase et mise en file d'attente pour livraison.</p>
                <button onClick={() => setShowSuccess(false)} className="w-full py-4 bg-slate-900 text-white rounded-2xl font-black uppercase text-[10px] tracking-[4px] active:scale-95 transition-all shadow-xl">Fermer</button>
            </div>
        </div>
      )}
    </div>
  );
}

function FilterSelect({ label, value, onChange, children }: any) {
    const { theme } = useApp();
    return (
        <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">{label}</label>
            <select 
                value={value} 
                onChange={e => onChange(e.target.value)} 
                className={`w-full px-8 py-4 border-none rounded-[1.5rem] outline-none font-black text-xs uppercase tracking-widest shadow-inner appearance-none ${theme === 'dark' ? 'bg-slate-800 text-white' : 'bg-slate-50 text-slate-700'}`}
            >
                {children}
            </select>
        </div>
    );
}