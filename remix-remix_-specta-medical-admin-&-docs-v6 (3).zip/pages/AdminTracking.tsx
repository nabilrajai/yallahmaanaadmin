import React, { useState, useEffect, useRef } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api } from '../api';
import { useApp } from '../App';

// Leaflet is global from script in index.html
declare var L: any;

interface AdminTrackingProps {
  defaultFleet?: 'commercials' | 'technicians';
  lockedFleet?: 'commercials' | 'technicians';
}

const MOROCCO_PRESETS = [
  { city: "Casablanca - Maârif", lat: 33.58988, lng: -7.63255, desc: "Cliniques & Centres Spécialisés" },
  { city: "Casablanca - Sidi Maârouf", lat: 33.53320, lng: -7.63350, desc: "Parc d'Affaires & Technopark" },
  { city: "Casablanca - Ain Sebaâ", lat: 33.60650, lng: -7.53120, desc: "Secteur Hospitalier & Logistique" },
  { city: "Rabat - Agdal", lat: 34.00410, lng: -6.84880, desc: "Pôle Médical & Cabinets" },
  { city: "Marrakech - Guéliz", lat: 31.63460, lng: -8.01420, desc: "Cliniques Privées Guéliz" },
  { city: "Tanger - Centre Ville", lat: 35.77280, lng: -5.80390, desc: "Hôpital & Polycliniques" },
  { city: "Fès - Ville Nouvelle", lat: 34.03310, lng: -5.00030, desc: "Centres de Santé & Cabinets" },
  { city: "Agadir - Centre", lat: 30.42780, lng: -9.59810, desc: "Zone Médicale Souss" }
];

export default function AdminTracking({ defaultFleet, lockedFleet }: AdminTrackingProps = {}) {
  const { theme } = useApp();
  const [searchParams, setSearchParams] = useSearchParams();

  // Fleet selector: 'commercials' | 'technicians'
  const paramFleet = lockedFleet || searchParams.get('fleet') || searchParams.get('tab') || defaultFleet;
  const initialFleet: 'commercials' | 'technicians' = paramFleet === 'technicians' ? 'technicians' : 'commercials';
  const [fleetType, setFleetType] = useState<'commercials' | 'technicians'>(initialFleet);

  useEffect(() => {
    if (lockedFleet) {
      setFleetType(lockedFleet);
    }
  }, [lockedFleet]);

  const [positions, setPositions] = useState<any[]>([]);
  const [selectedAgent, setSelectedAgent] = useState<any>(null);
  const [trajet, setTrajet] = useState<any[]>([]);
  const [trajetEmpty, setTrajetEmpty] = useState<boolean>(false);
  const [loading, setLoading] = useState(true);
  const [filterDate, setFilterDate] = useState(new Date().toISOString().split('T')[0]);
  const [searchTerm, setSearchTerm] = useState('');

  // Location Record / Simulate Modal
  const [recordModalOpen, setRecordModalOpen] = useState(false);
  const [recordCommercialId, setRecordCommercialId] = useState<string>('');
  const [recordLat, setRecordLat] = useState<string>('33.58988');
  const [recordLng, setRecordLng] = useState<string>('-7.63255');
  const [isRecording, setIsRecording] = useState(false);
  const [recordToast, setRecordToast] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // All commercials list for recording dropdown
  const [commercialsList, setCommercialsList] = useState<any[]>([]);

  const mapRef = useRef<any>(null);
  const mapContainer = useRef<HTMLDivElement>(null);
  const markersRef = useRef<any>({});
  const polylineRef = useRef<any>(null);
  const trajetMarkersRef = useRef<any[]>([]);

  // Calculate trajectory distance
  const trajectoryDistanceKm = React.useMemo(() => {
    if (trajet.length < 2) return 0;
    let total = 0;
    for (let i = 0; i < trajet.length - 1; i++) {
      const lat1 = parseFloat(trajet[i].latitude);
      const lon1 = parseFloat(trajet[i].longitude);
      const lat2 = parseFloat(trajet[i + 1].latitude);
      const lon2 = parseFloat(trajet[i + 1].longitude);
      if (!isNaN(lat1) && !isNaN(lon1) && !isNaN(lat2) && !isNaN(lon2)) {
        const R = 6371; // Earth radius in km
        const dLat = (lat2 - lat1) * Math.PI / 180;
        const dLon = (lon2 - lon1) * Math.PI / 180;
        const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                  Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                  Math.sin(dLon / 2) * Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        total += R * c;
      }
    }
    return Math.round(total * 10) / 10;
  }, [trajet]);

  // Initialize Map
  useEffect(() => {
    if (!mapContainer.current) return;

    mapRef.current = L.map(mapContainer.current).setView([33.5731, -7.5898], 11); // Casablanca Center

    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png?key=cb1_33ac_1_1f4293de7dfd680b356c1943', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
    }).addTo(mapRef.current);

    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, []);

  // Fetch all positions depending on fleetType
  const fetchAllPositions = async () => {
    setLoading(true);
    try {
      if (fleetType === 'commercials') {
        // Fetch both live locations and users registered as commercials (role_id=3)
        const [posRes, usersRes] = await Promise.all([
          api.commercialTracking.getAllLastPositions().catch(e => {
            console.error("Commercial positions fetch error", e);
            return null;
          }),
          api.users.list('role_id=3').catch(e => {
            console.error("Commercial users fetch error", e);
            return null;
          })
        ]);

        let livePositions: any[] = [];
        if (posRes) {
          if (Array.isArray(posRes.positions)) {
            livePositions = posRes.positions;
          } else if (posRes.data && Array.isArray(posRes.data.positions)) {
            livePositions = posRes.data.positions;
          } else if (Array.isArray(posRes.data)) {
            livePositions = posRes.data;
          } else if (Array.isArray(posRes)) {
            livePositions = posRes;
          }
        }

        let dbUsers: any[] = [];
        if (usersRes) {
          if (Array.isArray(usersRes.data)) {
            dbUsers = usersRes.data;
          } else if (Array.isArray(usersRes)) {
            dbUsers = usersRes;
          }
        }

        setCommercialsList(dbUsers);

        // Merge live positions with all registered commercials
        const merged: any[] = [];
        const liveCommercialIds = new Set<number>();

        livePositions.forEach(p => {
          const cId = p.commercial_id || p.id;
          if (cId) {
            liveCommercialIds.add(Number(cId));
            const matchedUser = dbUsers.find(u => Number(u.id) === Number(cId));
            merged.push({
              agent_id: Number(cId),
              agent_name: p.commercial_name || matchedUser?.name || 'Commercial',
              agent_phone: p.commercial_phone || matchedUser?.phone || '',
              agent_email: matchedUser?.email || '',
              region: matchedUser?.region || matchedUser?.ville || 'Région Centre',
              latitude: p.latitude,
              longitude: p.longitude,
              captured_at: p.captured_at,
              is_live: true,
              type: 'commercial'
            });
          }
        });

        // Add registered commercials who haven't sent a location yet
        dbUsers.forEach(u => {
          if (!liveCommercialIds.has(Number(u.id))) {
            merged.push({
              agent_id: Number(u.id),
              agent_name: u.name,
              agent_phone: u.phone || '',
              agent_email: u.email || '',
              region: u.region || u.ville || 'Région Centre',
              latitude: null,
              longitude: null,
              captured_at: null,
              is_live: false,
              type: 'commercial'
            });
          }
        });

        setPositions(merged);

        // Check if there is an ID or agent in search params to auto-select
        const queryId = searchParams.get('id') || searchParams.get('agent');
        if (queryId) {
          const target = merged.find(m => String(m.agent_id) === String(queryId));
          if (target) {
            setSelectedAgent(target);
          }
        }

      } else if (fleetType === 'technicians') {
        const [posRes, usersRes] = await Promise.all([
          api.tracking.getAllLastPositions().catch(e => {
            console.error("Tech positions fetch error", e);
            return null;
          }),
          api.users.list('role_id=4').catch(e => {
            console.error("Tech users fetch error", e);
            return null;
          })
        ]);

        let livePositions: any[] = [];
        if (posRes) {
          if (Array.isArray(posRes.positions)) {
            livePositions = posRes.positions;
          } else if (posRes.data && Array.isArray(posRes.data.positions)) {
            livePositions = posRes.data.positions;
          } else if (Array.isArray(posRes.data)) {
            livePositions = posRes.data;
          } else if (Array.isArray(posRes)) {
            livePositions = posRes;
          }
        }

        let dbUsers: any[] = [];
        if (usersRes) {
          if (Array.isArray(usersRes.data)) {
            dbUsers = usersRes.data;
          } else if (Array.isArray(usersRes)) {
            dbUsers = usersRes;
          }
        }

        const merged: any[] = [];
        const liveTechIds = new Set<number>();

        livePositions.forEach(p => {
          const tId = p.technician_id || p.id;
          if (tId) {
            liveTechIds.add(Number(tId));
            const matchedUser = dbUsers.find(u => Number(u.id) === Number(tId));
            merged.push({
              agent_id: Number(tId),
              agent_name: p.technician_name || matchedUser?.name || 'Technicien SAV',
              agent_phone: p.technician_phone || matchedUser?.phone || '',
              agent_email: matchedUser?.email || '',
              region: matchedUser?.region || 'Casablanca',
              latitude: p.latitude,
              longitude: p.longitude,
              captured_at: p.captured_at,
              is_live: true,
              type: 'technician'
            });
          }
        });

        dbUsers.forEach(u => {
          if (!liveTechIds.has(Number(u.id))) {
            merged.push({
              agent_id: Number(u.id),
              agent_name: u.name,
              agent_phone: u.phone || '',
              agent_email: u.email || '',
              region: u.region || 'Casablanca',
              latitude: null,
              longitude: null,
              captured_at: null,
              is_live: false,
              type: 'technician'
            });
          }
        });

        setPositions(merged);

        const queryId = searchParams.get('id') || searchParams.get('agent');
        if (queryId) {
          const target = merged.find(m => String(m.agent_id) === String(queryId));
          if (target) {
            setSelectedAgent(target);
          }
        }
      }
    } catch (e) {
      console.error("Fleet tracking fetch error", e);
    } finally {
      setLoading(false);
    }
  };

  // Fetch trajectory when agent or date changes
  const fetchTrajet = async (agentId: number, date: string) => {
    try {
      let res: any = null;
      if (fleetType === 'commercials') {
        res = await api.commercialTracking.getTrajet(agentId, date);
      } else if (fleetType === 'technicians') {
        res = await api.tracking.getTrajet(agentId, date);
      }

      let points: any[] = [];
      let countVal = -1;
      if (res) {
        if (typeof res.count === 'number') {
          countVal = res.count;
        } else if (res.data && typeof res.data.count === 'number') {
          countVal = res.data.count;
        }

        if (Array.isArray(res.trajet)) {
          points = res.trajet;
        } else if (res.data && Array.isArray(res.data.trajet)) {
          points = res.data.trajet;
        } else if (Array.isArray(res.data)) {
          points = res.data;
        } else if (Array.isArray(res)) {
          points = res;
        }
      }

      setTrajet(points);
      const isCurrentlyInactive = countVal === 0 || points.length === 0;
      setTrajetEmpty(isCurrentlyInactive);
      drawTrajet(points);
    } catch (e) {
      console.error("Trajet fetch error", e);
      setTrajetEmpty(true);
      setTrajet([]);
      drawTrajet([]);
    }
  };

  // Update Markers for Current Positions
  const updateMarkers = (pos: any[], selectedId?: number | null) => {
    if (!mapRef.current) return;

    // Clear old markers
    Object.values(markersRef.current).forEach((m: any) => m.remove());
    markersRef.current = {};

    // Marker styling depending on fleetType
    let iconBg = 'bg-indigo-600';
    let iconClass = 'ti-briefcase';
    let pulseBg = 'bg-emerald-500';
    let roleTitle = 'Commercial Terrain';

    if (fleetType === 'technicians') {
      iconBg = 'bg-blue-600';
      iconClass = 'ti-tool';
      roleTitle = 'Technicien SAV';
    }

    const agentIcon = L.divIcon({
      className: 'custom-fleet-icon',
      html: `
        <div class="relative w-10 h-10 ${iconBg} border-4 border-white rounded-2xl flex items-center justify-center text-white shadow-2xl hover:scale-110 transition-transform cursor-pointer">
          <i class="ti ${iconClass} text-sm"></i>
          <span class="absolute -top-1.5 -right-1.5 w-3.5 h-3.5 ${pulseBg} rounded-full border-2 border-white animate-pulse"></span>
        </div>
      `,
      iconSize: [40, 40],
      iconAnchor: [20, 20]
    });

    const livePositions = pos.filter(p => p.is_live && p.latitude && p.longitude);
    const filteredPos = selectedId ? livePositions.filter(p => p.agent_id === selectedId) : livePositions;

    filteredPos.forEach(p => {
      const lat = typeof p.latitude === 'string' ? parseFloat(p.latitude) : p.latitude;
      const lng = typeof p.longitude === 'string' ? parseFloat(p.longitude) : p.longitude;
      if (isNaN(lat) || isNaN(lng)) return;

      const timeStr = p.captured_at ? new Date(p.captured_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Maintenant';

      const marker = L.marker([lat, lng], { icon: agentIcon })
        .addTo(mapRef.current)
        .bindPopup(`
          <div class="p-3 font-sans w-56 text-slate-800">
            <div class="flex items-center gap-2 mb-2 pb-2 border-b border-slate-100">
              <span class="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse"></span>
              <span class="text-[9px] font-black uppercase tracking-wider text-indigo-600">${roleTitle} En Ligne</span>
            </div>
            <p class="font-black text-slate-900 text-sm mb-0.5">${p.agent_name}</p>
            <p class="text-[11px] font-bold text-slate-500 mb-1 flex items-center gap-1">
              <i class="ti ti-phone text-xs text-indigo-500"></i> ${p.agent_phone || 'Sans téléphone'}
            </p>
            <p class="text-[10px] font-bold text-slate-400 mb-3 flex items-center gap-1">
              <i class="ti ti-clock text-xs"></i> Dernière position: ${timeStr}
            </p>
            <button id="view-route-${p.agent_id}" class="w-full py-2 bg-slate-900 hover:bg-indigo-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-md transition-colors flex items-center justify-center gap-1.5">
              <i class="ti ti-route text-xs"></i> Voir le Trajet du Jour
            </button>
          </div>
        `);

      marker.on('popupopen', () => {
        const btn = document.getElementById(`view-route-${p.agent_id}`);
        if (btn) {
          btn.addEventListener('click', () => {
            const agent = pos.find(item => item.agent_id === p.agent_id);
            if (agent) {
              handleAgentSelect(agent);
            }
            mapRef.current.closePopup();
          });
        }
      });

      markersRef.current[p.agent_id] = marker;
    });

    const activeMarkers = Object.values(markersRef.current);
    if (activeMarkers.length > 0) {
      const group = new L.featureGroup(activeMarkers);
      mapRef.current.fitBounds(group.getBounds().pad(0.2));
    }
  };

  // Draw Route Polyline
  const drawTrajet = (points: any[]) => {
    if (!mapRef.current) return;

    if (polylineRef.current) {
      polylineRef.current.remove();
      polylineRef.current = null;
    }

    trajetMarkersRef.current.forEach((m: any) => m.remove());
    trajetMarkersRef.current = [];

    if (points.length < 2) return;

    const latlngs = points.map(p => {
      const lat = typeof p.latitude === 'string' ? parseFloat(p.latitude) : p.latitude;
      const lng = typeof p.longitude === 'string' ? parseFloat(p.longitude) : p.longitude;
      return [lat, lng];
    }).filter(coord => !isNaN(coord[0]) && !isNaN(coord[1]));

    if (latlngs.length < 2) return;

    let lineColor = '#4f46e5'; // Indigo for commercials
    if (fleetType === 'technicians') lineColor = '#2563eb';

    polylineRef.current = L.polyline(latlngs, {
      color: lineColor,
      weight: 5,
      opacity: 0.9,
      lineJoin: 'round'
    }).addTo(mapRef.current);

    const startPoint = latlngs[0];
    const endPoint = latlngs[latlngs.length - 1];

    const startMarker = L.circleMarker(startPoint, {
      radius: 10,
      color: '#10b981',
      fillColor: '#10b981',
      fillOpacity: 0.9,
      weight: 3,
      opacity: 1
    }).addTo(mapRef.current).bindPopup(`
      <div class="p-2 text-slate-800 font-sans">
        <span class="text-[9px] font-black uppercase text-emerald-600 tracking-wider">Point de Départ</span>
        <p class="text-xs font-bold text-slate-700 mt-1">Début de tournée enregistré</p>
      </div>
    `);

    const endMarker = L.circleMarker(endPoint, {
      radius: 10,
      color: '#ef4444',
      fillColor: '#ef4444',
      fillOpacity: 0.9,
      weight: 3,
      opacity: 1
    }).addTo(mapRef.current).bindPopup(`
      <div class="p-2 text-slate-800 font-sans">
        <span class="text-[9px] font-black uppercase text-rose-600 tracking-wider">Dernière Position Connue</span>
        <p class="text-xs font-bold text-slate-700 mt-1">Coordonnées GPS en temps réel</p>
      </div>
    `);

    trajetMarkersRef.current = [startMarker, endMarker];
    mapRef.current.fitBounds(polylineRef.current.getBounds().pad(0.25));
  };

  const handleAgentSelect = (agent: any) => {
    setSelectedAgent(agent);
    fetchTrajet(agent.agent_id, filterDate);
  };

  const resetTracking = () => {
    setSelectedAgent(null);
    setTrajet([]);
    setTrajetEmpty(false);
    setSearchTerm('');
    if (polylineRef.current) {
      polylineRef.current.remove();
      polylineRef.current = null;
    }
    trajetMarkersRef.current.forEach((m: any) => m.remove());
    trajetMarkersRef.current = [];
    fetchAllPositions();
  };

  const centerMapOnPoint = (latStr: any, lngStr: any, time: string) => {
    const lat = typeof latStr === 'string' ? parseFloat(latStr) : latStr;
    const lng = typeof lngStr === 'string' ? parseFloat(lngStr) : lngStr;
    if (isNaN(lat) || isNaN(lng) || !mapRef.current) return;

    mapRef.current.setView([lat, lng], 17);

    const highlightCircle = L.circleMarker([lat, lng], {
      radius: 20,
      color: '#4f46e5',
      fillColor: '#6366f1',
      fillOpacity: 0.35,
      weight: 2
    }).addTo(mapRef.current);

    setTimeout(() => {
      highlightCircle.remove();
    }, 3500);

    L.popup()
      .setLatLng([lat, lng])
      .setContent(`
        <div class="p-2 font-sans w-48 text-slate-800">
          <div class="flex items-center gap-2 mb-1 border-b border-slate-100 pb-1">
            <span class="w-2 h-2 rounded-full bg-indigo-600 animate-pulse"></span>
            <span class="text-[9px] font-black uppercase tracking-wider text-indigo-600">Point de Passage</span>
          </div>
          <p class="text-xs font-black text-slate-800 mb-0.5">${time}</p>
          <p class="text-[9px] text-slate-400 font-bold uppercase font-mono tracking-wider">Lat: ${lat.toFixed(5)}, Lng: ${lng.toFixed(5)}</p>
        </div>
      `)
      .openOn(mapRef.current);
  };

  // Switch fleet type handler
  const handleFleetChange = (newFleet: 'commercials' | 'technicians') => {
    setFleetType(newFleet);
    setSelectedAgent(null);
    setTrajet([]);
    setTrajetEmpty(false);
    setSearchTerm('');
    setSearchParams({ fleet: newFleet });
    if (polylineRef.current) {
      polylineRef.current.remove();
      polylineRef.current = null;
    }
    trajetMarkersRef.current.forEach((m: any) => m.remove());
    trajetMarkersRef.current = [];
  };

  // Handle storing commercial location (Route::post('commercial-locations'))
  const handleStoreCommercialLocation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!recordCommercialId) {
      setRecordToast({ type: 'error', text: 'Veuillez sélectionner un commercial' });
      return;
    }
    const lat = parseFloat(recordLat);
    const lng = parseFloat(recordLng);
    if (isNaN(lat) || isNaN(lng)) {
      setRecordToast({ type: 'error', text: 'Coordonnées GPS invalides' });
      return;
    }

    setIsRecording(true);
    setRecordToast(null);
    try {
      const res = await api.commercialTracking.storeLocation({
        commercial_id: Number(recordCommercialId),
        latitude: lat,
        longitude: lng
      });

      if (res && res.status !== false) {
        setRecordToast({ type: 'success', text: 'Position GPS du commercial enregistrée avec succès !' });
        // Refresh positions
        await fetchAllPositions();
        // If the recorded commercial is selected, refresh trajectory
        if (selectedAgent && Number(selectedAgent.agent_id) === Number(recordCommercialId)) {
          await fetchTrajet(Number(recordCommercialId), filterDate);
        }
        setTimeout(() => {
          setRecordModalOpen(false);
          setRecordToast(null);
        }, 1200);
      } else {
        setRecordToast({ type: 'error', text: res?.message || 'Erreur lors de l’enregistrement de la position' });
      }
    } catch (err: any) {
      console.error("Store location error", err);
      setRecordToast({ type: 'error', text: err?.message || 'Erreur serveur lors de l’enregistrement GPS' });
    } finally {
      setIsRecording(false);
    }
  };

  // Get current device geolocation
  const handleGetCurrentLocation = () => {
    if (!navigator.geolocation) {
      alert("La géolocalisation n'est pas supportée par votre navigateur.");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setRecordLat(pos.coords.latitude.toFixed(6));
        setRecordLng(pos.coords.longitude.toFixed(6));
        setRecordToast({ type: 'success', text: 'Coordonnées GPS récupérées depuis votre appareil !' });
      },
      (err) => {
        console.error("Geolocation error", err);
        setRecordToast({ type: 'error', text: 'Impossible d’accéder au GPS: ' + err.message });
      },
      { enableHighAccuracy: true }
    );
  };

  // Effects
  useEffect(() => {
    fetchAllPositions();
    const interval = setInterval(fetchAllPositions, 45000); // Live sync every 45s
    return () => clearInterval(interval);
  }, [fleetType]);

  useEffect(() => {
    updateMarkers(positions, selectedAgent ? selectedAgent.agent_id : null);
  }, [positions, selectedAgent, fleetType]);

  useEffect(() => {
    if (selectedAgent) {
      fetchTrajet(selectedAgent.agent_id, filterDate);
    }
  }, [filterDate]);

  // Filter positions
  const filteredPositions = positions.filter(p => {
    const name = p.agent_name || '';
    const phone = p.agent_phone || '';
    const reg = p.region || '';
    return name.toLowerCase().includes(searchTerm.toLowerCase()) ||
           phone.includes(searchTerm) ||
           reg.toLowerCase().includes(searchTerm.toLowerCase());
  });

  const liveCount = positions.filter(p => p.is_live).length;

  return (
    <div className="h-full flex flex-col gap-6 animate-in fade-in duration-500 font-sans">
      
      {/* 1. COMPREHENSIVE RESPONSIVE CONTROL BAR HEADER WITH FLEET SWITCHER */}
      <div className="bg-white p-5 sm:p-7 rounded-[2.5rem] shadow-sm border border-slate-100 flex flex-col gap-5 transition-all">
        
        {/* TOP ROW: Brand Title & Fleet Controls */}
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4">
          
          {/* Title & Brand descriptor */}
          <div className="flex items-center gap-3.5 sm:gap-4 min-w-0">
            <div className={`w-12 h-12 sm:w-14 sm:h-14 rounded-2xl flex items-center justify-center text-white text-xl sm:text-2xl shadow-lg shrink-0 transition-colors ${fleetType === 'commercials' ? 'bg-indigo-600 shadow-indigo-200' : 'bg-blue-600 shadow-blue-200'}`}>
              <i className={`ti ${fleetType === 'commercials' ? 'ti-map-pin' : 'ti-compass'}`}></i>
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-xl sm:text-2xl font-black text-slate-800 tracking-tight leading-none">
                  {fleetType === 'commercials' ? 'Suivi GPS Commerciaux' : 'Tech Fleet Intelligence'}
                </h1>
                <span className={`inline-flex items-center gap-1.5 text-[9px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full ${fleetType === 'commercials' ? 'bg-indigo-50 text-indigo-700 border border-indigo-200' : 'bg-blue-50 text-blue-700 border border-blue-200'}`}>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  Live GPS
                </span>
              </div>
              <p className="text-slate-400 font-bold uppercase text-[9px] sm:text-[10px] tracking-[2px] mt-1 truncate">
                {fleetType === 'commercials' ? 'Géolocalisation en direct & Historique des tournées commerciales' : 'Audit des déplacements et interventions de terrain'}
              </p>
            </div>
          </div>

          {/* Controls Cluster: Fleet Switcher & Quick Actions */}
          <div className="flex flex-wrap items-center gap-2.5 sm:gap-3 w-full xl:w-auto">
            {/* FLEET TYPE SELECTOR TABS (Only shown when not locked to a specific page) */}
            {!lockedFleet && (
              <div className="inline-flex bg-slate-100 p-1.5 rounded-2xl border border-slate-200/80 shadow-inner gap-1">
                <button
                  type="button"
                  onClick={() => handleFleetChange('commercials')}
                  className={`px-3.5 sm:px-4 py-2 sm:py-2.5 rounded-xl font-black text-[10px] sm:text-[11px] uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer ${fleetType === 'commercials' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'}`}
                >
                  <i className="ti ti-briefcase text-sm"></i>
                  <span>Commerciaux</span>
                  <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold ${fleetType === 'commercials' ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-700'}`}>
                    {fleetType === 'commercials' ? liveCount : ''}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => handleFleetChange('technicians')}
                  className={`px-3.5 sm:px-4 py-2 sm:py-2.5 rounded-xl font-black text-[10px] sm:text-[11px] uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer ${fleetType === 'technicians' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'}`}
                >
                  <i className="ti ti-tool text-sm"></i>
                  <span>Techniciens SAV</span>
                  <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold ${fleetType === 'technicians' ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-700'}`}>
                    {fleetType === 'technicians' ? liveCount : ''}
                  </span>
                </button>
              </div>
            )}

            {/* Quick Record Commercial GPS Position Button */}
            {fleetType === 'commercials' && (
              <button
                type="button"
                onClick={() => {
                  if (selectedAgent) {
                    setRecordCommercialId(String(selectedAgent.agent_id));
                  } else if (commercialsList.length > 0) {
                    setRecordCommercialId(String(commercialsList[0].id));
                  }
                  setRecordModalOpen(true);
                }}
                title="Enregistrer un nouveau point GPS pour un commercial"
                className="px-3.5 sm:px-4 py-2.5 sm:py-3 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-2xl font-black text-[10px] uppercase tracking-wider flex items-center gap-2 shadow-xs hover:scale-[1.02] active:scale-95 transition-all cursor-pointer"
              >
                <i className="ti ti-map-pin-plus text-sm"></i>
                <span>Enregistrer Position</span>
              </button>
            )}

            {/* Date filter picker */}
            <div className="bg-slate-50 border border-slate-200 hover:border-indigo-400 rounded-2xl px-3 sm:px-4 py-2 sm:py-2.5 flex items-center gap-2 transition-all">
              <i className="ti ti-calendar text-slate-400 text-sm"></i>
              <input 
                type="date" 
                value={filterDate} 
                onChange={e => setFilterDate(e.target.value)}
                className="bg-transparent border-none outline-none text-[10px] font-black uppercase tracking-wider text-slate-700 cursor-pointer"
              />
            </div>

            {/* Reset map & selection */}
            <button 
              type="button"
              onClick={resetTracking}
              title="Réinitialiser la carte et voir toute la flotte"
              className="px-3.5 sm:px-4 py-2.5 sm:py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl font-black text-[10px] uppercase tracking-wider shadow-md flex items-center gap-2 hover:scale-[1.02] active:scale-95 transition-all cursor-pointer"
            >
              <i className="ti ti-refresh text-xs"></i>
              <span className="hidden sm:inline">Réinitialiser</span>
            </button>
          </div>
        </div>

        {/* BOTTOM ROW: Responsive Fleet Stats & Status */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-4 border-t border-slate-100">
          <div className="bg-slate-50/80 hover:bg-slate-50 p-3.5 rounded-2xl border border-slate-100 flex items-center justify-between gap-3 transition-colors">
            <div className="flex items-center gap-3">
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-base shadow-xs ${fleetType === 'commercials' ? 'bg-indigo-100 text-indigo-700' : 'bg-blue-100 text-blue-700'}`}>
                <i className="ti ti-users"></i>
              </div>
              <div>
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-wider">Flotte Active</p>
                <p className="text-sm font-black text-slate-800">{liveCount} En ligne <span className="text-slate-400 font-semibold text-xs">/ {positions.length} Total</span></p>
              </div>
            </div>
            <span className={`text-[9px] font-black uppercase tracking-wider px-2.5 py-1 rounded-full ${liveCount > 0 ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-slate-200 text-slate-600'}`}>
              {liveCount > 0 ? `${Math.round((liveCount / (positions.length || 1)) * 100)}% Actif` : 'Inactif'}
            </span>
          </div>

          <div className="bg-slate-50/80 hover:bg-slate-50 p-3.5 rounded-2xl border border-slate-100 flex items-center justify-between gap-3 transition-colors">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center text-base shadow-xs">
                <i className="ti ti-activity"></i>
              </div>
              <div>
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-wider">Réseau GPS</p>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                  <span className="text-xs font-black text-slate-700 uppercase tracking-wider text-[10px]">Télémétrie en direct</span>
                </div>
              </div>
            </div>
            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider bg-white px-2.5 py-1 rounded-xl border border-slate-100">
              Auto-sync 15s
            </span>
          </div>

          <div className="bg-slate-50/80 hover:bg-slate-50 p-3.5 rounded-2xl border border-slate-100 flex items-center justify-between gap-3 col-span-1 sm:col-span-2 lg:col-span-1 transition-colors">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-9 h-9 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center text-base shadow-xs shrink-0">
                <i className="ti ti-route"></i>
              </div>
              <div className="min-w-0">
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-wider">Agent Sélectionné</p>
                <p className="text-sm font-black text-slate-800 truncate">
                  {selectedAgent ? selectedAgent.agent_name : 'Tous les agents (Vue Globale)'}
                </p>
              </div>
            </div>
            {selectedAgent && (
              <button 
                type="button"
                onClick={resetTracking} 
                className="text-[9px] font-black text-purple-700 hover:text-purple-900 bg-purple-50 hover:bg-purple-100 px-2.5 py-1 rounded-xl border border-purple-200 transition-colors uppercase tracking-wider shrink-0 cursor-pointer"
              >
                Effacer
              </button>
            )}
          </div>
        </div>

      </div>

      {/* 2. DUAL INTERACTIVE GRID */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-0 pb-6">
         
         {/* THE DYNAMIC LEFT-HAND CONTROL CONSOLE (width: col-span-4) */}
         <div className="lg:col-span-4 flex flex-col bg-white rounded-[2.5rem] border border-slate-100 shadow-xl overflow-hidden min-h-[500px] lg:h-[720px]">
            
            {/* Header / Search Controls */}
            {!selectedAgent ? (
              <div className="p-6 border-b border-slate-100 bg-slate-50/50">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-xs font-black text-slate-400 uppercase tracking-[3px]">
                    {fleetType === 'commercials' ? 'Commerciaux de Terrain' : 'Techniciens SAV'}
                  </h4>
                  <span className={`text-[9px] font-black uppercase tracking-widest px-3 py-1 rounded-full ${fleetType === 'commercials' ? 'bg-indigo-100 text-indigo-700' : 'bg-blue-100 text-blue-700'}`}>
                    {liveCount} En Ligne
                  </span>
                </div>
                
                {/* Search Text Input */}
                <div className="relative">
                  <input
                    type="text"
                    placeholder={`Recherche ${fleetType === 'commercials' ? 'commercial, ville ou tél...' : 'agent, téléphone...'}`}
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    className="w-full bg-white border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded-2xl pl-10 pr-4 py-3 text-xs font-bold text-slate-700 placeholder:text-slate-400 focus:outline-none transition-all"
                  />
                  <i className="ti ti-search absolute left-3.5 top-3.5 text-slate-400 text-sm"></i>
                  {searchTerm && (
                    <button 
                      onClick={() => setSearchTerm('')} 
                      className="absolute right-3.5 top-3.5 text-slate-400 hover:text-slate-600 font-bold"
                    >
                      <i className="ti ti-x"></i>
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className={`p-6 border-b ${fleetType === 'commercials' ? 'border-indigo-100 bg-gradient-to-r from-indigo-50/70 to-purple-50/50' : 'border-blue-100 bg-gradient-to-r from-blue-50/50 to-indigo-50/50'}`}>
                <button
                  onClick={resetTracking}
                  className="mb-4 inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-white border border-slate-200 hover:border-slate-400 text-slate-700 text-[10px] font-black uppercase tracking-wider rounded-xl transition-all shadow-sm group"
                >
                  <i className="ti ti-chevron-left transition-transform group-hover:-translate-x-0.5"></i> Retour à la flotte
                </button>

                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl overflow-hidden shadow-md bg-white border-2 border-white shrink-0">
                    <img 
                      src={`https://ui-avatars.com/api/?name=${encodeURIComponent(selectedAgent.agent_name)}&background=${fleetType === 'commercials' ? '4F46E5' : '2563EB'}&color=fff`} 
                      className="w-full h-full object-cover" 
                      alt="" 
                    />
                  </div>
                  <div className="min-w-0 flex-1">
                    <h5 className="font-black text-slate-800 text-base leading-none mb-1.5 truncate">{selectedAgent.agent_name}</h5>
                    <p className="text-[10px] font-bold text-slate-400 flex items-center gap-1.5 mb-2">
                      <i className="ti ti-phone text-xs text-indigo-500"></i>
                      <a href={`tel:${selectedAgent.agent_phone}`} className="hover:text-indigo-600 transition-colors truncate">
                        {selectedAgent.agent_phone || 'Sans numéro'}
                      </a>
                      {selectedAgent.region && (
                        <span className="text-[9px] px-2 py-0.5 bg-white/80 rounded-md text-slate-600 border border-slate-200">
                          {selectedAgent.region}
                        </span>
                      )}
                    </p>
                    
                    {/* Activity Badge & Distance Metrics */}
                    <div className="flex items-center gap-2 flex-wrap">
                      {trajetEmpty ? (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 bg-rose-100 text-rose-800 text-[9px] font-extrabold uppercase tracking-widest rounded-full shadow-sm">
                          <span className="w-1.5 h-1.5 bg-rose-500 rounded-full"></span>
                          Aucun trajet ce jour
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 bg-emerald-100 text-emerald-800 text-[9px] font-extrabold uppercase tracking-widest rounded-full shadow-sm animate-pulse">
                          <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
                          En Déplacement
                        </span>
                      )}

                      {trajet.length > 0 && (
                        <span className="text-[9px] font-black px-2.5 py-0.5 bg-indigo-100 text-indigo-800 rounded-full border border-indigo-200">
                          {trajectoryDistanceKm} km parcourus
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Content List Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
              
              {!selectedAgent ? (
                // Fleet list perspective
                loading && positions.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-24 gap-4">
                    <div className={`w-10 h-10 border-4 border-slate-100 rounded-full animate-spin ${fleetType === 'commercials' ? 'border-t-indigo-600' : 'border-t-blue-600'}`}></div>
                    <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest animate-pulse">Connexion à la passerelle GPS...</p>
                  </div>
                ) : filteredPositions.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-20 bg-slate-50/50 rounded-3xl p-6 border border-dashed border-slate-200">
                    <div className="w-12 h-12 bg-slate-100 text-slate-400 flex items-center justify-center rounded-2xl text-xl mb-3">
                      <i className="ti ti-user-x"></i>
                    </div>
                    <p className="text-xs font-black uppercase text-slate-500 tracking-wider text-center">Aucun résultat trouvé</p>
                    <p className="text-[10px] text-slate-400 font-bold mt-1 text-center">Vérifiez vos filtres ou tentez une autre date</p>
                  </div>
                ) : (
                  filteredPositions.map(p => {
                    const isSelected = selectedAgent?.agent_id === p.agent_id;
                    const timeStr = p.captured_at ? new Date(p.captured_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : null;

                    return (
                      <div 
                        key={p.agent_id}
                        onClick={() => handleAgentSelect(p)}
                        className={`p-4 rounded-3xl border transition-all text-left flex items-center justify-between gap-4 cursor-pointer group hover:shadow-lg ${isSelected ? 'bg-slate-900 border-slate-900 text-white shadow-xl scale-[1.01]' : 'bg-white border-slate-100 hover:border-slate-300'}`}
                      >
                        <div className="flex items-center gap-3.5 min-w-0">
                          <div className="relative w-11 h-11 rounded-2xl overflow-hidden shadow-inner bg-slate-50 shrink-0 border border-slate-100">
                            <img src={`https://ui-avatars.com/api/?name=${encodeURIComponent(p.agent_name)}&background=${fleetType === 'commercials' ? '4F46E5' : '2563EB'}&color=fff`} className="w-full h-full object-cover" alt="" />
                            {p.is_live && (
                              <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 rounded-full border-2 border-white"></span>
                            )}
                          </div>
                          <div className="min-w-0">
                            <h5 className={`font-extrabold text-sm leading-snug truncate ${isSelected ? 'text-white' : 'text-slate-800 group-hover:text-indigo-600 transition-colors'}`}>
                              {p.agent_name}
                            </h5>
                            <div className="flex items-center gap-2 mt-0.5">
                              {p.is_live ? (
                                <span className={`text-[10px] font-bold uppercase tracking-wider truncate ${isSelected ? 'text-emerald-300' : 'text-emerald-600'}`}>
                                  ● En direct: {timeStr}
                                </span>
                              ) : (
                                <span className={`text-[10px] font-bold uppercase tracking-wider truncate ${isSelected ? 'text-slate-400' : 'text-slate-400'}`}>
                                  Inactif aujourd'hui
                                </span>
                              )}
                              {p.region && (
                                <span className={`text-[9px] px-1.5 py-0.2 rounded font-medium ${isSelected ? 'bg-slate-800 text-slate-300' : 'bg-slate-100 text-slate-500'}`}>
                                  {p.region}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        
                        <div className="shrink-0 flex items-center gap-1.5">
                          {p.is_live && (
                            <span className="w-7 h-7 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-xs" title="Position GPS active">
                              <i className="ti ti-map-pin"></i>
                            </span>
                          )}
                          <span className={`w-8 h-8 rounded-xl border flex items-center justify-center transition-all group-hover:scale-105 ${isSelected ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-100 hover:border-indigo-300 text-slate-400 hover:text-indigo-600'}`}>
                            <i className="ti ti-chevron-right text-sm"></i>
                          </span>
                        </div>
                      </div>
                    );
                  })
                )
              ) : (
                // Timeline / trajectory deep-dive perspective
                <div className="space-y-4">
                  <div className="flex items-center justify-between bg-slate-50 p-4 rounded-2xl border border-slate-100">
                    <div>
                      <span className="text-[9px] font-black uppercase text-slate-400 tracking-wider">Points de passage</span>
                      <p className="text-xs font-black text-slate-800">{trajet.length} relevés GPS</p>
                    </div>
                    {trajet.length > 0 && (
                      <span className="bg-indigo-100 text-indigo-700 text-[9px] font-black uppercase tracking-wider px-3 py-1 rounded-full border border-indigo-200">
                        {trajectoryDistanceKm} km
                      </span>
                    )}
                  </div>

                  {trajetEmpty ? (
                    <div className="flex flex-col items-center justify-center py-16 px-6 bg-slate-50 rounded-3xl border border-dashed border-slate-200">
                      <div className="w-12 h-12 bg-amber-50 rounded-2xl text-amber-500 flex items-center justify-center text-xl mb-3">
                        <i className="ti ti-alert-triangle"></i>
                      </div>
                      <p className="text-xs font-black uppercase text-slate-600 tracking-widest text-center leading-tight">Aucun Relevé Enregistré</p>
                      <p className="text-[10px] text-slate-400 text-center font-bold mt-1 max-w-[200px]">
                        Aucune coordonnée GPS n'a été transmise par l'application pour ce commercial à cette date.
                      </p>
                      {fleetType === 'commercials' && (
                        <button
                          onClick={() => {
                            setRecordCommercialId(String(selectedAgent.agent_id));
                            setRecordModalOpen(true);
                          }}
                          className="mt-4 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-[10px] font-black uppercase tracking-wider shadow-sm flex items-center gap-1.5"
                        >
                          <i className="ti ti-plus"></i> Enregistrer un Point GPS
                        </button>
                      )}
                    </div>
                  ) : (
                    <div className="relative pl-6 space-y-4 border-l-2 border-dashed border-indigo-100 ml-4 py-2">
                      {trajet.map((t, idx) => {
                        const timeStr = new Date(t.captured_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
                        const dateStr = new Date(t.captured_at).toLocaleDateString([], { month: 'short', day: 'numeric' });
                        
                        // Pick colors for starting, ending and mid nodes
                        let badgeColor = 'bg-indigo-500 border-indigo-200';
                        if (idx === 0) badgeColor = 'bg-emerald-500 border-emerald-200 ring-4 ring-emerald-50';
                        if (idx === trajet.length - 1) badgeColor = 'bg-rose-500 border-rose-200 ring-4 ring-rose-50';

                        return (
                          <div 
                            key={t.id || idx}
                            onClick={() => centerMapOnPoint(t.latitude, t.longitude, `${timeStr} (${dateStr})`)}
                            className="relative flex flex-col p-3 rounded-2xl bg-white border border-slate-100 hover:border-indigo-300 hover:shadow-md cursor-pointer transition-all active:scale-[0.99] group"
                          >
                            {/* Dot timeline positioning */}
                            <span className={`absolute -left-[31px] top-4 w-4 h-4 rounded-full border-4 ${badgeColor} transition-all group-hover:scale-125 z-10`}></span>
                            
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-black text-slate-700 group-hover:text-indigo-600 transition-colors">
                                {idx === 0 ? '🚦 Début de Tournée' : (idx === trajet.length - 1 ? '🏁 Dernière Position' : '📍 Point de Passage')}
                              </span>
                              <span className="text-[10px] font-black text-indigo-600 font-mono">
                                {timeStr}
                              </span>
                            </div>

                            <div className="mt-1 flex items-center gap-2 text-[10px] text-slate-400 font-mono font-bold uppercase">
                              <span>Lat: {parseFloat(t.latitude).toFixed(5)}</span>
                              <span>•</span>
                              <span>Lng: {parseFloat(t.longitude).toFixed(5)}</span>
                            </div>
                            
                            <span className="absolute right-4 bottom-2 text-[8px] font-bold text-slate-300 uppercase opacity-0 group-hover:opacity-100 transition-opacity">
                              Cliquer pour centrer
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  )}

                </div>
              )}

            </div>

         </div>

         {/* 3. IMMERSIVE INTERACTIVE MAP SCREEN */}
         <div className="lg:col-span-8 bg-white rounded-[3rem] border-8 border-white shadow-2xl relative overflow-hidden flex flex-col min-h-[500px] lg:h-[720px]">
            <div ref={mapContainer} className="flex-1 w-full bg-slate-50 relative z-10"></div>
            
            {/* FLOATING STATUS HEADS-UP DISPLAY */}
            <div className="absolute top-6 left-6 z-20 flex flex-col sm:flex-row gap-3 pointer-events-none">
                <div className="bg-slate-900/90 text-white backdrop-blur-md px-5 py-3 rounded-full shadow-2xl flex items-center gap-3">
                  <span className="w-2.5 h-2.5 bg-emerald-400 rounded-full animate-pulse flex-shrink-0"></span>
                  <span className="text-[9px] font-black uppercase tracking-widest text-white leading-none">
                    GPS Gateway: Connecté ({fleetType === 'commercials' ? 'Commerciaux' : 'Techniciens SAV'})
                  </span>
                </div>
                {selectedAgent && (
                  <div className="bg-indigo-600/95 text-white backdrop-blur-md px-5 py-3 rounded-full shadow-2xl flex items-center gap-3 animate-in fade-in slide-in-from-left-4 duration-300 font-black">
                    <i className="ti ti-route text-xs"></i>
                    <span className="text-[9px] font-black uppercase tracking-widest leading-none">Trajet: {selectedAgent.agent_name}</span>
                  </div>
                )}
            </div>

            {/* DYNAMIC LEGEND & AUDIT GUIDE */}
            <div className="absolute bottom-6 right-6 z-20 bg-slate-900/90 backdrop-blur-md p-5 rounded-3xl border border-white/10 text-white shadow-2xl max-w-xs pointer-events-none transition-all hidden sm:block">
                <h6 className="text-[8px] font-black uppercase tracking-[3px] text-indigo-400 mb-3.5">LÉGENDE DE NAVIGATION</h6>
                <div className="space-y-3">
                    <div className="flex items-center gap-3">
                        <div className={`w-3.5 h-3.5 rounded-full border-2 border-white flex items-center justify-center ${fleetType === 'commercials' ? 'bg-indigo-600' : 'bg-blue-600'}`}>
                          <i className={`ti ${fleetType === 'commercials' ? 'ti-briefcase' : 'ti-tool'} text-[6px] text-white`}></i>
                        </div>
                        <span className="text-[9px] font-bold uppercase tracking-widest text-slate-300">
                          {fleetType === 'commercials' ? 'Position Commercial Live' : 'Technicien Actif'}
                        </span>
                    </div>
                    <div className="flex items-center gap-3">
                        <div className="w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-white"></div>
                        <span className="text-[9px] font-bold uppercase tracking-widest text-slate-300">Départ du jour</span>
                    </div>
                    <div className="flex items-center gap-3">
                        <div className="w-3.5 h-3.5 bg-rose-500 rounded-full border-2 border-white"></div>
                        <span className="text-[9px] font-bold uppercase tracking-widest text-slate-300">Dernier point enregistré</span>
                    </div>
                    <div className="flex items-center gap-3">
                        <div className="w-5 h-0.5 border-t-2 border-indigo-400"></div>
                        <span className="text-[9px] font-bold uppercase tracking-widest text-slate-300">Itinéraire Parcouru</span>
                    </div>
                </div>
            </div>
         </div>

      </div>

      {/* 4. MODAL: ENREGISTRER UNE POSITION GPS COMMERCIALE (Route::post('commercial-locations')) */}
      {recordModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-[2.5rem] shadow-2xl border border-slate-100 w-full max-w-lg overflow-hidden flex flex-col animate-in zoom-in-95 duration-200">
            
            {/* Modal Header */}
            <div className="p-6 bg-gradient-to-r from-indigo-600 to-purple-600 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-white text-lg">
                  <i className="ti ti-map-pin-plus"></i>
                </div>
                <div>
                  <h3 className="font-black text-lg leading-tight">Enregistrer une Position GPS</h3>
                  <p className="text-[10px] text-indigo-100 font-bold uppercase tracking-wider">
                    Route::post('commercial-locations')
                  </p>
                </div>
              </div>
              <button
                onClick={() => setRecordModalOpen(false)}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors"
              >
                <i className="ti ti-x"></i>
              </button>
            </div>

            {/* Modal Body / Form */}
            <form onSubmit={handleStoreCommercialLocation} className="p-6 space-y-4">
              {recordToast && (
                <div className={`p-3 rounded-2xl text-xs font-bold flex items-center gap-2 ${recordToast.type === 'success' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-rose-50 text-rose-800 border border-rose-200'}`}>
                  <i className={`ti ${recordToast.type === 'success' ? 'ti-check' : 'ti-alert-circle'}`}></i>
                  <span>{recordToast.text}</span>
                </div>
              )}

              {/* Commercial Selection */}
              <div>
                <label className="block text-[10px] font-black uppercase tracking-wider text-slate-500 mb-1.5">
                  Commercial *
                </label>
                <select
                  value={recordCommercialId}
                  onChange={e => setRecordCommercialId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-2xl px-4 py-3 text-xs font-bold text-slate-700 outline-none transition-all"
                  required
                >
                  <option value="">-- Sélectionner un commercial --</option>
                  {commercialsList.map(c => (
                    <option key={c.id} value={c.id}>
                      {c.name} {c.phone ? `(${c.phone})` : ''} {c.region ? `- ${c.region}` : ''}
                    </option>
                  ))}
                </select>
              </div>

              {/* Latitude & Longitude Inputs */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-wider text-slate-500 mb-1.5">
                    Latitude (ex: 33.58988) *
                  </label>
                  <input
                    type="number"
                    step="any"
                    value={recordLat}
                    onChange={e => setRecordLat(e.target.value)}
                    placeholder="33.58988"
                    className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-2xl px-4 py-3 text-xs font-bold text-slate-700 outline-none transition-all font-mono"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-wider text-slate-500 mb-1.5">
                    Longitude (ex: -7.63255) *
                  </label>
                  <input
                    type="number"
                    step="any"
                    value={recordLng}
                    onChange={e => setRecordLng(e.target.value)}
                    placeholder="-7.63255"
                    className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-2xl px-4 py-3 text-xs font-bold text-slate-700 outline-none transition-all font-mono"
                    required
                  />
                </div>
              </div>

              {/* Geolocation Button */}
              <button
                type="button"
                onClick={handleGetCurrentLocation}
                className="w-full py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-2xl text-[10px] font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-colors border border-slate-200"
              >
                <i className="ti ti-current-location text-indigo-600 text-sm"></i>
                <span>Utiliser ma position GPS actuelle</span>
              </button>

              {/* Quick Morocco City Presets */}
              <div>
                <label className="block text-[10px] font-black uppercase tracking-wider text-slate-400 mb-2">
                  Préréglages Villes Médicales Maroc
                </label>
                <div className="grid grid-cols-2 gap-2 max-h-36 overflow-y-auto pr-1">
                  {MOROCCO_PRESETS.map((preset, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setRecordLat(preset.lat.toFixed(5));
                        setRecordLng(preset.lng.toFixed(5));
                      }}
                      className="p-2 text-left bg-slate-50 hover:bg-indigo-50 border border-slate-200 hover:border-indigo-300 rounded-xl transition-all text-[10px]"
                    >
                      <p className="font-black text-slate-800 leading-tight">{preset.city}</p>
                      <p className="text-[8px] text-slate-400 truncate">{preset.desc}</p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex items-center justify-end gap-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setRecordModalOpen(false)}
                  className="px-5 py-3 rounded-2xl text-xs font-bold text-slate-600 hover:bg-slate-100 transition-colors"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  disabled={isRecording}
                  className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-black text-xs uppercase tracking-wider shadow-lg shadow-indigo-200 flex items-center gap-2 hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-50"
                >
                  {isRecording ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Envoi en cours...</span>
                    </>
                  ) : (
                    <>
                      <i className="ti ti-check"></i>
                      <span>Enregistrer Position</span>
                    </>
                  )}
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
}

