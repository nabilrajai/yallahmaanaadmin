import React, { useState, useEffect, useMemo } from 'react';
import { api } from '../api';
import { useApp } from '../App';
import { Promotion, Product, Machine, Category, Brand } from '../types';

export default function AdminPromotions() {
    const { theme } = useApp();
    const [promotions, setPromotions] = useState<Promotion[]>([]);
    const [products, setProducts] = useState<Product[]>([]);
    const [machines, setMachines] = useState<Machine[]>([]);
    const [categories, setCategories] = useState<Category[]>([]);
    const [brands, setBrands] = useState<Brand[]>([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [modal, setModal] = useState<{ type: 'add' | 'edit' | 'delete' | null, item: any }>({ type: null, item: null });
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [targetType, setTargetType] = useState('product');
    const [activeTab, setActiveTab] = useState<'all' | 'code' | 'machine' | 'product' | 'category' | 'brand'>('all');
    const [copiedCode, setCopiedCode] = useState<string | null>(null);

    const fetchData = async () => {
        setLoading(true);
        try {
            const [pRes, prodRes, machRes, catRes, brandRes] = await Promise.all([
                api.promotions.list().catch(() => ({ data: [] })),
                api.products.list('per_page=1000').catch(() => ({ data: [] })),
                api.machines.list('per_page=1000').catch(() => ({ data: [] })),
                api.categories.list('per_page=1000').catch(() => ({ data: [] })),
                api.brands.list('per_page=1000').catch(() => ({ data: [] }))
            ]);

            const promoList = Array.isArray(pRes.data) 
                ? pRes.data 
                : (Array.isArray(pRes.data?.data) ? pRes.data.data : (Array.isArray(pRes) ? pRes : []));
            
            const prodList = Array.isArray(prodRes.data?.data) ? prodRes.data.data : (Array.isArray(prodRes.data) ? prodRes.data : (Array.isArray(prodRes) ? prodRes : []));
            const machList = Array.isArray(machRes.data?.data) ? machRes.data.data : (Array.isArray(machRes.data) ? machRes.data : (Array.isArray(machRes) ? machRes : []));
            const catList = Array.isArray(catRes.data?.data) ? catRes.data.data : (Array.isArray(catRes.data) ? catRes.data : (Array.isArray(catRes) ? catRes : []));
            const brandList = Array.isArray(brandRes.data?.data) ? brandRes.data.data : (Array.isArray(brandRes.data) ? brandRes.data : (Array.isArray(brandRes) ? brandRes : []));

            setPromotions(promoList);
            setProducts(prodList);
            setMachines(machList);
            setCategories(catList);
            setBrands(brandList);
        } catch (e) {
            console.error(e);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => { fetchData(); }, []);

    const handleCopyCode = (code: string) => {
        navigator.clipboard.writeText(code);
        setCopiedCode(code);
        setTimeout(() => setCopiedCode(null), 2000);
    };

    const stats = useMemo(() => {
        const now = new Date();
        return {
            total: promotions.length,
            active: promotions.filter(p => p.is_active && new Date(p.start_date) <= now && new Date(p.end_date) >= now).length,
            scheduled: promotions.filter(p => p.is_active && new Date(p.start_date) > now).length,
            codesAndFidelity: promotions.filter(p => p.code || !p.promotionable_type).length,
            machinePromos: promotions.filter(p => (p.promotionable_type || (p as any).target_type || '').toLowerCase().includes('machine')).length,
        };
    }, [promotions]);

    const getPromotionStatus = (promo: Promotion) => {
        const now = new Date();
        const start = new Date(promo.start_date);
        const end = new Date(promo.end_date);
        if (!promo.is_active) return { label: 'Désactivée', color: 'bg-slate-100 text-slate-500' };
        if (now < start) return { label: 'Programmée', color: 'bg-blue-100 text-blue-600' };
        if (now > end) return { label: 'Expirée', color: 'bg-amber-100 text-amber-600' };
        return { label: 'Active', color: 'bg-emerald-100 text-emerald-600' };
    };

    const getTargetBadge = (promo: Promotion) => {
        const rawType = (promo.promotionable_type || (promo as any).target_type || '').toLowerCase();
        if (rawType.includes('machine')) {
            return { label: 'Machine', bg: 'bg-purple-100 text-purple-700 border-purple-200', icon: 'ti-cpu' };
        }
        if (rawType.includes('product')) {
            return { label: 'Consommable', bg: 'bg-sky-100 text-sky-700 border-sky-200', icon: 'ti-package' };
        }
        if (rawType.includes('category')) {
            return { label: 'Catégorie', bg: 'bg-indigo-100 text-indigo-700 border-indigo-200', icon: 'ti-category' };
        }
        if (rawType.includes('brand')) {
            return { label: 'Marque', bg: 'bg-amber-100 text-amber-700 border-amber-200', icon: 'ti-tag' };
        }
        if (promo.code || !promo.promotionable_type) {
            return { label: 'Code Promo / Fidélité', bg: 'bg-emerald-100 text-emerald-700 border-emerald-200', icon: 'ti-ticket' };
        }
        return { label: 'Article', bg: 'bg-slate-100 text-slate-700 border-slate-200', icon: 'ti-box' };
    };

    const getTargetName = (promo: Promotion) => {
        if (promo.promotionable) {
            const type = promo.promotionable_type ? promo.promotionable_type.split('\\').pop() : 'Cible';
            const name = promo.promotionable.name || (promo.promotionable as any).model || (promo.promotionable as any).reference || `#${promo.promotionable.id}`;
            return `${type}: ${name}`;
        }
        
        const rawType = (promo.promotionable_type || (promo as any).target_type || '').split('\\').pop()?.toLowerCase() || '';
        const targetId = promo.promotionable_id || (promo as any).target_id;
        
        if (rawType.includes('machine')) {
            const found = machines.find(m => m.id === Number(targetId));
            return `Machine: ${found ? (found.name || (found as any).model || found.reference || `#${found.id}`) : `#${targetId}`}`;
        }
        if (rawType.includes('product')) {
            const found = products.find(p => p.id === Number(targetId));
            return `Consommable: ${found ? found.name : `#${targetId}`}`;
        }
        if (rawType.includes('category')) {
            const found = categories.find(c => c.id === Number(targetId));
            return `Catégorie: ${found ? found.name : `#${targetId}`}`;
        }
        if (rawType.includes('brand')) {
            const found = brands.find(b => b.id === Number(targetId));
            return `Marque: ${found ? found.name : `#${targetId}`}`;
        }

        if (promo.description) {
            return promo.description;
        }

        return targetId ? `Cible #${targetId}` : 'Offre Globale / Panier';
    };

    const handleOpenEdit = (promo: Promotion) => {
        let detectedType = 'none';
        const rawType = (promo.promotionable_type || (promo as any).target_type || '').toLowerCase();
        if (rawType.includes('machine')) detectedType = 'machine';
        else if (rawType.includes('product')) detectedType = 'product';
        else if (rawType.includes('category')) detectedType = 'category';
        else if (rawType.includes('brand')) detectedType = 'brand';
        else detectedType = 'none';

        setTargetType(detectedType);
        setModal({ type: 'edit', item: promo });
    };

    const handleSave = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);
        const form = e.target as HTMLFormElement;
        const formData = new FormData(form);
        const data: any = Object.fromEntries(formData.entries());

        if (targetType === 'none') {
            data.target_type = '';
            data.target_id = '';
            data.promotionable_type = '';
            data.promotionable_id = '';
        }

        try {
            if (modal.type === 'add') {
                await api.promotions.create(data);
            } else {
                await api.promotions.update(modal.item.id, data);
            }
            setModal({ type: null, item: null });
            fetchData();
        } catch (e: any) {
            alert(e.message || "Erreur de sauvegarde de la promotion.");
        } finally {
            setIsSubmitting(false);
        }
    };
    
    const handleDelete = async () => {
        if (!modal.item) return;
        setIsSubmitting(true);
        try {
            await api.promotions.delete(modal.item.id);
            setModal({ type: null, item: null });
            fetchData();
        } catch (e) {
            alert("Erreur de suppression.");
        } finally {
            setIsSubmitting(false);
        }
    };

    const targetOptions = useMemo(() => {
        if (targetType === 'product') return products.map(p => ({ id: p.id, name: `📦 ${p.name} ${p.sku ? `(${p.sku})` : ''}` }));
        if (targetType === 'machine') return machines.map(m => ({ id: m.id, name: `⚙️ ${m.name || (m as any).model || m.reference || 'Machine'} ${m.serial_no ? `(S/N: ${m.serial_no})` : ''}` }));
        if (targetType === 'category') return categories.map(c => ({ id: c.id, name: `📁 ${c.name}` }));
        if (targetType === 'brand') return brands.map(b => ({ id: b.id, name: `🏷️ ${b.name}` }));
        return [];
    }, [targetType, products, machines, categories, brands]);

    const filteredPromotions = useMemo(() => {
        return promotions.filter(p => {
            const matchesSearch = 
                (p.name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
                (p.code || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
                (p.description || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
                getTargetName(p).toLowerCase().includes(searchTerm.toLowerCase());

            if (!matchesSearch) return false;

            if (activeTab === 'all') return true;
            if (activeTab === 'code') return !!p.code || !p.promotionable_type;
            
            const rawType = (p.promotionable_type || (p as any).target_type || '').toLowerCase();
            return rawType.includes(activeTab);
        });
    }, [promotions, activeTab, searchTerm, machines, products, categories, brands]);

    return (
        <div className="space-y-8 animate-in fade-in duration-700 pb-20">
            {/* TOP HEADER */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6">
                <div>
                    <h1 className="text-4xl font-black tracking-tight">Promotions & Discounts</h1>
                    <p className="text-slate-400 font-black uppercase text-[10px] tracking-[3px] opacity-60">Gestion des Réductions, Codes Promo & Campagnes (Machines & Consommables)</p>
                </div>
                <button 
                    onClick={() => { setModal({ type: 'add', item: { is_active: 1, promo_type: 'percentage' } }); setTargetType('product'); }}
                    className="bg-blue-600 text-white px-8 py-4 rounded-[1.5rem] font-black shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all flex items-center gap-3 active:scale-95 text-sm"
                >
                    <i className="ti ti-plus text-xl"></i> Créer Promotion
                </button>
            </div>

            {/* KPIS */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <PromoKPI label="Total Campagnes" value={stats.total} icon="ti-ad-2" color="bg-blue-600" />
                <PromoKPI label="Actives en Ce Moment" value={stats.active} icon="ti-flame" color="bg-emerald-600" />
                <PromoKPI label="Codes Promo & Fidélité" value={stats.codesAndFidelity} icon="ti-ticket" color="bg-indigo-600" />
                <PromoKPI label="Promos Machines" value={stats.machinePromos} icon="ti-cpu" color="bg-purple-600" />
            </div>

            {/* SEARCH AND TAB FILTERS */}
            <div className="flex flex-col lg:flex-row justify-between items-stretch lg:items-center gap-4">
                {/* Search Input */}
                <div className="relative flex-1 max-w-md">
                    <i className="ti ti-search absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 text-lg"></i>
                    <input 
                        type="text" 
                        placeholder="Rechercher par nom, code promo, description..." 
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                        className="w-full pl-12 pr-4 py-3 bg-white border border-slate-200/80 rounded-2xl outline-none font-bold text-sm shadow-sm focus:ring-4 focus:ring-blue-500/10 transition-all"
                    />
                </div>

                {/* Target Type Filter Tabs */}
                <div className="flex flex-wrap items-center gap-1.5 bg-slate-100 p-1.5 rounded-2xl border border-slate-200/80 text-xs font-black">
                    <button
                        onClick={() => setActiveTab('all')}
                        className={`px-4 py-2.5 rounded-xl transition-all flex items-center gap-2 ${activeTab === 'all' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}
                    >
                        <i className="ti ti-layout-grid text-sm"></i>
                        Toutes ({promotions.length})
                    </button>
                    <button
                        onClick={() => setActiveTab('code')}
                        className={`px-4 py-2.5 rounded-xl transition-all flex items-center gap-2 ${activeTab === 'code' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-500 hover:text-slate-800'}`}
                    >
                        <i className="ti ti-ticket text-sm"></i>
                        Codes Promo ({stats.codesAndFidelity})
                    </button>
                    <button
                        onClick={() => setActiveTab('machine')}
                        className={`px-4 py-2.5 rounded-xl transition-all flex items-center gap-2 ${activeTab === 'machine' ? 'bg-purple-600 text-white shadow-md' : 'text-slate-500 hover:text-slate-800'}`}
                    >
                        <i className="ti ti-cpu text-sm"></i>
                        Machines ({stats.machinePromos})
                    </button>
                    <button
                        onClick={() => setActiveTab('product')}
                        className={`px-4 py-2.5 rounded-xl transition-all flex items-center gap-2 ${activeTab === 'product' ? 'bg-sky-600 text-white shadow-md' : 'text-slate-500 hover:text-slate-800'}`}
                    >
                        <i className="ti ti-package text-sm"></i>
                        Consommables
                    </button>
                    <button
                        onClick={() => setActiveTab('category')}
                        className={`px-4 py-2.5 rounded-xl transition-all flex items-center gap-2 ${activeTab === 'category' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-500 hover:text-slate-800'}`}
                    >
                        <i className="ti ti-category text-sm"></i>
                        Catégories
                    </button>
                    <button
                        onClick={() => setActiveTab('brand')}
                        className={`px-4 py-2.5 rounded-xl transition-all flex items-center gap-2 ${activeTab === 'brand' ? 'bg-amber-600 text-white shadow-md' : 'text-slate-500 hover:text-slate-800'}`}
                    >
                        <i className="ti ti-tag text-sm"></i>
                        Marques
                    </button>
                </div>
            </div>

            {/* MAIN PROMOTIONS TABLE */}
            <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse min-w-[900px]">
                        <thead className="bg-slate-50/80 border-b border-slate-100">
                            <tr className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                <th className="px-8 py-5">Campagne</th>
                                <th className="px-8 py-5">Code Promo</th>
                                <th className="px-8 py-5">Type de Cible</th>
                                <th className="px-8 py-5">Valeur</th>
                                <th className="px-8 py-5">Cible / Détails</th>
                                <th className="px-8 py-5">Utilisation</th>
                                <th className="px-8 py-5">Validité</th>
                                <th className="px-8 py-5">Statut</th>
                                <th className="px-8 py-5 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 text-sm">
                            {loading ? (
                                <tr>
                                    <td colSpan={9} className="text-center py-16 text-slate-400 font-bold">
                                        <div className="animate-spin h-8 w-8 border-3 border-blue-600 border-t-transparent rounded-full mx-auto mb-3"></div>
                                        Chargement des promotions...
                                    </td>
                                </tr>
                            ) : filteredPromotions.length === 0 ? (
                                <tr>
                                    <td colSpan={9} className="text-center py-16 text-slate-400 font-bold">
                                        Aucune promotion trouvée.
                                    </td>
                                </tr>
                            ) : (
                                filteredPromotions.map((promo) => {
                                    const status = getPromotionStatus(promo);
                                    const targetBadge = getTargetBadge(promo);
                                    const targetName = getTargetName(promo);
                                    const usageLimit = promo.usage_limit;
                                    const usedCount = promo.used_count ?? 0;

                                    return (
                                        <tr key={promo.id} className="hover:bg-slate-50/60 transition-colors group">
                                            {/* Campagne */}
                                            <td className="px-8 py-5">
                                                <div className="font-black text-slate-800 text-sm leading-tight">
                                                    {promo.name}
                                                </div>
                                                {promo.description && (
                                                    <div className="text-xs text-slate-400 font-medium truncate max-w-[200px] mt-0.5">
                                                        {promo.description}
                                                    </div>
                                                )}
                                            </td>

                                            {/* Code Promo */}
                                            <td className="px-8 py-5">
                                                {promo.code ? (
                                                    <div className="flex items-center gap-1.5">
                                                        <code className="bg-slate-100 border border-slate-200 text-slate-800 font-mono font-bold px-2.5 py-1 rounded-xl text-xs tracking-wider shadow-2xs">
                                                            {promo.code}
                                                        </code>
                                                        <button
                                                            onClick={() => handleCopyCode(promo.code!)}
                                                            className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all active:scale-90"
                                                            title="Copier le code promo"
                                                        >
                                                            <i className={`ti ${copiedCode === promo.code ? 'ti-check text-emerald-600 font-bold' : 'ti-copy'} text-sm`}></i>
                                                        </button>
                                                    </div>
                                                ) : (
                                                    <span className="text-slate-300 font-medium text-xs">—</span>
                                                )}
                                            </td>

                                            {/* Type Badge */}
                                            <td className="px-8 py-5">
                                                <span className={`px-3 py-1 rounded-xl text-[10px] font-black border flex items-center gap-1.5 w-fit ${targetBadge.bg}`}>
                                                    <i className={`ti ${targetBadge.icon}`}></i>
                                                    {targetBadge.label}
                                                </span>
                                            </td>

                                            {/* Valeur */}
                                            <td className="px-8 py-5 font-black text-lg text-rose-500">
                                                -{promo.value}{promo.promo_type === 'percentage' ? '%' : ' MAD'}
                                            </td>

                                            {/* Cible / Détails */}
                                            <td className="px-8 py-5 text-xs font-bold text-slate-600 max-w-[220px] truncate" title={targetName}>
                                                {targetName}
                                            </td>

                                            {/* Utilisation */}
                                            <td className="px-8 py-5 text-xs font-bold text-slate-600">
                                                <span className="px-2.5 py-1 bg-slate-100 rounded-lg text-slate-700 font-mono text-[11px]">
                                                    {usedCount} {usageLimit ? `/ ${usageLimit}` : '(Illimité)'}
                                                </span>
                                            </td>

                                            {/* Validité */}
                                            <td className="px-8 py-5 text-xs font-bold text-slate-400">
                                                {new Date(promo.start_date).toLocaleDateString()} → {new Date(promo.end_date).toLocaleDateString()}
                                            </td>

                                            {/* Statut */}
                                            <td className="px-8 py-5">
                                                <span className={`px-3.5 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest ${status.color}`}>{status.label}</span>
                                            </td>

                                            {/* Actions */}
                                            <td className="px-8 py-5 text-right">
                                                <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-all">
                                                    <button onClick={() => handleOpenEdit(promo)} className="p-2.5 bg-blue-50 text-blue-600 rounded-xl hover:bg-blue-600 hover:text-white transition-all shadow-sm" title="Modifier la promotion"><i className="ti ti-edit text-base"></i></button>
                                                    <button onClick={() => setModal({ type: 'delete', item: promo })} className="p-2.5 bg-rose-50 text-rose-600 rounded-xl hover:bg-rose-600 hover:text-white transition-all shadow-sm" title="Supprimer la promotion"><i className="ti ti-trash text-base"></i></button>
                                                </div>
                                            </td>
                                        </tr>
                                    );
                                })
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* MODAL: ADD / EDIT */}
            {(modal.type === 'add' || modal.type === 'edit') && (
                <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[150] flex items-center justify-center p-4">
                    <div className="bg-white w-full max-w-3xl rounded-[3rem] shadow-2xl border-4 border-white flex flex-col max-h-[90vh]">
                        <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                            <div>
                                <h2 className="font-black text-lg uppercase tracking-widest text-slate-800">{modal.type === 'add' ? 'Nouvelle Campagne de Promotion' : 'Modifier la Campagne'}</h2>
                                <p className="text-slate-400 font-bold text-xs mt-0.5">Saisissez les informations de la réduction et le code promo</p>
                            </div>
                            <button onClick={() => setModal({ type: null, item: null })} className="w-10 h-10 bg-white rounded-full text-lg font-light text-slate-400 hover:text-red-500 shadow-md transition-all active:scale-90">×</button>
                        </div>
                        <form onSubmit={handleSave} className="p-10 space-y-6 overflow-y-auto custom-scrollbar">
                            <FormInput name="name" label="Nom de la Campagne" defaultValue={modal.item.name} required placeholder="Ex: Offre de Rentrée, Code Fidélité -10%" />
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <FormInput name="code" label="Code Promo (Optionnel)" defaultValue={modal.item.code} placeholder="Ex: PROMO-HYDRA2026, SPECT-10" />
                                <FormInput name="description" label="Description / Remarques" defaultValue={modal.item.description} placeholder="Ex: Valable sur les machines Hydra" />
                            </div>
                            
                            <div className="grid grid-cols-2 gap-6">
                                <FormSelect name="promo_type" label="Type de Réduction" defaultValue={modal.item.promo_type}>
                                    <option value="percentage">Pourcentage (%)</option>
                                    <option value="fixed_amount">Montant Fixe (MAD)</option>
                                </FormSelect>
                                <FormInput name="value" label="Valeur de la Réduction" type="number" step="0.01" defaultValue={modal.item.value} required placeholder="Ex: 10 ou 1500" />
                            </div>

                            <div className="grid grid-cols-3 gap-6">
                                <FormInput name="start_date" label="Date de Début" type="date" defaultValue={modal.item.start_date?.split(' ')[0] || modal.item.start_date?.split('T')[0]} required />
                                <FormInput name="end_date" label="Date de Fin" type="date" defaultValue={modal.item.end_date?.split(' ')[0] || modal.item.end_date?.split('T')[0]} required />
                                <FormInput name="usage_limit" label="Limite d'utilisations" type="number" min="1" defaultValue={modal.item.usage_limit} placeholder="Optionnel (Ex: 50)" />
                            </div>

                            <h3 className="text-xs font-black uppercase pt-4 border-t text-slate-700 flex items-center gap-2 tracking-wider">
                                <i className="ti ti-target text-blue-600"></i>
                                Ciblage de la Promotion
                            </h3>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <FormSelect name="target_type" label="Type d'Élément Cible" value={targetType} onChange={(e: any) => setTargetType(e.target.value)}>
                                    <option value="product">📦 Consommable Consommable</option>
                                    <option value="machine">⚙️ Machine & Équipement Médical</option>
                                    <option value="category">📁 Catégorie de Consommables</option>
                                    <option value="brand">🏷️ Marque / Constructeur</option>
                                    <option value="none">🎟️ Code Promo Général (Panier / Offre Globale)</option>
                                </FormSelect>

                                {targetType !== 'none' ? (
                                    <FormSelect name="target_id" label="Élément Spécifique" defaultValue={modal.item.promotionable_id || (modal.item as any).target_id}>
                                        <option value="">-- Sélectionner l'élément cible --</option>
                                        {targetOptions.map((opt: any) => <option key={opt.id} value={opt.id}>{opt.name}</option>)}
                                    </FormSelect>
                                ) : (
                                    <div className="flex items-center text-xs font-bold text-slate-400 bg-slate-50 px-4 py-3 rounded-xl border border-slate-100">
                                        Cette promotion s'appliquera globalement à l'aide du code promo.
                                    </div>
                                )}
                            </div>

                            <div className="pt-2">
                                <label className="flex items-center gap-3 cursor-pointer">
                                    <input name="is_active" type="checkbox" defaultChecked={modal.item.is_active ?? true} value="1" className="w-5 h-5 rounded border-slate-300 text-blue-600 focus:ring-blue-500" />
                                    <span className="text-xs font-black uppercase tracking-wider text-slate-700">Activer la campagne immédiatement</span>
                                </label>
                            </div>

                            <button type="submit" disabled={isSubmitting} className="w-full py-4 bg-blue-600 text-white rounded-2xl font-black uppercase tracking-widest hover:bg-blue-700 shadow-xl shadow-blue-500/20 active:scale-95 transition-all text-xs">
                                {isSubmitting ? 'Enregistrement...' : 'Enregistrer la Campagne'}
                            </button>
                        </form>
                    </div>
                </div>
            )}

            {/* MODAL: DELETE */}
            {modal.type === 'delete' && (
                 <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[150] flex items-center justify-center p-4">
                    <div className="bg-white p-8 rounded-3xl shadow-2xl text-center max-w-sm border-4 border-white">
                        <div className="w-14 h-14 bg-rose-50 text-rose-600 rounded-2xl flex items-center justify-center text-2xl mx-auto mb-4">
                            <i className="ti ti-trash"></i>
                        </div>
                        <h3 className="font-black text-lg mb-2 text-slate-800">Supprimer la Promotion ?</h3>
                        <p className="text-xs text-slate-500 mb-6 font-medium">Voulez-vous vraiment supprimer la campagne "{modal.item.name}" ?</p>
                        <div className="flex gap-3">
                            <button onClick={() => setModal({ type: null, item: null })} className="flex-1 py-3 bg-slate-100 rounded-xl font-bold text-xs text-slate-600 hover:bg-slate-200">Annuler</button>
                            <button onClick={handleDelete} disabled={isSubmitting} className="flex-1 py-3 bg-rose-600 text-white rounded-xl font-bold text-xs shadow-md hover:bg-rose-700">Supprimer</button>
                        </div>
                    </div>
                 </div>
            )}
        </div>
    );
}

function PromoKPI({ label, value, icon, color }: any) {
    return (
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex items-center gap-5 group hover:shadow-md transition-all">
            <div className={`w-14 h-14 rounded-2xl ${color} flex items-center justify-center text-white text-2xl shadow-md`}>
                <i className={`ti ${icon}`}></i>
            </div>
            <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-[3px] mb-1">{label}</p>
                <p className="text-2xl font-black text-slate-800 tracking-tighter leading-none">{value}</p>
            </div>
        </div>
    );
}

function FormInput({ label, name, ...props }: any) {
    return (
        <div className="flex flex-col gap-1">
            <label className="text-[10px] font-black uppercase tracking-widest text-slate-500 ml-1">{label}</label>
            <input name={name} {...props} className="px-4 py-3 bg-slate-50 rounded-xl border border-slate-100 outline-none font-bold text-sm focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all" />
        </div>
    );
}

function FormSelect({ label, name, children, ...props }: any) {
    return (
        <div className="flex flex-col gap-1">
            <label className="text-[10px] font-black uppercase tracking-widest text-slate-500 ml-1">{label}</label>
            <select name={name} {...props} className="px-4 py-3 bg-slate-50 rounded-xl border border-slate-100 outline-none font-bold text-sm focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all">
                {children}
            </select>
        </div>
    );
}
