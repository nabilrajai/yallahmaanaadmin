
import React, { useState, useEffect, useMemo } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { api } from '../api';
import { useApp } from '../App';

const QUOTE_STATUS_FLOW = [
  { id: 'draft', label: 'Brouillon', color: 'bg-slate-400', text: 'text-slate-600', bg: 'bg-slate-50', icon: 'ti-file-pencil' },
  { id: 'pending', label: 'En Attente', color: 'bg-blue-500', text: 'text-blue-600', bg: 'bg-blue-50', icon: 'ti-clock-play' },
  { id: 'accepted', label: 'Accepté', color: 'bg-emerald-500', text: 'text-emerald-600', bg: 'bg-emerald-50', icon: 'ti-circle-check' },
  { id: 'rejected', label: 'Rejeté', color: 'bg-rose-500', text: 'text-rose-600', bg: 'bg-rose-50', icon: 'ti-circle-x' },
  { id: 'expired', label: 'Expiré', color: 'bg-amber-500', text: 'text-amber-600', bg: 'bg-amber-50', icon: 'ti-calendar-cancel' }
];

export default function AdminDevis() {
  const { theme, checkPermission, showDenied } = useApp();
  const location = useLocation();
  const navigate = useNavigate();
  const [quotes, setQuotes] = useState<any[]>([]);
  const [clients, setClients] = useState<any[]>([]);
  const [inventory, setInventory] = useState<{ machines: any[], products: any[] }>({ machines: [], products: [] });
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<{ type: 'add' | 'edit' | 'print' | 'config' | 'item_picker' | 'status' | null, item: any }>({ type: null, item: null });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [importedFromOrder, setImportedFromOrder] = useState<string | null>(null);
  
  // View & Filter States
  const [viewMode, setViewMode] = useState<'list' | 'kanban'>('list');
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [dragOverColumn, setDragOverColumn] = useState<string | null>(null);

  // Selection States
  const [pickerType, setPickerType] = useState<'machine' | 'product'>('machine');
  const [pickerSearch, setPickerSearch] = useState('');
  const [clientSearch, setClientSearch] = useState('');

  const [config, setConfig] = useState<any>({
      company_name: 'Specta Medical Solutions',
      company_address: 'Casablanca, Morocco',
      company_email: 'contact@specta.ma',
      company_phone: '+212 5XX XX XX XX',
      quote_prefix: 'DEV-',
      quote_footer: 'Offre valable 30 jours. Garantie et service après-vente Specta inclus.'
  });

  const [formData, setFormData] = useState({
      client_id: '',
      items: [] as any[],
      notes: ''
  });

  const fetchData = async () => {
    setLoading(true);
    try {
      const [qRes, cRes, mRes, pRes, sRes] = await Promise.all([
        api.devis.list(),
        api.clients.list('per_page=1000'),
        api.machines.list(),
        api.products.list('per_page=1000'),
        api.request('/settings')
      ]);
      
      setQuotes(Array.isArray(qRes) ? qRes : (qRes.data || []));
      setClients(cRes.data || cRes || []);
      setInventory({
          machines: mRes.data || mRes || [],
          products: pRes.data?.data || pRes.data || []
      });

      const settingsMap: any = {};
      const settingsArray = Array.isArray(sRes.data) ? sRes.data : (Array.isArray(sRes) ? sRes : []);
      settingsArray.forEach((s: any) => settingsMap[s.key] = s.value);
      setConfig(prev => ({ ...prev, ...settingsMap }));
      
    } catch (e) { console.error(e); } finally { setLoading(false); }
  };

  useEffect(() => { fetchData(); }, []);

  // Handle prefill from "Demande Devis" order
  useEffect(() => {
    let prefill: any = (location.state as any)?.prefillDevis;
    if (!prefill) {
      try {
        const stored = sessionStorage.getItem('specta_prefill_devis');
        if (stored) {
          prefill = JSON.parse(stored);
        }
      } catch (e) {
        console.warn(e);
      }
    }

    if (prefill) {
      try {
        sessionStorage.removeItem('specta_prefill_devis');
      } catch (e) {}
      window.history.replaceState({}, document.title);

      if (prefill.client) {
        setClients(prev => {
          if (!prev.some(c => c.id.toString() === prefill.client.id.toString())) {
            return [prefill.client, ...prev];
          }
          return prev;
        });
      }

      setFormData({
        client_id: String(prefill.client_id || ''),
        items: Array.isArray(prefill.items) ? prefill.items : [],
        notes: prefill.notes || ''
      });

      if (prefill.sourceOrderNumber) {
        setImportedFromOrder(prefill.sourceOrderNumber);
      }

      setModal({ type: 'add', item: null });
    }
  }, [location.state]);

  // Synchronize machine catalog prices and details if inventory is loaded
  useEffect(() => {
    if (inventory.machines && inventory.machines.length > 0 && formData.items.length > 0) {
      setFormData(prev => {
        let changed = false;
        const updatedItems = prev.items.map(item => {
          if (item.type === 'machine') {
            const match = inventory.machines.find((m: any) => 
              String(m.id) === String(item.id) || 
              (m.name && item.name && m.name.toLowerCase().trim() === item.name.toLowerCase().trim())
            );
            if (match) {
              const catalogPrice = parseFloat(match.price_ht) || 0;
              const minPrice = parseFloat(match.min_price_ht) || 0;
              const newPrice = item.unit_price > 0 ? item.unit_price : catalogPrice;
              const newMinPrice = item.min_price_ht > 0 ? item.min_price_ht : minPrice;
              const newImg = item.image_url || match.image_url;
              if (newPrice !== item.unit_price || newMinPrice !== item.min_price_ht || (newImg && newImg !== item.image_url)) {
                changed = true;
                return {
                  ...item,
                  id: match.id,
                  unit_price: newPrice,
                  min_price_ht: newMinPrice,
                  image_url: newImg || item.image_url
                };
              }
            }
          }
          return item;
        });
        return changed ? { ...prev, items: updatedItems } : prev;
      });
    }
  }, [inventory.machines]);

  const filteredQuotes = useMemo(() => {
    return quotes.filter(q => {
        const searchLower = searchTerm.toLowerCase();
        const matchesSearch = 
            q.quote_number?.toLowerCase().includes(searchLower) ||
            q.client?.name?.toLowerCase().includes(searchLower);
        const matchesStatus = statusFilter === 'all' || q.status === statusFilter;
        return matchesSearch && matchesStatus;
    });
  }, [quotes, searchTerm, statusFilter]);

  const selectedClient = useMemo(() => {
      return clients.find(c => c.id.toString() === formData.client_id);
  }, [formData.client_id, clients]);

  const handleUpdateStatus = async (id: number, status: string) => {
    if (!checkPermission('devis', 'edit')) return showDenied("Modifier Statut");
    setIsSubmitting(true);
    try {
        await api.devis.updateStatus(id, status);
        fetchData();
        if (modal.item?.id === id) setModal({ ...modal, item: { ...modal.item, status } });
    } catch (e) {
        alert("Erreur lors de la mise à jour du statut. Vérifiez l'API.");
    } finally {
        setIsSubmitting(false);
    }
  };

  // Drag and Drop Logic
  const onDragStart = (e: React.DragEvent, quoteId: number) => {
    e.dataTransfer.setData('quoteId', quoteId.toString());
    e.dataTransfer.effectAllowed = 'move';
  };

  const onDragOver = (e: React.DragEvent, statusId: string) => {
    e.preventDefault();
    if (dragOverColumn !== statusId) setDragOverColumn(statusId);
  };

  const onDrop = async (e: React.DragEvent, targetStatus: string) => {
    e.preventDefault();
    setDragOverColumn(null);
    const quoteId = e.dataTransfer.getData('quoteId');
    if (!quoteId) return;

    const quote = quotes.find(q => q.id === parseInt(quoteId));
    if (quote && quote.status !== targetStatus) {
      handleUpdateStatus(parseInt(quoteId), targetStatus);
    }
  };

  const getFullImageUrl = (path: string) => {
    if (!path) return 'https://placehold.co/200x200?text=BIO';
    if (path.startsWith('http')) return path;
    return `https://birdeye-intelligence.ma/Spetcapp/Backend/storage/app/public/${path}`;
  };

  const handleAddItem = (item: any, type: 'machine' | 'product') => {
    setFormData(prev => ({
        ...prev,
        items: [...prev.items, { 
            id: item.id,
            type,
            name: item.name, 
            image_url: item.image_url,
            unit_price: parseFloat(item.price_ht) || 0,
            min_price_ht: parseFloat(item.min_price_ht) || 0, 
            quantity: 1,
            tax_rate: 20,
            discount_type: 'percent',
            discount_value: 0
        }]
    }));
    setModal(prev => ({ ...prev, type: modal.item ? 'edit' : 'add' }));
  };

  const calculateLineTotal = (item: any) => {
      const base = (parseFloat(item.unit_price) || 0) * (parseInt(item.quantity) || 1);
      let discount = 0;
      if (item.discount_type === 'percent') {
          discount = base * ((parseFloat(item.discount_value) || 0) / 100);
      } else {
          discount = (parseFloat(item.discount_value) || 0);
      }
      return Math.max(0, base - discount);
  };

  const calculateTotals = (items: any[]) => {
      let total_ht = 0;
      let total_tva = 0;
      items.forEach(i => {
          const line_ht = calculateLineTotal(i);
          const tva = line_ht * ((parseFloat(i.tax_rate) || 0) / 100);
          total_ht += line_ht;
          total_tva += tva;
      });
      return { ht: total_ht, tva: total_tva, ttc: total_ht + total_tva };
  };

  const handleSaveQuote = async () => {
    if (!formData.client_id || formData.items.length === 0) {
        alert("Veuillez sélectionner un client et au moins un article.");
        return;
    }

    const violations = formData.items.filter(i => {
        const lineTotalHT = calculateLineTotal(i);
        const unitPriceAfterDiscount = lineTotalHT / (parseInt(i.quantity) || 1);
        const floorPrice = parseFloat(i.min_price_ht || 0);
        return i.type === 'machine' && unitPriceAfterDiscount < floorPrice;
    });

    if (violations.length > 0) {
        const details = violations.map(v => `- ${v.name}: Final Net HT ${ (calculateLineTotal(v) / v.quantity).toFixed(2) } MAD (Plancher: ${v.min_price_ht} MAD)`).join('\n');
        alert(`ALERTE PRIX PLANCHER:\n\n${details}\n\nLe devis ne peut être synchronisé tant que les prix sont inférieurs au seuil contractuel.`);
        return;
    }

    setIsSubmitting(true);
    const totals = calculateTotals(formData.items);
    
    const payload = {
        client_id: formData.client_id,
        items: formData.items.map(i => ({
            [i.type === 'machine' ? 'machine_id' : 'product_id']: i.id,
            quantity: i.quantity,
            unit_price: i.unit_price,
            tax_rate: i.tax_rate,
            discount_type: i.discount_type,
            discount_value: i.discount_value,
            total_price: calculateLineTotal(i)
        })),
        notes: formData.notes,
        total_ht: totals.ht,
        total_tva: totals.tva,
        total_ttc: totals.ttc,
        status: modal.item?.status || 'draft'
    };

    try {
        if (modal.type === 'add') await api.devis.create(payload);
        else await api.devis.update(modal.item.id, payload);
        setModal({ type: null, item: null });
        fetchData();
    } catch (e) { 
        alert("Erreur critique lors de la synchronisation cloud."); 
    } finally { 
        setIsSubmitting(false); 
    }
  };

  const openEditModal = (q: any) => {
      setFormData({ 
          client_id: q.client_id.toString(), 
          notes: q.notes || '', 
          items: q.items?.map((i: any) => {
              const baseItem = i.machine || i.product;
              return { 
                id: i.machine_id || i.product_id, 
                type: i.machine_id ? 'machine' : 'product', 
                name: baseItem?.name || 'Article', 
                image_url: baseItem?.image_url,
                unit_price: parseFloat(i.unit_price), 
                min_price_ht: baseItem?.min_price_ht || 0,
                quantity: i.quantity,
                tax_rate: parseFloat(i.tax_rate || 20),
                discount_type: i.discount_type || 'percent',
                discount_value: parseFloat(i.discount_value || 0)
              };
          }) || []
      });
      setModal({ type: 'edit', item: q });
  };

  const filteredItemsForPicker = useMemo(() => {
      const source = pickerType === 'machine' ? inventory.machines : inventory.products;
      return source.filter(i => i.name.toLowerCase().includes(pickerSearch.toLowerCase()));
  }, [pickerType, pickerSearch, inventory]);

  return (
    <div className="space-y-8 pb-20 animate-in fade-in duration-700 no-print">
      {/* HUD DASHBOARD */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <QuoteKPI label="Volume Pipeline" value={quotes.length} icon="ti-file-stack" color="bg-blue-600" />
          <QuoteKPI label="Valeur Totale (TTC)" value={`${quotes.reduce((acc, q) => acc + parseFloat(q.total_ttc || 0), 0).toLocaleString()} MAD`} icon="ti-chart-line" color="bg-emerald-600" />
          <QuoteKPI label="Taux de Closing" value="68%" icon="ti-target-arrow" color="bg-rose-500" />
          <QuoteKPI label="Clients Cibles" value={clients.length} icon="ti-building-hospital" color="bg-indigo-600" />
      </div>

      {/* HEADER SECTION */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-8 bg-white p-10 rounded-[4rem] shadow-sm border border-slate-100">
        <div>
          <h1 className="text-5xl font-black text-slate-800 tracking-tighter mb-1">Quote Command Center</h1>
          <p className="text-slate-400 font-black uppercase text-[10px] tracking-[4px] opacity-70 italic">Gestion Intelligente du Cycle de Vente</p>
        </div>
        <div className="flex flex-wrap gap-4 items-center">
            <div className="flex bg-slate-100 p-1.5 rounded-[2rem] border border-slate-100 shadow-inner">
                <button onClick={() => setViewMode('list')} className={`px-6 py-2.5 rounded-[1.75rem] text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'list' ? 'bg-white text-blue-600 shadow-lg' : 'text-slate-400 hover:text-slate-600'}`}>
                  <i className="ti ti-list text-sm mr-2"></i> Liste
                </button>
                <button onClick={() => setViewMode('kanban')} className={`px-6 py-2.5 rounded-[1.75rem] text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'kanban' ? 'bg-white text-blue-600 shadow-lg' : 'text-slate-400 hover:text-slate-600'}`}>
                  <i className="ti ti-layout-kanban text-sm mr-2"></i> Kanban
                </button>
            </div>
            <button onClick={() => setModal({ type: 'config', item: null })} className="w-14 h-14 bg-slate-50 text-slate-400 rounded-full flex items-center justify-center border border-slate-100 shadow-sm active:scale-90"><i className="ti ti-settings text-xl"></i></button>
            <button 
              onClick={() => { setFormData({ client_id: '', items: [], notes: '' }); setModal({ type: 'add', item: null }); }}
              className="bg-blue-600 text-white px-10 py-5 rounded-[2rem] font-black shadow-2xl shadow-blue-100 hover:bg-blue-700 transition-all flex items-center gap-3 active:scale-95"
            >
              <i className="ti ti-plus text-xl"></i> Nouveau Devis
            </button>
        </div>
      </div>

      {/* FILTER BAR */}
      <div className="bg-white p-6 rounded-[3rem] shadow-sm border border-slate-100 flex flex-col lg:flex-row gap-6 items-center">
          <div className="flex-1 relative w-full group">
              <i className="ti ti-search absolute left-6 top-1/2 -translate-y-1/2 text-blue-600 text-xl group-focus-within:scale-110 transition-transform"></i>
              <input 
                type="text" 
                placeholder="Chercher par n° de devis ou client..." 
                className="w-full pl-16 pr-8 py-5 bg-slate-50 border-none rounded-[2rem] outline-none font-bold text-sm shadow-inner" 
                value={searchTerm} 
                onChange={e => setSearchTerm(e.target.value)} 
              />
          </div>
          <div className="flex gap-4 w-full lg:w-auto overflow-x-auto no-scrollbar pb-2 lg:pb-0">
                <button onClick={() => setStatusFilter('all')} className={`px-6 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest whitespace-nowrap transition-all ${statusFilter === 'all' ? 'bg-slate-900 text-white shadow-xl' : 'bg-slate-50 text-slate-400 hover:bg-slate-100'}`}>Tous ({quotes.length})</button>
                {QUOTE_STATUS_FLOW.map(s => (
                    <button key={s.id} onClick={() => setStatusFilter(s.id)} className={`px-6 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest whitespace-nowrap transition-all flex items-center gap-2 ${statusFilter === s.id ? `${s.color} text-white shadow-xl` : 'bg-slate-50 text-slate-400 hover:bg-slate-100'}`}>
                        <i className={`ti ${s.icon}`}></i> {s.label} ({quotes.filter(q => q.status === s.id).length})
                    </button>
                ))}
          </div>
          <button onClick={fetchData} className="w-14 h-14 bg-white text-slate-400 hover:text-blue-600 rounded-full flex items-center justify-center border border-slate-100 shadow-sm active:scale-90 shrink-0"><i className="ti ti-refresh text-xl"></i></button>
      </div>

      {/* MAIN VIEWPORT */}
      {loading ? (
        <div className="py-40 text-center space-y-4">
            <div className="animate-spin h-14 w-14 border-t-4 border-blue-600 rounded-full mx-auto"></div>
            <p className="text-[10px] font-black uppercase tracking-[5px] text-slate-400">Syncing Commercial Node...</p>
        </div>
      ) : viewMode === 'kanban' ? (
        <div className="flex gap-6 overflow-x-auto pb-10 custom-scrollbar min-h-[700px]">
            {QUOTE_STATUS_FLOW.map(col => {
                const colQuotes = filteredQuotes.filter(q => (q.status || 'draft') === col.id);
                const isOver = dragOverColumn === col.id;
                return (
                    <div 
                        key={col.id} 
                        onDragOver={(e) => onDragOver(e, col.id)}
                        onDragLeave={() => setDragOverColumn(null)}
                        onDrop={(e) => onDrop(e, col.id)}
                        className={`w-85 min-w-[340px] rounded-[3.5rem] p-6 flex flex-col gap-6 border transition-all duration-300 shrink-0 ${isOver ? 'bg-blue-50 border-blue-300 shadow-inner scale-[1.01]' : 'bg-slate-100/40 border-slate-200/50'}`}
                    >
                        <div className="flex items-center justify-between px-4">
                            <div className="flex items-center gap-3">
                                <div className={`w-3 h-3 rounded-full ${col.color}`}></div>
                                <h3 className="text-[11px] font-black uppercase tracking-[3px] text-slate-500">{col.label}</h3>
                            </div>
                            <span className="bg-white px-3 py-1 rounded-full text-[10px] font-black shadow-sm text-slate-400">
                                {colQuotes.length}
                            </span>
                        </div>

                        <div className="flex-1 space-y-5 overflow-y-auto pr-1 custom-scrollbar">
                            {colQuotes.map(quote => (
                                <div 
                                    key={quote.id} 
                                    draggable="true"
                                    onDragStart={(e) => onDragStart(e, quote.id)}
                                    className="bg-white p-6 rounded-[2.5rem] shadow-sm border border-slate-200 hover:border-blue-400 hover:shadow-xl hover:-translate-y-1 transition-all cursor-grab active:cursor-grabbing group relative"
                                >
                                    <div className="flex justify-between items-start mb-4">
                                        <span className="text-[10px] font-black text-blue-600 bg-blue-50 px-3 py-1 rounded-full border border-blue-100">#{quote.quote_number}</span>
                                        <p className="text-[9px] font-black text-slate-300 uppercase">{new Date(quote.created_at).toLocaleDateString()}</p>
                                    </div>
                                    <h4 className="font-black text-slate-800 text-base leading-tight mb-2 uppercase line-clamp-1">{quote.client?.name}</h4>
                                    <p className="text-[10px] font-bold text-slate-400 mb-6 flex items-center gap-1 uppercase"><i className="ti ti-map-pin"></i> {quote.client?.city}</p>
                                    
                                    <div className="flex justify-between items-end pt-4 border-t border-slate-50">
                                        <div>
                                            <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Total TTC</p>
                                            <p className="text-xl font-black text-slate-700 tracking-tighter">
                                                {parseFloat(quote.total_ttc || 0).toLocaleString()} <span className="text-[10px] opacity-40">MAD</span>
                                            </p>
                                        </div>
                                        <div className="flex gap-2">
                                            <button onClick={() => setModal({ type: 'print', item: quote })} className="w-10 h-10 rounded-xl bg-slate-50 text-slate-400 hover:bg-blue-600 hover:text-white transition-all flex items-center justify-center"><i className="ti ti-printer"></i></button>
                                            <button onClick={() => openEditModal(quote)} className="w-10 h-10 rounded-xl bg-slate-50 text-slate-400 hover:bg-slate-900 hover:text-white transition-all flex items-center justify-center"><i className="ti ti-edit"></i></button>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                );
            })}
        </div>
      ) : (
        <div className="bg-white rounded-[4rem] border border-slate-100 overflow-hidden shadow-sm">
            <table className="w-full text-left">
            <thead className="bg-slate-50/80 sticky top-0 z-10 backdrop-blur-md border-b">
                <tr className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                <th className="px-10 py-8">Référence</th>
                <th className="px-10 py-8">Client Destinataire</th>
                <th className="px-10 py-8">Statut Workflow</th>
                <th className="px-10 py-8 text-right">Net TTC</th>
                <th className="px-10 py-8 text-right">Actions</th>
                </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
                {filteredQuotes.map(q => (
                <tr key={q.id} className="hover:bg-slate-50/50 transition-all group">
                    <td className="px-10 py-8 font-black text-blue-600 text-lg">#{q.quote_number}</td>
                    <td className="px-10 py-8">
                        <p className="font-black text-slate-800 text-base uppercase">{q.client?.name}</p>
                        <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{new Date(q.created_at).toLocaleDateString()} • {q.client?.city}</p>
                    </td>
                    <td className="px-10 py-8">
                        <div className="relative inline-block group/status">
                            <button 
                                onClick={() => setModal({ type: 'status', item: q })}
                                className={`px-4 py-2 rounded-full text-[9px] font-black uppercase tracking-widest flex items-center gap-2 border shadow-sm transition-all hover:scale-105 active:scale-95 ${QUOTE_STATUS_FLOW.find(s => s.id === (q.status || 'draft'))?.bg} ${QUOTE_STATUS_FLOW.find(s => s.id === (q.status || 'draft'))?.text} border-transparent hover:border-current`}
                            >
                                <i className={`ti ${QUOTE_STATUS_FLOW.find(s => s.id === (q.status || 'draft'))?.icon}`}></i>
                                {QUOTE_STATUS_FLOW.find(s => s.id === (q.status || 'draft'))?.label || 'Brouillon'}
                            </button>
                        </div>
                    </td>
                    <td className="px-10 py-8 text-right font-black text-slate-700 text-lg">{parseFloat(q.total_ttc || 0).toLocaleString()} <span className="text-xs opacity-30 uppercase ml-1">MAD</span></td>
                    <td className="px-10 py-8 text-right">
                        <div className="flex justify-end gap-3 opacity-0 group-hover:opacity-100 transition-all translate-x-4 group-hover:translate-x-0">
                            <TooltipButton onClick={() => setModal({ type: 'print', item: q })} icon="ti-file-download" color="bg-emerald-50 text-emerald-600" tooltip="Télécharger / Imprimer PDF" />
                            <TooltipButton onClick={() => openEditModal(q)} icon="ti-edit" color="bg-slate-50 text-slate-600" tooltip="Modifier l'offre" />
                            <TooltipButton onClick={async () => { if(confirm("Supprimer ce devis ?")) { await api.devis.delete(q.id); fetchData(); } }} icon="ti-trash" color="bg-rose-50 text-rose-500" tooltip="Supprimer" />
                        </div>
                    </td>
                </tr>
                ))}
            </tbody>
            </table>
        </div>
      )}

      {/* STATUS UPDATE MODAL */}
      {modal.type === 'status' && modal.item && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[200] flex items-center justify-center p-4">
              <div className="bg-white rounded-[4rem] shadow-2xl p-12 text-center max-w-lg w-full animate-in zoom-in-95 border-4 border-white">
                  <h3 className="text-2xl font-black text-slate-800 mb-2 uppercase text-[10px] tracking-[4px]">Cycle de Vie Commercial</h3>
                  <p className="text-slate-400 font-bold mb-10 text-sm italic">Mettre à jour l'état du devis #{modal.item.quote_number}</p>
                  <div className="grid grid-cols-1 gap-4">
                      {QUOTE_STATUS_FLOW.map(s => (
                          <button 
                            key={s.id} 
                            onClick={() => { handleUpdateStatus(modal.item.id, s.id); setModal({ type: null, item: null }); }}
                            className={`w-full p-6 rounded-[2.5rem] border-2 transition-all flex items-center justify-between group ${modal.item.status === s.id ? 'bg-slate-900 border-slate-900 text-white shadow-2xl' : 'bg-white border-slate-100 hover:border-blue-400'}`}
                          >
                              <div className="flex items-center gap-4">
                                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-xl ${modal.item.status === s.id ? 'bg-white/10 text-white' : `${s.bg} ${s.text}`}`}>
                                      <i className={`ti ${s.icon}`}></i>
                                  </div>
                                  <span className="font-black uppercase text-xs tracking-widest">{s.label}</span>
                              </div>
                              {modal.item.status === s.id && <i className="ti ti-check text-emerald-400 text-2xl"></i>}
                          </button>
                      ))}
                  </div>
                  <button onClick={() => setModal({ type: null, item: null })} className="mt-10 px-10 py-4 bg-slate-50 text-slate-400 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-slate-100">Fermer</button>
              </div>
          </div>
      )}

      {/* CREATE / EDIT MODAL - Same as before but with status sync */}
      {(modal.type === 'add' || modal.type === 'edit') && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-md z-[150] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-[95vw] rounded-[4rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 border-4 border-white flex flex-col max-h-[95vh]">
            <div className="p-10 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
               <div className="flex items-center gap-6">
                  <div className="w-16 h-16 bg-blue-600 text-white rounded-3xl flex items-center justify-center text-3xl shadow-2xl shadow-blue-100">
                    <i className="ti ti-file-certificate"></i>
                  </div>
                  <div>
                    <h2 className="text-3xl font-black text-slate-800 tracking-tighter leading-none mb-1">Éditeur d'Offre Commerciale</h2>
                    <p className="text-[10px] font-black text-blue-500 uppercase tracking-[4px]">Validation Prix Plancher & Intelligence Remise</p>
                  </div>
               </div>
               <button onClick={() => setModal({ type: null, item: null })} className="w-16 h-16 flex items-center justify-center bg-white rounded-full text-slate-300 hover:text-red-500 shadow-xl transition-all text-3xl font-light hover:rotate-90">×</button>
            </div>
            
            <div className="flex-1 flex flex-col lg:flex-row overflow-hidden bg-slate-50/30">
                <div className="flex-1 p-10 lg:p-14 overflow-y-auto custom-scrollbar space-y-12">
                    {importedFromOrder && (
                        <div className="bg-gradient-to-r from-amber-50 to-amber-100/60 border-2 border-amber-200 rounded-[2.5rem] p-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-amber-900 shadow-sm animate-in fade-in">
                            <div className="flex items-center gap-4">
                                <div className="w-12 h-12 rounded-2xl bg-amber-500 text-white flex items-center justify-center text-2xl shadow-md shrink-0">
                                    <i className="ti ti-file-invoice"></i>
                                </div>
                                <div>
                                    <p className="font-black text-xs uppercase tracking-wider flex items-center gap-2 text-amber-950">
                                        Pré-rempli depuis la demande de devis #{importedFromOrder}
                                    </p>
                                    <p className="text-[11px] text-amber-800 font-medium mt-0.5">
                                        Client et équipement sélectionnés automatiquement. Vous pouvez ajuster le prix unitaire ci-dessous puis valider avec « Créer & Ajouter Devis ».
                                    </p>
                                </div>
                            </div>
                            <button 
                                type="button"
                                onClick={() => setImportedFromOrder(null)}
                                className="px-4 py-2 bg-white text-amber-900 border border-amber-200 rounded-xl text-[10px] font-black uppercase tracking-wider hover:bg-amber-50 transition-colors shrink-0"
                            >
                                Masquer
                            </button>
                        </div>
                    )}

                    {/* CLIENT SELECTION */}
                    <section className="space-y-6">
                        <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-[5px] border-b pb-4 mb-8">1. Identification du Bénéficiaire</h4>
                        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                            <div className="lg:col-span-5 relative group">
                                <i className="ti ti-search absolute left-6 top-1/2 -translate-y-1/2 text-blue-600 text-xl group-focus-within:scale-110 transition-transform"></i>
                                <input 
                                    type="text" 
                                    placeholder="Chercher Client par Nom ou Code..." 
                                    className="w-full pl-16 pr-8 py-6 bg-white border-2 border-slate-100 rounded-[2rem] outline-none font-black text-lg shadow-sm focus:border-blue-500 transition-all"
                                    value={clientSearch}
                                    onChange={e => setClientSearch(e.target.value)}
                                />
                                {clientSearch && (
                                    <div className="absolute top-full left-0 right-0 mt-4 bg-white rounded-[2rem] shadow-2xl border border-slate-100 z-50 max-h-64 overflow-y-auto p-4 custom-scrollbar">
                                        {clients.filter(c => c.name.toLowerCase().includes(clientSearch.toLowerCase())).map(c => (
                                            <button key={c.id} onClick={() => { setFormData({...formData, client_id: c.id.toString()}); setClientSearch(''); }} className="w-full p-4 hover:bg-blue-50 rounded-2xl flex items-center gap-4 text-left transition-colors">
                                                <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center font-black text-blue-600 uppercase text-xs">{c.name.charAt(0)}</div>
                                                <div>
                                                    <p className="font-black text-slate-800 text-sm leading-none mb-1">{c.name}</p>
                                                    <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{c.city} • {c.code}</p>
                                                </div>
                                            </button>
                                        ))}
                                    </div>
                                )}
                            </div>
                            
                            {selectedClient && (
                                <div className="lg:col-span-7 flex items-center gap-6 p-6 bg-white border-2 border-blue-100 rounded-[2.5rem] shadow-sm animate-in slide-in-from-right-4">
                                    <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-[1.5rem] flex items-center justify-center text-3xl shadow-inner shrink-0">🏥</div>
                                    <div className="min-w-0">
                                        <h5 className="text-xl font-black text-slate-800 leading-none mb-1 truncate uppercase">{selectedClient.name}</h5>
                                        <p className="text-[10px] font-bold text-slate-400 italic mb-2 truncate">"{selectedClient.address || 'Adresse non répertoriée'}"</p>
                                        <div className="flex gap-4">
                                            <span className="text-[9px] font-black text-blue-600 bg-blue-50 px-2 py-0.5 rounded uppercase">CLIENT CODE: {selectedClient.code}</span>
                                            <span className="text-[9px] font-black text-slate-500 bg-slate-50 px-2 py-0.5 rounded uppercase">{selectedClient.city}</span>
                                        </div>
                                    </div>
                                    <button onClick={() => setFormData({...formData, client_id: ''})} className="ml-auto p-3 text-slate-300 hover:text-red-500 transition-colors"><i className="ti ti-x text-2xl"></i></button>
                                </div>
                            )}
                        </div>
                    </section>

                    {/* ITEMS MANAGEMENT */}
                    <section className="space-y-8">
                        <div className="flex justify-between items-end border-b pb-6 mb-10">
                            <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-[5px]">2. Articles & Prestations de l'Offre</h4>
                            <div className="flex gap-3">
                                <button onClick={() => { setPickerType('machine'); setModal({...modal, type: 'item_picker'}); }} className="px-8 py-4 bg-slate-900 text-white rounded-[1.5rem] font-black text-[10px] uppercase tracking-[3px] active:scale-95 transition-all shadow-xl flex items-center gap-2"><i className="ti ti-plus text-lg"></i> Ajouter Machine</button>
                                <button onClick={() => { setPickerType('product'); setModal({...modal, type: 'item_picker'}); }} className="px-8 py-4 bg-blue-600 text-white rounded-[1.5rem] font-black text-[10px] uppercase tracking-[3px] active:scale-95 transition-all shadow-xl flex items-center gap-2"><i className="ti ti-plus text-lg"></i> Ajouter Article</button>
                            </div>
                        </div>

                        <div className="space-y-6">
                            {formData.items.map((item, idx) => {
                                const lineHT = calculateLineTotal(item);
                                const unitAfterDiscount = lineHT / (item.quantity || 1);
                                const isBelowFloor = item.type === 'machine' && unitAfterDiscount < parseFloat(item.min_price_ht);
                                const remisePercentage = item.discount_type === 'percent' ? item.discount_value : ((item.discount_value / (item.unit_price * item.quantity)) * 100).toFixed(1);
                                
                                return (
                                    <div key={idx} className={`flex flex-col xl:flex-row xl:items-center gap-8 p-8 rounded-[3.5rem] border transition-all animate-in slide-in-from-left-4 duration-300 relative group ${isBelowFloor ? 'bg-rose-50/50 border-rose-200 shadow-rose-100 shadow-2xl' : 'bg-white border-slate-100 shadow-sm hover:shadow-md'}`}>
                                        <div className="w-24 h-24 rounded-[2rem] bg-white border border-slate-100 overflow-hidden shrink-0 flex items-center justify-center p-3 shadow-inner">
                                            <img src={getFullImageUrl(item.image_url)} className="w-full h-full object-contain" />
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <div className="flex items-center gap-3 mb-2">
                                                <span className={`px-3 py-0.5 rounded-md text-[8px] font-black uppercase tracking-widest ${item.type === 'machine' ? 'bg-slate-900 text-white' : 'bg-blue-50 text-blue-600'}`}>{item.type}</span>
                                                <h5 className="text-xl font-black text-slate-800 leading-none truncate uppercase tracking-tight">{item.name}</h5>
                                            </div>
                                            {item.type === 'machine' && (
                                                <p className={`text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 ${isBelowFloor ? 'text-rose-600' : 'text-slate-400'}`}>
                                                    <i className="ti ti-alert-circle"></i> SEUIL PLANCHER HT: {parseFloat(item.min_price_ht).toLocaleString()} MAD
                                                </p>
                                            )}
                                        </div>
                                        
                                        <div className="flex flex-wrap items-center gap-8">
                                            <div className="w-24 text-center">
                                                <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest block mb-2">Qté</label>
                                                <div className="flex items-center bg-slate-100 rounded-2xl overflow-hidden shadow-inner">
                                                    <button onClick={() => { const items = [...formData.items]; items[idx].quantity = Math.max(1, (items[idx].quantity - 1)); setFormData({...formData, items}); }} className="w-8 h-10 flex items-center justify-center text-slate-400 hover:bg-slate-200 transition-colors"><i className="ti ti-minus"></i></button>
                                                    <input type="number" min="1" value={item.quantity} onChange={(e) => { const items = [...formData.items]; items[idx].quantity = parseInt(e.target.value) || 1; setFormData({...formData, items}); }} className="flex-1 w-full bg-transparent border-none text-center font-black outline-none text-sm" />
                                                    <button onClick={() => { const items = [...formData.items]; items[idx].quantity = items[idx].quantity + 1; setFormData({...formData, items}); }} className="w-8 h-10 flex items-center justify-center text-slate-400 hover:bg-slate-200 transition-colors"><i className="ti ti-plus"></i></button>
                                                </div>
                                            </div>
                                            <div className="w-44">
                                                <label className="text-[8px] font-black text-slate-700 uppercase tracking-widest block mb-2 text-center">Prix Unitaire HT (MAD)</label>
                                                <div className="relative">
                                                    <input 
                                                        type="number" 
                                                        value={item.unit_price} 
                                                        onChange={(e) => { const items = [...formData.items]; items[idx].unit_price = e.target.value; setFormData({...formData, items}); }} 
                                                        className="w-full px-4 py-3 rounded-2xl bg-white border-2 border-slate-200 focus:border-blue-600 font-black text-center outline-none transition-all text-slate-800 text-sm shadow-xs focus:ring-2 focus:ring-blue-100" 
                                                        placeholder="0.00"
                                                    />
                                                    <span className="text-[8px] font-bold text-blue-600 block text-center mt-1 uppercase">Ajustable</span>
                                                </div>
                                            </div>
                                            <div className="w-44">
                                                <label className="text-[8px] font-black text-rose-500 uppercase tracking-widest block mb-2 text-center">Promotion / Remise</label>
                                                <div className="flex bg-white border-2 border-slate-100 rounded-2xl overflow-hidden shadow-sm focus-within:border-rose-300 transition-colors">
                                                    <input type="number" value={item.discount_value} onChange={(e) => { const items = [...formData.items]; items[idx].discount_value = e.target.value; setFormData({...formData, items}); }} className="flex-1 px-4 py-2 border-none outline-none font-bold text-center text-rose-500" />
                                                    <button onClick={() => { const items = [...formData.items]; items[idx].discount_type = items[idx].discount_type === 'percent' ? 'fixed' : 'percent'; setFormData({...formData, items}); }} className="w-14 bg-rose-600 text-white font-black text-[10px] uppercase tracking-tighter hover:bg-rose-700 transition-colors">{item.discount_type === 'percent' ? '%' : 'MAD'}</button>
                                                </div>
                                                <p className="text-[8px] font-black text-center text-rose-400 uppercase mt-1">Impact: -{remisePercentage}%</p>
                                            </div>
                                            <div className="w-32 text-right">
                                                <label className="text-[8px] font-black text-blue-600 uppercase tracking-widest block mb-2">Total Net HT</label>
                                                <div className="text-xl font-black text-blue-600 tracking-tighter">{lineHT.toLocaleString()} <span className="text-[10px] opacity-30">MAD</span></div>
                                            </div>
                                            <button onClick={() => setFormData({...formData, items: formData.items.filter((_, i) => i !== idx)})} className="w-12 h-12 bg-white text-slate-300 hover:text-red-500 rounded-full flex items-center justify-center shadow-sm hover:shadow-lg transition-all active:scale-90"><i className="ti ti-trash text-xl"></i></button>
                                        </div>
                                        
                                        {isBelowFloor && (
                                            <div className="absolute -top-3 right-10 px-4 py-1 bg-rose-600 text-white rounded-full text-[8px] font-black uppercase tracking-[3px] shadow-xl animate-bounce">
                                                Prix Plancher Non-Atteint
                                            </div>
                                        )}
                                    </div>
                                );
                            })}
                            {formData.items.length === 0 && (
                                <div className="py-24 text-center border-4 border-dashed border-slate-100 rounded-[4rem] opacity-30 flex flex-col items-center">
                                    <i className="ti ti-shopping-cart-plus text-8xl mb-4"></i>
                                    <p className="font-black uppercase text-xs tracking-[5px]">Veuillez sélectionner des articles du catalogue</p>
                                </div>
                            )}
                        </div>
                    </section>
                </div>

                {/* SIDE SUMMARY PANEL */}
                <div className="w-full lg:w-[450px] bg-white border-l border-slate-100 p-12 space-y-10 overflow-y-auto">
                    <div className="bg-slate-900 rounded-[3.5rem] p-10 text-white space-y-8 shadow-2xl relative overflow-hidden">
                        <div className="absolute -right-10 -top-10 w-40 h-40 bg-blue-500 opacity-20 rounded-full blur-[60px]"></div>
                        <h4 className="text-[11px] font-black text-blue-400 uppercase tracking-[6px] border-b border-white/10 pb-6 flex items-center gap-3"><i className="ti ti-calculator text-2xl"></i> Financial Sync</h4>
                        
                        <div className="space-y-4">
                            <SummaryRow label="Total Brut HT" value={formData.items.reduce((acc, i) => acc + (parseFloat(i.unit_price) * i.quantity), 0)} />
                            <SummaryRow label="Remises Commerciales" value={formData.items.reduce((acc, i) => acc + (parseFloat(i.unit_price) * i.quantity), 0) - calculateTotals(formData.items).ht} isDiscount />
                            <SummaryRow label="Total Net HT" value={calculateTotals(formData.items).ht} isHighlight />
                            <SummaryRow label="TVA (20%)" value={calculateTotals(formData.items).tva} />
                        </div>

                        <div className="pt-10 border-t border-white/10">
                            <p className="text-[10px] font-black text-slate-500 uppercase tracking-[4px] mb-4">Net à Payer (TTC)</p>
                            <div className="flex items-baseline gap-4">
                                <p className="text-5xl font-black text-emerald-400 tracking-tighter leading-none">{calculateTotals(formData.items).ttc.toLocaleString()}</p>
                                <p className="text-xl font-black text-slate-600 uppercase tracking-widest">MAD</p>
                            </div>
                        </div>
                    </div>

                    <div className="space-y-4">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">Notes & Conditions</label>
                        <textarea 
                            value={formData.notes} 
                            onChange={(e) => setFormData({...formData, notes: e.target.value})} 
                            className="w-full p-8 bg-slate-50 border-none rounded-[2.5rem] outline-none font-medium text-sm h-48 italic shadow-inner leading-relaxed" 
                            placeholder="Validité du devis, délais de livraison, modalités de paiement..." 
                        />
                    </div>

                    <button 
                        onClick={handleSaveQuote} 
                        disabled={isSubmitting || formData.items.length === 0 || !formData.client_id} 
                        className="w-full py-8 bg-blue-600 hover:bg-blue-700 text-white rounded-[3rem] font-black uppercase text-sm tracking-[5px] shadow-[0_30px_60px_-10px_rgba(37,99,235,0.4)] active:scale-95 transition-all disabled:opacity-50 flex items-center justify-center gap-3 cursor-pointer"
                    >
                        <i className="ti ti-circle-check text-xl"></i>
                        {isSubmitting ? 'Syndication...' : (modal.type === 'add' ? 'Créer & Ajouter Devis' : 'Enregistrer Modifications')}
                    </button>
                </div>
            </div>
          </div>
        </div>
      )}

      {/* ITEM PICKER OVERLAY - Same as before */}
      {modal.type === 'item_picker' && (
          <div className="fixed inset-0 bg-slate-900/90 backdrop-blur-xl z-[200] flex items-center justify-center p-8 animate-in fade-in duration-300">
              <div className="bg-white w-full max-w-6xl rounded-[4rem] shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
                  <div className="p-10 border-b flex justify-between items-center bg-slate-50/50">
                      <div className="flex items-center gap-6">
                          <div className="w-14 h-14 bg-slate-900 text-white rounded-2xl flex items-center justify-center text-2xl shadow-xl"><i className="ti ti-box"></i></div>
                          <h2 className="text-3xl font-black tracking-tighter uppercase leading-none">Sélectionner {pickerType === 'machine' ? 'Équipement' : 'Consommable'}</h2>
                      </div>
                      <button onClick={() => setModal({...modal, type: modal.item ? 'edit' : 'add'})} className="w-14 h-14 bg-white rounded-full flex items-center justify-center text-slate-400 hover:text-red-500 shadow-md transition-all text-2xl font-light">×</button>
                  </div>
                  <div className="p-8 bg-slate-50 border-b flex gap-6">
                      <div className="flex-1 relative">
                          <i className="ti ti-search absolute left-6 top-1/2 -translate-y-1/2 text-slate-400 text-xl"></i>
                          <input 
                            type="text" 
                            placeholder="Chercher dans le catalogue..." 
                            className="w-full pl-16 pr-8 py-5 bg-white border-none rounded-[1.75rem] outline-none font-bold shadow-sm"
                            value={pickerSearch}
                            onChange={e => setPickerSearch(e.target.value)}
                          />
                      </div>
                  </div>
                  <div className="flex-1 overflow-y-auto p-10 custom-scrollbar">
                      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
                          {filteredItemsForPicker.map(item => (
                              <button key={item.id} onClick={() => handleAddItem(item, pickerType)} className="bg-white p-6 rounded-[3rem] border border-slate-100 shadow-sm hover:shadow-2xl transition-all group flex flex-col text-left active:scale-95">
                                  <div className="h-44 w-full bg-slate-50 rounded-[2.5rem] flex items-center justify-center p-4 mb-6 group-hover:scale-105 transition-transform duration-500">
                                      <img src={getFullImageUrl(item.image_url)} className="max-h-full max-w-full object-contain" alt="" />
                                  </div>
                                  <div className="space-y-1 px-4 mb-6 flex-1">
                                      <h5 className="font-black text-slate-800 text-sm leading-tight uppercase line-clamp-2">{item.name}</h5>
                                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{item.reference || item.sku}</p>
                                  </div>
                                  <div className="flex justify-between items-center px-4 pt-4 border-t border-slate-50">
                                      <div>
                                          <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">MSRP Brute</p>
                                          <p className="font-black text-blue-600 text-sm">{(item.price_ht || 0).toLocaleString()} MAD</p>
                                      </div>
                                      <div className="w-10 h-10 bg-slate-900 text-white rounded-xl flex items-center justify-center group-hover:bg-blue-600 transition-colors"><i className="ti ti-plus"></i></div>
                                  </div>
                              </button>
                          ))}
                      </div>
                  </div>
              </div>
          </div>
      )}

      {/* PRINT PREVIEW */}
      {modal.type === 'print' && (
          <QuotePrintTemplate item={modal.item} config={config} onClose={() => setModal({ type: null, item: null })} onEdit={() => openEditModal(modal.item)} getFullImageUrl={getFullImageUrl} />
      )}

      {/* PDF CONFIGURATION */}
      {modal.type === 'config' && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[150] flex items-center justify-center p-4">
              <div className="bg-white w-full max-w-2xl rounded-[4rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 border-4 border-white flex flex-col">
                  <div className="p-10 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                      <div>
                        <h2 className="text-2xl font-black text-slate-800 tracking-tighter uppercase text-[10px] tracking-[4px]">Entité Corporate</h2>
                        <p className="text-slate-400 font-bold uppercase text-[8px] tracking-[2px] mt-1">Paramètres de Facturation & Devis PDF</p>
                      </div>
                      <button onClick={() => setModal({ type: null, item: null })} className="w-14 h-14 flex items-center justify-center bg-white rounded-full text-slate-400 hover:text-red-500 shadow-xl transition-all text-2xl font-light">×</button>
                  </div>
                  <div className="p-10 space-y-8 overflow-y-auto max-h-[70vh] custom-scrollbar">
                      <FormConfigInput label="Dénomination Sociale" value={config.company_name} onChange={(v:any) => setConfig({...config, company_name: v})} />
                      <FormConfigInput label="Siège Social / Adresse" value={config.company_address} onChange={(v:any) => setConfig({...config, company_address: v})} />
                      <div className="grid grid-cols-2 gap-6">
                          <FormConfigInput label="Email de Contact" value={config.company_email} onChange={(v:any) => setConfig({...config, company_email: v})} />
                          <FormConfigInput label="Standard Téléphonique" value={config.company_phone} onChange={(v:any) => setConfig({...config, company_phone: v})} />
                      </div>
                      <div className="space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Pied de page / Conditions légales</label>
                          <textarea value={config.quote_footer} onChange={e => setConfig({...config, quote_footer: e.target.value})} className="w-full px-8 py-5 bg-slate-50 border-none rounded-[1.75rem] outline-none font-medium shadow-inner h-32 italic text-sm" />
                      </div>
                      <button onClick={async () => { await api.request('/settings/bulk', { method: 'POST', body: JSON.stringify({ settings: config }) }); setModal({ type: null, item: null }); }} className="w-full py-6 bg-slate-900 text-white rounded-[2rem] font-black uppercase text-xs tracking-widest shadow-2xl active:scale-95 transition-all">Enregistrer Protocoles PDF</button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
}

function QuoteKPI({ label, value, icon, color }: any) {
    return (
        <div className="bg-white p-8 rounded-[3.5rem] border border-slate-100 shadow-sm flex items-center gap-6 group hover:shadow-2xl transition-all relative overflow-hidden">
            <div className={`w-16 h-16 rounded-[1.75rem] ${color} flex items-center justify-center text-white text-3xl shadow-xl transition-transform group-hover:rotate-12`}>
                <i className={`ti ${icon}`}></i>
            </div>
            <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-[3px] mb-1">{label}</p>
                <p className="text-2xl font-black text-slate-800 tracking-tighter leading-none">{value}</p>
            </div>
            <div className={`absolute -right-6 -bottom-6 w-24 h-24 ${color} opacity-5 rounded-full blur-2xl`}></div>
        </div>
    );
}

function FormConfigInput({ label, value, onChange }: any) {
    return (
        <div className="space-y-1">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">{label}</label>
            <input value={value || ''} onChange={e => onChange(e.target.value)} className="w-full px-8 py-5 bg-slate-50 border-none rounded-[1.75rem] outline-none font-bold shadow-inner focus:ring-4 focus:ring-blue-500/5 transition-all" />
        </div>
    )
}

function SummaryRow({ label, value, isDiscount, isHighlight }: any) {
    return (
        <div className={`flex justify-between items-center text-sm ${isHighlight ? 'font-black text-blue-400 pt-2 border-t border-white/10' : 'font-bold'} ${isDiscount ? 'text-rose-400' : ''}`}>
            <span className={`uppercase tracking-widest text-[9px] ${isHighlight ? 'text-blue-500' : 'text-slate-500'}`}>{label}</span>
            <span>{isDiscount ? '- ' : ''}{parseFloat(value || 0).toLocaleString()} MAD</span>
        </div>
    )
}

function TooltipButton({ onClick, icon, color, tooltip }: any) {
    return (
        <div className="group/btn relative">
            <button onClick={onClick} className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all shadow-sm active:scale-90 ${color}`}>
                <i className={`ti ${icon} text-xl`}></i>
            </button>
            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 px-3 py-2 bg-slate-900 text-white text-[8px] font-black uppercase tracking-[2px] rounded-lg opacity-0 group-hover/btn:opacity-100 transition-all pointer-events-none whitespace-nowrap z-50">
                {tooltip}
                <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-slate-900"></div>
            </div>
        </div>
    )
}

function QuotePrintTemplate({ item, config, onClose, onEdit, getFullImageUrl }: any) {
    const [isGenerating, setIsGenerating] = useState(false);

    const printViaIframe = () => {
        const iframeId = 'devis-print-iframe';
        let iframe = document.getElementById(iframeId) as HTMLIFrameElement;
        if (iframe) {
            iframe.remove();
        }

        iframe = document.createElement('iframe');
        iframe.id = iframeId;
        iframe.style.position = 'fixed';
        iframe.style.right = '0';
        iframe.style.bottom = '0';
        iframe.style.width = '0';
        iframe.style.height = '0';
        iframe.style.border = '0';
        document.body.appendChild(iframe);

        const doc = iframe.contentWindow?.document || iframe.contentDocument;
        if (!doc) {
            window.print();
            return;
        }

        const paperEl = document.getElementById('quote-paper-container');
        const paperContent = paperEl ? paperEl.innerHTML : '';

        doc.open();
        doc.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <title>Devis SPECTA #${item.quote_number || item.id}</title>
                <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
                <script src="https://cdn.tailwindcss.com"></script>
                <style>
                    body { font-family: 'Plus Jakarta Sans', sans-serif; background: white; margin: 0; padding: 15mm; }
                    @page { size: A4 portrait; margin: 10mm; }
                    @media print {
                        body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
                    }
                </style>
            </head>
            <body>
                <div>${paperContent}</div>
                <script>
                    window.onload = function() {
                        window.focus();
                        setTimeout(function() {
                            try { window.print(); } catch(e) { console.error(e); }
                        }, 400);
                    };
                </script>
            </body>
            </html>
        `);
        doc.close();
    };

    const handlePrint = () => { 
        try {
            printViaIframe();
        } catch (e) {
            window.print();
        }
    };

    const handleDownloadPDF = async () => {
        setIsGenerating(true);
        try {
            const element = document.getElementById('quote-paper-container');
            if (!element) {
                handlePrint();
                return;
            }

            const filename = `Devis_SPECTA_${item.quote_number || item.id || 'offre'}.pdf`;

            if (typeof (window as any).html2pdf !== 'undefined') {
                const opt = {
                    margin: [4, 4, 4, 4],
                    filename: filename,
                    image: { type: 'jpeg', quality: 0.98 },
                    html2canvas: { scale: 2, useCORS: true, logging: false },
                    jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
                };
                await (window as any).html2pdf().set(opt).from(element).save();
            } else {
                handlePrint();
            }
        } catch (err) {
            console.error('Erreur export PDF:', err);
            handlePrint();
        } finally {
            setIsGenerating(false);
        }
    };

    const totals = useMemo(() => {
        const rawItems = item.items || [];
        let totalNetHT = 0;
        let totalTVA = 0;

        rawItems.forEach((line: any) => {
            const qty = parseInt(line.quantity) || 0;
            const unitPrice = parseFloat(line.unit_price) || 0;
            const brutLine = unitPrice * qty;
            const lineNetHT = parseFloat(line.total_price) || brutLine;
            
            totalNetHT += lineNetHT;
            totalTVA += lineNetHT * ((parseFloat(line.tax_rate) || 20) / 100);
        });

        return {
            net: totalNetHT,
            tva: totalTVA,
            ttc: totalNetHT + totalTVA
        };
    }, [item]);

    return (
        <div className="fixed inset-0 z-[200] bg-slate-600 overflow-y-auto preview-mode-active font-sans">
            {/* Action Bar for Preview */}
            <div className="fixed top-6 left-1/2 -translate-x-1/2 flex items-center gap-3 bg-slate-900/95 backdrop-blur-xl text-white px-6 py-3.5 rounded-[2rem] shadow-2xl z-[210] no-print border border-white/10">
                <div className="flex flex-col pr-5 border-r border-white/10">
                    <span className="text-[9px] font-black uppercase tracking-[2px] text-blue-400">Export & Impression</span>
                    <span className="text-xs font-bold text-slate-300">Offre #{item.quote_number}</span>
                </div>
                <button onClick={onEdit} className="hover:bg-white/10 px-4 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2">
                    <i className="ti ti-edit"></i> Éditer
                </button>
                <button 
                    onClick={handleDownloadPDF} 
                    disabled={isGenerating}
                    className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 shadow-xl active:scale-95 text-white cursor-pointer"
                >
                    <i className={`ti ${isGenerating ? 'ti-loader animate-spin' : 'ti-download'}`}></i> 
                    {isGenerating ? 'Génération PDF...' : 'Télécharger PDF'}
                </button>
                <button 
                    onClick={handlePrint} 
                    className="bg-blue-600 hover:bg-blue-500 px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 shadow-xl active:scale-95 text-white cursor-pointer"
                >
                    <i className="ti ti-printer"></i> Imprimer
                </button>
                <button onClick={onClose} className="bg-white/10 hover:bg-white/20 px-4 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all">Fermer</button>
            </div>

            {/* Paper Container */}
            <div id="quote-paper-container" className="preview-paper bg-white text-black p-[15mm] relative min-h-[297mm] w-[210mm] mx-auto shadow-2xl my-8">
                {/* Header Section */}
                <div className="flex justify-between items-start mb-4">
                    <div className="flex flex-col">
                        <img src="https://specta.ma/images/Specta_logo.webp" className="h-16 object-contain self-start" alt="Specta Logo" />
                    </div>
                    <div className="text-right text-[11px] font-medium space-y-1">
                        <p className="text-[13px] font-bold">Offre Commerciale</p>
                        <p>N° {item.quote_number}</p>
                        <p>Date: {new Date(item.created_at || Date.now()).toLocaleDateString('fr-FR')}</p>
                        <p>Client N°: {item.client?.code || '000000'}</p>
                    </div>
                </div>

                <div className="flex justify-between mb-8">
                    <div className="w-[45%]">
                        <p className="font-bold text-[12px] mb-2 text-slate-800">Émetteur</p>
                        <div className="bg-slate-100 p-4 text-[11px] font-medium space-y-1 rounded-sm border border-slate-200">
                            <p className="font-bold">SPECTA</p>
                            <p>Rue Caid Ahmed N°11 Quartier Mers Sultan</p>
                            <p>Casablanca Maroc</p>
                            <p className="font-bold">Tél: <span className="font-normal">0522 984 981</span></p>
                            <p className="font-bold">Email: <span className="font-normal">info@specta.ma</span></p>
                            <p className="font-bold">Web: <span className="font-normal">https://www.specta.ma/</span></p>
                        </div>
                    </div>
                    <div className="w-[50%] flex flex-col justify-end">
                        <p className="font-bold text-[12px] mb-2 text-slate-800">Adressé à</p>
                        <div className="p-4 text-[11px] font-medium space-y-1 rounded-sm border border-slate-300 min-h-[120px]">
                            <p className="font-bold text-[12px] text-blue-900">{item.client?.name}</p>
                            <p>{item.client?.address || '---'}</p>
                            <p>{item.client?.mobile || item.client?.phone || '---'}</p>
                            <p className="font-bold mt-2">E-mail : <span className="font-normal">{item.client?.email || '---'}</span></p>
                            <p className="font-bold">ICE : <span className="font-normal">{item.client?.ice || '---'}</span></p>
                        </div>
                    </div>
                </div>

                {/* Items Table */}
                <div className="mb-6">
                    <table className="w-full border-collapse border border-slate-300 text-[11px]">
                        <thead>
                            <tr className="bg-slate-100 font-bold border-b border-slate-300 text-slate-800">
                                <th className="border-r border-slate-300 px-2 py-2 text-center w-8">N°</th>
                                <th className="border-r border-slate-300 px-2 py-2 text-left w-24">Référence</th>
                                <th className="border-r border-slate-300 px-2 py-2 text-left">Désignation</th>
                                <th className="border-r border-slate-300 px-2 py-2 text-center w-12">Qté</th>
                                <th className="border-r border-slate-300 px-2 py-2 text-right w-24">P.U HT</th>
                                <th className="border-r border-slate-300 px-2 py-2 text-center w-16">Remise</th>
                                <th className="px-2 py-2 text-right w-28">Total HT</th>
                            </tr>
                        </thead>
                        <tbody>
                            {item.items?.map((line: any, idx: number) => {
                                const asset = line.machine || line.product;
                                const qty = parseInt(line.quantity) || 1;
                                const brutLine = (parseFloat(line.unit_price) || 0) * qty;
                                const netLine = parseFloat(line.total_price) || brutLine;
                                const remiseVal = brutLine - netLine;
                                const remisePct = brutLine > 0 ? (remiseVal / brutLine) * 100 : 0;
                                
                                return (
                                    <tr key={idx} className="border-b border-slate-300 text-slate-800">
                                        <td className="border-r border-slate-300 px-2 py-3 text-center align-top font-bold">{idx + 1}</td>
                                        <td className="border-r border-slate-300 px-2 py-3 text-left align-top font-bold">{asset?.sku || asset?.reference || '---'}</td>
                                        <td className="border-r border-slate-300 px-2 py-3 text-left align-top">{asset?.name || '---'}</td>
                                        <td className="border-r border-slate-300 px-2 py-3 text-center align-top">{qty.toLocaleString('fr-FR', {minimumFractionDigits: 2})}</td>
                                        <td className="border-r border-slate-300 px-2 py-3 text-right align-top">{(parseFloat(line.unit_price) || 0).toLocaleString('fr-FR', {minimumFractionDigits: 2})}</td>
                                        <td className="border-r border-slate-300 px-2 py-3 text-center align-top">{remisePct > 0 ? `${remisePct.toLocaleString('fr-FR', {maximumFractionDigits: 2})}%` : '---'}</td>
                                        <td className="px-2 py-3 text-right align-top">{netLine.toLocaleString('fr-FR', {minimumFractionDigits: 2})} DH</td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>

                {/* Totals & Conditions */}
                <div className="flex justify-between items-start text-[11px] text-slate-800 mt-8 border-t border-slate-300 pt-4">
                    <div className="space-y-2 max-w-[60%]">
                        <p><span className="font-bold">Conditions de paiement :</span> {item.payment_conditions || '---'}</p>
                        <p><span className="font-bold">Conditions de livraison :</span> {item.delivery_conditions || '---'}</p>
                        <p className="mt-2"><span className="font-bold">Note :</span> {item.notes || '---'}</p>
                    </div>
                    
                    <div className="w-64 space-y-2 text-[12px]">
                        <div className="flex justify-between items-center bg-slate-100 p-2 font-bold">
                            <span>Total HT</span>
                            <span>{totals.net.toLocaleString('fr-FR', {minimumFractionDigits: 2})} DH</span>
                        </div>
                        <div className="flex justify-between items-center p-2 font-bold text-slate-900 border-t border-slate-300">
                            <span>Total TTC</span>
                            <span>{totals.ttc.toLocaleString('fr-FR', {minimumFractionDigits: 2})} DH</span>
                        </div>
                    </div>
                </div>

                {/* Fixed Footer */}
                <div className="absolute bottom-[10mm] left-[15mm] right-[15mm] text-center text-[10px] font-bold text-slate-700 leading-snug border-t border-slate-300 pt-2">
                    <p>SPECTA SARL au capital de 1 000 000 DHS</p>
                    <p>Rue Caid Ahmed N°11 Quartier Mers Sultan - Casablanca</p>
                    <p>Fix:0522 98 49 81 - Email: info@specta.ma - web:www.specta.ma</p>
                    <p>ICE:001781901000091 - RC:360725 - IF:20684272 -TP34794426- CNSS:5195773</p>
                </div>
            </div>
        </div>
    );
}
