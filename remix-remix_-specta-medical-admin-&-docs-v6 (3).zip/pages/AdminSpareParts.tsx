import React, { useState, useEffect } from 'react';
import { api } from '../api';
import { useApp } from '../App';

interface SparePart {
  id: number;
  reference: string;
  name: string;
  manager: string;
  price: number;
  is_price_requestable: boolean;
  stock: number;
  planned_stock: number;
  is_active: boolean;
}

// Initial default data if local storage is empty
const DEFAULT_SPARE_PARTS: SparePart[] = [
  { id: 1, reference: 'SP-CARD-001', name: 'Carte Mère Specta v2', manager: 'Ahmed Alami', price: 4500, is_price_requestable: false, stock: 12, planned_stock: 15, is_active: true },
  { id: 2, reference: 'SP-LAS-740', name: 'Outil Diode Laser 808nm', manager: 'Driss Chraibi', price: 12000, is_price_requestable: true, stock: 3, planned_stock: 5, is_active: true },
  { id: 3, reference: 'SP-POIG-043', name: 'Poignée de Refroidissement Cryo', manager: 'Ahmed Alami', price: 3500, is_price_requestable: true, stock: 8, planned_stock: 10, is_active: true },
  { id: 4, reference: 'SP-FILT-902', name: 'Filtre à Eau Haute Pression', manager: 'Yasmine Benjelloun', price: 650, is_price_requestable: false, stock: 45, planned_stock: 50, is_active: true },
  { id: 5, reference: 'SP-ALIM-300', name: 'Bloc Alimentation DC 12V-50A', manager: 'Ahmed Alami', price: 1800, is_price_requestable: false, stock: 0, planned_stock: 10, is_active: false },
];

export default function AdminSpareParts() {
  const { theme, checkPermission, showDenied } = useApp();
  const [parts, setParts] = useState<SparePart[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [managerFilter, setManagerFilter] = useState('');
  const [requestableFilter, setRequestableFilter] = useState('all');

  const [modal, setModal] = useState<{
    type: 'add' | 'edit' | 'delete' | null;
    item: SparePart | null;
  }>({ type: null, item: null });

  const [formData, setFormData] = useState({
    reference: '',
    name: '',
    manager: '',
    price: 0,
    is_price_requestable: false,
    stock: 0,
    planned_stock: 0,
    is_active: true,
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  // Initialize data
  const loadData = async () => {
    setLoading(true);
    try {
      // Try to load from API
      const res = await api.spareParts.list();
      if (res && res.status === true && res.data && Array.isArray(res.data.data)) {
        const apiParts = res.data.data.map((p: any) => ({
          ...p,
          price: typeof p.price === 'string' ? parseFloat(p.price) : (typeof p.price === 'number' ? p.price : 0),
          is_price_requestable: typeof p.is_price_requestable === 'string' ? p.is_price_requestable === 'true' || p.is_price_requestable === '1' : !!p.is_price_requestable,
          is_active: typeof p.is_active === 'string' ? p.is_active === 'true' || p.is_active === '1' : p.is_active !== false,
        }));
        setParts(apiParts);
        localStorage.setItem('specta_spare_parts', JSON.stringify(apiParts));
      } else if (res && res.status !== false && Array.isArray(res)) {
        const mappedParts = res.map((p: any) => ({
          ...p,
          price: typeof p.price === 'string' ? parseFloat(p.price) : (typeof p.price === 'number' ? p.price : 0),
        }));
        setParts(mappedParts);
      } else {
        throw new Error("Fallback to storage");
      }
    } catch (e) {
      // Use LocalStorage fallback
      const cached = localStorage.getItem('specta_spare_parts');
      if (cached) {
        setParts(JSON.parse(cached));
      } else {
        localStorage.setItem('specta_spare_parts', JSON.stringify(DEFAULT_SPARE_PARTS));
        setParts(DEFAULT_SPARE_PARTS);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const saveToLocalStorage = (newParts: SparePart[]) => {
    localStorage.setItem('specta_spare_parts', JSON.stringify(newParts));
    setParts(newParts);
  };

  const syncWithBackendAndState = async (updatedParts: SparePart[]) => {
    // Save to state and localStorage first as instant feedback
    saveToLocalStorage(updatedParts);
  };

  const handleOpenModal = (type: 'add' | 'edit' | 'delete', item: SparePart | null) => {
    if (type === 'add' && !checkPermission('products', 'add')) return showDenied("Add Spare Part");
    if (type === 'edit' && !checkPermission('products', 'edit')) return showDenied("Edit Spare Part");
    if (type === 'delete' && !checkPermission('products', 'delete')) return showDenied("Delete Spare Part");

    setModal({ type, item });
    if (item) {
      setFormData({
        reference: item.reference,
        name: item.name,
        manager: item.manager,
        price: item.price,
        is_price_requestable: item.is_price_requestable,
        stock: item.stock,
        planned_stock: item.planned_stock,
        is_active: item.is_active,
      });
    } else {
      setFormData({
        reference: `SP-${Math.floor(100+Math.random()*900)}`,
        name: '',
        manager: '',
        price: 0,
        is_price_requestable: false,
        stock: 0,
        planned_stock: 0,
        is_active: true,
      });
    }
  };

  const handleToggleActive = async (part: SparePart) => {
    if (!checkPermission('products', 'edit')) return showDenied("Toggle Part Status");
    const updated = parts.map(p => p.id === part.id ? { ...p, is_active: !p.is_active } : p);
    await syncWithBackendAndState(updated);
    try {
      await api.spareParts.update(part.id, { is_active: !part.is_active });
    } catch (e) {
      console.log("Offline or non-implemented route; state cached locally.");
    }
  };

  const handleToggleRequestable = async (part: SparePart) => {
    if (!checkPermission('products', 'edit')) return showDenied("Toggle Price Requestability");
    const updated = parts.map(p => p.id === part.id ? { ...p, is_price_requestable: !p.is_price_requestable } : p);
    await syncWithBackendAndState(updated);
    try {
      await api.spareParts.update(part.id, { is_price_requestable: !part.is_price_requestable });
    } catch (e) {
      console.log("Offline or non-implemented route; state cached locally.");
    }
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      if (modal.type === 'add') {
        const newPartObj: SparePart = {
          id: parts.length > 0 ? Math.max(...parts.map(p => p.id)) + 1 : 1,
          ...formData,
        };
        const updated = [newPartObj, ...parts];
        await syncWithBackendAndState(updated);

        try {
          await api.spareParts.create(formData);
        } catch (e) {
          console.log("Offline or non-implemented route; state cached locally.");
        }
      } else if (modal.type === 'edit' && modal.item) {
        const updated = parts.map(p => p.id === modal.item!.id ? { ...p, ...formData } : p);
        await syncWithBackendAndState(updated);

        try {
          await api.spareParts.update(modal.item.id, formData);
        } catch (e) {
          console.log("Offline or non-implemented route; state cached locally.");
        }
      }
      setModal({ type: null, item: null });
    } catch (err) {
      alert("Error saving spare part.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!modal.item) return;
    setIsSubmitting(true);
    try {
      const updated = parts.filter(p => p.id !== modal.item!.id);
      await syncWithBackendAndState(updated);

      try {
        await api.spareParts.delete(modal.item.id);
      } catch (e) {
        console.log("Offline or non-implemented route; state cached locally.");
      }
      setModal({ type: null, item: null });
    } catch (err) {
      alert("Error deleting spare part.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Filtering
  const filteredParts = parts.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase()) || 
                          p.reference.toLowerCase().includes(search.toLowerCase());
    const matchesManager = managerFilter === '' || p.manager.toLowerCase().includes(managerFilter.toLowerCase());
    const matchesReq = requestableFilter === 'all' || 
                        (requestableFilter === 'yes' && p.is_price_requestable) || 
                        (requestableFilter === 'no' && !p.is_price_requestable);
    return matchesSearch && matchesManager && matchesReq;
  });

  // Extract list of managers for dropdown filtering
  const uniqueManagers = Array.from(new Set(parts.map(p => p.manager).filter(Boolean)));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-slate-800 tracking-tighter">Spare Parts Hub</h1>
          <p className="text-slate-400 font-bold uppercase text-[10px] tracking-[3px] opacity-60">
            Pièces de rechange, Inventaire & Demandes de devis
          </p>
        </div>
        <button
          onClick={() => handleOpenModal('add', null)}
          className="flex items-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs uppercase tracking-widest rounded-2xl shadow-lg transition-all transform hover:-translate-y-0.5 active:scale-95"
        >
          <i className="ti ti-plus text-sm"></i>
          Nouveau Spare Part
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center text-xl">
            <i className="ti ti-settings-2"></i>
          </div>
          <div>
            <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-wider">Total Spare Parts</h5>
            <p className="text-2xl font-black text-slate-800 mt-0.5">{parts.length}</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center text-xl">
            <i className="ti ti-check"></i>
          </div>
          <div>
            <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-wider">Actives</h5>
            <p className="text-2xl font-black text-slate-800 mt-0.5">{parts.filter(p => p.is_active).length}</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center text-xl">
            <i className="ti ti-help-circle"></i>
          </div>
          <div>
            <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-wider">Price on Request</h5>
            <p className="text-2xl font-black text-slate-800 mt-0.5">{parts.filter(p => p.is_price_requestable).length}</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 bg-rose-50 text-rose-600 rounded-2xl flex items-center justify-center text-xl">
            <i className="ti ti-package-off"></i>
          </div>
          <div>
            <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-wider">Hors Stock</h5>
            <p className="text-2xl font-black text-slate-800 mt-0.5">{parts.filter(p => p.stock === 0).length}</p>
          </div>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="relative w-full md:max-w-md">
          <i className="ti ti-search absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 text-lg"></i>
          <input
            type="text"
            placeholder="Rechercher par référence, désignation..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-slate-50 border-0 focus:ring-2 focus:ring-blue-500 rounded-2xl pl-12 pr-4 py-3 text-xs font-bold text-slate-700 placeholder-slate-400"
          />
        </div>
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          <select
            value={managerFilter}
            onChange={(e) => setManagerFilter(e.target.value)}
            className="bg-slate-50 border-0 focus:ring-2 focus:ring-blue-500 rounded-2xl px-4 py-3 text-xs font-bold text-slate-600"
          >
            <option value="">Tous les Responsables</option>
            {uniqueManagers.map(m => (
              <option key={m} value={m}>{m}</option>
            ))}
          </select>

          <select
            value={requestableFilter}
            onChange={(e) => setRequestableFilter(e.target.value)}
            className="bg-slate-50 border-0 focus:ring-2 focus:ring-blue-500 rounded-2xl px-4 py-3 text-xs font-bold text-slate-600"
          >
            <option value="all">Tarification (Tous)</option>
            <option value="yes">Prix sur Demande</option>
            <option value="no">Prix Fixe</option>
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50/50">
                <th className="p-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Référence</th>
                <th className="p-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Désignation</th>
                <th className="p-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Responsable</th>
                <th className="p-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Prix (MAD)</th>
                <th className="p-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Tarif sur Demande</th>
                <th className="p-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Stock</th>
                <th className="p-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Statut</th>
                <th className="p-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50 font-medium text-slate-700 text-xs">
              {loading ? (
                <tr>
                  <td colSpan={8} className="p-10 text-center text-slate-400">
                    Chargement des pièces...
                  </td>
                </tr>
              ) : filteredParts.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-10 text-center text-slate-400">
                    Aucune pièce trouvée.
                  </td>
                </tr>
              ) : (
                filteredParts.map(part => (
                  <tr key={part.id} className="hover:bg-slate-50/30 transition-colors">
                    <td className="p-5">
                      <span className="font-black text-slate-800 bg-slate-100 px-2.5 py-1 rounded-lg">
                        {part.reference}
                      </span>
                    </td>
                    <td className="p-5">
                      <span className="font-bold text-slate-900 block">{part.name}</span>
                    </td>
                    <td className="p-5 text-slate-500 font-semibold">{part.manager || 'No Manager assigned'}</td>
                    <td className="p-5 text-right font-black text-slate-900">
                      {part.is_price_requestable ? (
                        <span className="text-amber-600 italic text-[11px] font-medium">Prix Invisible (Demande)</span>
                      ) : (
                        `${part.price.toLocaleString()} MAD`
                      )}
                    </td>
                    <td className="p-5 text-center">
                      <button
                        onClick={() => handleToggleRequestable(part)}
                        className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                          part.is_price_requestable 
                            ? 'bg-amber-50 text-amber-600 border border-amber-200' 
                            : 'bg-slate-50 text-slate-400 hover:text-slate-600'
                        }`}
                      >
                        <i className={`ti ${part.is_price_requestable ? 'ti-toggle-left-filled' : 'ti-toggle-right'}`}></i>
                        {part.is_price_requestable ? 'Demande requise' : 'Prix Fixe'}
                      </button>
                    </td>
                    <td className="p-5 text-center">
                      <div className="flex flex-col items-center justify-center">
                        <span className={`font-black ${part.stock === 0 ? 'text-rose-500' : 'text-slate-800'}`}>
                          {part.stock}
                        </span>
                        <span className="text-[9px] text-slate-400 tracking-tighter">
                          Planifié: {part.planned_stock}
                        </span>
                      </div>
                    </td>
                    <td className="p-5 text-center">
                      <button
                        onClick={() => handleToggleActive(part)}
                        className={`w-11 h-6 rounded-full p-0.5 transition-colors focus:outline-none ${part.is_active ? 'bg-emerald-500' : 'bg-slate-200'}`}
                      >
                        <div className={`w-5 h-5 rounded-full bg-white shadow-sm transform transition-transform duration-200 ${part.is_active ? 'translate-x-5' : ''}`} />
                      </button>
                    </td>
                    <td className="p-5 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => handleOpenModal('edit', part)}
                          className="p-2 bg-slate-100 hover:bg-blue-50 text-slate-500 hover:text-blue-600 rounded-xl transition-all active:scale-90"
                          title="Modifier"
                        >
                          <i className="ti ti-edit text-sm"></i>
                        </button>
                        <button
                          onClick={() => handleOpenModal('delete', part)}
                          className="p-2 bg-slate-100 hover:bg-rose-50 text-slate-500 hover:text-rose-600 rounded-xl transition-all active:scale-90"
                          title="Supprimer"
                        >
                          <i className="ti ti-trash text-sm"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Form Dialog Modal */}
      {modal.type && (modal.type === 'add' || modal.type === 'edit') && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl overflow-hidden max-w-lg w-full max-h-[90vh] flex flex-col border border-slate-100 animate-in zoom-in-95">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h2 className="text-lg font-black text-slate-800 tracking-tight">
                {modal.type === 'add' ? 'Créer un Spare Part' : 'Modifier le Spare Part'}
              </h2>
              <button 
                onClick={() => setModal({ type: null, item: null })}
                className="w-8 h-8 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-400 hover:text-slate-600 transition-colors"
              >
                <i className="ti ti-x text-lg"></i>
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="flex-1 overflow-y-auto p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Référence</label>
                  <input
                    type="text"
                    required
                    value={formData.reference}
                    onChange={(e) => setFormData({ ...formData, reference: e.target.value })}
                    className="w-full bg-slate-50 border-0 focus:ring-2 focus:ring-blue-500 rounded-2xl px-4 py-3 text-xs font-bold text-slate-700"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Nom de la pièce</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full bg-slate-50 border-0 focus:ring-2 focus:ring-blue-500 rounded-2xl px-4 py-3 text-xs font-bold text-slate-700"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Gestionnaire de Stock</label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Ahmed Alami"
                  value={formData.manager}
                  onChange={(e) => setFormData({ ...formData, manager: e.target.value })}
                  className="w-full bg-slate-50 border-0 focus:ring-2 focus:ring-blue-500 rounded-2xl px-4 py-3 text-xs font-bold text-slate-700"
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-1 col-span-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Prix (MAD)</label>
                  <input
                    type="number"
                    min="0"
                    required
                    disabled={formData.is_price_requestable}
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-slate-50 border-0 focus:ring-2 focus:ring-blue-500 rounded-2xl px-4 py-3 text-xs font-bold text-slate-700 disabled:opacity-50"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Invisible ?</label>
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, is_price_requestable: !formData.is_price_requestable })}
                    className={`w-full py-3 rounded-2xl text-[10px] font-black uppercase tracking-wider border transition-all ${
                      formData.is_price_requestable 
                        ? 'bg-amber-50 text-amber-600 border-amber-200' 
                        : 'bg-slate-50 text-slate-400 border-slate-100'
                    }`}
                  >
                    {formData.is_price_requestable ? 'Demande' : 'Visible'}
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Stock Réel</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={formData.stock}
                    onChange={(e) => setFormData({ ...formData, stock: parseInt(e.target.value) || 0 })}
                    className="w-full bg-slate-50 border-0 focus:ring-2 focus:ring-blue-500 rounded-2xl px-4 py-3 text-xs font-bold text-slate-700"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Stock Commandé/Planifié</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={formData.planned_stock}
                    onChange={(e) => setFormData({ ...formData, planned_stock: parseInt(e.target.value) || 0 })}
                    className="w-full bg-slate-50 border-0 focus:ring-2 focus:ring-blue-500 rounded-2xl px-4 py-3 text-xs font-bold text-slate-700"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100">
                <div>
                  <h4 className="text-xs font-bold text-slate-700">Pièce Active</h4>
                  <p className="text-[9px] text-slate-400">Permettre l'utilisation de cette pièce dans les dossiers SAV</p>
                </div>
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, is_active: !formData.is_active })}
                  className={`w-11 h-6 rounded-full p-0.5 transition-colors focus:outline-none ${formData.is_active ? 'bg-emerald-500' : 'bg-slate-200'}`}
                >
                  <div className={`w-5 h-5 rounded-full bg-white shadow-sm transform transition-transform duration-200 ${formData.is_active ? 'translate-x-5' : ''}`} />
                </button>
              </div>

              <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setModal({ type: null, item: null })}
                  className="px-6 py-3 border border-slate-200 text-slate-500 hover:text-slate-800 font-bold text-xs uppercase tracking-widest rounded-2xl transition-all"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs uppercase tracking-widest rounded-2xl shadow-lg transition-all disabled:opacity-50"
                >
                  {isSubmitting ? 'Enregistrement...' : 'Enregistrer'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {modal.type === 'delete' && modal.item && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-8 max-w-sm w-full border border-slate-100 text-center animate-in zoom-in-95">
            <div className="w-16 h-16 bg-rose-50 text-rose-500 rounded-2xl flex items-center justify-center text-3xl mx-auto mb-4">
              <i className="ti ti-trash"></i>
            </div>
            <h3 className="text-lg font-black text-slate-800 tracking-tight">Supprimer la pièce ?</h3>
            <p className="text-slate-400 font-medium text-xs leading-relaxed mt-2 mb-8">
              Êtes-vous sûr de vouloir supprimer la pièce <span className="font-bold text-slate-700">{modal.item.name}</span> ({modal.item.reference}) ? Cette action est irréversible.
            </p>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setModal({ type: null, item: null })}
                className="flex-1 py-4 border border-slate-100 text-slate-400 hover:text-slate-700 font-black text-[10px] uppercase tracking-wider rounded-2xl transition-all"
              >
                Annuler
              </button>
              <button
                onClick={handleDelete}
                disabled={isSubmitting}
                className="flex-1 py-4 bg-rose-600 hover:bg-rose-700 text-white font-black text-[10px] uppercase tracking-wider rounded-2xl shadow-lg shadow-rose-200 transition-all disabled:opacity-50"
              >
                {isSubmitting ? 'Suppression...' : 'Supprimer'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
