
import React, { useState, useEffect } from 'react';
import { api } from '../api';
import { useApp } from '../App';
import { Category } from '../types';

export default function AdminCategories() {
  const { t } = useApp();
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<{ type: 'add' | 'edit' | 'delete' | null, item: any }>({ type: null, item: null });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fetchCategories = async () => {
    setLoading(true);
    try {
      const data = await api.categories.list('per_page=100');
      setCategories(data.data || data || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchCategories(); }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    const form = e.target as HTMLFormElement;
    const data = Object.fromEntries(new FormData(form).entries());
    try {
      if (modal.type === 'add') await api.categories.create(data);
      else await api.categories.update(modal.item.id, data);
      setModal({ type: null, item: null });
      fetchCategories();
    } catch (e) { alert("Error"); } finally { setIsSubmitting(false); }
  };

  const handleDelete = async () => {
    setIsSubmitting(true);
    try {
      await api.categories.delete(modal.item.id);
      setModal({ type: null, item: null });
      fetchCategories();
    } catch (e) { alert("Error"); } finally { setIsSubmitting(false); }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-black text-slate-800">{t.nav_categories}</h1>
        <button onClick={() => setModal({ type: 'add', item: { is_active: 1 } })} className="bg-blue-600 text-white px-6 py-2 rounded-xl font-bold shadow-lg">+ {t.add}</button>
      </div>

      <div className="bg-white rounded-[2rem] shadow-sm border border-slate-100 overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-50 border-b border-slate-100">
            <tr className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
              <th className="px-8 py-4">{t.name}</th>
              <th className="px-8 py-4">{t.sku} (Slug)</th>
              <th className="px-8 py-4">{t.is_active}</th>
              <th className="px-8 py-4 text-right">{t.actions}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {categories.map((c: any) => (
              <tr key={c.id} className="hover:bg-slate-50/50 transition-colors">
                <td className="px-8 py-5 font-bold">{c.name}</td>
                <td className="px-8 py-5 text-slate-400 font-mono text-xs uppercase">{c.slug}</td>
                <td className="px-8 py-5">
                    <span className={`px-2 py-1 rounded-lg text-[10px] font-black uppercase ${c.is_active ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'}`}>
                        {c.is_active ? t.is_active : 'Inactive'}
                    </span>
                </td>
                <td className="px-8 py-5 text-right">
                    <button onClick={() => setModal({ type: 'edit', item: c })} className="text-blue-500 mr-2"><i className="ti ti-edit"></i></button>
                    <button onClick={() => setModal({ type: 'delete', item: c })} className="text-red-500"><i className="ti ti-trash"></i></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {modal.type && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-[3rem] shadow-2xl p-8">
            <h2 className="text-2xl font-black mb-6 uppercase text-xs tracking-widest">{modal.type} Category</h2>
            {modal.type === 'delete' ? (
                <div className="space-y-6 text-center">
                    <p className="font-bold text-slate-600">Delete <span className="text-slate-900">{modal.item.name}</span>?</p>
                    <div className="flex gap-4">
                        <button onClick={() => setModal({ type: null, item: null })} className="flex-1 py-4 bg-slate-100 rounded-2xl font-bold">{t.cancel}</button>
                        <button onClick={handleDelete} className="flex-1 py-4 bg-red-500 text-white rounded-2xl font-bold">{t.confirm}</button>
                    </div>
                </div>
            ) : (
                <form onSubmit={handleSave} className="space-y-4">
                    <div className="space-y-1"><label className="text-[10px] font-black text-slate-400 ml-4">NAME</label>
                    <input name="name" defaultValue={modal.item.name} className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl outline-none font-bold" required /></div>
                    <div className="space-y-1"><label className="text-[10px] font-black text-slate-400 ml-4">SLUG</label>
                    <input name="slug" defaultValue={modal.item.slug} className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl outline-none font-mono text-sm" required /></div>
                    <div className="space-y-1"><label className="text-[10px] font-black text-slate-400 ml-4">DESCRIPTION</label>
                    <textarea name="description" defaultValue={modal.item.description} className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl outline-none h-20" /></div>
                    <button type="submit" disabled={isSubmitting} className="w-full py-5 bg-blue-600 text-white rounded-[2rem] font-black uppercase text-xs tracking-widest shadow-xl shadow-blue-200 mt-4">
                        {isSubmitting ? '...' : t.save}
                    </button>
                </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
