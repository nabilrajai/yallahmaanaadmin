
import React, { useState } from 'react';
import { useApp } from '../App';
import { Reclamation, ReclamationStatus, Priority } from '../types';
import { getAIDiagnostic } from '../services/geminiService';

const MOCK_TICKETS: Reclamation[] = [
  { id: 1, client_id: 1, subject: "Laser Handpiece Failure", description: "The laser fires intermittently and overheats after 5 minutes of use. Error code E-24 on display.", status_id: 1, status_label: 'new', priority_id: 1, priority_label: 'High', created_at: '2025-12-24', client: { name: 'Clinique Aljadid' } as any },
  { id: 2, client_id: 2, subject: "Suction Pump Noise", description: "Abnormal vibrating sound coming from the central suction unit.", status_id: 2, status_label: 'in_progress', priority_id: 2, priority_label: 'Medium', created_at: '2025-12-25', client: { name: 'Centre Oasis' } as any },
  { id: 3, client_id: 3, subject: "Documentation Request", description: "Need PDF user guide for the new SPECTA-V3 centrifuge.", status_id: 3, status_label: 'waiting_client', priority_id: 3, priority_label: 'Low', created_at: '2025-12-25', client: { name: 'Cheikh Zaid' } as any },
];

const COLUMNS: { id: ReclamationStatus; label: string; color: string }[] = [
  { id: 'new', label: 'Nouveau', color: 'bg-red-500' },
  { id: 'in_progress', label: 'En Cours', color: 'bg-amber-500' },
  { id: 'waiting_client', label: 'Attente Client', color: 'bg-blue-500' },
  { id: 'resolved', label: 'Résolu', color: 'bg-green-500' },
];

export default function SAVKanban() {
  const { t, lang } = useApp();
  const [tickets, setTickets] = useState(MOCK_TICKETS);
  const [selectedTicket, setSelectedTicket] = useState<Reclamation | null>(null);
  const [diagnostic, setDiagnostic] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const moveTicket = (id: number, newStatus: ReclamationStatus) => {
    setTickets(prev => prev.map(t => t.id === id ? { ...t, status_label: newStatus } : t));
  };

  const runAIDiagnostic = async (ticket: Reclamation) => {
    setIsAnalyzing(true);
    setDiagnostic(null);
    const result = await getAIDiagnostic(ticket.description, lang);
    setDiagnostic(result);
    setIsAnalyzing(false);
  };

  return (
    <div className="space-y-6 h-full flex flex-col">
      <div className="flex justify-between items-center shrink-0">
        <h1 className="text-2xl font-bold text-slate-800">{t.nav_sav}</h1>
      </div>

      <div className="flex gap-6 flex-1 overflow-x-auto min-h-0 pb-4">
        {COLUMNS.map(col => (
          <div key={col.id} className="w-80 bg-slate-100/50 rounded-3xl flex flex-col p-4 shrink-0 border border-slate-200/50">
            <div className="flex items-center justify-between mb-4 px-2">
              <h3 className="font-bold text-slate-700 flex items-center gap-2">
                <span className={`w-2 h-2 rounded-full ${col.color}`}></span>
                {col.label}
              </h3>
              <span className="bg-white px-2 py-0.5 rounded-lg text-xs font-bold text-slate-500 shadow-sm">
                {tickets.filter(t => t.status_label === col.id).length}
              </span>
            </div>

            <div className="flex-1 space-y-4 overflow-y-auto pr-1 custom-scrollbar">
              {tickets.filter(t => t.status_label === col.id).map(ticket => (
                <div 
                  key={ticket.id} 
                  onClick={() => { setSelectedTicket(ticket); setDiagnostic(null); }}
                  className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200 hover:border-blue-400 hover:shadow-md transition-all cursor-pointer group"
                >
                  <div className="flex justify-between items-start mb-2">
                    <span className={`text-[10px] font-black uppercase tracking-widest ${
                      ticket.priority_label === 'High' ? 'text-red-500' : 'text-slate-400'
                    }`}>
                      {ticket.priority_label}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">#{ticket.id}</span>
                  </div>
                  <h4 className="font-bold text-slate-800 text-sm mb-1 group-hover:text-blue-600 transition-colors">{ticket.subject}</h4>
                  <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed mb-3">{ticket.description}</p>
                  <div className="flex items-center gap-2 pt-3 border-t border-slate-50">
                    <img src={`https://picsum.photos/seed/${ticket.client?.name}/20/20`} className="w-5 h-5 rounded-full" alt="Client" />
                    <span className="text-[11px] font-medium text-slate-600">{ticket.client?.name}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Detail Modal */}
      {selectedTicket && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-6">
          <div className="bg-white w-full max-w-2xl rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="p-8 border-b border-slate-100 flex justify-between items-start">
              <div>
                <h2 className="text-2xl font-bold text-slate-800 mb-1">{selectedTicket.subject}</h2>
                <p className="text-slate-500 font-medium">{selectedTicket.client?.name}</p>
              </div>
              <button onClick={() => setSelectedTicket(null)} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                <svg className="w-6 h-6 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-8 space-y-6">
              <section>
                <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-3">Client Description</h4>
                <div className="bg-slate-50 p-4 rounded-2xl text-slate-700 leading-relaxed italic border border-slate-100">
                  "{selectedTicket.description}"
                </div>
              </section>

              <section className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest">{t.ai_diagnostic}</h4>
                  <button 
                    disabled={isAnalyzing}
                    onClick={() => runAIDiagnostic(selectedTicket)}
                    className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl text-xs font-bold shadow-lg shadow-blue-200 disabled:opacity-50 transition-all hover:scale-105 active:scale-95"
                  >
                    <svg className={`w-4 h-4 ${isAnalyzing ? 'animate-spin' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                    {isAnalyzing ? t.ai_analyzing : t.ai_diagnostic}
                  </button>
                </div>

                {diagnostic && (
                  <div className="bg-indigo-50 border border-indigo-100 p-6 rounded-3xl animate-in fade-in slide-in-from-bottom-4 duration-500">
                    <div className="flex items-center gap-2 text-indigo-600 font-bold text-sm mb-3">
                      <span className="p-1 bg-indigo-600 text-white rounded shadow-sm">AI</span>
                      {t.ai_suggestion}
                    </div>
                    <div className="text-slate-700 text-sm leading-relaxed whitespace-pre-wrap">
                      {diagnostic}
                    </div>
                  </div>
                )}
              </section>
            </div>

            <div className="p-8 border-t border-slate-100 bg-slate-50/50 flex justify-between gap-4">
              <div className="flex gap-2">
                {COLUMNS.map(c => (
                  <button 
                    key={c.id}
                    onClick={() => { moveTicket(selectedTicket.id, c.id); setSelectedTicket(null); }}
                    className={`px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-tight transition-all border ${
                      selectedTicket.status_label === c.id ? 'bg-white border-slate-200 text-slate-800' : 'bg-slate-200 border-transparent text-slate-500 hover:bg-slate-300'
                    }`}
                  >
                    {c.label}
                  </button>
                ))}
              </div>
              <button onClick={() => setSelectedTicket(null)} className="px-6 py-2 bg-slate-800 text-white rounded-xl font-bold text-sm">
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
