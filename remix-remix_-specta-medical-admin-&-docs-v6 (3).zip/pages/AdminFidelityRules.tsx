import React, { useState, useEffect } from 'react';
import { api } from '../api';
import { useApp } from '../App';

interface FidelityRule {
  id: number;
  rule_type: 'earning' | 'redemption';
  name: string;
  description: string;
  is_active: boolean;
  config: {
    amount_per_point?: number; // E.g., earning 1 point per 100 MAD spent
    value_per_point?: number;  // E.g., 1 point redeemed equals 0.5 MAD
    min_order_value?: number;  // Min spend to trigger points
    multiplier?: number;       // Promo points multiplier
  };
}

const DEFAULT_FIDELITY_RULES: FidelityRule[] = [
  {
    id: 1,
    rule_type: 'earning',
    name: 'Standard Loyalty Accumulation',
    description: 'Earn 1 point for every 10 MAD spent on products.',
    is_active: true,
    config: {
      amount_per_point: 10,
      min_order_value: 100,
    }
  },
  {
    id: 2,
    rule_type: 'redemption',
    name: 'Redemption Rewards Cash-out',
    description: 'Redeem 1 point for a discount of 0.1 MAD off checkout total.',
    is_active: true,
    config: {
      value_per_point: 0.1,
    }
  },
  {
    id: 3,
    rule_type: 'earning',
    name: 'VIP Machine Purchase Bonus',
    description: 'Earn double points on all high-end Medical Machine assets.',
    is_active: false,
    config: {
      amount_per_point: 5,
      multiplier: 2,
    }
  }
];

export default function AdminFidelityRules() {
  const { theme, checkPermission, showDenied } = useApp();
  const [rules, setRules] = useState<FidelityRule[]>([]);
  const [loading, setLoading] = useState(true);

  const [modal, setModal] = useState<{
    type: 'add' | 'edit' | 'delete' | null;
    item: FidelityRule | null;
  }>({ type: null, item: null });

  const [formData, setFormData] = useState({
    rule_type: 'earning' as 'earning' | 'redemption',
    name: '',
    description: '',
    is_active: true,
    amount_per_point: 10,
    value_per_point: 0.1,
    min_order_value: 0,
    multiplier: 1,
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const loadData = async () => {
    setLoading(true);
    try {
      const res = await api.fidelityRules.list();
      let rawItems: any[] = [];
      let success = false;

      if (res) {
        if (Array.isArray(res)) {
          rawItems = res;
          success = true;
        } else if (Array.isArray(res.data)) {
          rawItems = res.data;
          success = true;
        } else if (res.status === true && res.data) {
          if (Array.isArray(res.data.data)) {
            rawItems = res.data.data;
            success = true;
          } else if (Array.isArray(res.data)) {
            rawItems = res.data;
            success = true;
          }
        } else if (res.data && Array.isArray(res.data.data)) {
          rawItems = res.data.data;
          success = true;
        }
      }

      if (success) {
        const mapped = rawItems.map((item: any) => {
          let parsedConfig = {};
          if (item.config) {
            if (typeof item.config === 'string') {
              try {
                parsedConfig = JSON.parse(item.config);
              } catch (_) {
                parsedConfig = {};
              }
            } else if (typeof item.config === 'object') {
              parsedConfig = item.config;
            }
          }
          return {
            id: item.id,
            rule_type: item.rule_type || 'earning',
            name: item.name || '',
            description: item.description || '',
            is_active: typeof item.is_active === 'string' 
              ? item.is_active === 'true' || item.is_active === '1' 
              : !!item.is_active,
            config: parsedConfig,
          };
        });

        setRules(mapped);
        localStorage.setItem('specta_fidelity_rules', JSON.stringify(mapped));
      } else {
        throw new Error("Invalid response format");
      }
    } catch (e) {
      const cached = localStorage.getItem('specta_fidelity_rules');
      if (cached) {
        setRules(JSON.parse(cached));
      } else {
        setRules([]);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const saveToLocalStorage = (newRules: FidelityRule[]) => {
    localStorage.setItem('specta_fidelity_rules', JSON.stringify(newRules));
    setRules(newRules);
  };

  const handleOpenModal = (type: 'add' | 'edit' | 'delete', item: FidelityRule | null) => {
    if (type === 'add' && !checkPermission('promotions', 'add')) return showDenied("Add Fidelity Rule");
    if (type === 'edit' && !checkPermission('promotions', 'edit')) return showDenied("Edit Fidelity Rule");
    if (type === 'delete' && !checkPermission('promotions', 'delete')) return showDenied("Delete Fidelity Rule");

    setModal({ type, item });
    if (item) {
      setFormData({
        rule_type: item.rule_type,
        name: item.name,
        description: item.description,
        is_active: item.is_active,
        amount_per_point: item.config.amount_per_point || 10,
        value_per_point: item.config.value_per_point || 0.1,
        min_order_value: item.config.min_order_value || 0,
        multiplier: item.config.multiplier || 1,
      });
    } else {
      setFormData({
        rule_type: 'earning',
        name: '',
        description: '',
        is_active: true,
        amount_per_point: 10,
        value_per_point: 0.1,
        min_order_value: 0,
        multiplier: 1,
      });
    }
  };

  const handleToggleActive = async (rule: FidelityRule) => {
    if (!checkPermission('promotions', 'edit')) return showDenied("Toggle Rule Status");
    const updated = rules.map(r => r.id === rule.id ? { ...r, is_active: !r.is_active } : r);
    saveToLocalStorage(updated);
    try {
      await api.fidelityRules.toggleStatus(rule.id);
    } catch (e) {
      console.log("Offline or non-implemented route; toggled status locally.");
    }
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const configObj: any = {};
      if (formData.rule_type === 'earning') {
        configObj.amount_per_point = formData.amount_per_point;
        if (formData.min_order_value > 0) configObj.min_order_value = formData.min_order_value;
        if (formData.multiplier > 1) configObj.multiplier = formData.multiplier;
      } else {
        configObj.value_per_point = formData.value_per_point;
      }

      if (modal.type === 'add') {
        const newRule: FidelityRule = {
          id: rules.length > 0 ? Math.max(...rules.map(r => r.id)) + 1 : 1,
          rule_type: formData.rule_type,
          name: formData.name,
          description: formData.description,
          is_active: formData.is_active,
          config: configObj,
        };
        const updated = [...rules, newRule];
        saveToLocalStorage(updated);

        try {
          await api.fidelityRules.create({
            rule_type: formData.rule_type,
            name: formData.name,
            description: formData.description,
            is_active: formData.is_active,
            config: JSON.stringify(configObj),
          });
        } catch (e) {
          console.log("Offline or non-implemented route.");
        }
      } else if (modal.type === 'edit' && modal.item) {
        const updated = rules.map(r => r.id === modal.item!.id ? {
          ...r,
          rule_type: formData.rule_type,
          name: formData.name,
          description: formData.description,
          is_active: formData.is_active,
          config: configObj,
        } : r);
        saveToLocalStorage(updated);

        try {
          await api.fidelityRules.update(modal.item.id, {
            rule_type: formData.rule_type,
            name: formData.name,
            description: formData.description,
            is_active: formData.is_active,
            config: JSON.stringify(configObj),
          });
        } catch (e) {
          console.log("Offline or non-implemented route.");
        }
      }
      setModal({ type: null, item: null });
    } catch (err) {
      alert("Error saving rule");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!modal.item) return;
    setIsSubmitting(true);
    try {
      const updated = rules.filter(r => r.id !== modal.item!.id);
      saveToLocalStorage(updated);

      try {
        await api.fidelityRules.delete(modal.item.id);
      } catch (e) {
        console.log("Offline or non-implemented route.");
      }
      setModal({ type: null, item: null });
    } catch (err) {
      alert("Error deleting rule");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-slate-800 tracking-tighter">Dynamic Loyalty Rules</h1>
          <p className="text-slate-400 font-bold uppercase text-[10px] tracking-[3px] opacity-60">
            Configurez les paliers de gain et remboursement du programme de fidélité Specta
          </p>
        </div>
        <button
          onClick={() => handleOpenModal('add', null)}
          className="flex items-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs uppercase tracking-widest rounded-2xl shadow-lg transition-transform active:scale-95"
        >
          <i className="ti ti-plus"></i>
          Nouvelle règle fidélité
        </button>
      </div>

      {/* Rules Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {loading ? (
          <div className="col-span-full py-16 text-center text-slate-400 font-bold text-sm">
            Chargement des barèmes...
          </div>
        ) : rules.length === 0 ? (
          <div className="col-span-full py-16 text-center text-slate-400 font-bold text-sm">
            Aucun barème fidélité configuré actuellement.
          </div>
        ) : (
          rules.map(rule => (
            <div 
              key={rule.id} 
              className={`bg-white rounded-3xl p-6 border transition-all duration-300 shadow-sm relative overflow-hidden flex flex-col justify-between ${
                rule.is_active ? 'border-slate-100 hover:shadow-md' : 'border-slate-100 opacity-60'
              }`}
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className={`px-3 py-1.5 rounded-full text-[9px] font-black uppercase tracking-wider ${
                    rule.rule_type === 'earning' 
                      ? 'bg-blue-50 text-blue-600 border border-blue-100' 
                      : 'bg-emerald-50 text-emerald-600 border border-emerald-100'
                  }`}>
                    {rule.rule_type === 'earning' ? 'Gain de points' : 'Remboursement'}
                  </span>
                  
                  <button
                    onClick={() => handleToggleActive(rule)}
                    className={`w-11 h-6 rounded-full p-0.5 transition-colors focus:outline-none ${rule.is_active ? 'bg-emerald-500' : 'bg-slate-200'}`}
                  >
                    <div className={`w-5 h-5 rounded-full bg-white shadow-sm transform transition-transform duration-200 ${rule.is_active ? 'translate-x-5' : ''}`} />
                  </button>
                </div>

                <div>
                  <h3 className="text-sm font-black text-slate-800 tracking-tight leading-snug">{rule.name}</h3>
                  <p className="text-xs text-slate-400 font-medium leading-relaxed mt-1">{rule.description}</p>
                </div>

                {/* Configuration Specs Render */}
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-2 text-[11px] font-semibold text-slate-600">
                  <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block mb-1">Configuration Actuelle</span>
                  {rule.rule_type === 'earning' ? (
                    <>
                      <div className="flex justify-between items-center">
                        <span>Paliers d'achat:</span>
                        <span className="font-bold text-slate-800">1 pt / {rule.config.amount_per_point} MAD</span>
                      </div>
                      {rule.config.min_order_value && (
                        <div className="flex justify-between items-center">
                          <span>Achat minimum requis:</span>
                          <span className="font-bold text-slate-800">{rule.config.min_order_value} MAD</span>
                        </div>
                      )}
                      {rule.config.multiplier && (
                        <div className="flex justify-between items-center text-amber-600">
                          <span>Multiplicateur Points:</span>
                          <span className="font-bold">x{rule.config.multiplier} Premium</span>
                        </div>
                      )}
                    </>
                  ) : (
                    <div className="flex justify-between items-center">
                      <span>Remboursement:</span>
                      <span className="font-bold text-emerald-600">1 point = {rule.config.value_per_point} MAD</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-6 mt-6 border-t border-slate-50">
                <button
                  onClick={() => handleOpenModal('edit', rule)}
                  className="px-4 py-2 bg-slate-100 hover:bg-blue-50 text-slate-500 hover:text-blue-600 rounded-xl font-black text-[10px] uppercase tracking-wider transition-colors"
                >
                  Modifier
                </button>
                <button
                  onClick={() => handleOpenModal('delete', rule)}
                  className="p-2 bg-slate-100 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded-xl transition-colors"
                >
                  <i className="ti ti-trash"></i>
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Admin Rules Form Dialog Modal */}
      {modal.type && (modal.type === 'add' || modal.type === 'edit') && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl overflow-hidden max-w-md w-full border border-slate-100 animate-in zoom-in-95">
            <div className="p-6 bg-slate-50/50 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-lg font-black text-slate-800 tracking-tight">
                {modal.type === 'add' ? 'Créer une règle fidélité' : 'Modifier la configuration'}
              </h2>
              <button
                onClick={() => setModal({ type: null, item: null })}
                className="w-8 h-8 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-400 hover:text-slate-600 transition-colors"
              >
                <i className="ti ti-x text-lg"></i>
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="p-6 space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Type de règle</label>
                <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1 rounded-2xl border">
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, rule_type: 'earning' })}
                    className={`py-2 text-[10px] font-black uppercase tracking-wider rounded-xl transition-all ${
                      formData.rule_type === 'earning' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-500'
                    }`}
                  >
                    Gain de points
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, rule_type: 'redemption' })}
                    className={`py-2 text-[10px] font-black uppercase tracking-wider rounded-xl transition-all ${
                      formData.rule_type === 'redemption' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-500'
                    }`}
                  >
                    Remboursement (Cash)
                  </button>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Intitulé de la Règle</label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Gain Standard Médical"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-slate-50 border-0 focus:ring-2 focus:ring-blue-500 rounded-2xl px-4 py-3 text-xs font-bold text-slate-700"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Description explicative</label>
                <textarea
                  required
                  rows={2}
                  placeholder="Ex: Recevez 1 point pour chaque tranche de 10 MAD d'achats..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full bg-slate-50 border-0 focus:ring-2 focus:ring-blue-500 rounded-2xl px-4 py-3 text-xs font-bold text-slate-700 focus:outline-none"
                />
              </div>

              {/* Dynamic rule configuration parameters */}
              {formData.rule_type === 'earning' ? (
                <div className="space-y-3 bg-blue-50/40 p-4 border border-blue-100/50 rounded-2xl animate-in fade-in duration-300">
                  <span className="text-[8px] font-black text-blue-600 uppercase tracking-wider block">Paramétrage d'Acquisition</span>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-slate-500 uppercase">Val. MAD pour 1 pt</label>
                      <input
                        type="number"
                        min="1"
                        required
                        value={formData.amount_per_point}
                        onChange={(e) => setFormData({ ...formData, amount_per_point: parseInt(e.target.value) || 1 })}
                        className="w-full bg-white border border-slate-200 focus:ring-2 focus:ring-blue-500 rounded-xl px-3 py-2 text-xs font-bold text-slate-700"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-slate-500 uppercase">Achat Min Requis</label>
                      <input
                        type="number"
                        min="0"
                        value={formData.min_order_value}
                        onChange={(e) => setFormData({ ...formData, min_order_value: parseInt(e.target.value) || 0 })}
                        className="w-full bg-white border border-slate-200 focus:ring-2 focus:ring-blue-500 rounded-xl px-3 py-2 text-xs font-bold text-slate-700"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-slate-500 uppercase block">Bonus multiplicateur promotions</label>
                    <input
                      type="number"
                      min="1"
                      step={0.5}
                      value={formData.multiplier}
                      onChange={(e) => setFormData({ ...formData, multiplier: parseFloat(e.target.value) || 1 })}
                      className="w-full bg-white border border-slate-200 focus:ring-2 focus:ring-blue-500 rounded-xl px-3 py-2 text-xs font-bold text-slate-700"
                    />
                  </div>
                </div>
              ) : (
                <div className="space-y-3 bg-emerald-50/40 p-4 border border-emerald-100/50 rounded-2xl animate-in fade-in duration-300">
                  <span className="text-[8px] font-black text-emerald-600 uppercase tracking-wider block">Paramétrage Conversion (MAD)</span>
                  
                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-slate-500 block">Valeur financière d'un point (MAD)</label>
                    <input
                      type="number"
                      min="0.01"
                      step="0.01"
                      required
                      value={formData.value_per_point}
                      onChange={(e) => setFormData({ ...formData, value_per_point: parseFloat(e.target.value) || 0.01 })}
                      className="w-full bg-white border border-slate-200 focus:ring-2 focus:ring-emerald-500 rounded-xl px-3 py-2 text-xs font-bold text-slate-700"
                    />
                    <span className="text-[9px] text-slate-400 block pt-1">
                      Ex: si 1 point = 0.5 MAD, alors 100 points appliquent un rabais de 50 MAD en caisse.
                    </span>
                  </div>
                </div>
              )}

              <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setModal({ type: null, item: null })}
                  className="px-6 py-3 border border-slate-200 text-slate-500 hover:text-slate-800 font-bold text-xs uppercase tracking-widest rounded-2xl transition-all"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs uppercase tracking-widest rounded-2xl shadow-lg transition-all disabled:opacity-50"
                >
                  {isSubmitting ? 'Publication...' : 'Enregistrer la Règle'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Rules Delete Modal */}
      {modal.type === 'delete' && modal.item && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-8 max-w-sm w-full border border-slate-100 text-center animate-in zoom-in-95">
            <div className="w-16 h-16 bg-rose-50 text-rose-500 rounded-2xl flex items-center justify-center text-3xl mx-auto mb-4">
              <i className="ti ti-trash"></i>
            </div>
            <h3 className="text-lg font-black text-slate-800 tracking-tight">Supprimer la règle ?</h3>
            <p className="text-slate-400 font-medium text-xs leading-relaxed mt-2 mb-8">
              Confirmez-vous la suppression de la règle de barème <span className="font-bold text-slate-700">{modal.item.name}</span> ?
            </p>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setModal({ type: null, item: null })}
                className="flex-1 py-4 border border-slate-100 text-slate-400 hover:text-slate-700 font-black text-[10px] uppercase tracking-wider rounded-2xl transition-all"
              >
                Annuler
              </button>
              <button
                onClick={handleDelete}
                disabled={isSubmitting}
                className="flex-1 py-4 bg-rose-600 hover:bg-rose-700 text-white font-black text-[10px] uppercase tracking-wider rounded-2xl shadow-lg transition-all disabled:opacity-50"
              >
                Supprimer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
