
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api';
import { useApp } from '../App';

export default function Login() {
  const { t, lang, setLang, setUser } = useApp();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const data = await api.auth.login({ email, password });
      
      // CRITICAL: Check if role is Administrateur (role_id 1)
      if (data.user.role_id !== 1) {
          setError("Accès refusé: Ce portail est réservé aux administrateurs Specta.");
          setLoading(false);
          return;
      }

      api.setToken(data.token);
      localStorage.setItem('specta_user', JSON.stringify(data.user));
      setUser(data.user);
      navigate('/admin/dashboard');
    } catch (err: any) {
      setError(t.login_error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex bg-[#0f172a] overflow-hidden relative font-sans">
      {/* BACKGROUND ELEMENTS */}
      <div className="absolute top-[-10%] right-[-5%] w-[60vw] h-[60vw] lg:w-[40vw] lg:h-[40vw] bg-blue-600 rounded-full blur-[120px] opacity-20 animate-float"></div>
      <div className="absolute bottom-[-5%] left-[-5%] w-[50vw] h-[50vw] lg:w-[30vw] lg:h-[30vw] bg-indigo-600 rounded-full blur-[100px] opacity-10 animate-float" style={{ animationDelay: '2s' }}></div>

      <div className="hidden lg:flex lg:w-1/2 flex-col justify-center p-12 xl:p-24 z-10">
        <div className="animate-in fade-in slide-in-from-left-8 duration-1000">
           <img src="https://specta.ma/images/Specta_logo.webp" className="h-12 xl:h-14 mb-8 xl:mb-12 brightness-0 invert" alt="Specta" />
           <h1 className="text-3xl xl:text-5xl font-black text-white leading-tight mb-6">
             {t.hero_title.split('.').map((part, i) => i === 0 ? <span key={i}>{part}<br/></span> : <span key={i} className="text-blue-500">{part}</span>)}
           </h1>
           <p className="text-slate-400 text-lg max-w-md leading-relaxed">
             {t.hero_subtitle}
           </p>
        </div>
      </div>

      <div className="w-full lg:w-1/2 flex items-center justify-center p-4 sm:p-8 z-10 relative">
        <div className="absolute top-6 right-6 lg:top-8 lg:right-8 animate-in fade-in duration-1000">
           <button 
             onClick={() => setLang(lang === 'en' ? 'fr' : 'en')} 
             className="flex items-center gap-2 px-4 py-2 bg-white/5 backdrop-blur-xl border border-white/10 rounded-xl text-[10px] font-black uppercase tracking-widest text-slate-300 hover:bg-white/10 transition-all active:scale-95 shadow-2xl"
           >
              <i className="ti ti-language text-sm"></i> {lang === 'en' ? 'FR' : 'EN'}
           </button>
        </div>

        <div className="w-full max-w-md animate-in zoom-in-95 duration-700">
          <div className="bg-white/10 backdrop-blur-2xl p-8 sm:p-10 rounded-2xl sm:rounded-3xl border border-white/10 shadow-2xl space-y-8">
            <div className="space-y-2 text-center lg:text-left">
              <img src="https://specta.ma/images/Specta_logo.webp" className="h-8 mb-6 brightness-0 invert mx-auto lg:hidden" alt="Specta" />
              <h2 className="text-2xl sm:text-3xl font-black text-white">{t.welcome_back}</h2>
              <p className="text-slate-400 font-bold uppercase text-[9px] sm:text-[10px] tracking-[2px]">{t.admin_portal}</p>
            </div>

            {error && (
              <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-4 rounded-xl text-xs font-bold flex items-center gap-3 animate-shake">
                <i className="ti ti-alert-triangle text-lg"></i> {error}
              </div>
            )}

            <form onSubmit={handleLogin} className="space-y-5">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-[2px] ml-4">{t.email}</label>
                <div className="relative group">
                  <i className="ti ti-mail absolute left-5 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-blue-500 transition-colors"></i>
                  <input 
                    type="email" 
                    value={email} 
                    onChange={e => setEmail(e.target.value)} 
                    className="w-full pl-12 sm:pl-14 pr-6 py-3 sm:py-4 bg-white/5 border border-white/10 rounded-xl sm:rounded-2xl focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-white placeholder-slate-600 outline-none text-sm"
                    placeholder="name@company.com"
                    required 
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-[2px] ml-4">{t.password}</label>
                <div className="relative group">
                  <i className="ti ti-lock absolute left-5 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-blue-500 transition-colors"></i>
                  <input 
                    type={showPassword ? "text" : "password"} 
                    value={password} 
                    onChange={e => setPassword(e.target.value)} 
                    className="w-full pl-12 sm:pl-14 pr-12 sm:pr-14 py-3 sm:py-4 bg-white/5 border border-white/10 rounded-xl sm:rounded-2xl focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-white placeholder-slate-600 outline-none text-sm"
                    placeholder="••••••••"
                    required 
                  />
                  <button 
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-blue-500 transition-colors focus:outline-none"
                  >
                    <i className={`ti ${showPassword ? 'ti-eye-off' : 'ti-eye'} text-xl`}></i>
                  </button>
                </div>
              </div>

              <button 
                type="submit" 
                disabled={loading}
                className="w-full bg-blue-600 text-white py-3 sm:py-4 rounded-xl sm:rounded-2xl font-black text-xs sm:text-sm uppercase tracking-[2px] hover:bg-blue-500 transition-all shadow-xl shadow-blue-900/20 disabled:opacity-50 transform active:scale-95 flex items-center justify-center gap-3 overflow-hidden group mt-4"
              >
                {loading ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                ) : (
                    <>
                        {t.login}
                        <i className="ti ti-arrow-right group-hover:translate-x-2 transition-transform"></i>
                    </>
                )}
              </button>
            </form>
          </div>
          
          <div className="mt-8 text-center animate-in fade-in duration-1000 delay-500">
             <p className="text-slate-500 text-[10px] sm:text-xs font-medium px-4">
               Specta Medical Solutions &copy; 2024. All systems operational.
             </p>
          </div>
        </div>
      </div>
    </div>
  );
}