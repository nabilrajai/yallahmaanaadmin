
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { api } from '../api';
import { useApp } from '../App';
import { Product, Category, Brand } from '../types';

export default function AdminProducts() {
  const { t, checkPermission, showDenied, theme } = useApp();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [brands, setBrands] = useState<Brand[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [modal, setModal] = useState<{ type: 'add' | 'edit' | 'view' | 'delete' | null, item: any }>({ type: null, item: null });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isPrintPreview, setIsPrintPreview] = useState(false);
  const [filters, setFilters] = useState({ search: '', category_id: '', brand_id: '' });
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [pRes, cRes, bRes] = await Promise.all([
        api.products.list(`search=${filters.search}&category_id=${filters.category_id}&brand_id=${filters.brand_id}&per_page=500`),
        api.categories.list('per_page=100'),
        api.brands.list('per_page=100')
      ]);
      setProducts(pRes.data?.data || pRes.data || pRes || []);
      setCategories(cRes.data || cRes || []);
      setBrands(bRes.data || bRes || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const timer = setTimeout(fetchData, 400);
    return () => clearTimeout(timer);
  }, [filters]);

  const getFullUrl = (path: string) => {
    if (!path) return 'https://placehold.co/400x400?text=NO+IMAGE';
    if (path.startsWith('http')) return path;
    return `https://birdeye-intelligence.ma/Spetcapp/Backend/storage/app/public/${path}`;
  };

  const handleOpenModal = (type: 'add' | 'edit' | 'delete' | 'view', item: any) => {
      if (type === 'add' && !checkPermission('products', 'add')) return showDenied("Ajouter Consommable");
      if (type === 'edit' && !checkPermission('products', 'edit')) return showDenied("Modifier Consommable");
      if (type === 'delete' && !checkPermission('products', 'delete')) return showDenied("Supprimer Consommable");
      
      setModal({ type, item });
      if (type === 'edit' || type === 'view') {
        setImagePreview(getFullUrl(item.image_url));
      } else {
        setImagePreview(null);
      }
  };

  const closeModalAndCleanup = () => {
    setModal({ type: null, item: null });
    if (imagePreview && imagePreview.startsWith('blob:')) {
      URL.revokeObjectURL(imagePreview);
    }
    setImagePreview(null);
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (imagePreview && imagePreview.startsWith('blob:')) {
        URL.revokeObjectURL(imagePreview);
      }
      setImagePreview(URL.createObjectURL(file));
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    const form = e.target as HTMLFormElement;
    const elements = form.elements as any;
    
    const formData = new FormData();
    
    // Manually append all fields from the form
    formData.append('name', elements.name.value);
    formData.append('sku', elements.sku.value);
    formData.append('price_ht', elements.price_ht.value);
    formData.append('stock_qty', elements.stock_qty.value);
    formData.append('stock_alert_threshold', elements.stock_alert_threshold.value);
    formData.append('category_id', elements.category_id.value);
    formData.append('brand_id', elements.brand_id.value);
    formData.append('description', elements.description.value);

    // Explicitly check for an image file and only append if one exists.
    // This prevents sending an empty file and triggering backend validation.
    const imageFile = elements.image.files[0];
    if (imageFile) {
      formData.append('image', imageFile);
    }
    
    try {
      if (modal.type === 'add') {
        await api.products.create(formData);
      } else {
        await api.products.update(modal.item.id, formData);
      }
      closeModalAndCleanup();
      fetchData();
    } catch (e: any) {
      alert(e.message || "Error saving product");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async () => {
    setIsSubmitting(true);
    try {
      await api.products.delete(modal.item.id);
      closeModalAndCleanup();
      fetchData();
    } catch (e) {
      alert("Error deleting product");
    } finally {
      setIsSubmitting(false);
    }
  };

  const stats = useMemo(() => {
    const totalVal = products.reduce((acc, p) => acc + ((p.price_ht || p.price_ttc || 0) * p.stock_qty), 0);
    return {
        total: products.length,
        lowStock: products.filter(p => p.stock_qty <= (p.stock_alert_threshold || 5)).length,
        outOfStock: products.filter(p => p.stock_qty === 0).length,
        value: totalVal
    };
  }, [products]);

  if (isPrintPreview) {
    return (
      <div className="fixed inset-0 z-[200] bg-slate-600 overflow-y-auto preview-mode-active p-10 print:p-0">
        <div className="fixed top-8 left-1/2 -translate-x-1/2 flex items-center gap-6 bg-slate-900 text-white px-10 py-5 rounded-[2rem] shadow-2xl z-[210] border border-white/10 no-print">
            <div className="flex flex-col">
                <span className="text-[10px] font-black uppercase tracking-[2.5px] text-amber-500">Manual Print Required</span>
                <span className="text-sm font-bold text-slate-300">Press <kbd className="bg-white/20 px-2 rounded mx-1">Ctrl + P</kbd> to save PDF</span>
            </div>
            <button onClick={() => setIsPrintPreview(false)} className="bg-white/10 hover:bg-white/20 px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all">Exit Preview</button>
        </div>

        <div className="preview-paper mx-auto bg-white min-h-[297mm] w-[210mm] shadow-2xl p-[20mm] relative">
            <div className="flex justify-between items-center mb-12 border-b-4 border-blue-600 pb-10">
                <img src="https://specta.ma/images/Specta_logo.webp" className="h-16" alt="Specta Logo" />
                <div className="text-right">
                    <h1 className="text-3xl font-black text-slate-900 uppercase tracking-tighter">Inventory Audit</h1>
                    <p className="text-slate-500 text-sm font-bold uppercase tracking-widest">{new Date().toLocaleDateString()}</p>
                </div>
            </div>
            <table className="w-full text-left border-collapse">
                <thead>
                    <tr className="bg-slate-50 border-y border-slate-200 text-[10px] font-black uppercase tracking-widest text-slate-400">
                        <th className="px-4 py-4 w-24">Item</th>
                        <th className="px-4 py-4">SKU</th>
                        <th className="px-4 py-4">Designation</th>
                        <th className="px-4 py-4 text-right">Price (TTC)</th>
                        <th className="px-4 py-4 text-center">Qty</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                    {products.map(p => (
                        <tr key={p.id}>
                            <td className="px-4 py-4"><img src={getFullUrl(p.image_url)} className="w-12 h-12 object-contain bg-slate-50 rounded-lg" /></td>
                            <td className="px-4 py-4 font-mono text-[10px]">{p.sku}</td>
                            <td className="px-4 py-4 font-bold text-xs uppercase">{p.name}</td>
                            <td className="px-4 py-4 text-right font-black text-xs">{(p.price_ht || p.price_ttc || 0).toLocaleString()} MAD</td>
                            <td className="px-4 py-4 text-center font-bold text-xs">{p.stock_qty}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-700 pb-20 no-print">
      {/* STATS HUD */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <CompactStat label="Catalog Size" value={stats.total} icon="ti-package" color="bg-blue-600" />
          <CompactStat label="Low Stock" value={stats.lowStock} icon="ti-alert-triangle" color="bg-amber-500" />
          <CompactStat label="Inventory Value" value={`${Math.round(stats.value).toLocaleString()} MAD`} icon="ti-wallet" color="bg-emerald-600" />
          <CompactStat label="Stock Out" value={stats.outOfStock} icon="ti-shopping-cart-off" color="bg-rose-600" />
      </div>

      {/* ACTION BAR */}
      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-6 bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
        <div>
          <h1 className="text-2xl font-black text-slate-800 tracking-tighter">Product Inventory</h1>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-[4px] opacity-70">Commercial Assets & Consumable Registry</p>
        </div>
        
        <div className="flex flex-wrap gap-3">
            <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200">
                <button onClick={() => setViewMode('grid')} className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'grid' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}>
                   <i className="ti ti-layout-grid text-sm mr-2"></i> Grid
                </button>
                <button onClick={() => setViewMode('list')} className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'list' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}>
                   <i className="ti ti-list text-sm mr-2"></i> List
                </button>
            </div>
            
            <button onClick={() => setIsPrintPreview(true)} className="px-5 py-3 bg-slate-900 text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-slate-800 transition-all flex items-center gap-2 shadow-lg active:scale-95">
                <i className="ti ti-printer text-lg"></i> Audit PDF
            </button>

            <button onClick={() => handleOpenModal('add', { is_active: 1, tax_rate: 20, stock_alert_threshold: 5 })} className="bg-blue-600 text-white px-6 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all flex items-center gap-2 active:scale-95">
                <i className="ti ti-plus text-lg"></i> Add Item
            </button>
        </div>
      </div>

      {/* FILTER HUB */}
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100 flex flex-col md:flex-row gap-4 items-center">
        <div className="flex-1 relative w-full">
          <i className="ti ti-search absolute left-5 top-1/2 -translate-y-1/2 text-blue-600 text-xl"></i>
          <input 
            type="text" 
            placeholder="Recherche par SKU, Nom ou Description..." 
            className="w-full pl-14 pr-6 py-4 bg-slate-50 border-none rounded-xl outline-none focus:ring-4 focus:ring-blue-500/5 font-bold text-sm shadow-inner" 
            value={filters.search} 
            onChange={e => setFilters({ ...filters, search: e.target.value })} 
          />
        </div>
        <div className="flex gap-4 w-full md:w-auto">
            <select className="bg-slate-50 border-none rounded-xl px-5 py-4 outline-none font-black text-[10px] uppercase tracking-widest text-slate-600 shadow-inner flex-1 md:w-56" value={filters.category_id} onChange={e => setFilters({ ...filters, category_id: e.target.value })}>
              <option value="">All Categories</option>
              {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
            <button onClick={fetchData} className="w-14 h-14 bg-slate-50 text-slate-400 hover:text-blue-600 rounded-full flex items-center justify-center transition-all border border-slate-100 shadow-sm active:scale-90"><i className="ti ti-refresh text-2xl"></i></button>
        </div>
      </div>

      {/* CONTENT VIEWPORT */}
      {loading ? (
        <div className="py-40 text-center space-y-4">
            <div className="animate-spin h-14 w-14 border-t-4 border-blue-600 rounded-full mx-auto"></div>
            <p className="text-[10px] font-black uppercase tracking-[5px] text-slate-400">Scanning Inventory Node...</p>
        </div>
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-8">
            {products.map(p => (
                <div key={p.id} className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden hover:shadow-lg transition-all duration-700 group flex flex-col relative h-full">
                    <div className="h-40 bg-slate-50 flex items-center justify-center p-6 relative overflow-hidden group-hover:bg-slate-100 transition-colors">
                        <img src={getFullUrl(p.image_url)} className="w-full h-full object-contain group-hover:scale-110 transition-transform duration-1000" alt={p.name} />
                        <div className="absolute top-4 left-4">
                            <span className="px-3 py-1 bg-white/90 backdrop-blur shadow-sm border border-slate-100 rounded-full text-[8px] font-black text-slate-400 uppercase tracking-widest">{p.sku}</span>
                        </div>
                        <div className="absolute top-4 right-4 flex flex-col gap-2 translate-x-12 opacity-0 group-hover:translate-x-0 group-hover:opacity-100 transition-all duration-300">
                            <button onClick={() => handleOpenModal('edit', p)} className="w-10 h-10 rounded-xl bg-white text-blue-600 flex items-center justify-center shadow-xl hover:bg-blue-600 hover:text-white transition-all"><i className="ti ti-edit text-lg"></i></button>
                            <button onClick={() => handleOpenModal('delete', p)} className="w-10 h-10 rounded-xl bg-white text-rose-500 flex items-center justify-center shadow-xl hover:bg-rose-500 hover:text-white transition-all"><i className="ti ti-trash text-lg"></i></button>
                        </div>
                    </div>
                    <div className="p-5 space-y-4 flex-1 flex flex-col">
                        <div className="space-y-1">
                            <h3 className="text-xs font-black text-slate-800 leading-tight uppercase line-clamp-2 min-h-[2rem]">{p.name}</h3>
                            <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{categories.find(c => c.id === p.category_id)?.name || 'General Inventory'}</p>
                        </div>

                        <div className="flex justify-between items-end border-t border-slate-50 pt-4 mt-auto">
                            <div>
                                <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">Price Unit.</p>
                                <p className="text-sm font-black text-blue-600 tracking-tight">{(p.price_ht || p.price_ttc || 0).toLocaleString()} <span className="text-[9px] opacity-40">MAD</span></p>
                            </div>
                            <div className="text-right">
                                <span className={`px-3 py-1 rounded-lg text-[8px] font-black uppercase tracking-widest ${p.stock_qty <= (p.stock_alert_threshold || 5) ? 'bg-rose-50 text-rose-600' : 'bg-emerald-50 text-emerald-600'}`}>
                                    {p.stock_qty} in stock
                                </span>
                            </div>
                        </div>
                        <button onClick={() => handleOpenModal('view', p)} className="w-full py-2.5 bg-slate-900 text-white rounded-lg font-black text-[9px] uppercase tracking-[2px] active:scale-95 transition-all shadow-lg hover:shadow-slate-300">View Protocol</button>
                    </div>
                </div>
            ))}
        </div>
      ) : (
        <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden animate-in slide-in-from-bottom-6">
            <table className="w-full text-left">
                <thead className="bg-slate-50/50 border-b">
                    <tr className="text-[10px] font-black text-slate-400 uppercase tracking-[2px]">
                        <th className="px-6 py-4">Reference</th>
                        <th className="px-6 py-4">Product Details</th>
                        <th className="px-6 py-4 text-right">Value (TTC)</th>
                        <th className="px-6 py-4 text-center">Inventory</th>
                        <th className="px-6 py-4 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                    {products.map(p => (
                        <tr key={p.id} className="hover:bg-slate-50/50 transition-colors group">
                            <td className="px-6 py-4">
                                <div className="flex items-center gap-5">
                                    <div className="w-14 h-14 rounded-2xl bg-slate-50 flex items-center justify-center p-2 border border-slate-100 shrink-0">
                                        <img src={getFullUrl(p.image_url)} className="w-full h-full object-contain" alt="" />
                                    </div>
                                    <span className="font-mono text-[10px] font-bold text-slate-400">{p.sku}</span>
                                </div>
                            </td>
                            <td className="px-6 py-4">
                                <p className="font-black text-slate-800 text-xs uppercase leading-tight mb-1">{p.name}</p>
                                <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{categories.find(c => c.id === p.category_id)?.name || 'General'}</p>
                            </td>
                            <td className="px-6 py-4 text-right">
                                <p className="font-black text-blue-600 text-sm tracking-tight">{(p.price_ht || p.price_ttc || 0).toLocaleString()} MAD</p>
                            </td>
                            <td className="px-6 py-4 text-center">
                                <span className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest ${p.stock_qty <= (p.stock_alert_threshold || 5) ? 'bg-rose-50 text-rose-600' : 'bg-emerald-50 text-emerald-600'}`}>
                                    {p.stock_qty} Units
                                </span>
                            </td>
                            <td className="px-6 py-4 text-right">
                                <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-all">
                                    <button onClick={() => handleOpenModal('view', p)} className="p-3 text-blue-600 bg-blue-50 rounded-xl hover:bg-blue-600 hover:text-white transition-all"><i className="ti ti-eye text-lg"></i></button>
                                    <button onClick={() => handleOpenModal('edit', p)} className="p-3 text-slate-500 bg-slate-50 rounded-xl hover:bg-slate-800 hover:text-white transition-all"><i className="ti ti-edit text-lg"></i></button>
                                    <button onClick={() => handleOpenModal('delete', p)} className="p-3 text-rose-500 bg-rose-50 rounded-xl hover:bg-rose-600 hover:text-white transition-all"><i className="ti ti-trash text-lg"></i></button>
                                </div>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
      )}

      {/* MODALS */}
      {modal.type && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[150] flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className={`bg-white w-full ${modal.type === 'view' ? 'max-w-4xl' : 'max-w-2xl'} rounded-3xl shadow-2xl overflow-hidden border-4 border-white flex flex-col max-h-[95vh] animate-in zoom-in-95 duration-300`}>
            
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50 shrink-0">
                <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-blue-600 text-white rounded-[1.25rem] flex items-center justify-center text-2xl shadow-lg shadow-blue-100">
                        <i className={modal.type === 'delete' ? 'ti ti-trash' : (modal.type === 'view' ? 'ti ti-eye' : 'ti ti-package')}></i>
                    </div>
                    <h2 className="text-xl font-black uppercase text-[10px] tracking-[5px] text-slate-800">{modal.type} Product Protocol</h2>
                </div>
                <button onClick={closeModalAndCleanup} className="w-12 h-12 flex items-center justify-center bg-white rounded-full text-slate-300 hover:text-rose-500 shadow-xl transition-all text-2xl font-light hover:rotate-90">×</button>
            </div>

            <div className="p-8 overflow-y-auto custom-scrollbar flex-1">
              {modal.type === 'delete' ? (
                <div className="text-center py-8 space-y-8">
                  <div className="w-20 h-20 bg-rose-50 text-rose-500 rounded-2xl flex items-center justify-center mx-auto text-5xl shadow-inner animate-bounce"><i className="ti ti-trash"></i></div>
                  <div className="space-y-2">
                    <h3 className="text-xl font-black text-slate-800 tracking-tighter">Purge Data Node?</h3>
                    <p className="text-slate-500 font-medium italic">Confirming the removal of <span className="text-rose-600 font-black">"{modal.item.name}"</span> from the global inventory system.</p>
                  </div>
                  <div className="flex gap-4 pt-4 max-w-sm mx-auto">
                    <button onClick={closeModalAndCleanup} className="flex-1 py-4 bg-slate-50 text-slate-400 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-slate-100 transition-all active:scale-95">Abandon</button>
                    <button onClick={handleDelete} className="flex-1 py-4 bg-rose-600 text-white rounded-xl font-black text-[10px] uppercase tracking-widest shadow-2xl active:scale-95 transition-all">Confirm Purge</button>
                  </div>
                </div>
              ) : modal.type === 'view' ? (
                <div className="space-y-12">
                   <div className="flex flex-col lg:flex-row gap-12 items-start">
                        <div className="w-full lg:w-72 bg-slate-50 rounded-2xl border border-slate-100 p-6 flex items-center justify-center shrink-0 shadow-inner group">
                            <img src={imagePreview || 'https://placehold.co/400x400?text=NO+IMAGE'} className="w-full max-h-80 object-contain transition-transform duration-1000 group-hover:scale-105" alt="" />
                        </div>
                        <div className="flex-1 space-y-6">
                            <div className="space-y-2">
                                <span className="px-4 py-1.5 bg-blue-50 text-blue-600 rounded-full text-[9px] font-black uppercase tracking-widest border border-blue-100">SKU Node: {modal.item.sku}</span>
                                <h3 className="text-2xl font-black text-slate-800 tracking-tighter leading-tight uppercase">{modal.item.name}</h3>
                                <p className="text-slate-400 font-bold uppercase text-[10px] tracking-[4px]">{categories.find(c => c.id === modal.item.category_id)?.name || 'Unclassified'}</p>
                            </div>

                            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                                 <DataCard label="Current MSRP" value={`${(modal.item.price_ht || modal.item.price_ttc || 0).toLocaleString()} MAD`} color="text-blue-600" />
                                 <DataCard label="Stock Integrity" value={`${modal.item.stock_qty} Units`} color={modal.item.stock_qty <= (modal.item.stock_alert_threshold || 5) ? "text-rose-500" : "text-emerald-500"} />
                                 <DataCard label="Min. Threshold" value={modal.item.stock_alert_threshold || 5} color="text-slate-400" />
                            </div>

                            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 relative overflow-hidden">
                                 <h4 className="text-[9px] font-black text-slate-400 uppercase tracking-[4px] mb-4 flex items-center gap-2"><i className="ti ti-notes text-lg"></i> Commercial Description</h4>
                                 <p className="text-slate-600 text-sm leading-relaxed italic font-medium relative z-10">"{modal.item.description || 'No specific technical documentation provided for this item node.'}"</p>
                                 <i className="ti ti-quote text-6xl text-slate-100 absolute -bottom-4 -right-4"></i>
                            </div>
                        </div>
                   </div>
                </div>
              ) : (
                <form onSubmit={handleSave} className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Product Designation</label>
                    <input name="name" defaultValue={modal.item.name} className="w-full px-6 py-4 bg-slate-50 border-none rounded-xl outline-none font-black text-lg shadow-inner placeholder-slate-300" required placeholder="Asset full name..." />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">SKU / Unique Identifier</label>
                      <input name="sku" defaultValue={modal.item.sku} className="w-full px-6 py-3 bg-slate-50 border-none rounded-lg outline-none font-mono text-sm font-bold shadow-inner" required placeholder="e.g. SPCT-XYZ-01" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-blue-600 uppercase tracking-widest ml-6">Catalogue Price (TTC)</label>
                      <input name="price_ht" type="number" step="0.01" defaultValue={modal.item.price_ht || modal.item.price_ttc} className="w-full px-6 py-3 bg-blue-50 border-none rounded-lg outline-none font-black text-blue-700 text-base shadow-inner" required placeholder="0.00" />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Stock Available</label>
                        <input name="stock_qty" type="number" defaultValue={modal.item.stock_qty} className="w-full px-6 py-3 bg-slate-50 border-none rounded-lg outline-none font-bold shadow-inner" />
                    </div>
                    <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Low Stock Alert Threshold</label>
                        <input name="stock_alert_threshold" type="number" defaultValue={modal.item.stock_alert_threshold || 5} className="w-full px-6 py-3 bg-slate-50 border-none rounded-lg outline-none font-bold shadow-inner" />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Taxonomy Category</label>
                        <select name="category_id" defaultValue={modal.item.category_id} className="w-full px-6 py-3 bg-slate-50 border-none rounded-lg outline-none font-black text-xs uppercase tracking-widest shadow-inner appearance-none">
                            <option value="">-- No Category --</option>
                            {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                        </select>
                    </div>
                    <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Corporate Brand</label>
                        <select name="brand_id" defaultValue={modal.item.brand_id} className="w-full px-6 py-3 bg-slate-50 border-none rounded-lg outline-none font-black text-xs uppercase tracking-widest shadow-inner appearance-none">
                            <option value="">-- No Brand --</option>
                            {brands.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                        </select>
                    </div>
                  </div>

                  <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Detailed Description</label>
                      <textarea name="description" defaultValue={modal.item.description} className="w-full px-6 py-4 bg-slate-50 border-none rounded-xl outline-none font-medium h-24 italic shadow-inner text-sm" placeholder="Commercial specs..." />
                  </div>

                  <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100 flex flex-col md:flex-row items-center gap-6 shadow-inner">
                        <div className="w-24 h-24 bg-white rounded-xl overflow-hidden shadow-xl border-4 border-white flex items-center justify-center shrink-0">
                            <img src={imagePreview || 'https://placehold.co/400x400?text=NO+IMAGE'} className="w-full h-full object-contain" alt="" />
                        </div>
                        <div className="flex-1 space-y-4 w-full">
                            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">Product Visual</p>
                            <label className="w-full py-3 px-6 bg-slate-900 text-white rounded-lg font-black uppercase text-[10px] tracking-[3px] cursor-pointer hover:bg-blue-600 transition-all block text-center shadow-xl active:scale-95">
                                Syndicate Image File
                                <input name="image" type="file" className="hidden" accept="image/*" onChange={handleImageChange} />
                            </label>
                        </div>
                  </div>

                  <button type="submit" disabled={isSubmitting} className="w-full py-5 bg-blue-600 text-white rounded-2xl font-black uppercase text-xs tracking-[4px] shadow-[0_20px_50px_-10px_rgba(37,99,235,0.4)] active:scale-95 transition-all mt-4">
                    {isSubmitting ? 'Syncing...' : 'Commit Protocol'}
                  </button>
                </form>
              )}
            </div>

            <div className="p-6 border-t bg-slate-50 flex justify-center shrink-0">
                <button onClick={closeModalAndCleanup} className="px-16 py-3 bg-white border border-slate-200 text-slate-400 rounded-xl font-black uppercase text-[10px] tracking-[3px] active:scale-95 transition-all shadow-sm">Exit Insight</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function CompactStat({ label, value, icon, color }: any) {
    return (
        <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm flex items-center gap-4 group hover:shadow-lg transition-all relative overflow-hidden">
            <div className={`w-12 h-12 rounded-[1.25rem] ${color} flex items-center justify-center text-white text-xl shadow-lg transition-transform group-hover:rotate-12`}>
                <i className={`ti ${icon}`}></i>
            </div>
            <div className="min-w-0">
                <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-0.5 truncate">{label}</p>
                <p className="text-lg font-black text-slate-800 tracking-tighter truncate leading-none">{value}</p>
            </div>
            <div className={`absolute -right-6 -bottom-6 w-20 h-20 ${color} opacity-5 rounded-full`}></div>
        </div>
    );
}

function DataCard({ label, value, color }: any) {
    return (
        <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm text-center">
            <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest mb-2 leading-none">{label}</p>
            <p className={`text-xs font-black tracking-tight ${color}`}>{value}</p>
        </div>
    )
}
