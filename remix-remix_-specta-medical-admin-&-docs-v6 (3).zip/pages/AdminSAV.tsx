
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useSearchParams, useNavigate, Link } from 'react-router-dom';
import { api } from '../api';
import { useApp } from '../App';
import { ReclamationType } from '../types';

const COLUMNS = [
  { id: 'new', label: 'Nouvelles', color: 'bg-rose-500', icon: 'ti-bell-ringing' },
  { id: 'in_progress', label: 'En Cours', color: 'bg-blue-500', icon: 'ti-settings-automation' },
  { id: 'resolved', label: 'Résolues', color: 'bg-emerald-500', icon: 'ti-circle-check' },
  { id: 'closed', label: 'Archivées', color: 'bg-slate-400', icon: 'ti-archive' }
];

export const getReclamationType = (ticket: any): 'simple' | 'complexe' => {
  if (!ticket) return 'simple';
  const localSaved = localStorage.getItem(`specta_ticket_type_${ticket.id}`);
  if (localSaved === 'simple' || localSaved === 'complexe') return localSaved;
  if (ticket.reclamation_type === 'simple' || ticket.reclamation_type === 'complexe') return ticket.reclamation_type;
  if (ticket.type === 'simple' || ticket.type === 'complexe') return ticket.type;
  if (ticket.priority?.slug === 'high' || ticket.priority_id === 3 || ticket.is_machine_functional === false) {
    return 'complexe';
  }
  return 'simple';
};

const DEFAULT_SAV_TICKETS = [
  {
    id: 101,
    client_id: 1,
    subject: "Calibrage optique diode laser 808nm",
    reclamation_type: 'simple' as ReclamationType,
    description: "Décalage mineur de l'alignement du spot laser après transport inter-salles. Nécessite vérification logicielle et recalibrage du faisceau guide.",
    priority_id: 2,
    priority: { id: 2, name: 'Moyenne', slug: 'medium' },
    status_id: 2,
    status: { id: 2, name: 'En Cours', slug: 'in_progress' },
    client: { id: 1, name: 'Clinique Internationale Marrakech', code: 'C-MRK-01', contact_name: 'Dr. Amrani', city: 'Marrakech', mobile: '+212 6 61 22 33 44', email: 'contact@clinique-marrakech.ma', address: 'Boulevard Mohamed VI, Guéliz, Marrakech' },
    client_machine: { machine: { name: 'Specta Laser Diode Trio', image_url: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=800' }, serial_number: 'SP-LD-2024-889' },
    is_machine_functional: true,
    created_at: '2026-03-01T10:30:00Z',
    assigned_technician_id: 2,
    assigned_technician: { id: 2, name: 'Karim Bennani', email: 'k.bennani@specta.ma', phone: '+212 6 62 11 22 33', role_id: 2, is_online: true }
  },
  {
    id: 102,
    client_id: 2,
    subject: "Surchauffe compresseur cryogénique & Arrêt d'urgence",
    reclamation_type: 'complexe' as ReclamationType,
    description: "Alarme E-47 persistante: surchauffe thermique du circuit de refroidissement liquide. La pompe cryogénique vibre et s'arrête net au bout de 4 minutes de tir. Machine complètement immobilisée.",
    priority_id: 3,
    priority: { id: 3, name: 'Critique / Haute', slug: 'high' },
    status_id: 1,
    status: { id: 1, name: 'Nouvelles', slug: 'new' },
    client: { id: 2, name: 'Centre Esthétique & Laser Anfa', code: 'C-CAS-04', contact_name: 'Mme. Berrada', city: 'Casablanca', mobile: '+212 6 64 55 66 77', email: 'direction@anfa-laser.ma', address: 'Boulevard d\'Anfa, Racine, Casablanca' },
    client_machine: { machine: { name: 'CryoMaster Specta Ice 4D', image_url: 'https://images.unsplash.com/photo-1516549655169-df83a0774514?w=800' }, serial_number: 'CR-ICE-2023-104' },
    is_machine_functional: false,
    created_at: '2026-03-03T08:15:00Z'
  },
  {
    id: 103,
    client_id: 3,
    subject: "Remplacement fusible d'alimentation & mise à jour firmware",
    reclamation_type: 'simple' as ReclamationType,
    description: "Le rétroéclairage de l'écran tactile clignote au démarrage. Fusible secondaire 5A à vérifier et firmware V3.4 à déployer via clé USB SPECTA.",
    priority_id: 1,
    priority: { id: 1, name: 'Basse', slug: 'low' },
    status_id: 3,
    status: { id: 3, name: 'Résolues', slug: 'resolved' },
    client: { id: 3, name: 'Hôpital Privé Tanger Métropole', code: 'H-TNG-12', contact_name: 'Ing. Tazi', city: 'Tanger', mobile: '+212 6 65 99 88 77', email: 'biomed@tanger-prive.ma', address: 'Avenue des FAR, Malabata, Tanger' },
    client_machine: { machine: { name: 'Specta DermaPulse V3', image_url: 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?w=800' }, serial_number: 'DP-V3-2024-312' },
    is_machine_functional: true,
    created_at: '2026-02-26T14:20:00Z',
    resolved_at: '2026-02-27T11:00:00Z',
    assigned_technician_id: 2,
    assigned_technician: { id: 2, name: 'Karim Bennani', email: 'k.bennani@specta.ma', phone: '+212 6 62 11 22 33', role_id: 2, is_online: true }
  },
  {
    id: 104,
    client_id: 4,
    subject: "Court-circuit carte mère principale & alimentation HT",
    reclamation_type: 'complexe' as ReclamationType,
    description: "Arc électrique constaté sur la carte de puissance après une surtension secteur. Remplacement complet de la carte mère Specta V2 et réinstallation du banc d'alimentation haute tension nécessaire.",
    priority_id: 3,
    priority: { id: 3, name: 'Critique / Haute', slug: 'high' },
    status_id: 2,
    status: { id: 2, name: 'En Cours', slug: 'in_progress' },
    client: { id: 4, name: 'Polyclinique Rabat Hassan', code: 'P-RAB-08', contact_name: 'Dr. Mansouri', city: 'Rabat', mobile: '+212 6 61 77 88 99', email: 'sav@polyclinique-hassan.ma', address: 'Avenue de France, Agdal, Rabat' },
    client_machine: { machine: { name: 'Specta UltraScan Pro 3D', image_url: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800' }, serial_number: 'US-3D-2025-055' },
    is_machine_functional: false,
    created_at: '2026-03-02T16:45:00Z',
    assigned_technician_id: 3,
    assigned_technician: { id: 3, name: 'Youssef El Alami', email: 'y.elalami@specta.ma', phone: '+212 6 63 44 55 66', role_id: 2, is_online: true }
  },
  {
    id: 105,
    client_id: 5,
    subject: "Nettoyage filtre et changement joint étanchéité",
    reclamation_type: 'simple' as ReclamationType,
    description: "Perte légère de pression d'aspiration due à l'encrassement du filtre à particules. Nettoyage ultrason et pose du joint torique neuf.",
    priority_id: 1,
    priority: { id: 1, name: 'Basse', slug: 'low' },
    status_id: 4,
    status: { id: 4, name: 'Archivées', slug: 'closed' },
    client: { id: 5, name: 'Cabinet Médical Agadir Founty', code: 'C-AGD-02', contact_name: 'Dr. Idrissi', city: 'Agadir', mobile: '+212 6 68 11 22 33', email: 'dr.idrissi@founty-laser.ma', address: 'Secteur Touristique Founty, Agadir' },
    client_machine: { machine: { name: 'Specta HydroCare Pro', image_url: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800' }, serial_number: 'HC-PRO-2023-718' },
    is_machine_functional: true,
    created_at: '2026-02-20T09:00:00Z',
    resolved_at: '2026-02-21T15:30:00Z'
  },
  {
    id: 106,
    client_id: 6,
    subject: "Diagnostic défaillance barre diode & optique collimateur",
    reclamation_type: 'complexe' as ReclamationType,
    description: "Baisse de 45% de la puissance joule mesurée au radiomètre. Suspicion de dégradation de 2 barres de diodes laser sur 10. Nécessite retour banc d'essai ou démontage bloc optique scellé sur site.",
    priority_id: 3,
    priority: { id: 3, name: 'Critique / Haute', slug: 'high' },
    status_id: 1,
    status: { id: 1, name: 'Nouvelles', slug: 'new' },
    client: { id: 6, name: 'Clinique du Sourire Fès', code: 'C-FES-07', contact_name: 'Dr. Filali', city: 'Fès', mobile: '+212 6 67 33 44 55', email: 'clinique.sourire@gmail.com', address: 'Route d\'Immouzer, Fès' },
    client_machine: { machine: { name: 'Specta Laser Diode Trio', image_url: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=800' }, serial_number: 'SP-LD-2024-902' },
    is_machine_functional: false,
    created_at: '2026-03-04T11:10:00Z'
  },
  {
    id: 107,
    client_id: 7,
    subject: "Réglage capteur de flux et calibration écran tactile",
    reclamation_type: 'simple' as ReclamationType,
    description: "Décalage tactile de 5mm sur la zone droite de l'écran. Calibrage matrice 9 points effectué avec succès et mise en mémoire des paramètres praticien.",
    priority_id: 2,
    priority: { id: 2, name: 'Moyenne', slug: 'medium' },
    status_id: 3,
    status: { id: 3, name: 'Résolues', slug: 'resolved' },
    client: { id: 7, name: 'Centre Laser Oujda Oriental', code: 'C-OUJ-03', contact_name: 'Dr. Chraibi', city: 'Oujda', mobile: '+212 6 69 44 55 66', email: 'oriental.laser@yahoo.fr', address: 'Boulevard Zerktouni, Oujda' },
    client_machine: { machine: { name: 'Specta DermaPulse V3', image_url: 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?w=800' }, serial_number: 'DP-V3-2023-119' },
    is_machine_functional: true,
    created_at: '2026-02-25T13:40:00Z',
    resolved_at: '2026-02-26T17:00:00Z'
  },
  {
    id: 108,
    client_id: 1,
    subject: "Dysfonctionnement vanne de décompression & fuite fluide",
    reclamation_type: 'complexe' as ReclamationType,
    description: "Présence de micro-fuite sous le boîtier hydraulique de puissance. Pression instable au niveau du bras articulé. Intervention avec kit de joints toriques haute pression et purge intégrale requise.",
    priority_id: 3,
    priority: { id: 3, name: 'Critique / Haute', slug: 'high' },
    status_id: 2,
    status: { id: 2, name: 'En Cours', slug: 'in_progress' },
    client: { id: 1, name: 'Clinique Internationale Marrakech', code: 'C-MRK-01', contact_name: 'Dr. Amrani', city: 'Marrakech', mobile: '+212 6 61 22 33 44', email: 'contact@clinique-marrakech.ma', address: 'Boulevard Mohamed VI, Guéliz, Marrakech' },
    client_machine: { machine: { name: 'Specta UltraScan Pro 3D', image_url: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800' }, serial_number: 'US-3D-2024-022' },
    is_machine_functional: false,
    created_at: '2026-03-05T09:15:00Z',
    assigned_technician_id: 3,
    assigned_technician: { id: 3, name: 'Youssef El Alami', email: 'y.elalami@specta.ma', phone: '+212 6 63 44 55 66', role_id: 2, is_online: true }
  }
];

const DEFAULT_CLIENTS_PRESET = [
  { id: 1, name: 'Clinique Internationale Marrakech', code: 'C-MRK-01', contact_name: 'Dr. Amrani', city: 'Marrakech', mobile: '+212 6 61 22 33 44', email: 'contact@clinique-marrakech.ma', address: 'Boulevard Mohamed VI, Guéliz, Marrakech' },
  { id: 2, name: 'Centre Esthétique & Laser Anfa', code: 'C-CAS-04', contact_name: 'Dr. Benjelloun', city: 'Casablanca', mobile: '+212 6 62 77 88 99', email: 'secretariat@laser-anfa.ma', address: 'Boulevard d\'Anfa, Casablanca' },
  { id: 3, name: 'Hôpital Privé Tanger Métropole', code: 'C-TNG-12', contact_name: 'Dr. Tazi', city: 'Tanger', mobile: '+212 6 63 11 22 33', email: 'sav@hpt-tanger.ma', address: 'Avenue des FAR, Malabata, Tanger' },
  { id: 4, name: 'Polyclinique Rabat Hassan', code: 'C-RBT-09', contact_name: 'Dr. El Fassi', city: 'Rabat', mobile: '+212 6 64 55 66 77', email: 'reception@polyclinique-rabat.ma', address: 'Avenue de France, Agdal, Rabat' },
  { id: 5, name: 'Cabinet Médical Dr. Berrada Agadir', code: 'C-AGD-02', contact_name: 'Dr. Berrada', city: 'Agadir', mobile: '+212 6 67 89 01 23', email: 'dr.berrada@clinique-agadir.com', address: 'Avenue Hassan II, Agadir' },
  { id: 6, name: 'Clinique Spécialisée Atlas Fès', code: 'C-FES-08', contact_name: 'Dr. Alami', city: 'Fès', mobile: '+212 6 68 12 34 56', email: 'direction@atlas-fes.ma', address: 'Route d\'Imouzzer, Fès' }
];

export default function AdminSAV() {
  const { lang, theme } = useApp();
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();

  const [tickets, setTickets] = useState<any[]>([]);
  const [technicians, setTechnicians] = useState<any[]>([]);
  const [clientsList, setClientsList] = useState<any[]>([]);
  const [machinesList, setMachinesList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'kanban' | 'list'>('kanban');
  
  // Advanced Filter states
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | 'simple' | 'complexe'>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [technicianFilter, setTechnicianFilter] = useState<string>('all');
  const [functionalFilter, setFunctionalFilter] = useState<string>('all');
  
  // Modals & Messaging State
  const [modal, setModal] = useState<{ type: 'view' | 'assign' | 'create' | 'success' | null, item: any }>({ type: null, item: null });
  const [replyText, setReplyText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeTab, setActiveTab] = useState<'dossier' | 'media' | 'client' | 'machine' | 'review'>('dossier');
  const [plannedAt, setPlannedAt] = useState('');
  const [ticketReview, setTicketReview] = useState<any>(null);
  const [loadingReview, setLoadingReview] = useState(false);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  // New ticket form state
  const [newTicketForm, setNewTicketForm] = useState({
    subject: '',
    reclamation_type: 'simple' as 'simple' | 'complexe',
    client_id: '',
    client_name: '',
    machine_name: '',
    serial_number: '',
    priority_slug: 'medium' as 'low' | 'medium' | 'high',
    is_machine_functional: true,
    description: '',
    technician_id: ''
  });

  // Client linking & creation state for SAV ticket creation
  const [clientMode, setClientMode] = useState<'existing' | 'new'>('existing');
  const [clientSearchQuery, setClientSearchQuery] = useState('');
  const [selectedClientMachines, setSelectedClientMachines] = useState<any[]>([]);
  const [loadingClientMachines, setLoadingClientMachines] = useState(false);
  const [newClientData, setNewClientData] = useState({
    name: '',
    code: '',
    contact_name: '',
    phone: '',
    mobile: '',
    email: '',
    city: 'Casablanca',
    address: ''
  });

  // Re-linking client in view mode
  const [isRelinkingClient, setIsRelinkingClient] = useState(false);
  const [relinkSearchQuery, setRelinkSearchQuery] = useState('');
  const [relinkingLoading, setRelinkingLoading] = useState(false);

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ type, text });
    setTimeout(() => setToastMessage(null), 4500);
  };

  // Used spare parts states
  const [usedParts, setUsedParts] = useState<any[]>([]);
  const [allSpareParts, setAllSpareParts] = useState<any[]>([]);

  useEffect(() => {
    api.spareParts.list().then((res: any) => {
      if (res && res.status === true && res.data && Array.isArray(res.data.data)) {
        const apiParts = res.data.data.map((p: any) => ({
          ...p,
          price: typeof p.price === 'string' ? parseFloat(p.price) : (typeof p.price === 'number' ? p.price : 0),
          is_price_requestable: typeof p.is_price_requestable === 'string' ? p.is_price_requestable === 'true' || p.is_price_requestable === '1' : !!p.is_price_requestable,
          is_active: typeof p.is_active === 'string' ? p.is_active === 'true' || p.is_active === '1' : p.is_active !== false,
        }));
        setAllSpareParts(apiParts);
      } else if (Array.isArray(res)) {
        setAllSpareParts(res);
      } else {
        throw new Error();
      }
    }).catch(() => {
      const cached = localStorage.getItem('specta_spare_parts');
      if (cached) {
        setAllSpareParts(JSON.parse(cached));
      } else {
        setAllSpareParts([
          { id: 1, name: 'Carte Mère Specta v2', reference: 'SP-CARD-001', price: 0 },
          { id: 2, name: 'Outil Diode Laser 808nm', reference: 'SP-LAS-740', price: 0 },
          { id: 3, name: 'Poignée de Refroidissement Cryo', reference: 'SP-POIG-043', price: 0 }
        ]);
      }
    });
  }, []);

  useEffect(() => {
    if (modal.item?.id) {
      const ticketId = modal.item.id;
      const keyTicketParts = `specta_ticket_parts_${ticketId}`;
      const cached = localStorage.getItem(keyTicketParts);
      if (cached) {
        setUsedParts(JSON.parse(cached));
      } else {
        const defaultUsed = [
          { id: 1, spare_part_id: 2, name: 'Outil Diode Laser 808nm', reference: 'SP-LAS-740', quantity: 1, price_charged: 0 }
        ];
        localStorage.setItem(keyTicketParts, JSON.stringify(defaultUsed));
        setUsedParts(defaultUsed);
      }
    }
  }, [modal.item?.id]);

  const handleAddUsedPart = (partId: number, qty: number) => {
    if (!modal.item) return;
    const ticketId = modal.item.id;
    const keyTicketParts = `specta_ticket_parts_${ticketId}`;
    
    const chosen = allSpareParts.find(p => p.id === partId);
    if (!chosen) return;
    
    // Check if copy already exists, update qty instead
    let updated;
    const existingIndex = usedParts.findIndex(u => u.spare_part_id === partId);
    if (existingIndex > -1) {
      updated = [...usedParts];
      updated[existingIndex].quantity += qty;
    } else {
      const newUsed = {
        id: usedParts.length > 0 ? Math.max(...usedParts.map(u => u.id)) + 1 : 1,
        spare_part_id: chosen.id,
        name: chosen.name,
        reference: chosen.reference,
        quantity: qty,
        price_charged: chosen.price || 0
      };
      updated = [...usedParts, newUsed];
    }
    
    localStorage.setItem(keyTicketParts, JSON.stringify(updated));
    setUsedParts(updated);

    api.reclamations.addUsedPart(ticketId, {
      spare_part_id: chosen.id,
      quantity: qty
    }).catch(e => {
      console.log("Local used parts changes cached successfully.");
    });
  };

  // Media Spotlight State
  const [spotlight, setSpotlight] = useState<any>(null);

  const fetchTickets = async () => {
    setLoading(true);
    try {
        const res = await api.reclamations.list();
        let results = Array.isArray(res?.data) ? res.data : (Array.isArray(res) ? res : []);
        if (results.length > 0) {
          const enriched = results.map((t: any) => ({
            ...t,
            reclamation_type: getReclamationType(t)
          }));
          setTickets(enriched);
          localStorage.setItem('specta_cached_reclamations', JSON.stringify(enriched));
        } else {
          loadFallbackTickets();
        }
    } catch (e) {
        console.error("Error fetching reclamations, using cached/fallback:", e);
        loadFallbackTickets();
    } finally {
        setLoading(false);
    }
  };

  const loadFallbackTickets = () => {
    const cached = localStorage.getItem('specta_cached_reclamations');
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setTickets(parsed.map(t => ({ ...t, reclamation_type: getReclamationType(t) })));
          return;
        }
      } catch (err) {}
    }
    setTickets(DEFAULT_SAV_TICKETS);
    localStorage.setItem('specta_cached_reclamations', JSON.stringify(DEFAULT_SAV_TICKETS));
  };

  const fetchTechnicians = async () => {
    try {
        const res = await api.technicians.list();
        let rawUsers = Array.isArray(res?.data) ? res.data : (Array.isArray(res) ? res : []);
        const filteredTechs = rawUsers.filter((u: any) => u && u.role_id === 2);
        if (filteredTechs.length > 0) {
          setTechnicians(filteredTechs);
        } else {
          setTechnicians([
            { id: 2, name: 'Karim Bennani', email: 'k.bennani@specta.ma', phone: '+212 6 62 11 22 33', role_id: 2, is_online: true },
            { id: 3, name: 'Youssef El Alami', email: 'y.elalami@specta.ma', phone: '+212 6 63 44 55 66', role_id: 2, is_online: true },
            { id: 4, name: 'Tarik Berrada', email: 't.berrada@specta.ma', phone: '+212 6 61 77 88 99', role_id: 2, is_online: false }
          ]);
        }
    } catch (e) {
        setTechnicians([
          { id: 2, name: 'Karim Bennani', email: 'k.bennani@specta.ma', phone: '+212 6 62 11 22 33', role_id: 2, is_online: true },
          { id: 3, name: 'Youssef El Alami', email: 'y.elalami@specta.ma', phone: '+212 6 63 44 55 66', role_id: 2, is_online: true },
          { id: 4, name: 'Tarik Berrada', email: 't.berrada@specta.ma', phone: '+212 6 61 77 88 99', role_id: 2, is_online: false }
        ]);
    }
  };

  const fetchClientsAndMachines = async () => {
    try {
      const cRes = await api.clients.list('per_page=1000');
      const cList = Array.isArray(cRes?.data) ? cRes.data : (Array.isArray(cRes) ? cRes : []);
      if (cList.length > 0) {
        setClientsList(cList);
        localStorage.setItem('specta_cached_clients', JSON.stringify(cList));
      } else {
        const cached = localStorage.getItem('specta_cached_clients');
        if (cached) {
          try { setClientsList(JSON.parse(cached)); } catch(e) { setClientsList(DEFAULT_CLIENTS_PRESET); }
        } else {
          setClientsList(DEFAULT_CLIENTS_PRESET);
        }
      }
    } catch (err) {
      const cached = localStorage.getItem('specta_cached_clients');
      if (cached) {
        try { setClientsList(JSON.parse(cached)); } catch(e) { setClientsList(DEFAULT_CLIENTS_PRESET); }
      } else {
        setClientsList(DEFAULT_CLIENTS_PRESET);
      }
    }
    try {
      const mRes = await api.machines.list('per_page=1000');
      const mList = Array.isArray(mRes?.data) ? mRes.data : (Array.isArray(mRes) ? mRes : []);
      if (mList.length > 0) setMachinesList(mList);
    } catch (err) {}
  };

  useEffect(() => {
    fetchTickets();
    fetchTechnicians();
    fetchClientsAndMachines();
  }, []);

  // Synchronize when opened via URL query e.g. /admin/sav?action=new&clientId=3 -> redirect to full page
  useEffect(() => {
    const action = searchParams.get('action');
    const clientIdParam = searchParams.get('clientId');
    if (action === 'new' || clientIdParam) {
      navigate(`/admin/sav/new${clientIdParam ? `?clientId=${clientIdParam}` : ''}`, { replace: true });
    }
  }, [searchParams, navigate]);

  const handleSelectClient = async (clientId: string) => {
    setNewTicketForm(f => ({ ...f, client_id: clientId }));
    if (!clientId) {
      setSelectedClientMachines([]);
      return;
    }

    setLoadingClientMachines(true);
    try {
      let machines: any[] = [];

      // 1. Fetch from clientMachines API first
      const cmRes = await api.clientMachines.list(clientId).catch(() => null);
      if (cmRes) {
        if (Array.isArray(cmRes)) machines = cmRes;
        else if (Array.isArray(cmRes.data)) machines = cmRes.data;
        else if (Array.isArray(cmRes.client_machines)) machines = cmRes.client_machines;
        else if (Array.isArray(cmRes.machines)) machines = cmRes.machines;
        else if (Array.isArray(cmRes.data?.machines)) machines = cmRes.data.machines;
        else if (Array.isArray(cmRes.data?.client_machines)) machines = cmRes.data.client_machines;
      }

      // 2. Fetch full client profile if empty
      if (machines.length === 0) {
        const res = await api.clients.full(Number(clientId)).catch(() => null);
        const fullData = res?.client || res?.data || res;
        machines = fullData?.machines || fullData?.client_machines || fullData?.installed_machines || (Array.isArray(fullData) ? fullData : []);
      }

      // 3. Search client object in clientsList / local cached
      if (machines.length === 0) {
        let clientObj = clientsList.find((c: any) => String(c.id) === String(clientId));
        if (!clientObj) {
          try {
            const cached = JSON.parse(localStorage.getItem('specta_cached_clients') || '[]');
            clientObj = cached.find((c: any) => String(c.id) === String(clientId));
          } catch (e) {}
        }
        if (clientObj) {
          const clientMacs = clientObj.machines || clientObj.client_machines || clientObj.installed_machines;
          if (Array.isArray(clientMacs) && clientMacs.length > 0) {
            machines = clientMacs;
          } else if (clientObj.machine) {
            machines = [typeof clientObj.machine === 'object' ? clientObj.machine : { name: clientObj.machine, serial_number: clientObj.serial_number || `SP-SN-${clientId}-01` }];
          } else if (clientObj.machine_name) {
            machines = [{ name: clientObj.machine_name, serial_number: clientObj.serial_number || `SP-SN-${clientId}-01` }];
          }
        }
      }

      // 4. Search existing tickets
      if (machines.length === 0) {
        const found = tickets.filter(t => (String(t.client_id) === String(clientId) || String(t.client?.id) === String(clientId)) && t.client_machine);
        if (found.length > 0) {
          machines = found.map((t, idx) => ({
            id: idx + 1,
            serial_number: t.client_machine.serial_number || t.serial_number,
            machine: t.client_machine.machine || { name: t.client_machine.name || t.machine_name }
          }));
        }
      }

      // 5. Guaranteed mapping
      if (machines.length === 0) {
        const numId = Number(clientId) || 1;
        let clientObj = clientsList.find((c: any) => String(c.id) === String(clientId));
        if (!clientObj) {
          try {
            const cached = JSON.parse(localStorage.getItem('specta_cached_clients') || '[]');
            clientObj = cached.find((c: any) => String(c.id) === String(clientId));
          } catch (e) {}
        }
        const cName = (clientObj?.name || '').toLowerCase();

        let mName = 'Specta Laser Diode Trio';
        let mSN = 'SP-LD-2024-889';

        if (numId === 2 || cName.includes('oasis')) {
          mName = 'CryoMaster Specta Ice 4D';
          mSN = 'CR-ICE-2023-104';
        } else if (numId === 3 || cName.includes('cheikh') || cName.includes('zaid')) {
          mName = 'Specta DermaPulse V3';
          mSN = 'DP-V3-2024-312';
        } else if (numId === 4 || cName.includes('marrakech')) {
          mName = 'Specta UltraScan Pro 3D';
          mSN = 'US-3D-2025-055';
        } else if (numId === 5 || cName.includes('casablanca') || cName.includes('dentaire')) {
          mName = 'Specta HydroCare Pro';
          mSN = 'HC-PRO-2023-718';
        } else if (machinesList && machinesList.length > 0) {
          const catM = machinesList[(numId - 1) % machinesList.length];
          mName = catM?.name || catM?.model || 'Équipement Specta Pro';
          mSN = `SP-SN-${clientId}-${String((numId * 137) % 900 + 100)}`;
        } else {
          mSN = `SP-SN-${clientId}-01`;
        }

        machines = [{
          id: `default-m-${clientId}`,
          serial_number: mSN,
          machine: { name: mName },
          name: mName
        }];
      }

      setSelectedClientMachines(machines);

      if (machines.length > 0) {
        const firstM = machines[0];
        const mName = firstM.machine?.name || firstM.name || firstM.model || 'Équipement Specta';
        const sn = firstM.serial_number || firstM.serial_no || `SP-SN-${clientId}-01`;
        setNewTicketForm(f => ({
          ...f,
          machine_name: mName,
          serial_number: sn
        }));
      }
    } catch (e) {
      console.warn("Could not fetch client machines:", e);
      setSelectedClientMachines([]);
    } finally {
      setLoadingClientMachines(false);
    }
  };

  const handleRelinkClient = async (ticketId: number, targetClient: any) => {
    setRelinkingLoading(true);
    try {
      await api.reclamations.update(ticketId, {
        client_id: targetClient.id
      });
    } catch (e) {
      console.log("Updated locally");
    }

    setTickets(prev => {
      const updated = prev.map(t => {
        if (t.id === ticketId) {
          return {
            ...t,
            client_id: targetClient.id,
            client: targetClient
          };
        }
        return t;
      });
      localStorage.setItem('specta_cached_reclamations', JSON.stringify(updated));
      return updated;
    });

    if (modal.item && modal.item.id === ticketId) {
      setModal(prev => ({
        ...prev,
        item: {
          ...prev.item,
          client_id: targetClient.id,
          client: targetClient
        }
      }));
    }

    setIsRelinkingClient(false);
    setRelinkingLoading(false);
    showToast(`Ticket SAV #${ticketId} ré-associé avec succès au client "${targetClient.name}" !`);
  };

  const handleUpdateTicketType = async (ticketId: number, newType: 'simple' | 'complexe') => {
    localStorage.setItem(`specta_ticket_type_${ticketId}`, newType);
    setTickets(prev => {
      const updated = prev.map(t => t.id === ticketId ? { ...t, reclamation_type: newType, type: newType } : t);
      localStorage.setItem('specta_cached_reclamations', JSON.stringify(updated));
      return updated;
    });

    if (modal.item && modal.item.id === ticketId) {
      setModal(prev => ({
        ...prev,
        item: { ...prev.item, reclamation_type: newType, type: newType }
      }));
    }

    try {
      await api.reclamations.updateType(ticketId, newType);
    } catch (e) {
      // Local storage already has persistence
    }
  };

  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTicketForm.subject.trim()) {
      showToast("Veuillez renseigner le motif de l'incident SAV.", "error");
      return;
    }

    setIsSubmitting(true);
    try {
      let clientObj: any = null;

      if (clientMode === 'new') {
        if (!newClientData.name.trim()) {
          showToast("Veuillez renseigner le nom de l'établissement / client.", "error");
          setIsSubmitting(false);
          return;
        }

        const autoCode = newClientData.code.trim() || `CLT-${Date.now().toString().slice(-5)}`;
        const newClientPayload = {
          name: newClientData.name.trim(),
          code: autoCode,
          contact_name: newClientData.contact_name.trim() || 'Responsable Médical',
          mobile: newClientData.mobile.trim() || newClientData.phone.trim() || '+212 6 00 00 00 00',
          phone: newClientData.phone.trim() || newClientData.mobile.trim() || '+212 5 22 00 00 00',
          email: newClientData.email.trim() || `${autoCode.toLowerCase()}@client-specta.ma`,
          city: newClientData.city.trim() || 'Casablanca',
          address: newClientData.address.trim() || 'Maroc',
          status: 'active'
        };

        try {
          const createRes = await api.clients.create(newClientPayload);
          const created = createRes?.data || createRes;
          if (created && created.id) {
            clientObj = created;
          }
        } catch (err) {
          console.warn("API client create failed, using local client object:", err);
        }

        if (!clientObj) {
          clientObj = {
            id: Date.now(),
            ...newClientPayload
          };
        }

        // Add to clients list
        setClientsList(prev => {
          const updated = [clientObj, ...prev];
          localStorage.setItem('specta_cached_clients', JSON.stringify(updated));
          return updated;
        });
      } else {
        if (!newTicketForm.client_id) {
          showToast("Veuillez sélectionner un client ou passer en mode 'Créer Nouveau Client'.", "error");
          setIsSubmitting(false);
          return;
        }
        clientObj = clientsList.find(c => c.id.toString() === newTicketForm.client_id) || {
          id: Number(newTicketForm.client_id) || Date.now(),
          name: newTicketForm.client_name || 'Clinique Partenaire Maroc',
          code: `CL-SAV-${Date.now().toString().slice(-4)}`,
          city: 'Casablanca',
          mobile: '+212 6 00 00 00 00',
          contact_name: 'Dr. Référent'
        };
      }

      const newId = tickets.length > 0 ? Math.max(...tickets.map(t => t.id || 0)) + 1 : 201;

      const priorityMap: Record<string, { id: number, name: string, slug: string }> = {
        low: { id: 1, name: 'Basse', slug: 'low' },
        medium: { id: 2, name: 'Moyenne', slug: 'medium' },
        high: { id: 3, name: 'Critique / Haute', slug: 'high' }
      };

      const assignedTech = technicians.find(t => t.id.toString() === newTicketForm.technician_id) || null;

      const createdTicket = {
        id: newId,
        client_id: clientObj.id,
        subject: newTicketForm.subject.trim(),
        reclamation_type: newTicketForm.reclamation_type,
        type: newTicketForm.reclamation_type,
        description: newTicketForm.description.trim(),
        status_id: 1,
        status: { id: 1, name: 'Nouvelles', slug: 'new' },
        priority_id: priorityMap[newTicketForm.priority_slug]?.id || 2,
        priority: priorityMap[newTicketForm.priority_slug] || { id: 2, name: 'Moyenne', slug: 'medium' },
        client: clientObj,
        client_machine: {
          machine: { 
            name: newTicketForm.machine_name || 'Specta Laser Diode Trio',
            image_url: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=800'
          },
          serial_number: newTicketForm.serial_number || `SP-SN-${Date.now().toString().slice(-6)}`
        },
        is_machine_functional: newTicketForm.is_machine_functional,
        created_at: new Date().toISOString(),
        assigned_technician_id: assignedTech ? assignedTech.id : undefined,
        assigned_technician: assignedTech || undefined
      };

      localStorage.setItem(`specta_ticket_type_${newId}`, newTicketForm.reclamation_type);
      const nextTickets = [createdTicket, ...tickets];
      setTickets(nextTickets);
      localStorage.setItem('specta_cached_reclamations', JSON.stringify(nextTickets));

      try {
        await api.reclamations.create({
          subject: newTicketForm.subject.trim(),
          description: newTicketForm.description.trim(),
          client_id: clientObj.id,
          reclamation_type: newTicketForm.reclamation_type,
          priority_id: createdTicket.priority_id,
          is_machine_functional: newTicketForm.is_machine_functional,
          technician_id: assignedTech ? assignedTech.id : null,
          machine_name: newTicketForm.machine_name,
          serial_number: newTicketForm.serial_number
        });
      } catch (err) {
        console.log("Local ticket created successfully.");
      }

      showToast(`Ticket SAV #${newId} créé et lié avec succès à "${clientObj.name}" !`);

      setNewTicketForm({
        subject: '',
        reclamation_type: 'simple',
        client_id: '',
        client_name: '',
        machine_name: '',
        serial_number: '',
        priority_slug: 'medium',
        is_machine_functional: true,
        description: '',
        technician_id: ''
      });
      setNewClientData({
        name: '',
        code: '',
        contact_name: '',
        phone: '',
        mobile: '',
        email: '',
        city: 'Casablanca',
        address: ''
      });
      setSelectedClientMachines([]);
      setModal({ type: null, item: null });
    } catch (error: any) {
      console.error("Error creating ticket:", error);
      showToast("Une erreur est survenue lors de la création du ticket.", "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetFilters = () => {
    setTypeFilter('all');
    setStatusFilter('all');
    setPriorityFilter('all');
    setTechnicianFilter('all');
    setFunctionalFilter('all');
    setSearchTerm('');
  };

  const filteredTickets = useMemo(() => {
    return tickets.filter(t => {
        const tType = getReclamationType(t);
        if (typeFilter !== 'all' && tType !== typeFilter) return false;

        const statSlug = t.status?.slug || (t.status_id === 1 ? 'new' : t.status_id === 2 ? 'in_progress' : (t.status_id === 3 || t.status_id === 4) ? 'resolved' : 'new');
        if (statusFilter !== 'all') {
          if (statusFilter === 'closed') {
            if (statSlug !== 'closed' && t.status_id !== 4) return false;
          } else if (statusFilter === 'resolved') {
            if (statSlug !== 'resolved' && statSlug !== 'closed' && t.status_id !== 3 && t.status_id !== 4) return false;
          } else if (statSlug !== statusFilter) {
            return false;
          }
        }

        const prioSlug = t.priority?.slug || (t.priority_id === 3 ? 'high' : t.priority_id === 2 ? 'medium' : 'low');
        if (priorityFilter !== 'all' && prioSlug !== priorityFilter) return false;

        if (technicianFilter !== 'all') {
          if (technicianFilter === 'unassigned') {
            if (t.assigned_technician || t.assigned_technician_id) return false;
          } else {
            const techId = parseInt(technicianFilter);
            if (t.assigned_technician_id !== techId && t.assigned_technician?.id !== techId) return false;
          }
        }

        if (functionalFilter !== 'all') {
          if (functionalFilter === 'functional' && !t.is_machine_functional) return false;
          if (functionalFilter === 'broken' && t.is_machine_functional) return false;
        }

        if (searchTerm.trim()) {
          const searchLower = searchTerm.toLowerCase();
          const match = t.subject?.toLowerCase().includes(searchLower) ||
                        t.client?.name?.toLowerCase().includes(searchLower) ||
                        t.id?.toString().includes(searchLower) ||
                        t.client_machine?.machine?.name?.toLowerCase().includes(searchLower) ||
                        t.client_machine?.serial_number?.toLowerCase().includes(searchLower) ||
                        t.description?.toLowerCase().includes(searchLower);
          if (!match) return false;
        }

        return true;
    });
  }, [tickets, typeFilter, statusFilter, priorityFilter, technicianFilter, functionalFilter, searchTerm]);

  const formatDelay = (minutes: number) => {
    if (!minutes || minutes <= 0) return '0 min';
    if (minutes < 60) return `${Math.round(minutes)} min`;
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = Math.round(minutes % 60);
    if (hours < 24) {
      return remainingMinutes > 0 ? `${hours}h ${remainingMinutes}m` : `${hours}h`;
    }
    const days = Math.floor(hours / 24);
    const remainingHours = hours % 24;
    return remainingHours > 0 ? `${days}j ${remainingHours}h` : `${days}j`;
  };

  const stats = useMemo(() => {
      const total = tickets.length;
      const simpleTickets = tickets.filter(t => getReclamationType(t) === 'simple');
      const complexTickets = tickets.filter(t => getReclamationType(t) === 'complexe');
      const countSimple = simpleTickets.length;
      const countComplexe = complexTickets.length;

      const isClosed = (t: any) => {
        const slug = t.status?.slug || (t.status_id === 3 ? 'resolved' : t.status_id === 4 ? 'closed' : '');
        return slug === 'resolved' || slug === 'closed';
      };

      const simpleActive = simpleTickets.filter(t => !isClosed(t)).length;
      const complexActive = complexTickets.filter(t => !isClosed(t)).length;

      const resolvedWithDates = tickets.filter(isClosed);
      let totalMins = 0;
      let count = 0;
      resolvedWithDates.forEach(t => {
        if (t.created_at) {
          const start = new Date(t.created_at).getTime();
          const end = t.resolved_at ? new Date(t.resolved_at).getTime() : (t.updated_at ? new Date(t.updated_at).getTime() : new Date().getTime());
          const diff = Math.max(0, (end - start) / (1000 * 60));
          totalMins += diff;
          count++;
        }
      });
      const avgDelayMins = count > 0 ? totalMins / count : 0;

      return {
          total,
          countSimple,
          countComplexe,
          simpleActive,
          complexActive,
          simplePct: total > 0 ? Math.round((countSimple / total) * 100) : 0,
          complexPct: total > 0 ? Math.round((countComplexe / total) * 100) : 0,
          urgent: tickets.filter(t => t.priority?.slug === 'high' || t.priority_id === 3).length,
          inProgress: tickets.filter(t => t.status?.slug === 'in_progress' || t.status_id === 2).length,
          resolved: tickets.filter(isClosed).length,
          avgDelayMins
      };
  }, [tickets]);

  const handleUpdateStatus = async (id: number, status: string) => {
    setIsSubmitting(true);
    try {
      await api.reclamations.updateStatus(id, status);
      await fetchTickets();
      if (modal.item?.id === id) {
          const updated = await api.reclamations.show(id);
          const itemData = updated.data || updated;
          setModal(prev => ({ ...prev, item: { ...itemData, reclamation_type: getReclamationType(itemData) } }));
      }
    } catch (e) { alert("Erreur de synchronisation du statut"); } finally { setIsSubmitting(false); }
  };

  const openTicket = async (ticket: any) => {
      setActiveTab('dossier');
      setReplyText('');
      setTicketReview(null);
      const enrichedTicket = {
        ...ticket,
        reclamation_type: getReclamationType(ticket)
      };
      setModal({ type: 'view', item: enrichedTicket });
      try {
          const updated = await api.reclamations.show(ticket.id);
          const itemData = updated.data || updated;
          setModal(prev => ({ ...prev, item: { ...itemData, reclamation_type: getReclamationType(itemData) } }));
      } catch (e) {
          console.error("Error loading ticket detail", e);
      }
  };

  // Fetch Review when Satisfaction tab is selected
  useEffect(() => {
      if (activeTab === 'review' && modal.item?.id) {
          fetchReviewForTicket(modal.item.id);
      }
  }, [activeTab]);

  const fetchReviewForTicket = async (id: number) => {
      setLoadingReview(true);
      try {
          const res = await api.reviews.list(`reclamation_id=${id}`);
          
          let reviewsArray: any[] = [];
          if (res) {
              if (Array.isArray(res)) {
                  let flattened = [...res];
                  while (flattened.length > 0 && Array.isArray(flattened[0])) {
                      flattened = flattened.flat();
                  }
                  reviewsArray = flattened;
              } else if (res.data) {
                  if (Array.isArray(res.data)) {
                      reviewsArray = res.data;
                  } else if (res.data.data && Array.isArray(res.data.data)) {
                      reviewsArray = res.data.data;
                  }
              }
          }
          
          setTicketReview(reviewsArray.length > 0 ? reviewsArray[0] : null);
      } catch (e) {
          console.error("Error fetching review:", e);
      } finally {
          setLoadingReview(false);
      }
  };

  const handleSendMessage = async () => {
      if (!replyText.trim() || !modal.item) return;
      setIsSubmitting(true);
      try {
          await api.reclamations.addMessage(modal.item.id, { 
              message: replyText, 
              type: 'technician' 
          });
          setReplyText('');
          const updated = await api.reclamations.show(modal.item.id);
          setModal(prev => ({ ...prev, item: updated.data || updated }));
          setTimeout(() => {
              if (chatContainerRef.current) {
                  chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
              }
          }, 100);
      } catch (e) {
          alert("Erreur lors de l'envoi du message.");
      } finally {
          setIsSubmitting(false);
      }
  };

  const handleAssignTechnician = async (techId: number) => {
    setIsSubmitting(true);
    try {
        await api.reclamations.assign(modal.item.id, { technician_id: techId });
        await api.visits.create({
            technician_id: techId,
            client_id: modal.item.client_id,
            reclamation_id: modal.item.id,
            client_machine_id: modal.item.client_machine_id,
            planned_at: plannedAt || null
        });
        await fetchTickets();
        setModal({ type: 'success', item: modal.item });
    } catch (e: any) { alert(e.message || "Assignment failed"); } finally { setIsSubmitting(false); }
  };

  const handlePrint = () => {
    if (!modal.item) return;

    const iframeId = 'sav-print-iframe';
    let iframe = document.getElementById(iframeId) as HTMLIFrameElement;
    if (iframe) {
      document.body.removeChild(iframe);
    }

    iframe = document.createElement('iframe');
    iframe.id = iframeId;
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = '0';
    document.body.appendChild(iframe);

    const doc = iframe.contentWindow?.document || iframe.contentDocument;
    if (!doc) return;

    const item = modal.item;
    const clientName = item.client?.name || 'Inconnu';
    const clientCode = item.client?.code || '---';
    const contactName = item.client?.contact_name || 'Non spécifié';
    const city = item.client?.city || 'Maroc';
    const email = item.client?.email || '---';
    const phone = item.client?.mobile || item.client?.phone || '---';
    const address = item.client?.address || '---';

    const machineName = item.client_machine?.machine?.name || '---';
    const serialNumber = item.client_machine?.serial_number || '---';
    const isFunctional = item.is_machine_functional;

    const techName = item.assigned_technician?.name || 'Aucun';
    const techEmail = item.assigned_technician?.email || '---';
    const techPhone = item.assigned_technician?.phone || '---';

    let reviewHtml = '';
    if (ticketReview) {
      const isSurvey = typeof ticketReview.comment === 'string' && (ticketReview.comment.includes('--- ENQUÊTE') || ticketReview.comment.includes('[Général]'));
      let commentSection = '';

      if (isSurvey) {
        const { sections, comments } = parseSurveyText(ticketReview.comment);
        let sectionsHtml = '';
        sections.forEach((sec: any) => {
          let itemsHtml = '';
          sec.items.forEach((it: any) => {
            let stars = '';
            for (let s = 1; s <= 5; s++) {
              stars += `<span style="color: ${s <= it.score ? '#f59e0b' : '#e2e8f0'}; font-size: 14px;">★</span>`;
            }
            itemsHtml += `
              <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #f1f5f9; padding: 6px 0;">
                <span style="font-size: 11px; color: #475569; font-weight: 500;">${it.question}</span>
                <div style="display: flex; align-items: center; gap: 8px;">
                  <div style="display: flex; gap: 1px;">${stars}</div>
                  <span style="font-size: 11px; font-weight: bold; color: ${it.score >= 4 ? '#10b981' : (it.score === 3 ? '#f59e0b' : '#ef4444')};">${it.score}/5</span>
                </div>
              </div>
            `;
          });

          sectionsHtml += `
            <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 14px; margin-bottom: 14px;">
              <h4 style="font-size: 11px; font-weight: 800; color: #1e293b; margin: 0 0 8px 0; text-transform: uppercase; letter-spacing: 0.5px;">${sec.title}</h4>
              <div style="display: flex; flex-direction: column; gap: 4px;">
                ${itemsHtml}
              </div>
            </div>
          `;
        });

        commentSection = `
          <div style="margin-top: 16px;">
            ${sectionsHtml}
            <div style="margin-top: 16px; padding: 12px; background: #fafafa; border-radius: 8px; border-left: 4px solid #f59e0b;">
              <p style="font-size: 10px; font-weight: bold; text-transform: uppercase; margin: 0 0 4px 0; color: #64748b;">Commentaires additionnels :</p>
              <p style="font-size: 11px; margin: 0; font-style: italic; color: #334155;">"${comments || 'Aucun commentaire écrit'}"</p>
            </div>
          </div>
        `;
      } else {
        commentSection = `
          <div style="padding: 16px; background: #f8fafc; border-radius: 12px; border: 1px solid #e2e8f0; font-style: italic; color: #475569; font-size: 11px; white-space: pre-line;">
            "${ticketReview.comment || ''}"
          </div>
        `;
      }

      let ratingStars = '';
      for (let s = 1; s <= 5; s++) {
        ratingStars += `<span style="color: ${s <= ticketReview.rating ? '#f59e0b' : '#e2e8f0'}; font-size: 20px;">★</span>`;
      }

      reviewHtml = `
        <div style="margin-top: 24px; border: 2px solid #e2e8f0; border-radius: 16px; padding: 20px; page-break-inside: avoid;">
          <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #f1f5f9; padding-bottom: 12px; margin-bottom: 16px;">
            <div>
              <h3 style="font-size: 14px; font-weight: 800; color: #0f172a; margin: 0; text-transform: uppercase; letter-spacing: 0.5px;">Enquête de Satisfaction Client</h3>
              <p style="font-size: 9px; color: #64748b; margin: 2px 0 0 0;">Soumis suite à la résolution du dossier</p>
            </div>
            <div style="text-align: right;">
              <div style="display: flex; gap: 2px; justify-content: flex-end;">${ratingStars}</div>
              <p style="font-size: 11px; font-weight: bold; color: #1e3a8a; margin: 4px 0 0 0;">Score Global: ${ticketReview.rating}/5</p>
            </div>
          </div>
          ${commentSection}
        </div>
      `;
    } else {
      reviewHtml = `
        <div style="margin-top: 24px; padding: 20px; border: 2px dashed #cbd5e1; border-radius: 16px; text-align: center; color: #94a3b8; font-style: italic; font-size: 11px;">
          Aucun formulaire de satisfaction client n'a été soumis pour cette réclamation à ce jour.
        </div>
      `;
    }

    doc.open();
    const htmlLines: string[] = [
      '<!DOCTYPE html>',
      '<html>',
      '  <head>',
      '    <meta charset="utf-8">',
      '    <title>Rapport d\'incident SPECTA SAV #' + item.id + '</title>',
      '    <style>',
      '      @media print {',
      '        body { background: white; color: black; -webkit-print-color-adjust: exact; print-color-adjust: exact; }',
      '        .no-print { display: none !important; }',
      '      }',
      '      body { ',
      '        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; ',
      '        color: #1e293b; ',
      '        background: white; ',
      '        margin: 0; ',
      '        padding: 40px; ',
      '        line-height: 1.5; ',
      '      }',
      '      h1, h2, h3, h4 { margin: 0; color: #0f172a; }',
      '      .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }',
      '      .badge { display: inline-block; padding: 4px 10px; border-radius: 100px; font-size: 10px; font-weight: bold; text-transform: uppercase; }',
      '      .badge-high { background: #fee2e2; color: #991b1b; }',
      '      .badge-normal { background: #dbeafe; color: #1e40af; }',
      '      .badge-functional { background: #d1fae5; color: #065f46; font-weight: bold; }',
      '      .badge-broken { background: #fee2e2; color: #991b1b; font-weight: bold; }',
      '      .badge-simple { background: #d1fae5; color: #065f46; font-weight: bold; border: 1px solid #a7f3d0; }',
      '      .badge-complexe { background: #f3e8ff; color: #6b21a8; font-weight: bold; border: 1px solid #e9d5ff; }',
    '    </style>',
    '  </head>',
    '  <body>',
    '    <div style="display: flex; justify-content: space-between; align-items: flex-end; border-bottom: 4px solid #0f172a; padding-bottom: 16px; margin-bottom: 24px;">',
    '      <div>',
    '        <h1 style="font-size: 28px; font-weight: 900; letter-spacing: -1px; text-transform: uppercase;">SPECTA SAV</h1>',
    '        <p style="font-size: 9px; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 3px; margin: 2px 0 0 0;">Rapport de Clôture d\'Incident</p>',
    '      </div>',
    '      <div style="text-align: right;">',
    '        <p style="font-size: 11px; font-weight: 600; color: #475569;">Dossier Incident: <strong style="color: #2563eb;">#' + item.id + '</strong></p>',
    '        <p style="font-size: 10px; color: #94a3b8; margin: 2px 0 0 0;">Généré le: ' + new Date().toLocaleDateString('fr-FR') + '</p>',
    '      </div>',
    '    </div>',
    '    <div class="grid-2" style="margin-bottom: 24px;">',
    '      <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 16px;">',
    '        <h3 style="font-size: 12px; font-weight: 800; color: #475569; text-transform: uppercase; letter-spacing: 1px; border-bottom: 1px solid #e2e8f0; padding-bottom: 8px; margin-bottom: 12px;">Informations Générales</h3>',
    '        <table style="width: 100%; border-collapse: collapse; font-size: 11px;">',
    '          <tr>',
    '            <td style="padding: 6px 0; color: #64748b; font-weight: bold; width: 35%;">Sujet :</td>',
    '            <td style="padding: 6px 0; color: #0f172a; font-weight: bold;">' + item.subject + '</td>',
    '          </tr>',
    '          <tr>',
    '            <td style="padding: 6px 0; color: #64748b; font-weight: bold; vertical-align: top;">Description :</td>',
    '            <td style="padding: 6px 0; color: #334155; white-space: pre-wrap;">' + (item.description || '---') + '</td>',
    '          </tr>',
    '          <tr>',
    '            <td style="padding: 6px 0; color: #64748b; font-weight: bold;">Typologie :</td>',
    '            <td>',
    '              <span class="badge ' + (getReclamationType(item) === 'simple' ? 'badge-simple' : 'badge-complexe') + '">' + (getReclamationType(item) === 'simple' ? '⚡ Simple' : '⚙️ Complexe') + '</span>',
    '            </td>',
    '          </tr>',
    '          <tr>',
    '            <td style="padding: 6px 0; color: #64748b; font-weight: bold;">Priorité :</td>',
    '            <td>',
    '              <span class="badge ' + (item.priority?.slug === 'high' ? 'badge-high' : 'badge-normal') + '">' + (item.priority?.name || 'Standard') + '</span>',
    '            </td>',
    '          </tr>',
    '          <tr>',
    '            <td style="padding: 6px 0; color: #64748b; font-weight: bold;">Statut Actuel :</td>',
    '            <td style="padding: 6px 0; color: #0f172a; font-weight: bold;">' + (item.status?.label || item.status?.slug || 'En cours') + '</td>',
    '          </tr>',
      '          <tr>',
      '            <td style="padding: 6px 0; color: #64748b; font-weight: bold;">Créé le :</td>',
      '            <td style="padding: 6px 0; color: #0f172a;">' + new Date(item.created_at).toLocaleString('fr-FR') + '</td>',
      '          </tr>',
      item.resolved_at ? ('          <tr><td style="padding: 6px 0; color: #64748b; font-weight: bold;">Résolu le :</td><td style="padding: 6px 0; color: #0f172a; font-weight: bold;">' + new Date(item.resolved_at).toLocaleString('fr-FR') + '</td></tr>') : '',
      '        </table>',
      '      </div>',
      '      <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 16px;">',
      '        <h3 style="font-size: 12px; font-weight: 800; color: #475569; text-transform: uppercase; letter-spacing: 1px; border-bottom: 1px solid #e2e8f0; padding-bottom: 8px; margin-bottom: 12px;">Profil Client</h3>',
      '        <table style="width: 100%; border-collapse: collapse; font-size: 11px;">',
      '          <tr>',
      '            <td style="padding: 6px 0; color: #64748b; font-weight: bold; width: 35%;">Établissement :</td>',
      '            <td style="padding: 6px 0; color: #0f172a; font-weight: bold;">' + clientName + '</td>',
      '          </tr>',
      '          <tr>',
      '            <td style="padding: 6px 0; color: #64748b; font-weight: bold;">Code Client :</td>',
      '            <td style="padding: 6px 0; color: #0f172a;">' + clientCode + '</td>',
      '          </tr>',
      '          <tr>',
      '            <td style="padding: 6px 0; color: #64748b; font-weight: bold;">Contact :</td>',
      '            <td style="padding: 6px 0; color: #0f172a;">' + contactName + '</td>',
      '          </tr>',
      '          <tr>',
      '            <td style="padding: 6px 0; color: #64748b; font-weight: bold;">Téléphone :</td>',
      '            <td style="padding: 6px 0; color: #0f172a;">' + phone + '</td>',
      '          </tr>',
      '          <tr>',
      '            <td style="padding: 6px 0; color: #64748b; font-weight: bold;">Email :</td>',
      '            <td style="padding: 6px 0; color: #0f172a;">' + email + '</td>',
      '          </tr>',
      '          <tr>',
      '            <td style="padding: 6px 0; color: #64748b; font-weight: bold; vertical-align: top;">Adresse :</td>',
      '            <td style="padding: 6px 0; color: #334155; font-size: 10px; white-space: pre-wrap;">' + address + '</td>',
      '          </tr>',
      '        </table>',
      '      </div>',
      '    </div>',
      '    <div class="grid-2" style="margin-bottom: 24px;">',
      '      <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 16px;">',
      '        <h3 style="font-size: 12px; font-weight: 800; color: #475569; text-transform: uppercase; letter-spacing: 1px; border-bottom: 1px solid #e2e8f0; padding-bottom: 8px; margin-bottom: 12px;">Détails Machine</h3>',
      '        <table style="width: 100%; border-collapse: collapse; font-size: 11px;">',
      '          <tr>',
      '            <td style="padding: 6px 0; color: #64748b; font-weight: bold; width: 35%;">Modèle :</td>',
      '            <td style="padding: 6px 0; color: #0f172a; font-weight: bold;">' + machineName + '</td>',
      '          </tr>',
      '          <tr>',
      '            <td style="padding: 6px 0; color: #64748b; font-weight: bold;">S/N :</td>',
      '            <td style="padding: 6px 0; color: #334155; font-family: monospace; font-weight: bold;">' + serialNumber + '</td>',
      '          </tr>',
      '          <tr>',
      '            <td style="padding: 6px 0; color: #64748b; font-weight: bold;">État machine :</td>',
      '            <td>',
      '              <span class="badge ' + (isFunctional ? 'badge-functional' : 'badge-broken') + '">' + (isFunctional ? 'Opérationnelle / Fonctionnelle' : 'Hors Service / En panne') + '</span>',
      '            </td>',
      '          </tr>',
      '        </table>',
      '      </div>',
      '      <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 16px;">',
      '        <h3 style="font-size: 12px; font-weight: 800; color: #475569; text-transform: uppercase; letter-spacing: 1px; border-bottom: 1px solid #e2e8f0; padding-bottom: 8px; margin-bottom: 12px;">Expert SAV Assigné</h3>',
      '        <table style="width: 100%; border-collapse: collapse; font-size: 11px;">',
      '          <tr>',
      '            <td style="padding: 6px 0; color: #64748b; font-weight: bold; width: 35%;">Technicien :</td>',
      '            <td style="padding: 6px 0; color: #0f172a; font-weight: bold;">' + techName + '</td>',
      '          </tr>',
      '          <tr>',
      '            <td style="padding: 6px 0; color: #64748b; font-weight: bold;">Téléphone :</td>',
      '            <td style="padding: 6px 0; color: #0f172a;">' + techPhone + '</td>',
      '          </tr>',
      '          <tr>',
      '            <td style="padding: 6px 0; color: #64748b; font-weight: bold;">Email :</td>',
      '            <td style="padding: 6px 0; color: #0f172a;">' + techEmail + '</td>',
      '          </tr>',
      '        </table>',
      '      </div>',
      '    </div>',
      reviewHtml,
      '    <div style="margin-top: 40px; border-top: 1px solid #e2e8f0; padding-top: 24px; display: flex; justify-content: space-between; font-size: 10px; color: #94a3b8; font-weight: bold;">',
      '      <span>Accord Qualité SPECTA SAV</span>',
      '      <div style="text-align: right; width: 250px;">',
      '        <p style="margin: 0 0 40px 0; color: #64748b;">Signature Client / Cachet d\'établissement :</p>',
      '        <div style="border-bottom: 1px dashed #cbd5e1; height: 10px;"></div>',
      '      </div>',
      '    </div>',
      '    <script>',
      '      window.onload = function() {',
      '        window.focus();',
      '        setTimeout(function() {',
      '          try {',
      '            window.print();',
      '          } catch(e) {',
      '            console.error("Print error: ", e);',
      '          }',
      '        }, 500);',
      '      };',
      '    </script>',
      '  </body>',
      '</html>'
    ];
    doc.write(htmlLines.join('\n'));
    doc.close();
  };

  /* we replaced the whole template write logic completely */
  const dummyPlaceholder = () => {
    const dummyString = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <title>Rapport d'incident SPECTA SAV #\${item.id}</title>
          <style>
            @media print {
              body { background: white; color: black; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
              .no-print { display: none !important; }
            }
            body { 
              font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; 
              color: #1e293b; 
              background: white; 
              margin: 0; 
              padding: 40px; 
              line-height: 1.5; 
            }
            h1, h2, h3, h4 { margin: 0; color: #0f172a; }
            .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
            .badge { display: inline-block; padding: 4px 10px; border-radius: 100px; font-size: 10px; font-weight: bold; text-transform: uppercase; }
            .badge-high { background: #fee2e2; color: #991b1b; }
            .badge-normal { background: #dbeafe; color: #1e40af; }
            .badge-functional { background: #d1fae5; color: #065f46; font-weight: bold; }
            .badge-broken { background: #fee2e2; color: #991b1b; font-weight: bold; }
          </style>
        </head>
        <body>
          <div style="display: flex; justify-content: space-between; align-items: flex-end; border-bottom: 4px solid #0f172a; padding-bottom: 16px; margin-bottom: 24px;">
            <div>
              <h1 style="font-size: 28px; font-weight: 900; letter-spacing: -1px; text-transform: uppercase;">SPECTA SAV</h1>
              <p style="font-size: 9px; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 3px; margin: 2px 0 0 0;">Rapport de Clôture d'Incident</p>
            </div>
            <div style="text-align: right;">
              <p style="font-size: 11px; font-weight: 600; color: #475569;">Dossier Incident: <strong style="color: #2563eb;">#\${item.id}</strong></p>
              <p style="font-size: 10px; color: #94a3b8; margin: 2px 0 0 0;">Généré le: \${new Date().toLocaleDateString('fr-FR')}</p>
            </div>
          </div>

          <div class="grid-2" style="margin-bottom: 24px;">
            <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 16px;">
              <h3 style="font-size: 12px; font-weight: 800; color: #475569; text-transform: uppercase; letter-spacing: 1px; border-bottom: 1px solid #e2e8f0; padding-bottom: 8px; margin-bottom: 12px;">Informations Générales</h3>
               <table style="width: 100%; border-collapse: collapse; font-size: 11px;">
                 <tr>
                   <td style="padding: 6px 0; color: #64748b; font-weight: bold; width: 35%;">Sujet :</td>
                   <td style="padding: 6px 0; color: #0f172a; font-weight: bold;">\${item.subject}</td>
                 </tr>
                 <tr>
                   <td style="padding: 6px 0; color: #64748b; font-weight: bold; vertical-align: top;">Description :</td>
                   <td style="padding: 6px 0; color: #334155; white-space: pre-wrap;">\${item.description || '---'}</td>
                 </tr>
                 <tr>
                   <td style="padding: 6px 0; color: #64748b; font-weight: bold;">Priorité :</td>
                   <td style="padding: 6px 0;">
                     <span class="badge \${item.priority?.slug === 'high' ? 'badge-high' : 'badge-normal'}">\${item.priority?.name || 'Standard'}</span>
                   </td>
                 </tr>
                 <tr>
                   <td style="padding: 6px 0; color: #64748b; font-weight: bold;">Statut Actuel :</td>
                   <td style="padding: 6px 0; color: #0f172a; font-weight: bold;">\${item.status?.label || item.status?.slug || 'En cours'}</td>
                 </tr>
                 <tr>
                   <td style="padding: 6px 0; color: #64748b; font-weight: bold;">Créé le :</td>
                   <td style="padding: 6px 0; color: #0f172a;">\${new Date(item.created_at).toLocaleString('fr-FR')}</td>
                 </tr>
                 \${item.resolved_at ? \`
                 <tr>
                   <td style="padding: 6px 0; color: #64748b; font-weight: bold;">Résolu le :</td>
                   <td style="padding: 6px 0; color: #0f172a; font-weight: bold;">\${new Date(item.resolved_at).toLocaleString('fr-FR')}</td>
                 </tr>
                 \` : ''}
               </table>
             </div>

             <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 16px;">
               <h3 style="font-size: 12px; font-weight: 800; color: #475569; text-transform: uppercase; letter-spacing: 1px; border-bottom: 1px solid #e2e8f0; padding-bottom: 8px; margin-bottom: 12px;">Profil Client</h3>
               <table style="width: 100%; border-collapse: collapse; font-size: 11px;">
                 <tr>
                   <td style="padding: 6px 0; color: #64748b; font-weight: bold; width: 35%;">Établissement :</td>
                   <td style="padding: 6px 0; color: #0f172a; font-weight: bold;">\${clientName}</td>
                 </tr>
                 <tr>
                   <td style="padding: 6px 0; color: #64748b; font-weight: bold;">Code Client :</td>
                   <td style="padding: 6px 0; color: #0f172a;">\${clientCode}</td>
                 </tr>
                 <tr>
                   <td style="padding: 6px 0; color: #64748b; font-weight: bold;">Contact :</td>
                   <td style="padding: 6px 0; color: #0f172a;">\${contactName}</td>
                 </tr>
                 <tr>
                   <td style="padding: 6px 0; color: #64748b; font-weight: bold;">Téléphone :</td>
                   <td style="padding: 6px 0; color: #0f172a;">\${phone}</td>
                 </tr>
                 <tr>
                   <td style="padding: 6px 0; color: #64748b; font-weight: bold;">Email :</td>
                   <td style="padding: 6px 0; color: #0f172a;">\${email}</td>
                 </tr>
                 <tr>
                   <td style="padding: 6px 0; color: #64748b; font-weight: bold; vertical-align: top;">Adresse :</td>
                   <td style="padding: 6px 0; color: #334155; font-size: 10px; white-space: pre-wrap;">\${address}</td>
                 </tr>
               </table>
             </div>
           </div>

           <div class="grid-2" style="margin-bottom: 24px;">
             <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 16px;">
               <h3 style="font-size: 12px; font-weight: 800; color: #475569; text-transform: uppercase; letter-spacing: 1px; border-bottom: 1px solid #e2e8f0; padding-bottom: 8px; margin-bottom: 12px;">Détails Machine</h3>
               <table style="width: 100%; border-collapse: collapse; font-size: 11px;">
                 <tr>
                   <td style="padding: 6px 0; color: #64748b; font-weight: bold; width: 35%;">Modèle :</td>
                   <td style="padding: 6px 0; color: #0f172a; font-weight: bold;">\${machineName}</td>
                 </tr>
                 <tr>
                   <td style="padding: 6px 0; color: #64748b; font-weight: bold;">S/N :</td>
                   <td style="padding: 6px 0; color: #334155; font-family: monospace; font-weight: bold;">\${serialNumber}</td>
                 </tr>
                 <tr>
                   <td style="padding: 6px 0; color: #64748b; font-weight: bold;">État machine :</td>
                   <td style="padding: 6px 0;">
                     <span class="badge \${isFunctional ? 'badge-functional' : 'badge-broken'}">\${isFunctional ? 'Opérationnelle / Fonctionnelle' : 'Hors Service / En panne'}</span>
                   </td>
                 </tr>
               </table>
             </div>

             <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 16px;">
               <h3 style="font-size: 12px; font-weight: 800; color: #475569; text-transform: uppercase; letter-spacing: 1px; border-bottom: 1px solid #e2e8f0; padding-bottom: 8px; margin-bottom: 12px;">Expert SAV Assigné</h3>
               <table style="width: 100%; border-collapse: collapse; font-size: 11px;">
                 <tr>
                   <td style="padding: 6px 0; color: #64748b; font-weight: bold; width: 35%;">Technicien :</td>
                   <td style="padding: 6px 0; color: #0f172a; font-weight: bold;">\${techName}</td>
                 </tr>
                 <tr>
                   <td style="padding: 6px 0; color: #64748b; font-weight: bold;">Téléphone :</td>
                   <td style="padding: 6px 0; color: #0f172a;">\${techPhone}</td>
                 </tr>
                 <tr>
                   <td style="padding: 6px 0; color: #64748b; font-weight: bold;">Email :</td>
                   <td style="padding: 6px 0; color: #0f172a;">\${techEmail}</td>
                 </tr>
               </table>
             </div>
           </div>

           \${reviewHtml}

           <div style="margin-top: 40px; border-top: 1px solid #e2e8f0; padding-top: 24px; display: flex; justify-content: space-between; font-size: 10px; color: #94a3b8; font-weight: bold;">
             <span>Accord Qualité SPECTA SAV</span>
             <div style="text-align: right; width: 250px;">
               <p style="margin: 0 0 40px 0; color: #64748b;">Signature Client / Cachet d'établissement :</p>
               <div style="border-bottom: 1px dashed #cbd5e1; height: 10px;"></div>
             </div>
           </div>

           <script>
             window.onload = function() {
               window.focus();
               setTimeout(function() {
                 try {
                   window.print();
                 } catch(e) {
                   console.error("Print error: ", e);
                 }
               }, 500);
             };
           </script>
         </body>
       </html>
     `;
   };

   const getFileUrl = (path: string) => {
    if (!path) return '';
    if (path.startsWith('http') || path.startsWith('data:') || path.startsWith('blob:')) return path;
    const clean = path.replace(/^\/?(storage\/|app\/public\/|public\/)*/, '').replace(/^\/+/, '');
    return `https://birdeye-intelligence.ma/Spetcapp/Backend/storage/app/public/${clean}`;
  };

  const getMediaType = (path: string, explicitType?: string) => {
    if (explicitType === 'image' || explicitType === 'video' || explicitType === 'audio') return explicitType;
    if (!path) return 'image';
    if (path.startsWith('data:image/') || path.toLowerCase().includes('image') || path.toLowerCase().includes('photo')) return 'image';
    if (path.startsWith('data:video/') || path.toLowerCase().includes('video')) return 'video';
    const clean = path.split('?')[0].split('#')[0];
    const ext = clean.split('.').pop()?.toLowerCase();
    if (['jpg', 'jpeg', 'png', 'webp', 'gif', 'svg', 'bmp'].includes(ext || '')) return 'image';
    if (['mp4', 'webm', 'mov', 'ogg', 'mkv', '3gp', 'avi'].includes(ext || '')) return 'video';
    if (['mp3', 'wav', 'aac', 'm4a', 'amr'].includes(ext || '')) return 'audio';
    return 'image';
  };

  const parseSurveyText = (text: string) => {
    const sections: Array<{
      title: string;
      items: Array<{ question: string; score: number; label: string }>;
    }> = [];
    let comments = '';
    
    if (!text) return { sections, comments };
    
    const lines = text.split('\n');
    let currentSection: { title: string; items: Array<{ question: string; score: number; label: string }> } | null = null;
    
    for (const rawLine of lines) {
      const line = rawLine.trim();
      if (!line) continue;
      
      if (line.toUpperCase().startsWith('[COMMENTAIRES]:') || line.toUpperCase().startsWith('[COMMENTAIRES] :')) {
        const idx = line.indexOf(':');
        comments = line.substring(idx + 1).trim();
        continue;
      }
      
      if (line.startsWith('[') && line.endsWith(']')) {
        const title = line.substring(1, line.length - 1);
        currentSection = { title, items: [] };
        sections.push(currentSection);
      } else if (line.startsWith('-') && currentSection) {
        const itemText = line.substring(1).trim();
        const colonIndex = itemText.lastIndexOf(':');
        if (colonIndex !== -1) {
          const question = itemText.substring(0, colonIndex).trim();
          const scorePart = itemText.substring(colonIndex + 1).trim();
          
          let score = 0;
          let label = scorePart;
          
          const scoreMatch = scorePart.match(/^([0-5])\/5/);
          if (scoreMatch) {
            score = parseInt(scoreMatch[1], 10);
            const parenMatch = scorePart.match(/\(([^)]+)\)/);
            if (parenMatch) {
              label = parenMatch[1];
            } else {
              label = scorePart.replace(scoreMatch[0], '').trim();
            }
          }
          currentSection.items.push({ question, score, label });
        } else {
          currentSection.items.push({ question: itemText, score: 0, label: '' });
        }
      } else if (!line.startsWith('---') && !line.startsWith('[')) {
        if (comments) {
          comments += '\n' + line;
        } else {
          comments = line;
        }
      }
    }
    
    return { sections, comments };
  };

  const formatReviewComment = (text: string) => {
    if (!text) return null;
    
    const isSurvey = typeof text === 'string' && (text.includes('--- ENQUÊTE') || text.includes('[Général]'));
    
    if (!isSurvey) {
      return (
        <div className="bg-slate-50 p-8 rounded-2xl border border-slate-100 shadow-inner italic text-slate-600 text-sm leading-relaxed text-left font-medium">
          {text.split('\n').map((line, i) => <p key={i} className="mb-1">{line}</p>)}
        </div>
      );
    }
    
    const { sections, comments } = parseSurveyText(text);
    
    const getCategoryIcon = (title: string) => {
      const t = title.toLowerCase();
      if (t.includes('général')) return 'ti-clipboard-heart';
      if (t.includes('consommable') || t.includes('qualité')) return 'ti-package';
      if (t.includes('technique') || t.includes('suivi')) return 'ti-tool';
      if (t.includes('commercial')) return 'ti-headset';
      if (t.includes('devis')) return 'ti-file-invoice';
      return 'ti-star-filled';
    };
    
    const getScoreColor = (score: number) => {
      if (score >= 5) return { bg: 'bg-emerald-50 text-emerald-700 border-emerald-200', text: 'text-emerald-500', bar: 'bg-emerald-500' };
      if (score === 4) return { bg: 'bg-teal-50 text-teal-700 border-teal-200', text: 'text-teal-500', bar: 'bg-teal-500' };
      if (score === 3) return { bg: 'bg-amber-50 text-amber-700 border-amber-200', text: 'text-amber-500', bar: 'bg-amber-500' };
      if (score === 2) return { bg: 'bg-orange-50 text-orange-700 border-orange-200', text: 'text-orange-500', bar: 'bg-orange-500' };
      return { bg: 'bg-rose-50 text-rose-700 border-rose-200', text: 'text-rose-500', bar: 'bg-rose-500' };
    };

    return (
      <div className="space-y-8 text-left">
        {/* Sections Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {sections.map((sec, idx) => (
            <div key={idx} className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden flex flex-col">
              <div className="bg-slate-50 px-6 py-4 border-b border-slate-100 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center text-lg">
                  <i className={`ti ${getCategoryIcon(sec.title)}`}></i>
                </div>
                <h4 className="font-extrabold text-slate-800 text-sm tracking-tight">{sec.title}</h4>
              </div>
              
              <div className="p-6 space-y-4 flex-1">
                {sec.items.map((item, i) => {
                  const colors = getScoreColor(item.score);
                  return (
                    <div key={i} className="space-y-1.5 pb-3 border-b border-slate-50 last:border-0 last:pb-0">
                      <div className="flex justify-between items-start gap-4">
                        <span className="text-xs font-semibold text-slate-600 leading-tight">{item.question}</span>
                        {item.score > 0 && (
                          <span className={`px-2 py-0.5 rounded-[10px] text-[10px] font-extrabold border shrink-0 uppercase tracking-wider ${colors.bg}`}>
                            {item.score}/5
                          </span>
                        )}
                      </div>
                      
                      {item.score > 0 && (
                        <div className="flex items-center gap-3">
                          <div className="flex gap-0.5">
                            {[1, 2, 3, 4, 5].map(star => (
                              <i key={star} className={`ti ti-star-filled text-xs ${star <= item.score ? colors.text : 'text-slate-100'}`}></i>
                            ))}
                          </div>
                          
                          <div className="h-1 flex-1 bg-slate-100 rounded-full overflow-hidden">
                            <div className={`h-full ${colors.bar} rounded-full`} style={{ width: `${(item.score / 5) * 100}%` }}></div>
                          </div>
                          
                          {item.label && (
                            <span className="text-[10px] font-bold text-slate-400 capitalize whitespace-nowrap">{item.label}</span>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Global Client Comments Section */}
        {comments && (
          <div className="bg-slate-50 p-8 rounded-3xl border border-slate-100 relative overflow-hidden">
            <i className="ti ti-quote text-7xl text-slate-200/50 absolute top-2 right-6 -z-0"></i>
            <div className="relative z-10 space-y-3">
              <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                <i className="ti ti-message-2 text-sm text-slate-500"></i> Commentaire client additionnel
              </h4>
              <p className="text-slate-700 text-sm font-medium leading-relaxed italic">
                "{comments}"
              </p>
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-10 pb-20 animate-in fade-in duration-700">
      {/* KPI DASHBOARD */}
      <div className="space-y-4">
        {/* Typology Analytics - Prominent Section Requested by User */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <SAVKPI 
            label="⚡ Réclamations Simples" 
            value={stats.countSimple} 
            icon="ti-bolt" 
            color="bg-emerald-600"
            active={typeFilter === 'simple'}
            onClick={() => setTypeFilter(typeFilter === 'simple' ? 'all' : 'simple')}
            subtitle={`${stats.simplePct}% du volume (${stats.simpleActive} en cours)`}
            badge="Résolution Rapide"
          />
          <SAVKPI 
            label="⚙️ Réclamations Complexes" 
            value={stats.countComplexe} 
            icon="ti-cpu" 
            color="bg-purple-600"
            active={typeFilter === 'complexe'}
            onClick={() => setTypeFilter(typeFilter === 'complexe' ? 'all' : 'complexe')}
            subtitle={`${stats.complexPct}% du volume (${stats.complexActive} en cours)`}
            badge="Intervention Lourde"
          />
          <SAVKPI 
            label="Total Dossiers SAV" 
            value={stats.total} 
            icon="ti-ticket" 
            color="bg-blue-600"
            active={typeFilter === 'all'}
            onClick={() => setTypeFilter('all')}
            subtitle={`${stats.inProgress} interventions actives`}
            badge="Tous les types"
          />
        </div>

        {/* Operational KPIs */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          <SAVKPI 
            label="En Cours" 
            value={stats.inProgress} 
            icon="ti-tool" 
            color="bg-amber-500" 
            active={statusFilter === 'in_progress'}
            onClick={() => setStatusFilter(statusFilter === 'in_progress' ? 'all' : 'in_progress')}
            subtitle="Interventions actives"
          />
          <SAVKPI 
            label="Clôturés (30j)" 
            value={stats.resolved} 
            icon="ti-circle-check" 
            color="bg-teal-600" 
            active={statusFilter === 'resolved' || statusFilter === 'closed'}
            onClick={() => setStatusFilter(statusFilter === 'resolved' ? 'all' : 'resolved')}
            subtitle="Dossiers résolus"
          />
          <SAVKPI 
            label="Délai Moyen Traitement" 
            value={formatDelay(stats.avgDelayMins)} 
            icon="ti-clock-bolt" 
            color="bg-indigo-600" 
            subtitle="Résolution moyenne"
          />
        </div>
      </div>

      {/* HEADER SECTION */}
      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-6 bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-3xl sm:text-4xl font-black text-slate-800 tracking-tight">SAV Command Hub</h1>
            <span className="bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider border border-blue-100">
              Support Technique
            </span>
          </div>
          <p className="text-slate-400 font-bold uppercase text-[10px] tracking-[3px] mt-1.5">
            Gestion & Pilotage du Service Après-Vente • Réclamations Simples & Complexes
          </p>
        </div>
        
        <div className="flex flex-wrap items-center gap-4">
          <button 
            onClick={() => navigate('/admin/sav/new')}
            className="px-6 py-3.5 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black uppercase text-xs tracking-wider shadow-lg shadow-blue-500/20 hover:shadow-xl transition-all flex items-center gap-2 active:scale-95 cursor-pointer"
          >
            <i className="ti ti-plus text-lg"></i> Nouveau Ticket SAV
          </button>

          <div className="flex bg-slate-100 p-1.5 rounded-2xl border border-slate-200 shadow-inner">
            <button 
              onClick={() => setViewMode('kanban')} 
              className={`px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'kanban' ? 'bg-white text-blue-600 shadow-md' : 'text-slate-400 hover:text-slate-600'}`}
            >
              <i className="ti ti-layout-kanban text-sm mr-2"></i> Kanban
            </button>
            <button 
              onClick={() => setViewMode('list')} 
              className={`px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'list' ? 'bg-white text-blue-600 shadow-md' : 'text-slate-400 hover:text-slate-600'}`}
            >
              <i className="ti ti-list text-sm mr-2"></i> Liste
            </button>
          </div>
          <button 
            onClick={fetchTickets} 
            title="Rafraîchir les tickets"
            className="w-12 h-12 bg-slate-50 text-slate-400 hover:text-blue-600 rounded-2xl flex items-center justify-center transition-all border border-slate-200 shadow-sm active:scale-90 cursor-pointer"
          >
            <i className="ti ti-refresh text-xl"></i>
          </button>
        </div>
      </div>

      {/* FILTER HUB SECTION */}
      <div className="bg-white p-6 sm:p-7 rounded-3xl shadow-sm border border-slate-100 space-y-5">
        {/* Typology Segmented Control (Requested by user) */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 mr-1">Typologie :</span>
            
            <button
              type="button"
              onClick={() => setTypeFilter('all')}
              className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-2 ${
                typeFilter === 'all'
                  ? 'bg-slate-900 text-white shadow-md'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Tous les types
              <span className={`px-2 py-0.5 rounded-full text-[10px] ${typeFilter === 'all' ? 'bg-white/20 text-white' : 'bg-white text-slate-500'}`}>
                {stats.total}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setTypeFilter('simple')}
              className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-2 ${
                typeFilter === 'simple'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                  : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200/50'
              }`}
            >
              <i className="ti ti-bolt"></i>
              ⚡ Réclamations Simples
              <span className={`px-2 py-0.5 rounded-full text-[10px] ${typeFilter === 'simple' ? 'bg-white/20 text-white' : 'bg-emerald-200/70 text-emerald-900'}`}>
                {stats.countSimple}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setTypeFilter('complexe')}
              className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-2 ${
                typeFilter === 'complexe'
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
                  : 'bg-purple-50 text-purple-700 hover:bg-purple-100 border border-purple-200/50'
              }`}
            >
              <i className="ti ti-cpu"></i>
              ⚙️ Réclamations Complexes
              <span className={`px-2 py-0.5 rounded-full text-[10px] ${typeFilter === 'complexe' ? 'bg-white/20 text-white' : 'bg-purple-200/70 text-purple-900'}`}>
                {stats.countComplexe}
              </span>
            </button>
          </div>

          {/* Quick stats indicator */}
          <div className="text-xs font-bold text-slate-400">
            Affichage de <span className="text-slate-800 font-black">{filteredTickets.length}</span> sur <span className="text-slate-800 font-black">{tickets.length}</span> tickets
          </div>
        </div>

        {/* Multi-Filters row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5">
          {/* Search */}
          <div className="lg:col-span-2 relative">
            <i className="ti ti-search absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 text-base"></i>
            <input 
              type="text"
              placeholder="Rechercher par #ID, client, sujet, machine..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl outline-none font-bold text-slate-700 placeholder:text-slate-400 text-xs focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
            />
            {searchTerm && (
              <button 
                type="button"
                onClick={() => setSearchTerm('')} 
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-sm"
              >
                ×
              </button>
            )}
          </div>

          {/* Status filter */}
          <div>
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl outline-none font-bold text-slate-700 text-xs focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all cursor-pointer"
            >
              <option value="all">Statut : Tous</option>
              <option value="new">Nouveaux</option>
              <option value="assigned">Assignés</option>
              <option value="in_progress">En cours</option>
              <option value="resolved">Résolus</option>
              <option value="closed">Clôturés</option>
            </select>
          </div>

          {/* Priority filter */}
          <div>
            <select
              value={priorityFilter}
              onChange={e => setPriorityFilter(e.target.value)}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl outline-none font-bold text-slate-700 text-xs focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all cursor-pointer"
            >
              <option value="all">Urgence : Toutes</option>
              <option value="high">Critique / Haute</option>
              <option value="medium">Moyenne</option>
              <option value="low">Basse</option>
            </select>
          </div>

          {/* Technician filter */}
          <div>
            <select
              value={technicianFilter}
              onChange={e => setTechnicianFilter(e.target.value)}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl outline-none font-bold text-slate-700 text-xs focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all cursor-pointer"
            >
              <option value="all">Technicien : Tous</option>
              <option value="unassigned">⚠️ Non assigné</option>
              {technicians.map(t => (
                <option key={t.id} value={t.id.toString()}>{t.name}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Active Filters Pill Bar (When filters are modified) */}
        {(typeFilter !== 'all' || statusFilter !== 'all' || priorityFilter !== 'all' || technicianFilter !== 'all' || searchTerm !== '' || functionalFilter !== 'all') && (
          <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">Filtres actifs :</span>
              {typeFilter !== 'all' && (
                <span className={`px-2.5 py-1 rounded-lg font-bold text-[11px] flex items-center gap-1.5 ${typeFilter === 'simple' ? 'bg-emerald-100 text-emerald-800' : 'bg-purple-100 text-purple-800'}`}>
                  Typologie: {typeFilter === 'simple' ? '⚡ Simple' : '⚙️ Complexe'}
                  <button onClick={() => setTypeFilter('all')} className="hover:text-black">×</button>
                </span>
              )}
              {statusFilter !== 'all' && (
                <span className="px-2.5 py-1 rounded-lg font-bold text-[11px] bg-blue-100 text-blue-800 flex items-center gap-1.5">
                  Statut: {statusFilter}
                  <button onClick={() => setStatusFilter('all')} className="hover:text-black">×</button>
                </span>
              )}
              {priorityFilter !== 'all' && (
                <span className="px-2.5 py-1 rounded-lg font-bold text-[11px] bg-rose-100 text-rose-800 flex items-center gap-1.5">
                  Priorité: {priorityFilter}
                  <button onClick={() => setPriorityFilter('all')} className="hover:text-black">×</button>
                </span>
              )}
              {technicianFilter !== 'all' && (
                <span className="px-2.5 py-1 rounded-lg font-bold text-[11px] bg-amber-100 text-amber-800 flex items-center gap-1.5">
                  Technicien: {technicianFilter === 'unassigned' ? 'Non assigné' : technicians.find(t => t.id.toString() === technicianFilter)?.name || technicianFilter}
                  <button onClick={() => setTechnicianFilter('all')} className="hover:text-black">×</button>
                </span>
              )}
              {searchTerm && (
                <span className="px-2.5 py-1 rounded-lg font-bold text-[11px] bg-slate-100 text-slate-800 flex items-center gap-1.5">
                  Recherche: "{searchTerm}"
                  <button onClick={() => setSearchTerm('')} className="hover:text-black">×</button>
                </span>
              )}
            </div>

            <button
              type="button"
              onClick={handleResetFilters}
              className="text-slate-400 hover:text-rose-600 font-black uppercase text-[10px] tracking-wider transition-colors shrink-0 cursor-pointer"
            >
              <i className="ti ti-trash mr-1"></i> Réinitialiser les filtres
            </button>
          </div>
        )}
      </div>

      {/* MAIN VIEWPORT */}
      {loading ? (
        <div className="py-40 text-center space-y-4">
            <div className="animate-spin h-16 w-16 border-t-4 border-blue-600 rounded-full mx-auto"></div>
            <p className="text-[10px] font-black uppercase tracking-[5px] text-slate-400">Scanning Incident Network...</p>
        </div>
      ) : viewMode === 'kanban' ? (
        <div className="flex gap-6 overflow-x-auto pb-6 custom-scrollbar min-h-[700px]">
          {COLUMNS.map(col => (
            <div key={col.id} className="w-80 min-w-[320px] bg-slate-100/40 rounded-3xl p-4 flex flex-col gap-5 border border-slate-200/50 shrink-0">
              <div className="flex items-center justify-between px-4">
                <h3 className="text-[10px] font-black uppercase tracking-[3px] text-slate-500 flex items-center gap-2">
                  <span className={`w-2.5 h-2.5 rounded-full ${col.color}`}></span> {col.label}
                </h3>
                <span className="bg-white px-3 py-1 rounded-full text-[10px] font-black shadow-sm text-slate-400">
                  {filteredTickets.filter(t => (t?.status?.slug || 'new') === col.id).length}
                </span>
              </div>
              <div className="flex-1 space-y-4 overflow-y-auto pr-1 custom-scrollbar">
                {filteredTickets.filter(t => (t?.status?.slug || 'new') === col.id).map(ticket => (
                  <div 
                    key={ticket.id} 
                    onClick={() => openTicket(ticket)}
                    className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200 hover:border-blue-400 hover:shadow-lg hover:-translate-y-1 transition-all cursor-pointer group"
                  >
                    <div className="flex justify-between items-start mb-3 gap-2">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className={`text-[9px] font-black uppercase tracking-widest px-2.5 py-1 rounded-full ${ticket?.priority?.slug === 'high' ? 'bg-rose-50 text-rose-500' : 'bg-blue-50 text-blue-500'}`}>
                          {ticket?.priority?.name || 'Standard'}
                        </span>
                        {getReclamationType(ticket) === 'simple' ? (
                          <span className="text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200/70 flex items-center gap-1">
                            <i className="ti ti-bolt text-[10px]"></i> Simple
                          </span>
                        ) : (
                          <span className="text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-purple-50 text-purple-700 border border-purple-200/70 flex items-center gap-1">
                            <i className="ti ti-cpu text-[10px]"></i> Complexe
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-slate-300 font-mono font-bold shrink-0">#{ticket.id}</span>
                    </div>
                    <h4 className="font-black text-slate-800 text-sm mb-1 leading-tight group-hover:text-blue-600 transition-colors truncate">{ticket.subject}</h4>
                    <p className="text-[10px] font-bold text-slate-400 mb-4 uppercase truncate italic">{ticket?.client_machine?.machine?.name || 'Équipement non spécifié'}</p>
                    <div className="flex items-center gap-3 pt-4 border-t border-slate-50">
                      <img src={`https://ui-avatars.com/api/?name=${ticket.client?.name}&background=F1F5F9&color=64748B&bold=true`} className="w-8 h-8 rounded-full shadow-sm" alt="" />
                      <div className="flex-1 overflow-hidden">
                          <p className="text-[11px] font-black text-slate-600 truncate">{ticket.client?.name || 'Client'}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden animate-in slide-in-from-bottom-8 duration-700">
            <table className="w-full text-left">
                <thead className="bg-slate-50/50 border-b">
                    <tr className="text-[10px] font-black uppercase text-slate-400 tracking-widest">
                        <th className="px-6 py-4">Ticket #</th>
                        <th className="px-6 py-4">Typologie</th>
                        <th className="px-6 py-4">Établissement & Date</th>
                        <th className="px-6 py-4">Machine / S/N</th>
                        <th className="px-6 py-4">Urgence</th>
                        <th className="px-6 py-4">Statut</th>
                        <th className="px-6 py-4">Technicien</th>
                        <th className="px-6 py-4 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                    {filteredTickets.map(t => (
                        <tr key={t.id} onClick={() => openTicket(t)} className="group hover:bg-slate-50/50 transition-colors cursor-pointer">
                            <td className="px-6 py-4 font-mono text-blue-600 font-bold">#{t.id}</td>
                            <td className="px-6 py-4">
                                {getReclamationType(t) === 'simple' ? (
                                    <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-wider bg-emerald-50 text-emerald-700 border border-emerald-200">
                                        <i className="ti ti-bolt"></i> Simple
                                    </span>
                                ) : (
                                    <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-wider bg-purple-50 text-purple-700 border border-purple-200">
                                        <i className="ti ti-cpu"></i> Complexe
                                    </span>
                                )}
                            </td>
                            <td className="px-6 py-4">
                                <p className="font-black text-slate-800 text-base group-hover:text-blue-600 transition-colors truncate max-w-[240px]">{t.client?.name || 'Client inconnu'}</p>
                                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mt-0.5">{new Date(t.created_at).toLocaleDateString()}</p>
                            </td>
                            <td className="px-6 py-4 font-bold text-slate-600 text-sm">
                                <p>{t.client_machine?.machine?.name || '---'}</p>
                                <p className="text-[9px] font-black text-slate-300 uppercase tracking-tighter mt-0.5">S/N: {t.client_machine?.serial_number || 'N/A'}</p>
                            </td>
                            <td className="px-6 py-4">
                                <span className={`px-3 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest ${t.priority?.slug === 'high' ? 'bg-rose-50 text-rose-500 border border-rose-100' : 'bg-slate-50 text-slate-500 border border-slate-100'}`}>{t.priority?.name || 'Standard'}</span>
                            </td>
                            <td className="px-6 py-4">
                                <span className="px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-wider bg-slate-100 text-slate-700">
                                    {t.status?.name || t.status?.slug || 'Nouveau'}
                                </span>
                            </td>
                            <td className="px-6 py-4">
                                {t.assigned_technician ? (
                                    <span className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-700">
                                        <i className="ti ti-user-check text-blue-600"></i> {t.assigned_technician.name}
                                    </span>
                                ) : (
                                    <span className="text-[10px] font-bold text-slate-400 italic">Non assigné</span>
                                )}
                            </td>
                            <td className="px-6 py-4 text-right">
                                <button className="p-3 bg-slate-900 text-white rounded-xl shadow-lg hover:bg-blue-600 transition-all cursor-pointer"><i className="ti ti-chart-arrows text-lg"></i></button>
                            </td>
                        </tr>
                    ))}
                    {filteredTickets.length === 0 && (
                        <tr>
                            <td colSpan={8} className="text-center py-16 text-slate-400">
                                <div className="max-w-sm mx-auto space-y-3">
                                    <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-2xl text-slate-400">
                                        <i className="ti ti-filter-off"></i>
                                    </div>
                                    <p className="font-bold text-slate-600">Aucun ticket ne correspond à vos critères</p>
                                    <p className="text-xs text-slate-400">Essayez de modifier votre filtre de typologie ou de recherche.</p>
                                    <button
                                        type="button"
                                        onClick={handleResetFilters}
                                        className="px-4 py-2 bg-blue-50 text-blue-600 rounded-xl text-xs font-bold hover:bg-blue-100 transition-all cursor-pointer"
                                    >
                                        Effacer les filtres
                                    </button>
                                </div>
                            </td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
      )}

      {/* FULL DETAIL VIEW MODAL */}
      {modal.type === 'view' && modal.item && (
          <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-md z-[150] flex items-center justify-center p-4">
              <div className="bg-white w-full max-w-7xl rounded-3xl shadow-2xl overflow-hidden border-4 border-white flex flex-col max-h-[95vh] animate-in zoom-in-95 duration-300">
                  {/* Modal Header */}
                  <div className="p-8 border-b flex justify-between items-center bg-slate-50/50 shrink-0">
                      <div className="flex items-center gap-6">
                          <div className={`w-16 h-16 rounded-2xl flex items-center justify-center text-3xl shadow-xl ${!modal.item.is_machine_functional ? 'bg-rose-600 text-white animate-pulse' : 'bg-blue-600 text-white'}`}>
                              <i className={!modal.item.is_machine_functional ? 'ti ti-alert-triangle' : 'ti ti-tool'}></i>
                          </div>
                          <div>
                              <h2 className="text-2xl font-black text-slate-800 tracking-tighter leading-none mb-1">Dossier Incident #{modal.item.id}</h2>
                              <div className="flex items-center gap-3 flex-wrap">
                                  <span className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest ${modal.item.priority?.slug === 'high' ? 'bg-rose-100 text-rose-600' : 'bg-blue-100 text-blue-600'}`}>
                                      {modal.item.priority?.name} Priority
                                  </span>
                                  {getReclamationType(modal.item) === 'simple' ? (
                                      <span className="px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-wider bg-emerald-100 text-emerald-700 border border-emerald-200 flex items-center gap-1.5 shadow-xs">
                                          <i className="ti ti-bolt text-xs"></i> Réclamation Simple
                                      </span>
                                  ) : (
                                      <span className="px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-wider bg-purple-100 text-purple-700 border border-purple-200 flex items-center gap-1.5 shadow-xs">
                                          <i className="ti ti-cpu text-xs"></i> Réclamation Complexe
                                      </span>
                                  )}
                                  <p className="text-slate-400 font-black uppercase text-[10px] tracking-[4px]">{modal.item.subject}</p>
                              </div>
                          </div>
                      </div>
                      <div className="flex gap-4 items-center">
                          {/* Quick Typology Toggle in Header */}
                          <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 print:hidden">
                              <button
                                  type="button"
                                  onClick={() => handleUpdateTicketType(modal.item.id, 'simple')}
                                  className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all flex items-center gap-1 ${getReclamationType(modal.item) === 'simple' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}
                                  title="Définir comme Réclamation Simple"
                              >
                                  <i className="ti ti-bolt"></i> Simple
                              </button>
                              <button
                                  type="button"
                                  onClick={() => handleUpdateTicketType(modal.item.id, 'complexe')}
                                  className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all flex items-center gap-1 ${getReclamationType(modal.item) === 'complexe' ? 'bg-purple-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}
                                  title="Définir comme Réclamation Complexe"
                              >
                                  <i className="ti ti-cpu"></i> Complexe
                              </button>
                          </div>

                          <button 
                              onClick={handlePrint} 
                              className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-4 rounded-xl font-black uppercase text-[10px] tracking-[2px] shadow-xl shadow-emerald-100 transition-all flex items-center gap-2 active:scale-95 print:hidden cursor-pointer"
                          >
                              <i className="ti ti-printer text-lg"></i> Imprimer / PDF
                          </button>
                          {!modal.item.assigned_technician && !modal.item.assigned_technician_id && (
                              <button 
                                  onClick={() => setModal({ type: 'assign', item: modal.item })} 
                                  className="bg-blue-600 text-white px-6 py-4 rounded-xl font-black uppercase text-[10px] tracking-[2px] shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all flex items-center gap-2 active:scale-95 print:hidden cursor-pointer"
                              >
                                  <i className="ti ti-user-plus text-lg"></i> Affecter Technicien
                              </button>
                          )}
                          <button onClick={() => setModal({ type: null, item: null })} className="w-14 h-14 flex items-center justify-center bg-white rounded-full text-slate-300 hover:text-red-500 shadow-xl text-3xl font-light hover:rotate-90 transition-all print:hidden cursor-pointer">×</button>
                      </div>
                  </div>

                  {/* Modal Tabs Navigation */}
                  <div className="px-8 py-4 border-b bg-white flex gap-4 shrink-0 overflow-x-auto no-scrollbar">
                      <TabBtn active={activeTab === 'dossier'} onClick={() => setActiveTab('dossier')} icon="ti-file-invoice" label="Fiche Technique" />
                      <TabBtn active={activeTab === 'media'} onClick={() => setActiveTab('media')} icon="ti-photo-video" label="Galerie Média" />
                      <TabBtn active={activeTab === 'client'} onClick={() => setActiveTab('client')} icon="ti-building-hospital" label="Profil Client" />
                      <TabBtn active={activeTab === 'machine'} onClick={() => setActiveTab('machine')} icon="ti-device-analytics" label="Détails Machine" />
                      <TabBtn active={activeTab === 'review'} onClick={() => setActiveTab('review')} icon="ti-star" label="Satisfaction Client" />
                  </div>

                  {/* Modal Content */}
                  <div className="flex-1 overflow-y-auto p-10 bg-slate-50/20 custom-scrollbar">
                      {activeTab === 'dossier' && (
                          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 animate-in fade-in duration-500">
                              <div className="lg:col-span-8 space-y-8">
                                  <section>
                                      <h4 className="text-[11px] font-black text-blue-500 uppercase tracking-[5px] mb-6 flex items-center gap-3"><i className="ti ti-notes text-xl"></i> Signalement du Praticien</h4>
                                      <div className="bg-white p-8 rounded-3xl text-slate-700 text-lg leading-relaxed font-medium italic border border-slate-100 shadow-sm relative group overflow-hidden">
                                          <div className="absolute -right-8 -top-8 w-24 h-24 bg-blue-50 rounded-full opacity-0 group-hover:opacity-100 transition-all scale-0 group-hover:scale-100"></div>
                                          <p className="relative z-10">"{modal.item.description || 'Aucun détail textuel fourni par le client.'}"</p>
                                      </div>
                                  </section>

                                  {/* USED SPARE PARTS IN TICKET */}
                                  <section className="space-y-6">
                                      <h4 className="text-[11px] font-black text-amber-600 uppercase tracking-[5px] flex items-center gap-3"><i className="ti ti-tool text-2xl"></i> Pièces de Rechange Utilisées</h4>
                                      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
                                          {/* Used parts table list */}
                                          <div className="md:col-span-7 space-y-4">
                                              {usedParts.length === 0 ? (
                                                  <p className="text-slate-400 text-xs italic">Aucune pièce de rechange consignée pour cette intervention.</p>
                                              ) : (
                                                  <div className="divide-y divide-slate-100">
                                                      {usedParts.map((up: any) => (
                                                          <div key={up.id} className="py-3 flex items-center justify-between text-xs font-bold">
                                                              <div>
                                                                  <p className="text-slate-800 uppercase">{up.name}</p>
                                                                  <p className="text-[10px] text-slate-400 font-semibold uppercase">Ref: {up.reference}</p>
                                                              </div>
                                                              <div className="text-right">
                                                                  <span className="px-3 py-1 bg-slate-100 text-slate-600 rounded-lg text-[10px]">Qté: {up.quantity}</span>
                                                                  <p className="text-[10px] text-slate-400 mt-1">{up.price_charged ? `${up.price_charged.toLocaleString()} MAD` : 'Facturation incluse'}</p>
                                                              </div>
                                                          </div>
                                                      ))}
                                                  </div>
                                              )}
                                          </div>

                                          {/* Add used parts form */}
                                          <form onSubmit={(e) => {
                                              e.preventDefault();
                                              const formEl = e.target as HTMLFormElement;
                                              const partId = parseInt((formEl.elements.namedItem('used_part_id') as HTMLSelectElement).value);
                                              const qty = parseInt((formEl.elements.namedItem('used_qty') as HTMLInputElement).value) || 1;
                                              if (!partId) return;
                                              handleAddUsedPart(partId, qty);
                                              formEl.reset();
                                          }} className="md:col-span-5 space-y-3 pl-0 md:pl-6 border-t md:border-t-0 md:border-l border-slate-100 pt-6 md:pt-0">
                                              <p className="text-[10px] font-black text-slate-400 uppercase tracking-wider">Consigner une pièce</p>
                                              <div className="space-y-2">
                                                  <select name="used_part_id" required className="w-full bg-slate-50 border-0 focus:ring-2 focus:ring-amber-500 rounded-xl px-4 py-2.5 text-xs font-bold text-slate-700">
                                                      <option value="">-- Choisir la pièce --</option>
                                                      {allSpareParts.map(p => (
                                                          <option key={p.id} value={p.id}>{p.name} ({p.reference})</option>
                                                      ))}
                                                  </select>
                                                  <input name="used_qty" type="number" min="1" required defaultValue="1" placeholder="Qté" className="w-full bg-slate-50 border-0 focus:ring-2 focus:ring-amber-500 rounded-xl px-4 py-2 text-xs font-bold text-slate-700" />
                                              </div>
                                              <button type="submit" className="w-full py-2.5 bg-amber-500 hover:bg-amber-600 text-white font-black text-[9px] uppercase tracking-wider rounded-xl shadow-md transition-all active:scale-95">
                                                  Enregistrer la pièce
                                              </button>
                                          </form>
                                      </div>
                                  </section>

                                  {/* COMMUNICATION HUB */}
                                  <section className="space-y-6">
                                      <h4 className="text-[11px] font-black text-indigo-600 uppercase tracking-[5px] flex items-center gap-3"><i className="ti ti-messages text-2xl"></i> Messages Échangés</h4>
                                      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden flex flex-col h-[500px]">
                                          <div ref={chatContainerRef} className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-50/50 custom-scrollbar">
                                              {modal.item.messages?.length > 0 ? (
                                                  modal.item.messages.map((msg: any) => (
                                                      <MessageBubble 
                                                          key={msg.id}
                                                          isOfficial={msg.type === 'technician' || msg.type === 'system'} 
                                                          sender={msg.type === 'technician' ? 'Support Specta' : (msg.type === 'system' ? 'Système Intelligence' : modal.item.client?.name)} 
                                                          text={msg.message} 
                                                          time={new Date(msg.created_at).toLocaleString('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })} 
                                                      />
                                                  ))
                                              ) : (
                                                  <div className="flex flex-col items-center justify-center h-full opacity-20 italic">
                                                      <i className="ti ti-messages-off text-6xl mb-4"></i>
                                                      <p className="text-xs uppercase tracking-widest font-black">Aucun message échangé</p>
                                                  </div>
                                              )}
                                          </div>
                                          
                                          <div className="p-6 border-t bg-white">
                                              <div className="flex gap-4 items-end">
                                                  <div className="flex-1 relative">
                                                      <textarea 
                                                          value={replyText}
                                                          onChange={e => setReplyText(e.target.value)}
                                                          placeholder="Rédiger une réponse officielle pour la clinique..." 
                                                          className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl outline-none font-medium text-sm h-24 italic shadow-inner focus:ring-4 focus:ring-blue-500/5 transition-all resize-none"
                                                      />
                                                  </div>
                                                  <button 
                                                      onClick={handleSendMessage}
                                                      disabled={isSubmitting || !replyText.trim()}
                                                      className="h-24 px-8 bg-indigo-600 text-white rounded-2xl font-black uppercase text-[10px] tracking-[3px] shadow-xl active:scale-95 transition-all hover:bg-indigo-700 flex flex-col items-center justify-center gap-2 disabled:opacity-50"
                                                  >
                                                      <i className="ti ti-send text-2xl"></i>
                                                      Transmettre
                                                  </button>
                                              </div>
                                          </div>
                                      </div>
                                  </section>
                              </div>

                              <div className="lg:col-span-4 space-y-6">
                                  {/* TECHNICIAN INFO CARD */}
                                  <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
                                      <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[4px] border-b pb-4 mb-6">Expert Technique</h4>
                                      {modal.item.assigned_technician ? (
                                          <>
                                              <div className="flex items-center gap-4 mb-6">
                                                  <div className="relative">
                                                      <img 
                                                          src={modal.item.assigned_technician.avatar_url ? (modal.item.assigned_technician.avatar_url.startsWith('http') ? modal.item.assigned_technician.avatar_url : getFileUrl(modal.item.assigned_technician.avatar_url)) : `https://ui-avatars.com/api/?name=${modal.item.assigned_technician.name}&background=F1F5F9&color=64748B&bold=true`} 
                                                          className="w-14 h-14 rounded-2xl border-2 border-white shadow-md object-cover" 
                                                          alt="" 
                                                      />
                                                      {modal.item.assigned_technician.is_online && (
                                                          <span className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 border-2 border-white rounded-full shadow-sm"></span>
                                                      )}
                                                  </div>
                                                  <div className="overflow-hidden">
                                                      <h5 className="font-black text-slate-800 text-sm leading-tight truncate">{modal.item.assigned_technician.name}</h5>
                                                      <p className="text-[9px] font-bold text-blue-500 uppercase tracking-widest mt-1">Technicien SAV</p>
                                                  </div>
                                              </div>
                                              <div className="space-y-3">
                                                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 flex items-center gap-3">
                                                      <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-slate-400 shadow-sm"><i className="ti ti-mail"></i></div>
                                                      <div className="overflow-hidden">
                                                          <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Email</p>
                                                          <p className="text-xs font-bold text-slate-700 truncate">{modal.item.assigned_technician.email || '---'}</p>
                                                      </div>
                                                  </div>
                                                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 flex items-center gap-3">
                                                      <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-slate-400 shadow-sm"><i className="ti ti-phone"></i></div>
                                                      <div>
                                                          <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Téléphone</p>
                                                          <p className="text-xs font-bold text-slate-700">{modal.item.assigned_technician.phone || '---'}</p>
                                                      </div>
                                                  </div>
                                              </div>
                                          </>
                                      ) : (
                                          <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100 text-center border-dashed">
                                              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mx-auto mb-3 shadow-sm text-slate-300">
                                                  <i className="ti ti-user-off text-xl"></i>
                                              </div>
                                              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest italic">Aucun technicien assigné</p>
                                              <button onClick={() => setModal({ type: 'assign', item: modal.item })} className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg text-[9px] font-black uppercase tracking-widest shadow-lg hover:bg-blue-700 transition-all">Assigner maintenant</button>
                                          </div>
                                      )}
                                  </div>

                                  <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
                                      <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[4px] border-b pb-4 mb-6">Statistiques de l'incident</h4>
                                      <div className="space-y-4">
                                          <DataBox 
                                              label="Typologie Incident" 
                                              value={
                                                  getReclamationType(modal.item) === 'simple' ? (
                                                      <span className="inline-flex items-center gap-1.5 text-emerald-600 font-black">
                                                          <i className="ti ti-bolt text-base"></i> Réclamation Simple
                                                      </span>
                                                  ) : (
                                                      <span className="inline-flex items-center gap-1.5 text-purple-600 font-black">
                                                          <i className="ti ti-cpu text-base"></i> Réclamation Complexe
                                                      </span>
                                                  )
                                              } 
                                          />

                                          <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-2">
                                              <p className="text-[8px] font-black text-slate-400 uppercase tracking-wider">Modifier la Typologie</p>
                                              <div className="grid grid-cols-2 gap-2">
                                                  <button
                                                      type="button"
                                                      onClick={() => handleUpdateTicketType(modal.item.id, 'simple')}
                                                      className={`py-2 px-3 rounded-lg text-[9px] font-black uppercase tracking-wider flex items-center justify-center gap-1 transition-all ${getReclamationType(modal.item) === 'simple' ? 'bg-emerald-600 text-white shadow-sm' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'}`}
                                                  >
                                                      <i className="ti ti-bolt"></i> Simple
                                                  </button>
                                                  <button
                                                      type="button"
                                                      onClick={() => handleUpdateTicketType(modal.item.id, 'complexe')}
                                                      className={`py-2 px-3 rounded-lg text-[9px] font-black uppercase tracking-wider flex items-center justify-center gap-1 transition-all ${getReclamationType(modal.item) === 'complexe' ? 'bg-purple-600 text-white shadow-sm' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'}`}
                                                  >
                                                      <i className="ti ti-cpu"></i> Complexe
                                                  </button>
                                              </div>
                                          </div>

                                          <DataBox label="Date Création" value={new Date(modal.item.created_at).toLocaleString()} />
                                          <DataBox label="Délai de réponse SLA" value={modal.item.sla_response_deadline ? new Date(modal.item.sla_response_deadline).toLocaleTimeString() : 'Non défini'} />
                                          <DataBox label="Canal de réception" value={modal.item.channel || 'App Mobile'} />
                                          <DataBox label="État Fonctionnel" value={modal.item.is_machine_functional ? <span className="text-emerald-600">Opérationnel</span> : <span className="text-rose-600">Hors Service</span>} />
                                      </div>
                                  </div>
                              </div>
                          </div>
                      )}

                      {activeTab === 'review' && (
                          <div className="max-w-3xl mx-auto py-10 animate-in fade-in zoom-in-95 duration-500">
                               {loadingReview ? (
                                   <div className="text-center py-20"><div className="animate-spin h-12 w-12 border-t-2 border-blue-600 rounded-full mx-auto"></div></div>
                               ) : ticketReview ? (
                                   <div className="bg-white p-12 rounded-3xl shadow-2xl border-4 border-white text-center space-y-10 relative overflow-hidden">
                                       <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-amber-400 to-amber-600"></div>
                                       <div className="space-y-4">
                                           <div className="w-20 h-20 bg-amber-50 rounded-full flex items-center justify-center mx-auto text-amber-500 text-5xl shadow-inner">
                                               <i className="ti ti-star-filled"></i>
                                           </div>
                                           <h3 className="text-2xl font-black text-slate-800 tracking-tighter">Évaluation de la Prestation</h3>
                                           <div className="flex justify-center gap-2">
                                               {[1,2,3,4,5].map(s => (
                                                   <i key={s} className={`ti ti-star-filled text-3xl ${s <= ticketReview.rating ? 'text-amber-400' : 'text-slate-100'}`}></i>
                                               ))}
                                           </div>
                                       </div>
                                       
                                       <div className="w-full text-left">
                                           {formatReviewComment(ticketReview.comment)}
                                       </div>

                                       <div className="pt-8 border-t border-slate-100 flex flex-col items-center gap-4">
                                            <p className="text-[10px] font-black text-slate-400 uppercase tracking-[4px]">Technicien Noté</p>
                                            <div className="flex items-center gap-4">
                                                <img src={`https://ui-avatars.com/api/?name=${ticketReview.technician?.name || 'T'}&background=F1F5F9&color=64748B&bold=true`} className="w-12 h-12 rounded-full border-2 border-white shadow-md" alt="" />
                                                <div className="text-left">
                                                    <p className="font-black text-slate-800 leading-none mb-1">{ticketReview.technician?.name || 'Staff Technique'}</p>
                                                    <p className="text-[9px] font-bold text-blue-500 uppercase tracking-widest">Expert Specta</p>
                                                </div>
                                            </div>
                                       </div>
                                   </div>
                               ) : (
                                   <div className="text-center py-24 space-y-6 opacity-30">
                                       <i className="ti ti-mood-empty text-8xl"></i>
                                       <p className="font-black uppercase tracking-[8px] text-xs">Aucun avis client pour ce ticket</p>
                                   </div>
                               )}
                          </div>
                      )}

                      {activeTab === 'media' && (
                          <div className="space-y-6 animate-in fade-in duration-500">
                              {(() => {
                                  const rawMediaList = [
                                      ...(Array.isArray(modal.item?.media) ? modal.item.media : []),
                                      ...(Array.isArray(modal.item?.gallery) ? modal.item.gallery : []),
                                      ...(Array.isArray(modal.item?.media_gallery) ? modal.item.media_gallery : []),
                                      ...(Array.isArray(modal.item?.images) ? modal.item.images : []),
                                      ...(Array.isArray(modal.item?.reclamation_media) ? modal.item.reclamation_media : []),
                                      ...(Array.isArray(modal.item?.reclamation_medias) ? modal.item.reclamation_medias : []),
                                      ...(Array.isArray(modal.item?.photos) ? modal.item.photos : [])
                                  ];

                                  // Deduplicate by path/url
                                  const seenPaths = new Set();
                                  const mediaList = rawMediaList.filter((m: any) => {
                                      const path = m.file_path || m.url || m.image_url || m.src || m.path || '';
                                      if (!path || seenPaths.has(path)) return false;
                                      seenPaths.add(path);
                                      return true;
                                  });

                                  return (
                                      <div className="space-y-6">
                                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-50 p-6 rounded-3xl border border-slate-100">
                                              <div>
                                                  <h4 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-2">
                                                      <i className="ti ti-photo-video text-blue-600 text-lg"></i>
                                                      <span>Galerie Média & Constats ({mediaList.length})</span>
                                                  </h4>
                                                  <p className="text-[11px] text-slate-400 font-bold mt-0.5">
                                                      Photos, vidéos et fichiers attachés au dossier #{modal.item.id}
                                                  </p>
                                              </div>
                                              <label className="px-5 py-3 bg-slate-900 hover:bg-blue-600 text-white rounded-2xl text-xs font-black uppercase tracking-wider flex items-center gap-2 cursor-pointer shadow-lg transition-all active:scale-95 shrink-0 self-start sm:self-auto">
                                                  <i className="ti ti-upload text-sm"></i>
                                                  <span>+ Ajouter Média</span>
                                                  <input
                                                      type="file"
                                                      accept="image/*,video/*,audio/*"
                                                      multiple
                                                      className="hidden"
                                                      onChange={async (e) => {
                                                          const files = e.target.files;
                                                          if (!files || files.length === 0) return;

                                                          const fileArray = Array.from(files);
                                                          const formData = new FormData();
                                                          formData.append('reclamation_id', String(modal.item.id));
                                                          
                                                          fileArray.forEach(f => {
                                                              formData.append('images[]', f);
                                                              formData.append('gallery[]', f);
                                                              formData.append('media[]', f);
                                                              formData.append('files[]', f);
                                                              formData.append('photos[]', f);
                                                              formData.append('file', f);
                                                              formData.append('image', f);
                                                          });

                                                          // Asynchronously read each file as DataURL for permanent local preview
                                                          const readPromises = fileArray.map(f => new Promise<any>((resolve) => {
                                                              const reader = new FileReader();
                                                              reader.onload = (evt) => {
                                                                  const dataUrl = evt.target?.result as string;
                                                                  resolve({
                                                                      id: `media-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
                                                                      file_path: dataUrl || URL.createObjectURL(f),
                                                                      file_type: f.type.startsWith('video/') ? 'video' : f.type.startsWith('audio/') ? 'audio' : 'image',
                                                                      file_name: f.name,
                                                                      caption: f.name.replace(/\.[^/.]+$/, '')
                                                                  });
                                                              };
                                                              reader.onerror = () => {
                                                                  resolve({
                                                                      id: `media-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
                                                                      file_path: URL.createObjectURL(f),
                                                                      file_type: f.type.startsWith('video/') ? 'video' : f.type.startsWith('audio/') ? 'audio' : 'image',
                                                                      file_name: f.name,
                                                                      caption: f.name.replace(/\.[^/.]+$/, '')
                                                                  });
                                                              };
                                                              reader.readAsDataURL(f);
                                                          }));

                                                          const newItems = await Promise.all(readPromises);

                                                          // Try uploading to backend /reclamations/{id}/gallery
                                                          try {
                                                              const res = await api.reclamations.uploadGallery(modal.item.id, formData);
                                                              const returned = res?.data || res?.gallery || res?.media || res?.images || res?.reclamation_media || (Array.isArray(res) ? res : null);
                                                              if (Array.isArray(returned) && returned.length > 0) {
                                                                  returned.forEach((r: any) => {
                                                                      newItems.push({
                                                                          id: r.id || `uploaded-${Date.now()}`,
                                                                          file_path: r.file_path || r.url || r.image_url || r.path,
                                                                          file_type: r.file_type || r.type || 'image',
                                                                          caption: r.caption || r.file_name
                                                                      });
                                                                  });
                                                              }
                                                          } catch (err) {
                                                              console.warn('API uploadGallery notice:', err);
                                                          }

                                                          // Update ticket object with all media array keys
                                                          const existing = Array.isArray(modal.item.media) ? modal.item.media : [];
                                                          const combinedMedia = [...existing, ...newItems];

                                                          const updatedItem = {
                                                              ...modal.item,
                                                              media: combinedMedia,
                                                              gallery: combinedMedia,
                                                              media_gallery: combinedMedia,
                                                              images: combinedMedia,
                                                              reclamation_media: combinedMedia
                                                          };

                                                          setModal(m => ({ ...m, item: updatedItem }));
                                                          setTickets(prev => {
                                                              const updated = prev.map(t => t.id === modal.item.id ? updatedItem : t);
                                                              try {
                                                                  localStorage.setItem('specta_cached_reclamations', JSON.stringify(updated));
                                                              } catch (e) {}
                                                              return updated;
                                                          });

                                                          showToast(`${fileArray.length} fichier(s) ajouté(s) à la galerie avec succès !`, 'success');
                                                          e.target.value = '';
                                                      }}
                                                  />
                                              </label>
                                          </div>

                                          {mediaList.length > 0 ? (
                                              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                                                  {mediaList.map((m: any, idx: number) => {
                                                      const path = m.file_path || m.url || m.image_url || m.src || m.path || '';
                                                      const type = getMediaType(path, m.file_type || m.media_type);
                                                      const url = getFileUrl(path);
                                                      const label = m.caption || m.file_name || m.title || '';
                                                      return (
                                                        <div key={idx} onClick={() => setSpotlight({ ...m, file_path: path, file_type: type })} className="group relative aspect-square bg-slate-100 rounded-2xl overflow-hidden border-2 border-slate-100 hover:border-blue-500 shadow-sm hover:shadow-xl transition-all cursor-zoom-in flex flex-col items-center justify-center">
                                                            {type === 'image' && <img src={url} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={label} />}
                                                            {type === 'video' && (
                                                                <div className="relative w-full h-full">
                                                                    <video src={url} className="w-full h-full object-cover" muted />
                                                                    <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                                                                        <i className="ti ti-player-play-filled text-white text-4xl opacity-90 group-hover:scale-125 transition-transform"></i>
                                                                    </div>
                                                                    <div className="absolute top-3 left-3 bg-purple-600/90 text-white px-2.5 py-1 rounded-lg text-[8px] font-black uppercase tracking-widest shadow-md">
                                                                      Vidéo
                                                                    </div>
                                                                </div>
                                                            )}
                                                            {type === 'audio' && (
                                                                <div className="flex flex-col items-center gap-4 text-slate-400 group-hover:text-blue-600 transition-colors">
                                                                    <i className="ti ti-microphone text-5xl"></i>
                                                                    <p className="text-[10px] font-black uppercase tracking-widest">Audio</p>
                                                                </div>
                                                            )}
                                                            {label && (
                                                              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950/90 via-slate-900/50 to-transparent p-3 pt-6 text-white text-[11px] font-bold truncate">
                                                                {label}
                                                              </div>
                                                            )}
                                                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-all pointer-events-none">
                                                                <i className="ti ti-maximize text-white text-3xl"></i>
                                                            </div>
                                                        </div>
                                                      );
                                                  })}
                                              </div>
                                          ) : (
                                              <div className="p-16 text-center border-2 border-dashed border-slate-200 rounded-3xl bg-slate-50/50">
                                                  <div className="w-16 h-16 rounded-2xl bg-amber-50 text-amber-500 flex items-center justify-center text-3xl mx-auto mb-3 shadow-inner">
                                                      <i className="ti ti-photo-off"></i>
                                                  </div>
                                                  <h4 className="text-base font-black text-slate-800 uppercase tracking-wider mb-1">Aucun média attaché</h4>
                                                  <p className="text-xs text-slate-400 font-medium max-w-sm mx-auto">
                                                      Ce dossier SAV ne contient aucune photo ou vidéo de constat technique. Utilisez le bouton « + Ajouter Média » ci-dessus pour en joindre.
                                                  </p>
                                              </div>
                                          )}
                                      </div>
                                  );
                              })()}
                          </div>
                      )}

                      {activeTab === 'client' && (
                          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 animate-in fade-in duration-500">
                               <div className="bg-white p-8 sm:p-10 rounded-3xl border border-slate-100 shadow-sm space-y-6">
                                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
                                        <div className="flex items-center gap-5">
                                            <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center text-3xl shadow-inner shrink-0">🏥</div>
                                            <div>
                                                <h3 className="text-2xl font-black text-slate-800 tracking-tight leading-tight mb-1">{modal.item.client?.name || 'Aucun client associé'}</h3>
                                                <div className="flex items-center gap-2">
                                                    <span className="text-[10px] font-black text-blue-600 bg-blue-50 px-2.5 py-0.5 rounded-md uppercase tracking-wider">
                                                        Code: {modal.item.client?.code || '---'}
                                                    </span>
                                                    {modal.item.client?.city && (
                                                        <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2.5 py-0.5 rounded-md uppercase tracking-wider">
                                                            📍 {modal.item.client.city}
                                                        </span>
                                                    )}
                                                </div>
                                            </div>
                                        </div>

                                        <div className="flex items-center gap-2 shrink-0">
                                            <button
                                                type="button"
                                                onClick={() => setIsRelinkingClient(true)}
                                                className="px-3.5 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-1.5 shadow-sm active:scale-95"
                                            >
                                                <i className="ti ti-arrows-exchange text-sm"></i>
                                                Changer le Client
                                            </button>
                                            {modal.item.client?.id && (
                                                <button
                                                    type="button"
                                                    onClick={() => navigate(`/admin/clients?clientId=${modal.item.client.id}`)}
                                                    className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl text-xs font-black uppercase transition-all"
                                                    title="Ouvrir Fiche 360°"
                                                >
                                                    <i className="ti ti-external-link text-base"></i>
                                                </button>
                                            )}
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
                                        <DataBox label="Contact Principal / Praticien" value={modal.item.client?.contact_name || 'Non spécifié'} />
                                        <DataBox label="Ville d'Activité" value={modal.item.client?.city || 'Maroc'} />
                                        <DataBox label="Téléphone / Mobile" value={modal.item.client?.mobile || modal.item.client?.phone || '---'} />
                                        <DataBox label="Email Officiel" value={modal.item.client?.email || '---'} />
                                        {modal.item.client?.address && (
                                            <div className="col-span-1 md:col-span-2">
                                                <DataBox label="Adresse Complète" value={modal.item.client.address} />
                                            </div>
                                        )}
                                    </div>

                                    {/* Re-linking dialog inside active client tab */}
                                    {isRelinkingClient && (
                                        <div className="mt-6 p-6 bg-slate-50 border-2 border-blue-200 rounded-2xl space-y-4 animate-in fade-in zoom-in-95">
                                            <div className="flex items-center justify-between">
                                                <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-2">
                                                    <i className="ti ti-link text-blue-600"></i>
                                                    Associer ce Ticket SAV à un autre Client
                                                </h4>
                                                <button
                                                    type="button"
                                                    onClick={() => setIsRelinkingClient(false)}
                                                    className="text-slate-400 hover:text-slate-700 text-sm font-bold"
                                                >
                                                    ✕
                                                </button>
                                            </div>

                                            <div className="relative">
                                                <i className="ti ti-search absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"></i>
                                                <input
                                                    type="text"
                                                    placeholder="Rechercher par nom, ville, code..."
                                                    value={relinkSearchQuery}
                                                    onChange={e => setRelinkSearchQuery(e.target.value)}
                                                    className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none"
                                                />
                                            </div>

                                            <div className="space-y-2 max-h-56 overflow-y-auto custom-scrollbar pr-1">
                                                {clientsList
                                                    .filter(c => {
                                                        if (!relinkSearchQuery.trim()) return true;
                                                        const q = relinkSearchQuery.toLowerCase();
                                                        return c.name?.toLowerCase().includes(q) ||
                                                               c.code?.toLowerCase().includes(q) ||
                                                               c.city?.toLowerCase().includes(q);
                                                    })
                                                    .slice(0, 8)
                                                    .map(c => (
                                                        <div
                                                            key={c.id}
                                                            onClick={() => handleRelinkClient(modal.item.id, c)}
                                                            className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                                                                modal.item.client?.id === c.id
                                                                    ? 'bg-blue-50 border-blue-300'
                                                                    : 'bg-white hover:bg-slate-100/80 border-slate-200'
                                                            }`}
                                                        >
                                                            <div>
                                                                <p className="text-xs font-black text-slate-800">{c.name}</p>
                                                                <p className="text-[10px] text-slate-400 font-bold">{c.code} • {c.city || 'Maroc'}</p>
                                                            </div>
                                                            {modal.item.client?.id === c.id ? (
                                                                <span className="text-[10px] font-black text-blue-600 bg-blue-100 px-2 py-0.5 rounded-full">Actuel</span>
                                                            ) : (
                                                                <button
                                                                    type="button"
                                                                    disabled={relinkingLoading}
                                                                    className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-[10px] font-black uppercase tracking-wider shadow-sm"
                                                                >
                                                                    Lier
                                                                </button>
                                                            )}
                                                        </div>
                                                    ))}
                                            </div>
                                        </div>
                                    )}
                               </div>
                          </div>
                      )}

                      {activeTab === 'machine' && (
                          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 animate-in fade-in duration-500">
                               <div className="lg:col-span-5">
                                    <div className="bg-white rounded-3xl border border-slate-100 shadow-xl overflow-hidden group">
                                        <div className="h-64 bg-slate-50 flex items-center justify-center p-10">
                                            <img src={getFileUrl(modal.item.client_machine?.machine?.image_url)} className="w-full h-full object-contain group-hover:scale-110 transition-transform duration-1000" alt="" />
                                        </div>
                                        <div className="p-8 space-y-4">
                                            <h3 className="text-xl font-black text-slate-800 tracking-tight leading-tight">{modal.item.client_machine?.machine?.name}</h3>
                                            <div className="flex gap-3">
                                                <span className="px-4 py-1 bg-blue-50 text-blue-600 rounded-full text-[9px] font-black uppercase tracking-widest border border-blue-100">S/N: {modal.item.client_machine?.serial_number}</span>
                                            </div>
                                        </div>
                                    </div>
                               </div>
                          </div>
                      )}
                  </div>

                  {/* Modal Footer / Workflow Sync */}
                  <div className="p-8 border-t bg-slate-50 flex flex-wrap gap-4 items-center shrink-0">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-[4px] mr-6">Changer État :</p>
                    {COLUMNS.map(c => (
                        <button 
                            key={c.id} 
                            onClick={() => handleUpdateStatus(modal.item.id, c.id)} 
                            disabled={isSubmitting}
                            className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all border-2 flex items-center gap-2 ${modal.item.status?.slug === c.id ? 'bg-slate-900 border-slate-900 text-white shadow-xl' : 'bg-white text-slate-400 border-slate-100 hover:border-blue-400 hover:text-blue-500'}`}
                        >
                            <i className={`ti ${c.icon}`}></i> {c.label}
                        </button>
                    ))}
                    <div className="flex-1"></div>
                    <button onClick={() => setModal({ type: null, item: null })} className="px-10 py-4 bg-slate-200 text-slate-600 rounded-xl font-black uppercase text-[10px] tracking-[4px] active:scale-95 transition-all shadow-md">Fermer Insight</button>
                  </div>
              </div>

              {/* BEAUTIFUL PRINTABLE DOSSIER REPORT */}
              <div id="print-section" className="hidden print:block p-10 bg-white text-slate-800 font-sans w-full leading-relaxed">
                  <style dangerouslySetInnerHTML={{ __html: `
                    @media print {
                      body {
                        background-color: white !important;
                        color: black !important;
                      }
                      body > * {
                        display: none !important;
                      }
                      #print-section, #print-section * {
                        display: block !important;
                        visibility: visible !important;
                      }
                      #print-section {
                        position: absolute !important;
                        left: 0 !important;
                        top: 0 !important;
                        width: 100% !important;
                        display: block !important;
                        background: white !important;
                        color: black !important;
                      }
                      @page {
                        margin: 1.5cm;
                      }
                      .print\\:hidden {
                        display: none !important;
                      }
                    }
                  `}} />
                  
                  <div className="border-b-4 border-slate-900 pb-6 mb-8 flex justify-between items-end">
                      <div>
                          <h1 className="text-3xl font-black tracking-tighter text-slate-900">SPECTA SAV</h1>
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-[4px] mt-1">Rapport Complet de Réclamation</p>
                      </div>
                      <div className="text-right">
                          <p className="text-[11px] font-bold text-slate-505">Imprimé le: {new Date().toLocaleDateString('fr-FR')}</p>
                          <p className="text-[11px] font-black text-blue-600">Dossier Incident: #{modal.item.id}</p>
                      </div>
                  </div>

                  <div className="grid grid-cols-2 gap-8 mb-8">
                      <div className="bg-slate-50/80 p-6 rounded-2xl border border-slate-200/60">
                          <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest border-b pb-2 mb-3">Informations Générales</h3>
                          <div className="space-y-2">
                              <p className="text-xs"><strong className="text-slate-500 font-bold">Sujet:</strong> <span className="text-slate-800 font-semibold">{modal.item.subject}</span></p>
                              <p className="text-xs"><strong className="text-slate-500 font-bold">Description:</strong> <span className="text-slate-700">{modal.item.description || '---'}</span></p>
                              <p className="text-xs"><strong className="text-slate-500 font-bold">Priorité:</strong> <span className="text-slate-800 font-semibold">{modal.item.priority?.name || 'Standard'}</span></p>
                              <p className="text-xs"><strong className="text-slate-500 font-bold">Statut Actuel:</strong> <span className="text-slate-800 font-semibold">{modal.item.status?.label || modal.item.status?.slug || 'En cours'}</span></p>
                              <p className="text-xs"><strong className="text-slate-500 font-bold">Créé le:</strong> <span className="text-slate-800">{new Date(modal.item.created_at).toLocaleDateString('fr-FR')} {new Date(modal.item.created_at).toLocaleTimeString('fr-FR')}</span></p>
                              {modal.item.resolved_at && <p className="text-xs"><strong className="text-slate-500 font-bold">Résolu le:</strong> <span className="text-slate-800">{new Date(modal.item.resolved_at).toLocaleDateString('fr-FR')}</span></p>}
                              {modal.item.closed_at && <p className="text-xs"><strong className="text-slate-500 font-bold">Clôturé le:</strong> <span className="text-slate-800">{new Date(modal.item.closed_at).toLocaleDateString('fr-FR')}</span></p>}
                          </div>
                      </div>

                      <div className="bg-slate-50/80 p-6 rounded-2xl border border-slate-200/60">
                          <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest border-b pb-2 mb-3">Profil Client</h3>
                          <div className="space-y-2">
                              <p className="text-xs"><strong className="text-slate-500 font-bold">Établissement:</strong> <span className="text-slate-800 font-bold">{modal.item.client?.name}</span></p>
                              <p className="text-xs"><strong className="text-slate-500 font-bold">Code Client:</strong> <span className="text-slate-800 font-semibold">{modal.item.client?.code}</span></p>
                              <p className="text-xs"><strong className="text-slate-500 font-bold">Contact Principal:</strong> <span className="text-slate-800">{modal.item.client?.contact_name || 'Non spécifié'}</span></p>
                              <p className="text-xs"><strong className="text-slate-500 font-bold">Ville / Activité:</strong> <span className="text-slate-800">{modal.item.client?.city || 'Maroc'}</span></p>
                              <p className="text-xs"><strong className="text-slate-500 font-bold">Email Officiel:</strong> <span className="text-slate-800">{modal.item.client?.email || '---'}</span></p>
                              <p className="text-xs"><strong className="text-slate-500 font-bold">Téléphone:</strong> <span className="text-slate-800">{modal.item.client?.mobile || modal.item.client?.phone || '---'}</span></p>
                              {modal.item.client?.address && <p className="text-xs"><strong className="text-slate-500 font-bold">Adresse:</strong> <span className="text-slate-700 text-xxs block whitespace-pre-line leading-tight mt-1">{modal.item.client?.address}</span></p>}
                          </div>
                      </div>
                  </div>

                  <div className="grid grid-cols-2 gap-8 mb-8">
                      <div className="bg-slate-50/80 p-6 rounded-2xl border border-slate-200/60">
                          <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest border-b pb-2 mb-3">Détails de la Machine</h3>
                          <div className="space-y-2">
                              <p className="text-xs"><strong className="text-slate-500 font-bold">Machine Specta:</strong> <span className="text-slate-800 font-bold">{modal.item.client_machine?.machine?.name || '---'}</span></p>
                              <p className="text-xs"><strong className="text-slate-500 font-bold">Numéro de Série:</strong> <span className="text-slate-800 font-mono font-bold text-xxs">{modal.item.client_machine?.serial_number || '---'}</span></p>
                              <p className="text-xs"><strong className="text-slate-500 font-bold">État Fonctionnel:</strong> <span className={modal.item.is_machine_functional ? "text-emerald-600 font-bold" : "text-rose-600 font-bold"}>{modal.item.is_machine_functional ? 'Opérationnel / Fonctionnel' : 'Hors Service / En panne'}</span></p>
                          </div>
                      </div>

                      <div className="bg-slate-50/80 p-6 rounded-2xl border border-slate-200/60">
                          <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest border-b pb-2 mb-3">Expert Technique Assigné</h3>
                          <div className="space-y-2">
                              {modal.item.assigned_technician ? (
                                  <>
                                      <p className="text-xs"><strong className="text-slate-500 font-bold">Nom Expert:</strong> <span className="text-slate-800 font-bold">{modal.item.assigned_technician.name}</span></p>
                                      <p className="text-xs"><strong className="text-slate-500 font-bold">Rôle:</strong> <span className="text-blue-600 font-bold text-[9px] uppercase tracking-wider">Technicien SAV</span></p>
                                      <p className="text-xs"><strong className="text-slate-500 font-bold">Email:</strong> <span className="text-slate-800">{modal.item.assigned_technician.email || '---'}</span></p>
                                      <p className="text-xs"><strong className="text-slate-500 font-bold">Téléphone direct:</strong> <span className="text-slate-800">{modal.item.assigned_technician.phone || '---'}</span></p>
                                  </>
                              ) : (
                                  <p className="text-xs italic text-slate-400">Aucun expert technique assigné à ce dossier.</p>
                              )}
                          </div>
                      </div>
                  </div>

                  {ticketReview ? (
                      <div className="bg-slate-50/80 p-6 rounded-2xl border border-slate-200/60 mt-4 break-inside-avoid shadow-sm">
                          <div className="border-b pb-3 mb-4 flex justify-between items-center bg-slate-100/50 -mx-6 -mt-6 p-6 rounded-t-2xl">
                              <h3 className="text-xs font-black text-slate-500 uppercase tracking-widest">Enquête de Satisfaction Client</h3>
                              <span className="bg-amber-100 text-amber-800 px-3 py-1 rounded-full text-xs font-extrabold">Note Finale: {ticketReview.rating}/5</span>
                          </div>
                          
                          <div className="space-y-4">
                              {formatReviewComment(ticketReview.comment)}
                          </div>
                          
                          <div className="mt-8 pt-6 border-t border-slate-200/60 flex justify-between items-center text-slate-400 font-semibold text-xxs">
                              <span>Signature Client / Accord Qualité SPECTA</span>
                              <span className="w-48 border-b border-dashed border-slate-400 h-10"></span>
                          </div>
                      </div>
                  ) : (
                      <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 text-center text-slate-400 italic text-xs mt-4">
                          Aucun formulaire de satisfaction client n'a été soumis pour cette réclamation à ce jour.
                      </div>
                  )}
              </div>
          </div>
      )}

      {/* CREATE TICKET MODAL */}
      {modal.type === 'create' && (
          <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-md z-[170] flex items-center justify-center p-4">
              <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 border-4 border-white flex flex-col max-h-[92vh]">
                  <div className="p-6 border-b flex justify-between items-center bg-slate-50/50">
                      <div>
                          <h2 className="text-xl font-black text-slate-800 tracking-tight flex items-center gap-2">
                              <i className="ti ti-ticket text-blue-600"></i> Nouveau Dossier Incident SAV
                          </h2>
                          <p className="text-slate-400 font-bold text-xs uppercase tracking-wider mt-0.5">Déclarer un incident & définir sa typologie</p>
                      </div>
                      <button onClick={() => setModal({ type: null, item: null })} className="w-10 h-10 flex items-center justify-center bg-white rounded-full text-slate-400 hover:text-slate-700 text-2xl shadow-sm transition-all">×</button>
                  </div>

                  <form onSubmit={handleCreateTicket} className="p-6 sm:p-8 space-y-6 overflow-y-auto custom-scrollbar flex-1">
                      {/* Typologie Selection (CRITICAL) */}
                      <div>
                          <label className="text-xs font-black text-slate-600 uppercase tracking-wider block mb-2.5">
                              Typologie de la Réclamation <span className="text-rose-500">*</span>
                          </label>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                              <div 
                                  onClick={() => setNewTicketForm(f => ({ ...f, reclamation_type: 'simple' }))}
                                  className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex items-start gap-3.5 ${newTicketForm.reclamation_type === 'simple' ? 'border-emerald-500 bg-emerald-50/60 ring-2 ring-emerald-500/20 shadow-sm' : 'border-slate-200 bg-slate-50/40 hover:border-slate-300'}`}
                              >
                                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg shrink-0 ${newTicketForm.reclamation_type === 'simple' ? 'bg-emerald-600 text-white shadow-md' : 'bg-slate-200 text-slate-500'}`}>
                                      <i className="ti ti-bolt"></i>
                                  </div>
                                  <div>
                                      <div className="flex items-center gap-2">
                                          <p className="text-sm font-black text-slate-800">⚡ Réclamation Simple</p>
                                          {newTicketForm.reclamation_type === 'simple' && <i className="ti ti-circle-check-filled text-emerald-600 text-sm"></i>}
                                      </div>
                                      <p className="text-[11px] text-slate-500 mt-1 leading-snug">Incident standard, réglage, recalibrage ou consommable léger.</p>
                                  </div>
                              </div>

                              <div 
                                  onClick={() => setNewTicketForm(f => ({ ...f, reclamation_type: 'complexe' }))}
                                  className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex items-start gap-3.5 ${newTicketForm.reclamation_type === 'complexe' ? 'border-purple-500 bg-purple-50/60 ring-2 ring-purple-500/20 shadow-sm' : 'border-slate-200 bg-slate-50/40 hover:border-slate-300'}`}
                              >
                                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg shrink-0 ${newTicketForm.reclamation_type === 'complexe' ? 'bg-purple-600 text-white shadow-md' : 'bg-slate-200 text-slate-500'}`}>
                                      <i className="ti ti-cpu"></i>
                                  </div>
                                  <div>
                                      <div className="flex items-center gap-2">
                                          <p className="text-sm font-black text-slate-800">⚙️ Réclamation Complexe</p>
                                          {newTicketForm.reclamation_type === 'complexe' && <i className="ti ti-circle-check-filled text-purple-600 text-sm"></i>}
                                      </div>
                                      <p className="text-[11px] text-slate-500 mt-1 leading-snug">Panne lourde, circuit cryo, carte de puissance ou remplacement multi-composants.</p>
                                  </div>
                              </div>
                          </div>
                      </div>

                      {/* Sujet */}
                      <div>
                          <label className="text-xs font-black text-slate-600 uppercase tracking-wider block mb-2">
                              Sujet / Motif de l'incident <span className="text-rose-500">*</span>
                          </label>
                          <input 
                              type="text" 
                              required 
                              placeholder="Ex: Alarme thermique E-47 compresseur"
                              value={newTicketForm.subject}
                              onChange={e => setNewTicketForm(f => ({ ...f, subject: e.target.value }))}
                              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 text-sm"
                          />
                      </div>

                      {/* Client Selection & Creation */}
                      <div className="space-y-3 p-5 bg-slate-50/70 border border-slate-200 rounded-2xl">
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                              <label className="text-xs font-black text-slate-700 uppercase tracking-wider flex items-center gap-2">
                                  <i className="ti ti-building-hospital text-blue-600 text-base"></i>
                                  Client Bénéficiaire & Établissement <span className="text-rose-500">*</span>
                              </label>

                              {/* Toggle Mode: Existing vs New */}
                              <div className="flex bg-slate-200/80 p-1 rounded-xl w-fit">
                                  <button
                                      type="button"
                                      onClick={() => setClientMode('existing')}
                                      className={`px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                                          clientMode === 'existing'
                                              ? 'bg-white text-blue-600 shadow-sm'
                                              : 'text-slate-500 hover:text-slate-800'
                                      }`}
                                  >
                                      <i className="ti ti-database"></i> Client Existant
                                  </button>
                                  <button
                                      type="button"
                                      onClick={() => {
                                          setClientMode('new');
                                          if (!newClientData.code) {
                                              setNewClientData(prev => ({
                                                  ...prev,
                                                  code: `CLT-${Date.now().toString().slice(-5)}`
                                              }));
                                          }
                                      }}
                                      className={`px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                                          clientMode === 'new'
                                              ? 'bg-blue-600 text-white shadow-sm'
                                              : 'text-slate-500 hover:text-slate-800'
                                      }`}
                                  >
                                      <i className="ti ti-user-plus"></i> ➕ Créer Nouveau Client & Lier
                                  </button>
                              </div>
                          </div>

                          {clientMode === 'existing' ? (
                              <div>
                                  {!newTicketForm.client_id ? (
                                      <div className="space-y-3">
                                          <div className="relative">
                                              <i className="ti ti-search absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"></i>
                                              <input
                                                  type="text"
                                                  placeholder="Rechercher par nom, code client, ville ou praticien..."
                                                  value={clientSearchQuery}
                                                  onChange={e => setClientSearchQuery(e.target.value)}
                                                  className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none"
                                              />
                                          </div>

                                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto custom-scrollbar pr-1">
                                              {clientsList
                                                  .filter(c => {
                                                      if (!clientSearchQuery.trim()) return true;
                                                      const q = clientSearchQuery.toLowerCase();
                                                      return c.name?.toLowerCase().includes(q) ||
                                                             c.code?.toLowerCase().includes(q) ||
                                                             c.city?.toLowerCase().includes(q) ||
                                                             c.contact_name?.toLowerCase().includes(q);
                                                  })
                                                  .slice(0, 8)
                                                  .map(c => (
                                                      <div
                                                          key={c.id}
                                                          onClick={() => handleSelectClient(c.id.toString())}
                                                          className="p-3 bg-white hover:bg-blue-50/60 border border-slate-200 hover:border-blue-300 rounded-xl cursor-pointer transition-all flex items-center justify-between group shadow-sm"
                                                      >
                                                          <div className="min-w-0 pr-2">
                                                              <p className="text-xs font-black text-slate-800 truncate group-hover:text-blue-600 transition-colors">{c.name}</p>
                                                              <p className="text-[10px] text-slate-400 font-bold truncate">
                                                                  <span className="text-blue-600 font-mono">{c.code}</span> • {c.city || 'Maroc'} {c.contact_name ? `• ${c.contact_name}` : ''}
                                                              </p>
                                                          </div>
                                                          <span className="p-1.5 bg-slate-100 group-hover:bg-blue-600 group-hover:text-white rounded-lg text-slate-400 transition-colors shrink-0">
                                                              <i className="ti ti-check text-xs"></i>
                                                          </span>
                                                      </div>
                                                  ))}
                                          </div>
                                      </div>
                                  ) : (
                                      /* Client selected card */
                                      <div className="space-y-3">
                                          {(() => {
                                              const selectedClient = clientsList.find(c => c.id.toString() === newTicketForm.client_id);
                                              return (
                                                  <div className="p-4 bg-white border-2 border-blue-200 rounded-2xl shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                                      <div className="flex items-center gap-3.5">
                                                          <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center text-xl shrink-0">
                                                              🏥
                                                          </div>
                                                          <div>
                                                              <div className="flex items-center gap-2">
                                                                  <h4 className="text-sm font-black text-slate-800">{selectedClient?.name || newTicketForm.client_name || 'Client Sélectionné'}</h4>
                                                                  <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-[9px] font-black uppercase font-mono">
                                                                      {selectedClient?.code || 'CLT'}
                                                                  </span>
                                                              </div>
                                                              <p className="text-[11px] text-slate-500 font-bold mt-0.5">
                                                                  📍 {selectedClient?.city || 'Maroc'} • 📞 {selectedClient?.mobile || selectedClient?.phone || 'Non renseigné'} • 👤 {selectedClient?.contact_name || 'Praticien'}
                                                              </p>
                                                          </div>
                                                      </div>

                                                      <button
                                                          type="button"
                                                          onClick={() => {
                                                              setNewTicketForm(f => ({ ...f, client_id: '' }));
                                                              setSelectedClientMachines([]);
                                                          }}
                                                          className="px-3 py-1.5 bg-slate-100 hover:bg-rose-50 hover:text-rose-600 text-slate-600 text-xs font-black uppercase tracking-wider rounded-xl transition-all self-end sm:self-center shrink-0 flex items-center gap-1"
                                                      >
                                                          <i className="ti ti-x text-xs"></i> Changer de client
                                                      </button>
                                                  </div>
                                              );
                                          })()}

                                          {/* Machine park selector if available */}
                                          {loadingClientMachines ? (
                                              <div className="p-3 bg-white rounded-xl border border-slate-200 text-center text-xs text-slate-400 flex items-center justify-center gap-2">
                                                  <div className="w-3.5 h-3.5 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                                                  Recherche du parc machine du client...
                                              </div>
                                          ) : selectedClientMachines.length > 0 ? (
                                              <div className="p-3 bg-blue-50/70 border border-blue-100 rounded-xl space-y-2">
                                                  <div className="flex items-center justify-between">
                                                      <span className="text-[10px] font-black text-blue-800 uppercase tracking-wider flex items-center gap-1.5">
                                                          <i className="ti ti-cpu text-blue-600"></i> Parc Machine Installé ({selectedClientMachines.length})
                                                      </span>
                                                      <span className="text-[9px] font-bold text-blue-600">Cliquer pour préremplir l'équipement</span>
                                                  </div>
                                                  <div className="flex flex-wrap gap-2">
                                                      {selectedClientMachines.map((cm: any) => {
                                                          const mName = cm.machine?.name || cm.name || 'Équipement Specta';
                                                          const isSelected = newTicketForm.machine_name === mName;
                                                          return (
                                                              <button
                                                                  key={cm.id || cm.serial_number}
                                                                  type="button"
                                                                  onClick={() => {
                                                                      setNewTicketForm(f => ({
                                                                          ...f,
                                                                          machine_name: mName,
                                                                          serial_number: cm.serial_number || f.serial_number
                                                                      }));
                                                                  }}
                                                                  className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all flex items-center gap-1.5 ${
                                                                      isSelected
                                                                          ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                                                                          : 'bg-white text-slate-700 border-slate-200 hover:border-blue-300'
                                                                  }`}
                                                              >
                                                                  <i className="ti ti-device-heart-monitor text-xs"></i>
                                                                  {mName}
                                                                  {cm.serial_number && (
                                                                      <span className={`font-mono text-[10px] ${isSelected ? 'text-blue-200' : 'text-slate-400'}`}>
                                                                          (S/N: {cm.serial_number})
                                                                      </span>
                                                                  )}
                                                              </button>
                                                          );
                                                      })}
                                                  </div>
                                              </div>
                                          ) : null}
                                      </div>
                                  )}
                              </div>
                          ) : (
                              /* CREATE NEW CLIENT & LINK ON THE SPOT */
                              <div className="space-y-4 p-4 bg-white border-2 border-dashed border-blue-300 rounded-2xl animate-in fade-in zoom-in-95">
                                  <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                                      <div className="flex items-center gap-2">
                                          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                                          <p className="text-xs font-black text-slate-800 uppercase tracking-wider">Formulaire Nouveau Client Référencé</p>
                                      </div>
                                      <span className="text-[10px] text-blue-600 font-bold bg-blue-50 px-2.5 py-0.5 rounded-full">
                                          Création & Liaison Immédiate
                                      </span>
                                  </div>

                                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                      <div>
                                          <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider block mb-1">
                                              Nom de l'établissement / Raison Sociale <span className="text-rose-500">*</span>
                                          </label>
                                          <input
                                              type="text"
                                              required
                                              placeholder="Ex: Clinique Esthétique Al Madina"
                                              value={newClientData.name}
                                              onChange={e => setNewClientData(d => ({ ...d, name: e.target.value }))}
                                              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none"
                                          />
                                      </div>

                                      <div>
                                          <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider block mb-1">
                                              Code Client (Généré)
                                          </label>
                                          <input
                                              type="text"
                                              placeholder="Ex: CLT-8921"
                                              value={newClientData.code}
                                              onChange={e => setNewClientData(d => ({ ...d, code: e.target.value }))}
                                              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-blue-600 focus:ring-2 focus:ring-blue-500 outline-none"
                                          />
                                      </div>

                                      <div>
                                          <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider block mb-1">
                                              Praticien / Contact Principal
                                          </label>
                                          <input
                                              type="text"
                                              placeholder="Ex: Dr. Benmoussa"
                                              value={newClientData.contact_name}
                                              onChange={e => setNewClientData(d => ({ ...d, contact_name: e.target.value }))}
                                              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none"
                                          />
                                      </div>

                                      <div>
                                          <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider block mb-1">
                                              Téléphone / Mobile Direct <span className="text-rose-500">*</span>
                                          </label>
                                          <input
                                              type="text"
                                              required
                                              placeholder="Ex: +212 6 61 23 45 67"
                                              value={newClientData.mobile}
                                              onChange={e => setNewClientData(d => ({ ...d, mobile: e.target.value }))}
                                              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none"
                                          />
                                      </div>

                                      <div>
                                          <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider block mb-1">
                                              Ville <span className="text-rose-500">*</span>
                                          </label>
                                          <select
                                              value={newClientData.city}
                                              onChange={e => setNewClientData(d => ({ ...d, city: e.target.value }))}
                                              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none"
                                          >
                                              <option value="Casablanca">Casablanca</option>
                                              <option value="Rabat">Rabat</option>
                                              <option value="Marrakech">Marrakech</option>
                                              <option value="Tanger">Tanger</option>
                                              <option value="Fès">Fès</option>
                                              <option value="Agadir">Agadir</option>
                                              <option value="Oujda">Oujda</option>
                                              <option value="Meknès">Meknès</option>
                                              <option value="Tétouan">Tétouan</option>
                                              <option value="Autre">Autre Ville</option>
                                          </select>
                                      </div>

                                      <div>
                                          <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider block mb-1">
                                              Email Officiel
                                          </label>
                                          <input
                                              type="email"
                                              placeholder="contact@clinique.ma"
                                              value={newClientData.email}
                                              onChange={e => setNewClientData(d => ({ ...d, email: e.target.value }))}
                                              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none"
                                          />
                                      </div>

                                      <div className="col-span-1 sm:col-span-2">
                                          <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider block mb-1">
                                              Adresse de l'établissement
                                          </label>
                                          <input
                                              type="text"
                                              placeholder="Ex: Boulevard Zerktouni, Immeuble B"
                                              value={newClientData.address}
                                              onChange={e => setNewClientData(d => ({ ...d, address: e.target.value }))}
                                              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none"
                                          />
                                      </div>
                                  </div>

                                  <div className="p-2.5 bg-blue-50 rounded-xl text-[10px] text-blue-700 font-bold flex items-center gap-2">
                                      <i className="ti ti-info-circle text-base shrink-0"></i>
                                      Ce nouveau client sera automatiquement enregistré dans la base de données et lié à ce dossier d'incident SAV.
                                  </div>
                              </div>
                          )}
                      </div>

                      {/* Niveau d'Urgence */}
                      <div>
                          <label className="text-xs font-black text-slate-600 uppercase tracking-wider block mb-2">
                              Niveau d'Urgence
                          </label>
                          <select
                              value={newTicketForm.priority_slug}
                              onChange={e => setNewTicketForm(f => ({ ...f, priority_slug: e.target.value as any }))}
                              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 text-sm"
                          >
                              <option value="low">Basse (Intervention planifiable sous 5 jours)</option>
                              <option value="medium">Moyenne (Sous 48h)</option>
                              <option value="high">Critique / Haute (Machine arrêtée - Intervention Immédiate)</option>
                          </select>
                      </div>

                      {/* Machine & Numéro de série */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                              <label className="text-xs font-black text-slate-600 uppercase tracking-wider block mb-2">
                                  Modèle d'Équipement
                              </label>
                              {machinesList.length > 0 ? (
                                  <select
                                      value={newTicketForm.machine_name}
                                      onChange={e => setNewTicketForm(f => ({ ...f, machine_name: e.target.value }))}
                                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 text-sm"
                                  >
                                      <option value="">-- Choisir une machine --</option>
                                      {machinesList.map(m => (
                                          <option key={m.id} value={m.name}>{m.name}</option>
                                      ))}
                                  </select>
                              ) : (
                                  <input 
                                      type="text" 
                                      placeholder="Ex: Specta Laser Diode Trio"
                                      value={newTicketForm.machine_name}
                                      onChange={e => setNewTicketForm(f => ({ ...f, machine_name: e.target.value }))}
                                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 text-sm"
                                  />
                              )}
                          </div>

                          <div>
                              <label className="text-xs font-black text-slate-600 uppercase tracking-wider block mb-2">
                                  Numéro de Série (S/N)
                              </label>
                              <input 
                                  type="text" 
                                  placeholder="Ex: SP-SN-2024-912"
                                  value={newTicketForm.serial_number}
                                  onChange={e => setNewTicketForm(f => ({ ...f, serial_number: e.target.value }))}
                                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 text-sm"
                              />
                          </div>
                      </div>

                      {/* État de la machine & Technicien */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                              <label className="text-xs font-black text-slate-600 uppercase tracking-wider block mb-2">
                                  État Fonctionnel de la Machine
                              </label>
                              <div className="flex gap-4 pt-1">
                                  <label className="flex items-center gap-2 cursor-pointer">
                                      <input 
                                          type="radio" 
                                          name="functional_state"
                                          checked={newTicketForm.is_machine_functional === true}
                                          onChange={() => setNewTicketForm(f => ({ ...f, is_machine_functional: true }))}
                                          className="w-4 h-4 text-emerald-600 focus:ring-emerald-500"
                                      />
                                      <span className="text-xs font-bold text-slate-700">Opérationnelle</span>
                                  </label>
                                  <label className="flex items-center gap-2 cursor-pointer">
                                      <input 
                                          type="radio" 
                                          name="functional_state"
                                          checked={newTicketForm.is_machine_functional === false}
                                          onChange={() => setNewTicketForm(f => ({ ...f, is_machine_functional: false }))}
                                          className="w-4 h-4 text-rose-600 focus:ring-rose-500"
                                      />
                                      <span className="text-xs font-bold text-rose-600">Hors Service</span>
                                  </label>
                              </div>
                          </div>

                          <div>
                              <label className="text-xs font-black text-slate-600 uppercase tracking-wider block mb-2">
                                  Assigner un Technicien (Optionnel)
                              </label>
                              <select
                                  value={newTicketForm.technician_id}
                                  onChange={e => setNewTicketForm(f => ({ ...f, technician_id: e.target.value }))}
                                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 text-sm"
                              >
                                  <option value="">-- Assigner plus tard --</option>
                                  {technicians.map(t => (
                                      <option key={t.id} value={t.id}>{t.name}</option>
                                  ))}
                              </select>
                          </div>
                      </div>

                      {/* Description */}
                      <div>
                          <label className="text-xs font-black text-slate-600 uppercase tracking-wider block mb-2">
                              Description détaillée de l'incident
                          </label>
                          <textarea
                              rows={3}
                              placeholder="Symptômes constatés, codes erreurs affichés, manipulations déjà effectuées..."
                              value={newTicketForm.description}
                              onChange={e => setNewTicketForm(f => ({ ...f, description: e.target.value }))}
                              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none font-medium text-slate-800 focus:ring-2 focus:ring-blue-500 resize-none text-sm"
                          />
                      </div>

                      <div className="pt-4 border-t flex justify-end gap-3">
                          <button 
                              type="button" 
                              onClick={() => setModal({ type: null, item: null })}
                              className="px-6 py-3 bg-slate-100 hover:bg-slate-200 text-slate-600 font-black uppercase text-xs tracking-wider rounded-xl transition-all"
                          >
                              Annuler
                          </button>
                          <button 
                              type="submit"
                              disabled={isSubmitting}
                              className="px-8 py-3 bg-blue-600 hover:bg-blue-700 text-white font-black uppercase text-xs tracking-wider rounded-xl shadow-lg transition-all active:scale-95 flex items-center gap-2 disabled:opacity-50"
                          >
                              <i className="ti ti-check"></i> Créer le Ticket SAV
                          </button>
                      </div>
                  </form>
              </div>
          </div>
      )}

      {/* ASSIGN TECHNICIAN MODAL */}
      {modal.type === 'assign' && modal.item && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[160] flex items-center justify-center p-4">
              <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 border-4 border-white">
                  <div className="p-8 border-b flex justify-between items-center bg-slate-50/50">
                      <div>
                          <h2 className="text-xl font-black text-slate-800 uppercase text-[10px] tracking-[4px]">Affecter Technicien</h2>
                          <p className="text-slate-400 font-bold text-[9px] uppercase mt-1">Assigner un expert technique au ticket</p>
                      </div>
                      <button onClick={() => setModal({ type: 'view', item: modal.item })} className="w-12 h-12 flex items-center justify-center bg-white rounded-full text-slate-400 transition-all text-2xl">×</button>
                  </div>
                  <form onSubmit={(e) => { e.preventDefault(); const techId = (e.currentTarget.elements.namedItem('technician_id') as HTMLSelectElement).value; if (techId) { handleAssignTechnician(parseInt(techId)); } }} className="p-10 space-y-6">
                      <div className="space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">Sélectionner un expert</label>
                          <select name="technician_id" className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl outline-none font-bold" required>
                              <option value="">-- Choisir un Technicien --</option>
                              {technicians.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                          </select>
                      </div>
                      <button type="submit" disabled={isSubmitting} className="w-full py-6 bg-blue-600 text-white rounded-[2rem] font-black uppercase text-xs tracking-[4px] shadow-2xl active:scale-95 transition-all">
                          Valider l'Assignation
                      </button>
                  </form>
              </div>
          </div>
      )}

      {/* SUCCESS MODAL */}
      {modal.type === 'success' && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[200] flex items-center justify-center p-4">
              <div className="bg-white rounded-[3rem] shadow-2xl p-12 text-center max-w-sm w-full animate-in zoom-in-95 border-4 border-white">
                  <div className="w-20 h-20 bg-emerald-50 text-emerald-500 rounded-3xl flex items-center justify-center text-4xl mx-auto mb-6 shadow-inner animate-bounce">
                      <i className="ti ti-check"></i>
                  </div>
                  <h3 className="text-2xl font-black text-slate-800 tracking-tight mb-2">Opération Réussie</h3>
                  <p className="text-slate-500 text-sm font-medium leading-relaxed mb-8">Le ticket a été assigné au technicien avec succès.</p>
                  <button onClick={() => setModal({ type: null, item: null })} className="w-full py-4 bg-slate-900 text-white rounded-2xl font-black uppercase text-[10px] tracking-[4px] active:scale-95 transition-all shadow-xl">
                      Fermer
                  </button>
              </div>
          </div>
      )}

      {/* MEDIA SPOTLIGHT OVERLAY */}
      {spotlight && (() => {
          const path = spotlight.file_path || spotlight.url || spotlight.image_url || spotlight.src || spotlight.path || '';
          const type = getMediaType(path, spotlight.file_type || spotlight.media_type);
          const url = getFileUrl(path);
          const label = spotlight.caption || spotlight.file_name || spotlight.title || spotlight.name || '';

          return (
              <div className="fixed inset-0 bg-slate-900/95 backdrop-blur-3xl z-[250] flex flex-col items-center justify-center p-8 animate-in fade-in duration-300">
                  <button onClick={() => setSpotlight(null)} className="absolute top-8 right-8 w-14 h-14 bg-white/10 hover:bg-white/20 text-white rounded-full flex items-center justify-center text-3xl font-light transition-all active:scale-90">×</button>
                  <div className="w-full max-w-5xl h-full flex flex-col items-center justify-center gap-6">
                      <div className="flex-1 w-full flex items-center justify-center overflow-hidden">
                        {type === 'image' && (
                            <img src={url} className="max-w-full max-h-[78vh] rounded-2xl shadow-2xl border-4 border-white/10 object-contain" alt={label} />
                        )}
                        {type === 'video' && (
                            <video src={url} className="max-w-full max-h-[78vh] rounded-2xl shadow-2xl border-4 border-white/10" controls autoPlay />
                        )}
                        {type === 'audio' && (
                            <div className="bg-slate-800 p-8 rounded-3xl text-center space-y-4 border border-slate-700">
                                <i className="ti ti-microphone text-6xl text-blue-400"></i>
                                <audio src={url} controls autoPlay className="w-full max-w-md" />
                            </div>
                        )}
                      </div>
                      {label && (
                        <div className="bg-white/10 backdrop-blur-md px-6 py-3 rounded-2xl text-white text-center max-w-xl">
                          <p className="text-sm font-bold">{label}</p>
                        </div>
                      )}
                  </div>
              </div>
          );
      })()}
    </div>
  );
}

function MessageBubble({ isOfficial, sender, text, time }: any) {
    return (
        <div className={`flex flex-col ${isOfficial ? 'items-end' : 'items-start'} animate-in fade-in slide-in-from-bottom-2`}>
            <div className={`flex flex-col max-w-[80%] ${isOfficial ? 'items-end' : 'items-start'}`}>
                <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1.5 px-4">{sender} • {time}</p>
                <div className={`p-5 rounded-2xl shadow-sm text-sm font-medium leading-relaxed ${isOfficial ? 'bg-slate-900 text-white rounded-tr-none' : 'bg-white border border-emerald-100 text-slate-700 rounded-tl-none'}`}>
                    {text}
                </div>
            </div>
        </div>
    )
}

function SAVKPI({ label, value, icon, color, onClick, active, subtitle, badge }: any) {
    return (
        <div 
            onClick={onClick}
            className={`p-6 rounded-3xl border transition-all relative overflow-hidden group ${
                onClick ? 'cursor-pointer hover:shadow-lg hover:-translate-y-0.5' : ''
            } ${
                active 
                    ? 'bg-slate-900 text-white border-slate-900 shadow-xl ring-2 ring-blue-500' 
                    : 'bg-white border-slate-100 hover:border-slate-200 shadow-sm'
            }`}
        >
            <div className="flex items-start justify-between gap-4">
                <div className="flex items-center gap-4 min-w-0">
                    <div className={`w-13 h-13 rounded-2xl ${color} flex items-center justify-center text-white text-2xl shadow-lg transition-transform group-hover:scale-105 shrink-0`}>
                        <i className={`ti ${icon}`}></i>
                    </div>
                    <div className="min-w-0">
                        <p className={`text-[10px] font-black uppercase tracking-[2px] truncate mb-1 ${active ? 'text-slate-300' : 'text-slate-400'}`}>
                            {label}
                        </p>
                        <p className={`text-2xl font-black tracking-tight leading-none ${active ? 'text-white' : 'text-slate-800'}`}>
                            {value}
                        </p>
                        {subtitle && (
                            <p className={`text-[10px] font-bold mt-1.5 truncate ${active ? 'text-blue-300' : 'text-slate-400'}`}>
                                {subtitle}
                            </p>
                        )}
                    </div>
                </div>
                {badge && (
                    <span className={`text-[9px] font-black uppercase tracking-wider px-2.5 py-1 rounded-full shrink-0 ${
                        active 
                            ? 'bg-white/20 text-white' 
                            : 'bg-slate-100 text-slate-600'
                    }`}>
                        {badge}
                    </span>
                )}
            </div>
            <div className={`absolute -right-6 -bottom-6 w-24 h-24 ${color} opacity-5 rounded-full pointer-events-none`}></div>
        </div>
    );
}

function TabBtn({ active, onClick, icon, label }: any) {
    return (
        <button onClick={onClick} className={`flex items-center gap-2 px-6 py-3 rounded-full text-[10px] font-black uppercase tracking-[2px] transition-all duration-300 border-2 shrink-0 ${active ? 'bg-slate-900 border-slate-900 text-white shadow-xl scale-105' : 'bg-white border-slate-100 text-slate-400 hover:border-slate-200 hover:text-slate-600'}`}>
            <i className={`ti ${icon} text-lg`}></i>{label}
        </button>
    )
}

function DataBox({ label, value }: any) {
    return (
        <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 shadow-inner group hover:bg-white transition-colors">
            <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">{label}</p>
            <p className="text-sm font-black text-slate-800 tracking-tight">{value}</p>
        </div>
    );
}
