import React, { useState, useEffect, useMemo, useRef } from 'react';
import { api } from '../api';
import { useApp } from '../App';
import { Link } from 'react-router-dom';
import * as XLSX from 'xlsx';

const MOROCCAN_REGIONS = [
  {
    name: "Région Nord",
    center: "Tanger",
    cities: "Tanger, Tétouan, Chefchaouen, Larache, Al Hoceïma, Ouezzane, M'diq, Fnideq",
    color: "from-sky-500 to-blue-600",
    badgeBg: "bg-sky-50 text-sky-700 border-sky-200"
  },
  {
    name: "Région Centre-Ouest",
    center: "Rabat",
    cities: "Rabat, Salé, Kénitra, Khémisset, Sidi Kacem, Sidi Slimane",
    color: "from-indigo-500 to-purple-600",
    badgeBg: "bg-indigo-50 text-indigo-700 border-indigo-200"
  },
  {
    name: "Région Centre",
    center: "Casablanca",
    cities: "Casablanca, Mohammedia, El Jadida, Settat, Berrechid, Benslimane, Nouaceur, Khouribga",
    color: "from-blue-600 to-indigo-700",
    badgeBg: "bg-blue-50 text-blue-700 border-blue-200"
  },
  {
    name: "Région Sud",
    center: "Marrakech",
    cities: "Marrakech, Safi, Essaouira, Agadir, Taroudant, Ouarzazate, Errachidia, Béni Mellal, Azilal, Tinghir, Guelmim, Tan-Tan, Tiznit, Laâyoune, Dakhla",
    color: "from-amber-500 to-orange-600",
    badgeBg: "bg-amber-50 text-amber-800 border-amber-200"
  }
];

const LEAD_STATUSES: Record<string, { label: string; bg: string; text: string; border: string; icon: string }> = {
  new: { label: 'Nouveau', bg: 'bg-sky-50', text: 'text-sky-700', border: 'border-sky-200', icon: 'ti-sparkles' },
  contacted: { label: 'Contacté', bg: 'bg-indigo-50', text: 'text-indigo-700', border: 'border-indigo-200', icon: 'ti-phone' },
  qualified: { label: 'Qualifié', bg: 'bg-purple-50', text: 'text-purple-700', border: 'border-purple-200', icon: 'ti-certificate' },
  proposal: { label: 'Proposition / Devis', bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-200', icon: 'ti-file-invoice' },
  won: { label: 'Gagné / Client', bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-200', icon: 'ti-trophy' },
  lost: { label: 'Perdu', bg: 'bg-rose-50', text: 'text-rose-700', border: 'border-rose-200', icon: 'ti-circle-x' },
};

export default function AdminCommercialTeam() {
  const { user, checkPermission, showDenied } = useApp();
  const [commercials, setCommercials] = useState<any[]>([]);
  const [leadsList, setLeadsList] = useState<any[]>([]);
  const [allClients, setAllClients] = useState<any[]>([]);
  const [performanceStats, setPerformanceStats] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters & Search
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRegionFilter, setSelectedRegionFilter] = useState('all');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState('all');
  const [viewMode, setViewMode] = useState<'cards' | 'table'>('cards');

  // Modals
  const [singleLeadModal, setSingleLeadModal] = useState<{ open: boolean; commercial: any | null; editingLead?: any | null }>({ open: false, commercial: null, editingLead: null });
  const [excelImportModal, setExcelImportModal] = useState<{ open: boolean; commercial: any | null }>({ open: false, commercial: null });
  const [portfolioModal, setPortfolioModal] = useState<{ open: boolean; commercial: any | null }>({ open: false, commercial: null });
  const [regionModal, setRegionModal] = useState<{ open: boolean; commercial: any | null }>({ open: false, commercial: null });
  const [portfolioSearch, setPortfolioSearch] = useState('');

  // Form states & submission
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [newRegionValue, setNewRegionValue] = useState('');
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Excel Import States
  const [excelFile, setExcelFile] = useState<File | null>(null);
  const [parsedRows, setParsedRows] = useState<any[]>([]);
  const [importTargetCommercialId, setImportTargetCommercialId] = useState<string>('');
  const [importProgress, setImportProgress] = useState<{ current: number; total: number; success: number; errors: string[] } | null>(null);
  const [isImporting, setIsImporting] = useState(false);
  const [isDragOver, setIsDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [uRes, lRes, cRes, pRes] = await Promise.all([
        api.users.list('role_id=3'),
        api.leads.list().catch(() => ({ data: [] })),
        api.clients.list('per_page=1000').catch(() => ({ data: [] })),
        api.payments.getCommercialStats().catch(() => ({ commercials: [] }))
      ]);

      const rawCommercials = Array.isArray(uRes.data) ? uRes.data : (Array.isArray(uRes) ? uRes : []);
      const rawLeads = Array.isArray(lRes.data) ? lRes.data : (Array.isArray(lRes) ? lRes : []);
      const rawClients = Array.isArray(cRes.data) ? cRes.data : (Array.isArray(cRes) ? cRes : []);
      const rawPerf = pRes.commercials || [];

      setCommercials(rawCommercials);
      setLeadsList(rawLeads);
      setAllClients(rawClients);
      setPerformanceStats(rawPerf);
    } catch (err) {
      console.error("Failed to load commercial team:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Merge commercial info with performance, leads, and clients
  const enrichedCommercials = useMemo(() => {
    return commercials.map(c => {
      const perf = performanceStats.find(p => p.id === c.id) || {};
      
      // Leads assigned to this commercial
      const assignedLeads = leadsList.filter(l => l.assigned_to === c.id || l.assigned_commercial?.id === c.id);
      
      // Clients assigned to this commercial (legacy / formal accounts)
      const assignedClients = allClients.filter(cl => cl.commercial_id === c.id || cl.commercial?.id === c.id);
      
      const totalSales = parseFloat(perf.total_sales || c.total_sales || 0);
      const totalPaid = parseFloat(perf.total_paid || c.total_paid || 0);
      const balance = parseFloat(perf.balance || (totalSales - totalPaid) || 0);
      
      // Status counts for leads
      const newLeads = assignedLeads.filter(l => l.status === 'new').length;
      const contactedLeads = assignedLeads.filter(l => l.status === 'contacted').length;
      const qualifiedLeads = assignedLeads.filter(l => l.status === 'qualified').length;
      const proposalLeads = assignedLeads.filter(l => l.status === 'proposal').length;
      const wonLeads = assignedLeads.filter(l => l.status === 'won').length;
      const lostLeads = assignedLeads.filter(l => l.status === 'lost').length;

      return {
        ...c,
        assignedLeads,
        assignedClients,
        totalLeadsCount: assignedLeads.length,
        totalClientsCount: assignedClients.length,
        combinedTotalCount: assignedLeads.length + assignedClients.length,
        newLeads,
        contactedLeads,
        qualifiedLeads,
        proposalLeads,
        wonLeads,
        lostLeads,
        totalSales,
        totalPaid,
        balance,
        regionData: MOROCCAN_REGIONS.find(r => r.name === c.region) || null
      };
    });
  }, [commercials, leadsList, allClients, performanceStats]);

  // Filtered commercials
  const filteredCommercials = useMemo(() => {
    return enrichedCommercials.filter(c => {
      const search = searchTerm.toLowerCase();
      const matchSearch = 
        c.name?.toLowerCase().includes(search) ||
        c.email?.toLowerCase().includes(search) ||
        c.phone?.toLowerCase().includes(search) ||
        c.region?.toLowerCase().includes(search);

      const matchRegion = 
        selectedRegionFilter === 'all' ||
        (selectedRegionFilter === 'unassigned' && !c.region) ||
        c.region === selectedRegionFilter;

      return matchSearch && matchRegion;
    });
  }, [enrichedCommercials, searchTerm, selectedRegionFilter]);

  // Overall KPIs
  const globalKpis = useMemo(() => {
    const totalComms = enrichedCommercials.length;
    const activeComms = enrichedCommercials.filter(c => c.is_active).length;
    const totalLeads = leadsList.length;
    const totalSalesSum = enrichedCommercials.reduce((acc, c) => acc + (c.totalSales || 0), 0);
    const totalPaidSum = enrichedCommercials.reduce((acc, c) => acc + (c.totalPaid || 0), 0);

    return {
      totalComms,
      activeComms,
      totalLeads,
      totalSalesSum,
      totalPaidSum
    };
  }, [enrichedCommercials, leadsList]);

  // ============================================================================
  // EXCEL TEMPLATE GENERATOR (.XLSX)
  // ============================================================================
  const handleDownloadExcelTemplate = () => {
    const templateData = [
      {
        "name": "Dr. Mohamed Alami",
        "company": "Clinique Internationale Casablanca",
        "email": "dr.alami@clinique-internationale.ma",
        "phone": "0661123456",
        "city": "Casablanca",
        "address": "120 Boulevard d'Anfa, 2ème étage",
        "status": "new",
        "source": "Salon Médical",
        "budget": "250 000 MAD",
        "notes": "Intéressé par échographe Doppler couleur et sonde cardiaque"
      },
      {
        "name": "Dr. Fatima Zahra Bennani",
        "company": "Cabinet de Radiologie Agdal",
        "email": "contact@radiologie-agdal.ma",
        "phone": "0662987654",
        "city": "Rabat",
        "address": "45 Avenue Fal Ould Oumeir, Agdal",
        "status": "contacted",
        "source": "Recommandation",
        "budget": "180 000 MAD",
        "notes": "Rénovation équipement imagerie médicale - Prévu Q3"
      },
      {
        "name": "Dr. Karim Tazi",
        "company": "Centre d'Ophtalmologie du Nord",
        "email": "k.tazi@ophtalmo-nord.com",
        "phone": "0663456789",
        "city": "Tanger",
        "address": "Boulevard Pasteur, Tanger Centre",
        "status": "qualified",
        "source": "Appel Direct",
        "budget": "320 000 MAD",
        "notes": "Demande de démonstration sur site"
      },
      {
        "name": "Dr. Sanae El Idrissi",
        "company": "Polyclinique Guéliz",
        "email": "dr.sanae@polyclinique-gueliz.ma",
        "phone": "0664112233",
        "city": "Marrakech",
        "address": "Avenue Mohammed V, Guéliz",
        "status": "proposal",
        "source": "Site Web",
        "budget": "450 000 MAD",
        "notes": "Devis transmis pour 2 moniteurs multiparamétriques et respirateur"
      }
    ];

    const worksheet = XLSX.utils.json_to_sheet(templateData);
    
    // Auto column widths
    worksheet['!cols'] = [
      { wch: 25 }, // name
      { wch: 35 }, // company
      { wch: 32 }, // email
      { wch: 18 }, // phone
      { wch: 16 }, // city
      { wch: 40 }, // address
      { wch: 14 }, // status (new, contacted, qualified, proposal, won, lost)
      { wch: 20 }, // source
      { wch: 18 }, // budget
      { wch: 55 }, // notes
    ];

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Leads");
    
    // Download
    XLSX.writeFile(workbook, "modele_leads_commercial.xlsx");
  };

  // ============================================================================
  // EXCEL PARSER (READS .XLSX / .XLS / .CSV)
  // ============================================================================
  const parseExcelFile = (file: File) => {
    setExcelFile(file);
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const data = evt.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const rawJson: any[] = XLSX.utils.sheet_to_json(worksheet, { defval: '' });

        const normalized = rawJson.map((row) => {
          // Check keys case-insensitively & support French/English aliases
          const getVal = (keys: string[]) => {
            for (const k of keys) {
              for (const rowKey of Object.keys(row)) {
                if (rowKey.trim().toLowerCase() === k.toLowerCase()) {
                  const val = row[rowKey];
                  return val !== undefined && val !== null ? String(val).trim() : '';
                }
              }
            }
            return '';
          };

          const name = getVal(['name', 'nom', 'nom complet', 'contact', 'contact_name', 'interlocuteur', 'docteur', 'dr', 'medecin']);
          const company = getVal(['company', 'societe', 'société', 'clinique', 'cabinet', 'etablissement', 'établissement', 'entreprise', 'centre', 'raison_sociale', 'hopital']);
          const phone = getVal(['phone', 'telephone', 'téléphone', 'tel', 'mobile', 'whatsapp', 'gsm']);
          const email = getVal(['email', 'mail', 'courriel', 'e-mail']);
          const city = getVal(['city', 'ville', 'region', 'localite', 'localité']);
          const address = getVal(['address', 'adresse', 'adresse complete', 'adresse complète']);
          let status = getVal(['status', 'statut', 'etat', 'état']).toLowerCase();
          const source = getVal(['source', 'provenance', 'canal', 'origine']);
          const budget = getVal(['budget', 'budget estimatif', 'montant', 'valeur']);
          const notes = getVal(['notes', 'remarques', 'besoins', 'commentaire', 'commentaires', 'description']);

          const validStatuses = ['new', 'contacted', 'qualified', 'proposal', 'won', 'lost'];
          if (!validStatuses.includes(status)) {
            if (status.includes('nouv') || status.includes('new')) status = 'new';
            else if (status.includes('contac') || status.includes('appel')) status = 'contacted';
            else if (status.includes('qualif')) status = 'qualified';
            else if (status.includes('prop') || status.includes('devis')) status = 'proposal';
            else if (status.includes('gagn') || status.includes('sign') || status.includes('won') || status.includes('actif')) status = 'won';
            else if (status.includes('perd') || status.includes('lost') || status.includes('annul')) status = 'lost';
            else status = 'new';
          }

          const leadName = name || company || 'Prospect Médical';
          const leadCompany = company || name || 'Cabinet Médical';

          return {
            name: leadName,
            company: leadCompany,
            email: email || null,
            phone: phone || null,
            city: city || null,
            address: address || null,
            status: status || 'new',
            source: source || 'Import Excel',
            budget: budget || null,
            notes: notes || null,
            isValid: Boolean(leadName && leadCompany)
          };
        });

        setParsedRows(normalized.filter(r => r.name || r.company));
      } catch (err: any) {
        console.error("Failed to parse Excel file:", err);
        alert("Erreur lors de la lecture du fichier Excel: " + err.message);
      }
    };
    reader.readAsBinaryString(file);
  };

  const handleDropFile = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      parseExcelFile(file);
    }
  };

  // ============================================================================
  // BULK IMPORT EXECUTION USING API /leads
  // ============================================================================
  const handleExecuteImport = async () => {
    if (parsedRows.length === 0) {
      alert("Aucune ligne valide à importer.");
      return;
    }

    const targetCommId = importTargetCommercialId ? parseInt(importTargetCommercialId, 10) : (excelImportModal.commercial?.id || null);

    setIsImporting(true);
    setImportProgress({
      current: 0,
      total: parsedRows.length,
      success: 0,
      errors: []
    });

    let successCount = 0;
    const errorList: string[] = [];

    for (let i = 0; i < parsedRows.length; i++) {
      const row = parsedRows[i];
      const payload: any = {
        name: row.name,
        company: row.company,
        email: row.email || undefined,
        phone: row.phone || undefined,
        city: row.city || undefined,
        address: row.address || undefined,
        status: row.status || 'new',
        source: row.source || 'Import Excel',
        budget: row.budget || undefined,
        notes: row.notes || undefined,
      };

      if (targetCommId) {
        payload.assigned_to = targetCommId;
      }

      try {
        await api.leads.create(payload);
        successCount++;
      } catch (err: any) {
        console.error(`Error importing row ${i + 1} (${row.name}):`, err);
        errorList.push(`Ligne ${i + 1} (${row.name}): ${err.message || 'Erreur API'}`);
      }

      setImportProgress({
        current: i + 1,
        total: parsedRows.length,
        success: successCount,
        errors: errorList
      });
    }

    setIsImporting(false);
    await fetchData();

    if (errorList.length === 0) {
      setTimeout(() => {
        setExcelImportModal({ open: false, commercial: null });
        setExcelFile(null);
        setParsedRows([]);
        setImportProgress(null);
      }, 1500);
    }
  };

  // Open single lead modal
  const handleOpenSingleLead = (commercial?: any, lead?: any) => {
    if (!checkPermission('clients', 'add')) {
      return showDenied("Gestion des Leads");
    }
    setSingleLeadModal({ open: true, commercial: commercial || null, editingLead: lead || null });
    setFeedbackMsg(null);
  };

  // Save single lead (create or update)
  const handleSaveSingleLead = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    setFeedbackMsg(null);

    const form = e.currentTarget;
    const formData = new FormData(form);
    const payload: any = Object.fromEntries(formData.entries());

    if (!payload.assigned_to && singleLeadModal.commercial) {
      payload.assigned_to = singleLeadModal.commercial.id;
    }

    try {
      if (singleLeadModal.editingLead) {
        await api.leads.update(singleLeadModal.editingLead.id, payload);
        setFeedbackMsg({ type: 'success', text: 'Lead mis à jour avec succès !' });
      } else {
        await api.leads.create(payload);
        setFeedbackMsg({ type: 'success', text: 'Lead créé avec succès et assigné au commercial !' });
      }
      await fetchData();
      setTimeout(() => {
        setSingleLeadModal({ open: false, commercial: null, editingLead: null });
        setFeedbackMsg(null);
      }, 1200);
    } catch (err: any) {
      console.error("Error saving lead:", err);
      setFeedbackMsg({ type: 'error', text: err.message || "Erreur lors de l'enregistrement du lead." });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Update lead status
  const handleUpdateLeadStatus = async (leadId: number, newStatus: string) => {
    try {
      await api.leads.updateStatus(leadId, newStatus);
      // update locally
      setLeadsList(prev => prev.map(l => l.id === leadId ? { ...l, status: newStatus } : l));
    } catch (err: any) {
      console.error("Failed to update status:", err);
      alert("Erreur lors du changement de statut: " + err.message);
    }
  };

  // Delete lead
  const handleDeleteLead = async (leadId: number) => {
    if (!confirm("Êtes-vous sûr de vouloir supprimer ce prospect / lead ?")) return;
    try {
      await api.leads.delete(leadId);
      setLeadsList(prev => prev.filter(l => l.id !== leadId));
      await fetchData();
    } catch (err: any) {
      console.error("Failed to delete lead:", err);
      alert("Erreur lors de la suppression: " + err.message);
    }
  };

  // Save Commercial Region
  const handleSaveRegion = async () => {
    if (!regionModal.commercial) return;
    setIsSubmitting(true);
    try {
      const fullUser = await api.users.show(regionModal.commercial.id);
      const payload = {
        name: fullUser.name,
        email: fullUser.email,
        role_id: fullUser.role_id,
        phone: fullUser.phone,
        is_active: fullUser.is_active ? '1' : '0',
        region: newRegionValue,
      };

      await api.users.update(regionModal.commercial.id, payload);
      await fetchData();
      setRegionModal({ open: false, commercial: null });
    } catch (err: any) {
      console.error("Failed to update region:", err);
      alert(err.message || "Erreur lors de la mise à jour de la région.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Export Specific Commercial Leads to Excel
  const handleExportCommercialLeads = (commercial: any) => {
    const leads = leadsList.filter(l => l.assigned_to === commercial.id || l.assigned_commercial?.id === commercial.id);
    if (leads.length === 0) {
      alert("Aucun lead à exporter pour ce commercial.");
      return;
    }

    const exportData = leads.map(l => ({
      "ID": l.id,
      "Nom Contact": l.name,
      "Établissement / Clinique": l.company,
      "Téléphone": l.phone || '',
      "Email": l.email || '',
      "Ville": l.city || '',
      "Adresse": l.address || '',
      "Statut": LEAD_STATUSES[l.status]?.label || l.status,
      "Source": l.source || '',
      "Budget": l.budget || '',
      "Notes & Besoins": l.notes || '',
      "Date Création": l.created_at ? new Date(l.created_at).toLocaleDateString('fr-FR') : ''
    }));

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Leads");
    XLSX.writeFile(workbook, `leads_${commercial.name.toLowerCase().replace(/\s+/g, '_')}.xlsx`);
  };

  return (
    <div className="space-y-8 pb-20 animate-in fade-in duration-500">
      {/* TOP HERO HEADER */}
      <div className="bg-white p-8 lg:p-10 rounded-[3.5rem] shadow-sm border border-slate-100 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <span className="px-3 py-1 bg-blue-50 text-blue-600 rounded-xl text-[10px] font-black uppercase tracking-widest border border-blue-100">
              Équipe Commerciale & Portefeuille
            </span>
            <span className="text-slate-300">•</span>
            <span className="text-xs font-bold text-slate-400">Import Excel & Attribution Leads</span>
          </div>
          <h1 className="text-3xl font-black text-slate-800 tracking-tight">Commerciaux & Gestion des Leads</h1>
          <p className="text-slate-400 text-xs font-medium mt-1">
            Consultez les informations détaillées de chaque commercial, importez massivement des fichiers Excel de prospects et attribuez-les directement.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Download template button */}
          <button
            onClick={handleDownloadExcelTemplate}
            className="px-5 py-4 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-2xl font-black text-xs uppercase tracking-widest transition-all flex items-center gap-2.5 active:scale-95 shadow-sm"
            title="Télécharger le modèle Excel pré-rempli"
          >
            <i className="ti ti-file-download text-lg text-emerald-600"></i>
            Modèle Excel
          </button>

          {/* Upload excel button */}
          <button
            onClick={() => {
              setExcelImportModal({ open: true, commercial: null });
              setExcelFile(null);
              setParsedRows([]);
              setImportProgress(null);
              setImportTargetCommercialId('');
            }}
            className="px-6 py-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-emerald-600/20 active:scale-95 transition-all flex items-center gap-2.5"
          >
            <i className="ti ti-file-spreadsheet text-lg"></i>
            Importer Excel
          </button>

          {/* GPS Tracking link for commercials */}
          <Link
            to="/admin/tracking?fleet=commercials"
            className="px-5 py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-indigo-600/20 active:scale-95 transition-all flex items-center gap-2.5"
            title="Suivi GPS temps réel et historique des trajets des commerciaux"
          >
            <i className="ti ti-map-pin text-lg"></i>
            Suivi GPS
          </Link>

          {/* New single lead */}
          <button
            onClick={() => handleOpenSingleLead()}
            className="px-6 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-500/20 active:scale-95 transition-all flex items-center gap-2.5"
          >
            <i className="ti ti-user-plus text-lg"></i>
            Nouveau Lead
          </button>

          {/* Refresh */}
          <button
            onClick={fetchData}
            title="Rafraîchir"
            className="w-12 h-12 bg-slate-100 text-slate-600 hover:bg-slate-200 rounded-2xl flex items-center justify-center transition-all active:scale-95 shadow-sm"
          >
            <i className={`ti ti-refresh text-lg ${loading ? 'animate-spin' : ''}`}></i>
          </button>
        </div>
      </div>

      {/* KPI METRICS OVERVIEW */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm flex items-center gap-5">
          <div className="w-14 h-14 rounded-2xl bg-indigo-600 text-white flex items-center justify-center text-2xl shadow-lg shadow-indigo-600/20">
            <i className="ti ti-users-group"></i>
          </div>
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Commerciaux Actifs</p>
            <p className="text-2xl font-black text-slate-800 tracking-tight leading-none">
              {globalKpis.activeComms} <span className="text-sm font-bold text-slate-400">/ {globalKpis.totalComms}</span>
            </p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm flex items-center gap-5">
          <div className="w-14 h-14 rounded-2xl bg-sky-600 text-white flex items-center justify-center text-2xl shadow-lg shadow-sky-600/20">
            <i className="ti ti-sparkles"></i>
          </div>
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Total Prospects / Leads</p>
            <p className="text-2xl font-black text-slate-800 tracking-tight leading-none">{globalKpis.totalLeads}</p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm flex items-center gap-5">
          <div className="w-14 h-14 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-black text-xl tracking-tight shadow-lg shadow-emerald-600/20 select-none">
            DH
          </div>
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Ventes Globales</p>
            <p className="text-2xl font-black text-slate-800 tracking-tight leading-none">
              {globalKpis.totalSalesSum.toLocaleString()} <span className="text-xs font-bold text-emerald-600">MAD</span>
            </p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm flex items-center gap-5">
          <div className="w-14 h-14 rounded-2xl bg-amber-500 text-white flex items-center justify-center text-2xl shadow-lg shadow-amber-500/20">
            <i className="ti ti-wallet"></i>
          </div>
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Encaissements</p>
            <p className="text-2xl font-black text-slate-800 tracking-tight leading-none">
              {globalKpis.totalPaidSum.toLocaleString()} <span className="text-xs font-bold text-amber-600">MAD</span>
            </p>
          </div>
        </div>
      </div>

      {/* SEARCH, REGION FILTER & VIEW SWITCHER */}
      <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex-1 w-full relative">
          <i className="ti ti-search absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 text-base"></i>
          <input
            type="text"
            placeholder="Rechercher par nom, email, téléphone ou région..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-6 py-3.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs font-bold text-slate-700 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all placeholder:text-slate-400"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          {/* Region filter */}
          <div className="relative flex-1 md:flex-none">
            <select
              value={selectedRegionFilter}
              onChange={(e) => setSelectedRegionFilter(e.target.value)}
              className="w-full md:w-auto px-5 py-3.5 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs font-bold text-slate-700 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all appearance-none pr-10 cursor-pointer"
            >
              <option value="all">🌍 Toutes les Régions</option>
              {MOROCCAN_REGIONS.map((r, i) => (
                <option key={i} value={r.name}>{r.name} ({r.center})</option>
              ))}
              <option value="unassigned">Non Spécifié</option>
            </select>
            <i className="ti ti-chevron-down absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none text-xs"></i>
          </div>

          {/* View mode toggle */}
          <div className="flex bg-slate-100 p-1 rounded-2xl border border-slate-200/60">
            <button
              onClick={() => setViewMode('cards')}
              className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 ${viewMode === 'cards' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
            >
              <i className="ti ti-layout-grid text-sm"></i>
              Cartes
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 ${viewMode === 'table' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
            >
              <i className="ti ti-list text-sm"></i>
              Tableau
            </button>
          </div>
        </div>
      </div>

      {/* COMMERCIALS DIRECTORY CONTENT */}
      {loading ? (
        <div className="bg-white p-20 rounded-[3.5rem] border border-slate-100 text-center">
          <div className="animate-spin h-10 w-10 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-xs font-black uppercase tracking-widest text-slate-400">Chargement de l'équipe commerciale & des leads...</p>
        </div>
      ) : filteredCommercials.length === 0 ? (
        <div className="bg-white p-20 rounded-[3.5rem] border border-slate-100 text-center">
          <div className="w-16 h-16 bg-slate-100 text-slate-400 rounded-3xl flex items-center justify-center mx-auto mb-4 text-2xl">
            <i className="ti ti-user-x"></i>
          </div>
          <h3 className="text-base font-black text-slate-700 uppercase tracking-wider mb-1">Aucun commercial trouvé</h3>
          <p className="text-xs text-slate-400">Modifiez vos critères de recherche ou ajoutez un nouveau profil.</p>
        </div>
      ) : viewMode === 'cards' ? (
        /* CARDS GRID VIEW */
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
          {filteredCommercials.map((c) => {
            const avatarUrl = c.avatar_url 
              ? (c.avatar_url.startsWith('http') ? c.avatar_url : `https://birdeye-intelligence.ma/Spetcapp/Backend/storage/app/public/${c.avatar_url}`)
              : `https://ui-avatars.com/api/?name=${encodeURIComponent(c.name || 'Commercial')}&background=2563EB&color=fff&bold=true`;

            return (
              <div
                key={c.id}
                className="bg-white rounded-[3rem] border border-slate-100 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden flex flex-col group"
              >
                {/* Header with region banner */}
                <div className="p-8 pb-6 bg-gradient-to-b from-slate-50 to-white border-b border-slate-100/80 relative">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <div className="relative">
                        <img
                          src={avatarUrl}
                          alt={c.name}
                          className="w-16 h-16 rounded-2xl object-cover border-2 border-white shadow-md"
                        />
                        <span className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white ${c.is_active ? 'bg-emerald-500' : 'bg-slate-300'}`}></span>
                      </div>
                      <div>
                        <h3 className="text-lg font-black text-slate-800 tracking-tight">{c.name}</h3>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">ID Commercial: #{c.id}</p>
                        <span className={`inline-block mt-1 px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider ${c.is_active ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}>
                          {c.is_active ? 'Actif' : 'Inactif'}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        setRegionModal({ open: true, commercial: c });
                        setNewRegionValue(c.region || '');
                      }}
                      title="Modifier la région"
                      className="p-2.5 rounded-xl bg-white border border-slate-200 text-slate-500 hover:text-blue-600 hover:border-blue-300 transition-colors shadow-sm text-xs"
                    >
                      <i className="ti ti-map-pin"></i>
                    </button>
                  </div>

                  {/* Region badge */}
                  <div className="mt-5">
                    {c.regionData ? (
                      <div className={`p-3 rounded-2xl border ${c.regionData.badgeBg} flex items-center justify-between`}>
                        <div className="flex items-center gap-2">
                          <i className="ti ti-map-pin-filled text-sm"></i>
                          <div>
                            <span className="text-xs font-black">{c.regionData.name}</span>
                            <span className="text-[10px] opacity-75 font-semibold ml-2">({c.regionData.center})</span>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="p-3 rounded-2xl border border-dashed border-slate-200 bg-slate-50/50 flex items-center justify-between text-slate-400 text-xs font-bold">
                        <span className="flex items-center gap-2"><i className="ti ti-alert-triangle"></i> Région non attribuée</span>
                        <button
                          onClick={() => {
                            setRegionModal({ open: true, commercial: c });
                            setNewRegionValue('');
                          }}
                          className="text-[10px] font-black text-blue-600 hover:underline uppercase tracking-wider"
                        >
                          Affecter
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Body with contact & portfolio info */}
                <div className="p-8 space-y-6 flex-1 flex flex-col justify-between">
                  {/* Contact links */}
                  <div className="space-y-2.5">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Coordonnées de Contact</p>
                    <div className="flex flex-col gap-2">
                      <a
                        href={`mailto:${c.email}`}
                        className="flex items-center gap-2.5 text-xs font-bold text-slate-600 hover:text-blue-600 transition-colors truncate"
                      >
                        <i className="ti ti-mail text-slate-400 text-sm"></i>
                        <span className="truncate">{c.email || 'Pas d\'email'}</span>
                      </a>
                      <div className="flex items-center justify-between">
                        <a
                          href={`tel:${c.phone}`}
                          className="flex items-center gap-2.5 text-xs font-bold text-slate-600 hover:text-blue-600 transition-colors"
                        >
                          <i className="ti ti-phone text-slate-400 text-sm"></i>
                          <span>{c.phone || 'Non renseigné'}</span>
                        </a>
                        {c.phone && (
                          <a
                            href={`https://wa.me/${c.phone.replace(/[^0-9]/g, '')}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-2.5 py-1 bg-emerald-50 text-emerald-600 hover:bg-emerald-100 rounded-lg text-[10px] font-black flex items-center gap-1 transition-colors"
                          >
                            <i className="ti ti-brand-whatsapp"></i> WhatsApp
                          </a>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Pipeline Breakdown Box */}
                  <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100 space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Portefeuille Leads</span>
                      <span className="px-2.5 py-0.5 bg-blue-100 text-blue-700 rounded-lg text-xs font-black">
                        {c.totalLeadsCount} Prospects
                      </span>
                    </div>

                    {/* Pipeline status pills */}
                    <div className="grid grid-cols-3 gap-2">
                      <div className="p-2 bg-white rounded-xl border border-slate-100 text-center">
                        <p className="text-[9px] font-bold text-sky-600 uppercase">Nouveaux</p>
                        <p className="text-sm font-black text-slate-800">{c.newLeads}</p>
                      </div>
                      <div className="p-2 bg-white rounded-xl border border-slate-100 text-center">
                        <p className="text-[9px] font-bold text-indigo-600 uppercase">Qualifiés</p>
                        <p className="text-sm font-black text-slate-800">{c.qualifiedLeads + c.contactedLeads}</p>
                      </div>
                      <div className="p-2 bg-white rounded-xl border border-slate-100 text-center">
                        <p className="text-[9px] font-bold text-emerald-600 uppercase">Gagnés</p>
                        <p className="text-sm font-black text-slate-800">{c.wonLeads}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-200/60">
                      <div>
                        <p className="text-[9px] font-bold text-slate-400 uppercase">Chiffre d'Affaires</p>
                        <p className="text-sm font-black text-slate-800">{c.totalSales.toLocaleString()} <span className="text-[10px] text-slate-400">MAD</span></p>
                      </div>
                      <div>
                        <p className="text-[9px] font-bold text-slate-400 uppercase">Encaissements</p>
                        <p className="text-sm font-black text-emerald-600">{c.totalPaid.toLocaleString()} <span className="text-[10px] text-emerald-400">MAD</span></p>
                      </div>
                    </div>
                  </div>

                  {/* Primary Action Buttons */}
                  <div className="pt-2 space-y-2.5">
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => {
                          setExcelImportModal({ open: true, commercial: c });
                          setImportTargetCommercialId(String(c.id));
                          setExcelFile(null);
                          setParsedRows([]);
                          setImportProgress(null);
                        }}
                        className="py-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-xl font-black text-[10px] uppercase tracking-wider transition-colors flex items-center justify-center gap-1.5 shadow-sm"
                      >
                        <i className="ti ti-file-spreadsheet text-base"></i>
                        Import Excel
                      </button>

                      <button
                        onClick={() => handleOpenSingleLead(c)}
                        className="py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-black text-[10px] uppercase tracking-wider transition-colors flex items-center justify-center gap-1.5 shadow-sm"
                      >
                        <i className="ti ti-user-plus text-base"></i>
                        + Lead Manuel
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => {
                          setPortfolioModal({ open: true, commercial: c });
                          setPortfolioSearch('');
                        }}
                        className="py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-black text-[10px] uppercase tracking-wider transition-colors flex items-center justify-center gap-1.5"
                      >
                        <i className="ti ti-folder-open"></i>
                        Voir Leads ({c.totalLeadsCount})
                      </button>

                      <button
                        onClick={() => handleExportCommercialLeads(c)}
                        className="py-3 bg-slate-50 hover:bg-slate-100 text-slate-600 rounded-xl font-black text-[10px] uppercase tracking-wider transition-colors flex items-center justify-center gap-1.5 border border-slate-200"
                        title="Exporter les leads de ce commercial en fichier Excel"
                      >
                        <i className="ti ti-download text-emerald-600"></i>
                        Export Excel
                      </button>
                    </div>

                    <Link
                      to={`/admin/tracking?fleet=commercials&agent=${c.id}`}
                      className="w-full py-2.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl font-black text-[10px] uppercase tracking-wider transition-colors flex items-center justify-center gap-1.5"
                      title="Voir la géolocalisation et le trajet GPS de ce commercial"
                    >
                      <i className="ti ti-current-location text-sm"></i>
                      Suivi GPS & Trajet
                    </Link>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* TABLE LIST VIEW */
        <div className="bg-white rounded-[3.5rem] border border-slate-100 shadow-sm overflow-hidden p-8">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead className="bg-slate-50 text-slate-400 border-b border-slate-100">
                <tr className="text-[10px] font-black uppercase tracking-widest">
                  <th className="px-8 py-5">Commercial</th>
                  <th className="px-8 py-5">Région Assignée</th>
                  <th className="px-8 py-5">Contact</th>
                  <th className="px-8 py-5">Portefeuille Leads</th>
                  <th className="px-8 py-5">Chiffre d'Affaires</th>
                  <th className="px-8 py-5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredCommercials.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="px-8 py-5">
                      <div className="flex items-center gap-3">
                        <img
                          src={c.avatar_url ? (c.avatar_url.startsWith('http') ? c.avatar_url : `https://birdeye-intelligence.ma/Spetcapp/Backend/storage/app/public/${c.avatar_url}`) : `https://ui-avatars.com/api/?name=${encodeURIComponent(c.name)}&background=2563EB&color=fff`}
                          alt=""
                          className="w-10 h-10 rounded-xl object-cover"
                        />
                        <div>
                          <p className="font-black text-slate-800 text-sm">{c.name}</p>
                          <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">ID #{c.id}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-5">
                      <span className={`px-3 py-1 rounded-lg text-xs font-bold ${c.regionData ? c.regionData.badgeBg : 'bg-slate-100 text-slate-400'}`}>
                        {c.region || 'Non Assignée'}
                      </span>
                    </td>
                    <td className="px-8 py-5">
                      <p className="text-xs font-bold text-slate-700">{c.phone || '-'}</p>
                      <p className="text-[10px] text-slate-400">{c.email}</p>
                    </td>
                    <td className="px-8 py-5">
                      <button
                        onClick={() => {
                          setPortfolioModal({ open: true, commercial: c });
                          setPortfolioSearch('');
                        }}
                        className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-xl text-xs font-black transition-colors"
                      >
                        {c.totalLeadsCount} Leads / Prospects
                      </button>
                    </td>
                    <td className="px-8 py-5">
                      <p className="text-sm font-black text-slate-800">{c.totalSales.toLocaleString()} MAD</p>
                      <p className="text-[10px] font-bold text-emerald-600">Reçu: {c.totalPaid.toLocaleString()} MAD</p>
                    </td>
                    <td className="px-8 py-5 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => {
                            setExcelImportModal({ open: true, commercial: c });
                            setImportTargetCommercialId(String(c.id));
                            setExcelFile(null);
                            setParsedRows([]);
                            setImportProgress(null);
                          }}
                          className="px-3 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-xl text-xs font-black transition-colors flex items-center gap-1"
                          title="Importer un fichier Excel pour ce commercial"
                        >
                          <i className="ti ti-file-spreadsheet"></i>
                          Excel
                        </button>
                        <button
                          onClick={() => handleOpenSingleLead(c)}
                          className="px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-black transition-colors flex items-center gap-1 shadow-sm"
                        >
                          <i className="ti ti-user-plus"></i>
                          + Lead
                        </button>
                        <Link
                          to={`/admin/tracking?fleet=commercials&agent=${c.id}`}
                          className="px-3 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl text-xs font-black transition-colors flex items-center gap-1"
                          title="Voir la géolocalisation et le trajet GPS"
                        >
                          <i className="ti ti-current-location"></i>
                          GPS
                        </Link>
                        <button
                          onClick={() => {
                            setRegionModal({ open: true, commercial: c });
                            setNewRegionValue(c.region || '');
                          }}
                          className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl text-xs font-bold transition-colors"
                          title="Modifier la région"
                        >
                          <i className="ti ti-map-pin"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ================================================================ */}
      {/* MODAL: IMPORTATION EXCEL DES LEADS / PROSPECTS                  */}
      {/* ================================================================ */}
      {excelImportModal.open && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[130] flex items-center justify-center p-4 overflow-y-auto animate-in fade-in">
          <div className="bg-white rounded-[3.5rem] p-8 md:p-10 w-full max-w-4xl shadow-2xl border-4 border-white my-8 animate-in zoom-in-95 duration-200 max-h-[90vh] flex flex-col">
            {/* Header */}
            <div className="flex justify-between items-start pb-6 border-b border-slate-100 shrink-0">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="px-3 py-1 bg-emerald-50 text-emerald-700 rounded-xl text-[10px] font-black uppercase tracking-widest border border-emerald-200">
                    Importation Massive Excel (.xlsx / .csv)
                  </span>
                </div>
                <h2 className="text-2xl font-black text-slate-800 tracking-tight">Importer des Leads & Prospects</h2>
                <p className="text-xs text-slate-400 font-medium mt-1">
                  Téléchargez le modèle Excel, remplissez les informations de vos prospects et téléversez le fichier pour attribution immédiate.
                </p>
              </div>
              <button
                onClick={() => {
                  if (!isImporting) {
                    setExcelImportModal({ open: false, commercial: null });
                  }
                }}
                disabled={isImporting}
                className="w-10 h-10 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center transition-colors disabled:opacity-50"
              >
                <i className="ti ti-x text-lg"></i>
              </button>
            </div>

            {/* Scrollable Content */}
            <div className="overflow-y-auto flex-1 custom-scrollbar py-6 space-y-6 pr-1">
              {/* Step 1: Assignment selector & Template download button */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100 space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">
                    1. Commercial Destinataire
                  </label>
                  <select
                    value={importTargetCommercialId}
                    onChange={(e) => setImportTargetCommercialId(e.target.value)}
                    disabled={isImporting}
                    className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-800 outline-none focus:ring-2 focus:ring-blue-500/20 cursor-pointer"
                  >
                    <option value="">Sélectionner un commercial (optionnel)</option>
                    {commercials.map(c => (
                      <option key={c.id} value={c.id}>
                        {c.name} {c.region ? `(${c.region})` : ''}
                      </option>
                    ))}
                  </select>
                  <p className="text-[10px] text-slate-400 italic">
                    Tous les prospects du fichier seront assignés à ce commercial.
                  </p>
                </div>

                <div className="p-5 bg-emerald-50/60 rounded-2xl border border-emerald-100/80 flex flex-col justify-between">
                  <div>
                    <label className="text-[10px] font-black text-emerald-800 uppercase tracking-widest block mb-1">
                      2. Modèle Excel Prêt à l'Emploi
                    </label>
                    <p className="text-xs text-emerald-700/80">
                      Téléchargez le fichier avec les colonnes formatées (nom, clinique, téléphone, email, ville, statut, budget, notes).
                    </p>
                  </div>
                  <button
                    onClick={handleDownloadExcelTemplate}
                    type="button"
                    className="mt-3 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 shadow-sm transition-all"
                  >
                    <i className="ti ti-download"></i>
                    Télécharger Modèle (.xlsx)
                  </button>
                </div>
              </div>

              {/* Step 2: Drag and Drop Upload Area */}
              <div
                onDragOver={(e) => { e.preventDefault(); setIsDragOver(true); }}
                onDragLeave={() => setIsDragOver(false)}
                onDrop={handleDropFile}
                onClick={() => fileInputRef.current?.click()}
                className={`p-8 border-2 border-dashed rounded-[2.5rem] text-center transition-all cursor-pointer ${
                  isDragOver 
                    ? 'border-blue-500 bg-blue-50/50 scale-[0.99]' 
                    : excelFile 
                      ? 'border-emerald-400 bg-emerald-50/30' 
                      : 'border-slate-200 bg-slate-50/50 hover:bg-slate-50 hover:border-slate-300'
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".xlsx, .xls, .csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel, text/csv"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files && e.target.files.length > 0) {
                      parseExcelFile(e.target.files[0]);
                    }
                  }}
                />

                <div className="w-16 h-16 rounded-2xl bg-white shadow-md border border-slate-100 flex items-center justify-center mx-auto mb-4 text-emerald-600 text-2xl">
                  <i className={excelFile ? "ti ti-file-check" : "ti ti-cloud-upload"}></i>
                </div>

                {excelFile ? (
                  <div>
                    <h4 className="text-sm font-black text-slate-800">{excelFile.name}</h4>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {(excelFile.size / 1024).toFixed(1)} KB • {parsedRows.length} lignes détectées
                    </p>
                    <span className="inline-block mt-2 px-3 py-1 bg-emerald-100 text-emerald-800 rounded-full text-[10px] font-black uppercase tracking-wider">
                      Fichier Prêt pour Importation
                    </span>
                  </div>
                ) : (
                  <div>
                    <h4 className="text-sm font-black text-slate-800">Glissez-déposez votre fichier Excel ou CSV ici</h4>
                    <p className="text-xs text-slate-400 mt-1">
                      Formats acceptés: <span className="font-bold text-slate-600">.xlsx, .xls, .csv</span>
                    </p>
                    <button
                      type="button"
                      className="mt-4 px-5 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-blue-600 transition-colors"
                    >
                      Parcourir les fichiers
                    </button>
                  </div>
                )}
              </div>

              {/* Progress Bar & Status during import */}
              {importProgress && (
                <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                  <div className="flex justify-between items-center text-xs font-black text-slate-700">
                    <span>Progression de l'importation</span>
                    <span>{importProgress.current} / {importProgress.total} ({Math.round((importProgress.current / importProgress.total) * 100)}%)</span>
                  </div>
                  <div className="w-full bg-slate-200 h-3 rounded-full overflow-hidden">
                    <div
                      className="bg-emerald-500 h-full rounded-full transition-all duration-300"
                      style={{ width: `${(importProgress.current / importProgress.total) * 100}%` }}
                    ></div>
                  </div>
                  <div className="flex items-center gap-4 text-xs font-bold">
                    <span className="text-emerald-600 flex items-center gap-1">
                      <i className="ti ti-check"></i> {importProgress.success} importés avec succès
                    </span>
                    {importProgress.errors.length > 0 && (
                      <span className="text-rose-600 flex items-center gap-1">
                        <i className="ti ti-alert-triangle"></i> {importProgress.errors.length} erreurs
                      </span>
                    )}
                  </div>
                  {importProgress.errors.length > 0 && (
                    <div className="max-h-28 overflow-y-auto p-3 bg-white rounded-xl border border-rose-100 text-[11px] text-rose-600 font-mono space-y-1">
                      {importProgress.errors.map((err, idx) => (
                        <p key={idx}>{err}</p>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Step 3: Parsed Data Preview Table */}
              {parsedRows.length > 0 && (
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                      Aperçu des données ({parsedRows.length} lignes)
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        setExcelFile(null);
                        setParsedRows([]);
                      }}
                      className="text-xs font-bold text-rose-500 hover:underline"
                    >
                      Effacer
                    </button>
                  </div>

                  <div className="border border-slate-200 rounded-2xl overflow-hidden max-h-60 overflow-y-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-100 text-slate-500 text-[10px] font-black uppercase tracking-wider sticky top-0">
                        <tr>
                          <th className="px-4 py-2.5">#</th>
                          <th className="px-4 py-2.5">Nom Contact</th>
                          <th className="px-4 py-2.5">Établissement / Clinique</th>
                          <th className="px-4 py-2.5">Téléphone</th>
                          <th className="px-4 py-2.5">Ville</th>
                          <th className="px-4 py-2.5">Statut</th>
                          <th className="px-4 py-2.5">Budget</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 bg-white">
                        {parsedRows.slice(0, 50).map((row, idx) => (
                          <tr key={idx} className="hover:bg-slate-50">
                            <td className="px-4 py-2 font-mono text-slate-400">{idx + 1}</td>
                            <td className="px-4 py-2 font-bold text-slate-800">{row.name}</td>
                            <td className="px-4 py-2 text-slate-600">{row.company}</td>
                            <td className="px-4 py-2 font-mono text-slate-500">{row.phone || '-'}</td>
                            <td className="px-4 py-2 text-slate-600">{row.city || '-'}</td>
                            <td className="px-4 py-2">
                              <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase ${LEAD_STATUSES[row.status]?.bg || 'bg-slate-100'} ${LEAD_STATUSES[row.status]?.text || 'text-slate-600'}`}>
                                {LEAD_STATUSES[row.status]?.label || row.status}
                              </span>
                            </td>
                            <td className="px-4 py-2 text-slate-600">{row.budget || '-'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  {parsedRows.length > 50 && (
                    <p className="text-[10px] text-slate-400 text-center italic">
                      + {parsedRows.length - 50} autres lignes non affichées dans l'aperçu...
                    </p>
                  )}
                </div>
              )}
            </div>

            {/* Modal Actions Footer */}
            <div className="flex gap-4 pt-4 border-t border-slate-100 shrink-0">
              <button
                type="button"
                onClick={() => setExcelImportModal({ open: false, commercial: null })}
                disabled={isImporting}
                className="flex-1 py-4 rounded-2xl font-black text-xs uppercase tracking-widest bg-slate-100 text-slate-600 hover:bg-slate-200 transition-colors disabled:opacity-50"
              >
                Fermer
              </button>
              <button
                type="button"
                onClick={handleExecuteImport}
                disabled={isImporting || parsedRows.length === 0}
                className="flex-1 py-4 rounded-2xl font-black text-xs uppercase tracking-widest bg-emerald-600 text-white hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-600/20 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isImporting ? (
                  <>
                    <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full"></div>
                    Importation en cours...
                  </>
                ) : (
                  <>
                    <i className="ti ti-upload text-base"></i>
                    Importer {parsedRows.length} Leads
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================================================================ */}
      {/* MODAL: AJOUTER / MODIFIER UN LEAD MANUELLEMENT                   */}
      {/* ================================================================ */}
      {singleLeadModal.open && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[120] flex items-center justify-center p-4 overflow-y-auto animate-in fade-in">
          <div className="bg-white rounded-[3rem] p-8 md:p-10 w-full max-w-2xl shadow-2xl border-4 border-white my-8 animate-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center mb-6 pb-4 border-b border-slate-100">
              <div>
                <span className="px-3 py-1 bg-blue-50 text-blue-600 rounded-xl text-[10px] font-black uppercase tracking-widest">
                  {singleLeadModal.editingLead ? 'Édition Prospect' : 'Affectation Lead Commercial'}
                </span>
                <h2 className="text-2xl font-black text-slate-800 tracking-tight mt-1">
                  {singleLeadModal.editingLead ? 'Modifier le Prospect' : 'Nouveau Prospect / Lead'}
                </h2>
                {singleLeadModal.commercial && (
                  <p className="text-xs font-bold text-slate-500 mt-0.5">
                    Attribution à : <span className="text-blue-600 font-black">{singleLeadModal.commercial.name}</span>
                  </p>
                )}
              </div>
              <button
                onClick={() => setSingleLeadModal({ open: false, commercial: null, editingLead: null })}
                className="w-10 h-10 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center transition-colors"
              >
                <i className="ti ti-x text-lg"></i>
              </button>
            </div>

            {feedbackMsg && (
              <div className={`p-4 rounded-2xl text-xs font-bold mb-6 ${feedbackMsg.type === 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-rose-50 text-rose-700 border border-rose-200'}`}>
                {feedbackMsg.text}
              </div>
            )}

            <form onSubmit={handleSaveSingleLead} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {/* Contact Name */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    Nom du Contact / Médecin *
                  </label>
                  <input
                    name="name"
                    required
                    defaultValue={singleLeadModal.editingLead?.name || ''}
                    placeholder="Ex: Dr. Mohamed Alami"
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold text-slate-800 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all"
                  />
                </div>

                {/* Company / Clinic */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    Établissement / Clinique / Cabinet *
                  </label>
                  <input
                    name="company"
                    required
                    defaultValue={singleLeadModal.editingLead?.company || ''}
                    placeholder="Ex: Clinique Internationale Casablanca"
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold text-slate-800 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all"
                  />
                </div>

                {/* Commercial Assignment */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    Commercial Assigné *
                  </label>
                  <select
                    name="assigned_to"
                    required
                    defaultValue={singleLeadModal.editingLead?.assigned_to || (singleLeadModal.commercial ? singleLeadModal.commercial.id : '')}
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold text-slate-800 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all cursor-pointer"
                  >
                    <option value="">Sélectionner un commercial</option>
                    {commercials.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} {c.region ? `(${c.region})` : ''}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Status */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    Statut du Pipeline *
                  </label>
                  <select
                    name="status"
                    defaultValue={singleLeadModal.editingLead?.status || 'new'}
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold text-slate-800 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all cursor-pointer"
                  >
                    <option value="new">Nouveau Lead</option>
                    <option value="contacted">Contacté</option>
                    <option value="qualified">Qualifié</option>
                    <option value="proposal">Proposition / Devis</option>
                    <option value="won">Gagné / Client</option>
                    <option value="lost">Perdu</option>
                  </select>
                </div>

                {/* Phone */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    Téléphone & WhatsApp
                  </label>
                  <input
                    name="phone"
                    defaultValue={singleLeadModal.editingLead?.phone || ''}
                    placeholder="Ex: 0661123456"
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold text-slate-800 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all"
                  />
                </div>

                {/* Email */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    Email
                  </label>
                  <input
                    name="email"
                    type="email"
                    defaultValue={singleLeadModal.editingLead?.email || ''}
                    placeholder="contact@clinique.ma"
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold text-slate-800 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all"
                  />
                </div>

                {/* City */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    Ville
                  </label>
                  <input
                    name="city"
                    defaultValue={singleLeadModal.editingLead?.city || ''}
                    placeholder="Ex: Casablanca, Rabat, Tanger..."
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold text-slate-800 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all"
                  />
                </div>

                {/* Budget */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    Budget Estimé
                  </label>
                  <input
                    name="budget"
                    defaultValue={singleLeadModal.editingLead?.budget || ''}
                    placeholder="Ex: 250 000 MAD"
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold text-slate-800 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all"
                  />
                </div>

                {/* Source */}
                <div className="md:col-span-2 space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    Source du Lead
                  </label>
                  <input
                    name="source"
                    defaultValue={singleLeadModal.editingLead?.source || 'Prospection Directe'}
                    placeholder="Ex: Salon Médical, Recommandation, Appel Direct, Site Web..."
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold text-slate-800 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all"
                  />
                </div>

                {/* Address */}
                <div className="md:col-span-2 space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    Adresse Complète
                  </label>
                  <input
                    name="address"
                    defaultValue={singleLeadModal.editingLead?.address || ''}
                    placeholder="Ex: 45 Boulevard d'Anfa, Étage 3..."
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold text-slate-800 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all"
                  />
                </div>

                {/* Notes */}
                <div className="md:col-span-2 space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    Besoins / Équipements d'intérêt / Remarques
                  </label>
                  <textarea
                    name="notes"
                    rows={3}
                    defaultValue={singleLeadModal.editingLead?.notes || ''}
                    placeholder="Ex: Intéressé par échographe portable, demande de devis express..."
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-medium text-slate-800 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all"
                  ></textarea>
                </div>
              </div>

              <div className="flex gap-4 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setSingleLeadModal({ open: false, commercial: null, editingLead: null })}
                  className="flex-1 py-4 rounded-2xl font-black text-xs uppercase tracking-widest bg-slate-100 text-slate-600 hover:bg-slate-200 transition-colors"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 py-4 rounded-2xl font-black text-xs uppercase tracking-widest bg-blue-600 text-white hover:bg-blue-700 transition-colors shadow-lg shadow-blue-500/20 disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <>
                      <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full"></div>
                      Enregistrement...
                    </>
                  ) : (
                    <>
                      <i className="ti ti-check text-base"></i>
                      {singleLeadModal.editingLead ? 'Mettre à jour le Lead' : 'Créer & Affecter le Lead'}
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================================================================ */}
      {/* MODAL: VOIR LE PORTEFEUILLE LEADS D'UN COMMERCIAL               */}
      {/* ================================================================ */}
      {portfolioModal.open && portfolioModal.commercial && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[120] flex items-center justify-center p-4 overflow-y-auto animate-in fade-in">
          <div className="bg-white rounded-[3.5rem] p-8 md:p-10 w-full max-w-5xl shadow-2xl border-4 border-white my-8 animate-in zoom-in-95 duration-200 max-h-[90vh] flex flex-col">
            <div className="flex justify-between items-start mb-6 pb-4 border-b border-slate-100 shrink-0">
              <div className="flex items-center gap-4">
                <img
                  src={portfolioModal.commercial.avatar_url ? (portfolioModal.commercial.avatar_url.startsWith('http') ? portfolioModal.commercial.avatar_url : `https://birdeye-intelligence.ma/Spetcapp/Backend/storage/app/public/${portfolioModal.commercial.avatar_url}`) : `https://ui-avatars.com/api/?name=${encodeURIComponent(portfolioModal.commercial.name)}&background=2563EB&color=fff`}
                  alt=""
                  className="w-14 h-14 rounded-2xl object-cover border-2 border-white shadow-md"
                />
                <div>
                  <h2 className="text-2xl font-black text-slate-800 tracking-tight">{portfolioModal.commercial.name}</h2>
                  <p className="text-xs font-bold text-slate-400">
                    Portefeuille Prospects & Leads • Région: <span className="text-blue-600 font-black">{portfolioModal.commercial.region || 'Non Spécifiée'}</span>
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    const comm = portfolioModal.commercial;
                    handleExportCommercialLeads(comm);
                  }}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-sm"
                  title="Exporter les leads en Excel"
                >
                  <i className="ti ti-download text-emerald-600"></i>
                  Excel
                </button>

                <button
                  onClick={() => {
                    const comm = portfolioModal.commercial;
                    setPortfolioModal({ open: false, commercial: null });
                    setExcelImportModal({ open: true, commercial: comm });
                    setImportTargetCommercialId(String(comm.id));
                    setExcelFile(null);
                    setParsedRows([]);
                    setImportProgress(null);
                  }}
                  className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-1.5 shadow-sm transition-all active:scale-95"
                >
                  <i className="ti ti-file-spreadsheet"></i>
                  + Import Excel
                </button>

                <button
                  onClick={() => {
                    const comm = portfolioModal.commercial;
                    setPortfolioModal({ open: false, commercial: null });
                    handleOpenSingleLead(comm);
                  }}
                  className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-1.5 shadow-sm transition-all active:scale-95"
                >
                  <i className="ti ti-user-plus"></i>
                  + Lead
                </button>

                <button
                  onClick={() => setPortfolioModal({ open: false, commercial: null })}
                  className="w-10 h-10 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center transition-colors"
                >
                  <i className="ti ti-x text-lg"></i>
                </button>
              </div>
            </div>

            {/* Search & Filter inside leads */}
            <div className="mb-4 shrink-0 flex flex-col md:flex-row gap-3">
              <div className="relative flex-1">
                <i className="ti ti-search absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
                <input
                  type="text"
                  placeholder="Filtrer dans les leads de ce commercial..."
                  value={portfolioSearch}
                  onChange={(e) => setPortfolioSearch(e.target.value)}
                  className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 outline-none focus:ring-2 focus:ring-blue-500/20"
                />
              </div>

              <select
                value={selectedStatusFilter}
                onChange={(e) => setSelectedStatusFilter(e.target.value)}
                className="px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 outline-none focus:ring-2 focus:ring-blue-500/20 cursor-pointer"
              >
                <option value="all">Tous les Statuts</option>
                <option value="new">Nouveau</option>
                <option value="contacted">Contacté</option>
                <option value="qualified">Qualifié</option>
                <option value="proposal">Proposition / Devis</option>
                <option value="won">Gagné / Client</option>
                <option value="lost">Perdu</option>
              </select>
            </div>

            {/* List of leads */}
            <div className="overflow-y-auto flex-1 custom-scrollbar pr-1">
              {(() => {
                const assigned = leadsList.filter(l => l.assigned_to === portfolioModal.commercial.id || l.assigned_commercial?.id === portfolioModal.commercial.id);
                
                const filtered = assigned.filter((l: any) => {
                  const s = portfolioSearch.toLowerCase();
                  const matchSearch =
                    l.name?.toLowerCase().includes(s) ||
                    l.company?.toLowerCase().includes(s) ||
                    l.city?.toLowerCase().includes(s) ||
                    l.phone?.toLowerCase().includes(s) ||
                    l.email?.toLowerCase().includes(s);

                  const matchStatus = selectedStatusFilter === 'all' || l.status === selectedStatusFilter;

                  return matchSearch && matchStatus;
                });

                if (filtered.length === 0) {
                  return (
                    <div className="text-center py-16 text-slate-400">
                      <i className="ti ti-folder-off text-4xl mb-2 opacity-50"></i>
                      <p className="text-xs font-bold uppercase tracking-wider">Aucun prospect ou lead trouvé pour ce commercial</p>
                      <div className="flex items-center justify-center gap-3 mt-4">
                        <button
                          onClick={() => {
                            const comm = portfolioModal.commercial;
                            setPortfolioModal({ open: false, commercial: null });
                            setExcelImportModal({ open: true, commercial: comm });
                            setImportTargetCommercialId(String(comm.id));
                            setExcelFile(null);
                            setParsedRows([]);
                            setImportProgress(null);
                          }}
                          className="px-5 py-2.5 bg-emerald-50 text-emerald-700 rounded-xl text-xs font-black uppercase tracking-wider hover:bg-emerald-100 transition-colors flex items-center gap-2"
                        >
                          <i className="ti ti-file-spreadsheet"></i>
                          Importer un fichier Excel
                        </button>
                        <button
                          onClick={() => {
                            const comm = portfolioModal.commercial;
                            setPortfolioModal({ open: false, commercial: null });
                            handleOpenSingleLead(comm);
                          }}
                          className="px-5 py-2.5 bg-blue-50 text-blue-600 rounded-xl text-xs font-black uppercase tracking-wider hover:bg-blue-100 transition-colors flex items-center gap-2"
                        >
                          <i className="ti ti-user-plus"></i>
                          Ajouter un lead manuel
                        </button>
                      </div>
                    </div>
                  );
                }

                return (
                  <div className="divide-y divide-slate-100">
                    {filtered.map((l: any) => {
                      const statusConfig = LEAD_STATUSES[l.status] || LEAD_STATUSES.new;

                      return (
                        <div key={l.id} className="py-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 hover:bg-slate-50/70 p-3 rounded-2xl transition-colors">
                          <div className="space-y-1.5 flex-1">
                            <div className="flex items-center gap-3 flex-wrap">
                              <span className="font-black text-slate-800 text-sm">{l.name}</span>
                              <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2.5 py-0.5 rounded-md">
                                {l.company}
                              </span>
                              
                              {/* Quick status dropdown */}
                              <select
                                value={l.status || 'new'}
                                onChange={(e) => handleUpdateLeadStatus(l.id, e.target.value)}
                                className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase border outline-none cursor-pointer ${statusConfig.bg} ${statusConfig.text} ${statusConfig.border}`}
                              >
                                <option value="new">Nouveau</option>
                                <option value="contacted">Contacté</option>
                                <option value="qualified">Qualifié</option>
                                <option value="proposal">Proposition / Devis</option>
                                <option value="won">Gagné / Client</option>
                                <option value="lost">Perdu</option>
                              </select>

                              {l.budget && (
                                <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                                  Budget: {l.budget}
                                </span>
                              )}
                            </div>

                            <p className="text-xs text-slate-500 font-medium flex items-center gap-4 flex-wrap">
                              {l.city && <span><i className="ti ti-map-pin text-slate-400"></i> {l.city}</span>}
                              {l.phone && <span><i className="ti ti-phone text-slate-400"></i> {l.phone}</span>}
                              {l.email && <span><i className="ti ti-mail text-slate-400"></i> {l.email}</span>}
                              {l.source && <span className="text-[10px] text-slate-400 font-semibold">• Source: {l.source}</span>}
                            </p>

                            {l.notes && (
                              <p className="text-[11px] text-slate-500 italic bg-white p-2 rounded-xl border border-slate-100">
                                "{l.notes}"
                              </p>
                            )}
                          </div>

                          {/* Quick action buttons */}
                          <div className="flex items-center gap-2 shrink-0">
                            {l.phone && (
                              <a
                                href={`https://wa.me/${l.phone.replace(/[^0-9]/g, '')}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="px-3 py-1.5 bg-emerald-50 text-emerald-600 hover:bg-emerald-100 rounded-xl text-xs font-bold flex items-center gap-1 transition-colors"
                              >
                                <i className="ti ti-brand-whatsapp"></i> WhatsApp
                              </a>
                            )}
                            {l.phone && (
                              <a
                                href={`tel:${l.phone}`}
                                className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl text-xs font-bold transition-colors"
                                title="Appeler"
                              >
                                <i className="ti ti-phone"></i>
                              </a>
                            )}
                            <button
                              onClick={() => {
                                const comm = portfolioModal.commercial;
                                setPortfolioModal({ open: false, commercial: null });
                                handleOpenSingleLead(comm, l);
                              }}
                              className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl text-xs font-bold transition-colors"
                              title="Modifier"
                            >
                              <i className="ti ti-edit"></i>
                            </button>
                            <button
                              onClick={() => handleDeleteLead(l.id)}
                              className="p-2 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-xl text-xs font-bold transition-colors"
                              title="Supprimer"
                            >
                              <i className="ti ti-trash"></i>
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                );
              })()}
            </div>
          </div>
        </div>
      )}

      {/* ================================================================ */}
      {/* MODAL: MODIFIER LA RÉGION GÉOGRAPHIQUE D'UN COMMERCIAL          */}
      {/* ================================================================ */}
      {regionModal.open && regionModal.commercial && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[120] flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white rounded-[3rem] p-8 md:p-10 w-full max-w-lg shadow-2xl border-4 border-white animate-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center mb-6 pb-4 border-b border-slate-100">
              <div>
                <span className="px-3 py-1 bg-blue-50 text-blue-600 rounded-xl text-[10px] font-black uppercase tracking-widest">
                  Affectation Géographique
                </span>
                <h2 className="text-2xl font-black text-slate-800 tracking-tight mt-1">Secteur Régional</h2>
                <p className="text-xs text-slate-400 font-bold">Commercial: {regionModal.commercial.name}</p>
              </div>
              <button
                onClick={() => setRegionModal({ open: false, commercial: null })}
                className="w-10 h-10 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center transition-colors"
              >
                <i className="ti ti-x text-lg"></i>
              </button>
            </div>

            <div className="space-y-4 mb-6">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">
                Sélectionner la Région Commerciale
              </label>

              <div className="space-y-3">
                {MOROCCAN_REGIONS.map((r, idx) => (
                  <label
                    key={idx}
                    className={`flex items-start gap-4 p-4 rounded-2xl border transition-all cursor-pointer ${newRegionValue === r.name ? 'border-blue-500 bg-blue-50/40 shadow-sm' : 'border-slate-100 hover:bg-slate-50'}`}
                  >
                    <input
                      type="radio"
                      name="regionSelect"
                      value={r.name}
                      checked={newRegionValue === r.name}
                      onChange={() => setNewRegionValue(r.name)}
                      className="mt-1 text-blue-600 focus:ring-blue-500"
                    />
                    <div>
                      <p className="text-sm font-black text-slate-800">{r.name}</p>
                      <p className="text-[11px] font-bold text-blue-600 mb-1">Centre Hub: {r.center}</p>
                      <p className="text-[10px] text-slate-400 leading-relaxed">{r.cities}</p>
                    </div>
                  </label>
                ))}

                <label
                  className={`flex items-center gap-4 p-4 rounded-2xl border transition-all cursor-pointer ${newRegionValue === '' ? 'border-blue-500 bg-blue-50/40 shadow-sm' : 'border-slate-100 hover:bg-slate-50'}`}
                >
                  <input
                    type="radio"
                    name="regionSelect"
                    value=""
                    checked={newRegionValue === ''}
                    onChange={() => setNewRegionValue('')}
                    className="text-blue-600 focus:ring-blue-500"
                  />
                  <div>
                    <p className="text-sm font-black text-slate-800">Aucune région assignée</p>
                    <p className="text-[10px] text-slate-400">Non restreint à un secteur géographique précis</p>
                  </div>
                </label>
              </div>
            </div>

            <div className="flex gap-4">
              <button
                type="button"
                onClick={() => setRegionModal({ open: false, commercial: null })}
                className="flex-1 py-4 rounded-2xl font-black text-xs uppercase tracking-widest bg-slate-100 text-slate-600 hover:bg-slate-200 transition-colors"
              >
                Annuler
              </button>
              <button
                type="button"
                onClick={handleSaveRegion}
                disabled={isSubmitting}
                className="flex-1 py-4 rounded-2xl font-black text-xs uppercase tracking-widest bg-blue-600 text-white hover:bg-blue-700 transition-colors shadow-lg shadow-blue-500/20 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full"></div>
                    Enregistrement...
                  </>
                ) : (
                  <>
                    <i className="ti ti-check text-base"></i>
                    Confirmer
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
