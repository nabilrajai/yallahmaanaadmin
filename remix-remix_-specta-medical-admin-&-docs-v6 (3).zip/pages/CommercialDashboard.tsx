import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api';
import { useApp } from '../App';
import { 
  BarChart, Bar, 
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer 
} from 'recharts';

export default function CommercialDashboard() {
  const { user, t } = useApp();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'clients' | 'devis'>('clients');

  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const fetchPerformance = async () => {
    if (!user?.id) return;
    setLoading(true);
    setErrorMsg(null);
    try {
      const res = await api.payments.getCommercialFullStats(`commercial_id=${user.id}`);
      setData(res.data?.[0] || null);
    } catch (e: any) {
      console.error("Dashboard Load Error", e);
      setErrorMsg(e?.message || "Erreur de chargement du tableau de bord.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPerformance();
  }, [user]);

  const metrics = useMemo(() => {
    if (!data) return { ca: 0, orders: 0, devis: 0, clients: 0, enc: 0, conv: 0 };
    const s = data.stats || {};
    const ca = parseFloat(s.orders?.total_ttc || 0);
    const orders = s.orders?.count || 0;
    const devis = s.devis?.count || 0;
    return {
      ca,
      orders,
      devis,
      clients: s.clients_count || 0,
      enc: parseFloat(s.payments?.total_paid || 0),
      conv: devis > 0 ? Math.round((orders / devis) * 100) : 0
    };
  }, [data]);

  if (loading) return (
    <div className="flex items-center justify-center h-full opacity-30">
      <i className="ti ti-refresh text-6xl animate-spin"></i>
    </div>
  );

  return (
    <div className="space-y-8 pb-20 animate-in fade-in duration-700">
      <div className="bg-white p-10 rounded-[4rem] shadow-sm border border-slate-100 flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="flex items-center gap-6">
          <img src={`https://ui-avatars.com/api/?name=${user?.name}&background=5D87FF&color=fff&bold=true`} className="w-20 h-20 rounded-[2rem] shadow-2xl border-4 border-white object-cover" alt="" />
          <div>
            <h1 className="text-3xl font-black text-slate-800 tracking-tighter leading-none mb-1 uppercase">Bonjour, {user?.name.split(' ')[0]}</h1>
            <p className="text-slate-400 font-black uppercase text-[10px] tracking-[4px]">Votre Tableau de Bord Commercial • {user?.region || 'Secteur Non Défini'}</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Link to="/admin/commercial-visits" className="px-6 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-[1.5rem] font-black text-[10px] uppercase tracking-widest shadow-xl shadow-blue-600/20 active:scale-95 transition-all flex items-center gap-2 relative">
            <i className="ti ti-calendar-event text-base"></i>
            <span>Demandes de Visite</span>
            <span className="w-2 h-2 rounded-full bg-rose-400 animate-pulse inline-block shrink-0"></span>
          </Link>
          <button onClick={fetchPerformance} className="px-8 py-4 bg-slate-900 text-white rounded-[1.5rem] font-black text-[10px] uppercase tracking-widest shadow-xl active:scale-95 transition-all flex items-center gap-3">
            <i className="ti ti-refresh text-lg"></i> Sync Data
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <KPICard label="Volume Ventes" value={`${metrics.ca.toLocaleString()} MAD`} subValue={`${metrics.orders} Commandes`} icon="DH" color="bg-blue-600" />
          <KPICard label="Taux Conversion" value={`${metrics.conv}%`} subValue={`${metrics.devis} Devis émis`} icon="ti-chart-pie" color="bg-indigo-600" />
          <KPICard label="Portefeuille" value={metrics.clients} subValue="Clients Actifs" icon="ti-users" color="bg-emerald-600" />
          <KPICard label="Encaissements" value={`${metrics.enc.toLocaleString()} MAD`} subValue="Total Collecté" icon="ti-wallet" color="bg-amber-500" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-8 space-y-6">
              <div className="flex gap-4 p-2 bg-slate-100 rounded-[2.5rem] w-fit shadow-inner">
                  <TabBtn active={activeTab === 'clients'} onClick={() => setActiveTab('clients')} icon="ti-users" label="Mes Clients" />
                  <TabBtn active={activeTab === 'devis'} onClick={() => setActiveTab('devis')} icon="ti-file-invoice" label="Mes Devis" />
              </div>

              <div className="bg-white rounded-[4rem] border border-slate-100 shadow-sm overflow-hidden min-h-[500px]">
                  {activeTab === 'clients' && (
                      <table className="w-full text-left">
                          <thead className="bg-slate-50 border-b">
                              <tr className="text-[10px] font-black uppercase text-slate-400 tracking-widest">
                                  <th className="px-10 py-6">Etablissement</th>
                                  <th className="px-10 py-6">Ville</th>
                                  <th className="px-10 py-6 text-right">CA</th>
                              </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-50">
                              {data?.clients?.map((c: any) => (
                                  <tr key={c.id} className="hover:bg-slate-50/50 transition-all">
                                      <td className="px-10 py-6 font-black text-slate-800 uppercase text-sm">{c.name}</td>
                                      <td className="px-10 py-6 font-bold text-slate-400 text-xs">{c.city}</td>
                                      <td className="px-10 py-6 text-right font-black text-blue-600">
                                          {parseFloat(c.orders_sum_total_ttc || 0).toLocaleString()} <span className="text-[8px]">MAD</span>
                                      </td>
                                  </tr>
                              ))}
                          </tbody>
                      </table>
                  )}

                  {activeTab === 'devis' && (
                      <div className="p-10 text-center opacity-20 py-20">
                          <i className="ti ti-file-invoice text-8xl mb-4"></i>
                          <p className="font-black uppercase tracking-[4px]">Consultez vos devis dans le module Devis</p>
                      </div>
                  )}
              </div>
          </div>

          <div className="lg:col-span-4 space-y-8">
              <div className="bg-slate-900 p-10 rounded-[4rem] text-white shadow-2xl relative overflow-hidden">
                   <div className="absolute -right-10 -top-10 w-40 h-40 bg-blue-500 opacity-20 rounded-full blur-[80px]"></div>
                   <h4 className="text-[11px] font-black text-blue-400 uppercase tracking-[6px] border-b border-white/10 pb-6 mb-8 flex items-center gap-3 relative z-10"><i className="ti ti-dna text-2xl"></i> Performance DNA</h4>
                   <div className="space-y-6 relative z-10">
                        <ScoreBar label="Conversion" value={metrics.conv} color="bg-blue-500" />
                        <ScoreBar label="Recouvrement" value={metrics.ca > 0 ? Math.round((metrics.enc / metrics.ca) * 100) : 0} color="bg-emerald-500" />
                   </div>
              </div>

              <div className="bg-white p-10 rounded-[4rem] border border-slate-100 shadow-sm">
                  <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-[6px] border-b pb-6 mb-8 flex items-center gap-3">Top Secteurs</h4>
                  <div className="h-64 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={data?.clients_by_city || []}>
                              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                              <XAxis dataKey="city" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 9}} />
                              <YAxis hide />
                              <Tooltip cursor={{fill: '#f8fafc'}} />
                              <Bar dataKey="count" fill="#5D87FF" radius={[10, 10, 0, 0]} />
                          </BarChart>
                      </ResponsiveContainer>
                  </div>
              </div>
          </div>
      </div>
    </div>
  );
}

function KPICard({ label, value, subValue, icon, color }: any) {
    const isCurrency = icon === 'DH' || icon === 'MAD' || icon === 'ti-currency-dirham' || icon === 'morocco-currency';
    return (
        <div className="bg-white p-8 rounded-[3.5rem] border border-slate-100 shadow-sm flex items-center gap-6 group hover:shadow-2xl transition-all relative overflow-hidden border-b-4 border-b-slate-50">
            <div className={`w-16 h-16 rounded-[1.75rem] ${color} flex items-center justify-center text-white shadow-xl transition-transform group-hover:rotate-12 select-none`}>
                {isCurrency ? (
                    <span className="font-black text-2xl tracking-tight text-white leading-none">DH</span>
                ) : (
                    <i className={`ti ${icon} text-3xl`}></i>
                )}
            </div>
            <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-[3px] mb-1.5">{label}</p>
                <p className="text-2xl font-black text-slate-800 tracking-tighter leading-none mb-1">{value}</p>
                <p className="text-[9px] font-bold text-slate-300 uppercase">{subValue}</p>
            </div>
        </div>
    );
}

function TabBtn({ active, onClick, icon, label }: any) {
    return (
        <button onClick={onClick} className={`flex items-center gap-3 px-8 py-3.5 rounded-[2rem] text-[10px] font-black uppercase tracking-widest transition-all duration-300 ${active ? 'bg-white text-blue-600 shadow-xl' : 'text-slate-400 hover:text-slate-600'}`}><i className={`ti ${icon} text-lg`}></i>{label}</button>
    )
}

function ScoreBar({ label, value, color }: any) {
    return (
        <div className="space-y-2">
            <div className="flex justify-between items-center text-[9px] font-black uppercase tracking-[2px]">
                <span className="text-slate-400">{label}</span>
                <span className="text-white">{value}%</span>
            </div>
            <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                <div className={`h-full ${color} transition-all duration-1000`} style={{ width: `${value}%` }}></div>
            </div>
        </div>
    )
}
