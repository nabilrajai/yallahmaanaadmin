const BASE_URL = 'https://birdeye-intelligence.ma/Spetcapp/Backend/api';

export const api = {
  getToken: () => localStorage.getItem('specta_token'),
  setToken: (token: string) => localStorage.setItem('specta_token', token),
  clearToken: () => localStorage.removeItem('specta_token'),

  async request(endpoint: string, options: RequestInit = {}, retries = 2) {
    const token = this.getToken();
    
    const headers: Record<string, string> = {
      'Accept': 'application/json',
      'Authorization': token ? `Bearer ${token}` : '',
    };

    const isFormData = options.body instanceof FormData;
    
    if (options.body && !isFormData) {
      headers['Content-Type'] = 'application/json';
    }

    const config = { ...options, headers: { ...headers, ...(options.headers as any) } };
    
    // Ensure we don't accidentally override the browser's generated multipart/form-data with boundary
    // The browser will automatically set Content-Type to multipart/form-data with the correct boundary
    if (isFormData && (config.headers as any)['Content-Type']) {
        delete (config.headers as any)['Content-Type'];
    }

    try {
      const response = await fetch(`${BASE_URL}${endpoint}`, config);
      
      if (response.status === 401) {
        this.clearToken();
        window.location.hash = '#/login';
        throw new Error('Unauthorized');
      }

      if (response.status === 204) return null;

      const contentType = response.headers.get('content-type');
      
      if (!contentType || !contentType.includes('application/json')) {
        if (response.status === 404) {
           const err = new Error(`ROUTE_NOT_FOUND`);
           (err as any).status = 404;
           (err as any).endpoint = `${BASE_URL}${endpoint}`;
           throw err;
        }
        throw new Error(`Erreur Serveur (${response.status}): Réponse non-JSON.`);
      }

      const data = await response.json();
      
      if (!response.ok) {
        const isDbOrServerError = 
          response.status >= 500 || 
          (typeof data?.message === 'string' && (
            data.message.includes('SQLSTATE') || 
            data.message.includes('Operation not permitted') ||
            data.message.includes('Connection')
          ));

        if (isDbOrServerError && retries > 0) {
          const delay = (3 - retries + 1) * 800;
          await new Promise(res => setTimeout(res, delay));
          return this.request(endpoint, options, retries - 1);
        }

        if (response.status === 422 && data?.errors) {
            const firstError = Object.values(data.errors)[0];
            const msg = Array.isArray(firstError) ? firstError[0] : (typeof firstError === 'string' ? firstError : 'Validation Error');
            throw new Error(msg);
        }

        let errorMessage = data?.message || `API Error: ${response.status}`;
        if (typeof errorMessage === 'string' && (errorMessage.includes('SQLSTATE') || errorMessage.includes('Operation not permitted'))) {
            errorMessage = "Le serveur de base de données est temporairement indisponible. Veuillez réessayer dans un instant.";
        }
        throw new Error(errorMessage);
      }
      return data;
    } catch (error: any) {
      if ((error.name === 'TypeError' || error.message === 'Failed to fetch') && retries > 0) {
        await new Promise(res => setTimeout(res, 1000));
        return this.request(endpoint, options, retries - 1);
      }
      throw error; 
    }
  },

  auth: {
    login: (credentials: any) => api.request('/auth/login', { method: 'POST', body: JSON.stringify(credentials) }),
    logout: () => api.request('/auth/logout', { method: 'POST' }),
  },
  users: {
    list: (params: string = '') => api.request(`/users?${params}`),
    show: (id: number) => api.request(`/users/${id}`),
    create: (data: FormData | any) => api.request('/users', { 
        method: 'POST', 
        body: data instanceof FormData ? data : JSON.stringify(data) 
    }),
    update: (id: number, data: FormData | any) => {
        if (data instanceof FormData) {
            data.append('_method', 'PUT');
            return api.request(`/users/${id}`, { method: 'POST', body: data });
        }
        return api.request(`/users/${id}`, { method: 'PUT', body: JSON.stringify(data) });
    },
    delete: (id: number) => api.request(`/users/${id}`, { method: 'DELETE' }),
  },
  devis: {
    list: (params: string = '') => api.request(`/devis?${params}`),
    show: (id: number) => api.request(`/devis/${id}`),
    create: (data: any) => api.request('/devis', { method: 'POST', body: JSON.stringify(data) }),
    update: (id: number, data: any) => api.request(`/devis/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    updateStatus: (id: number, status: string) => api.request(`/devis/${id}/status`, { method: 'POST', body: JSON.stringify({ status }) }),
    delete: (id: number) => api.request(`/devis/${id}`, { method: 'DELETE' }),
  },
  payments: {
    list: (params: string = '') => api.request(`/payments?${params}`),
    create: (data: any) => api.request('/payments/store', { method: 'PUT', body: JSON.stringify(data) }),
    update: (id: number, data: any) => api.request(`/payments/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    delete: (id: number) => api.request(`/payments/${id}`, { method: 'DELETE' }),
    getStats: () => api.request('/payments/stats'),
    getCommercialStats: () => api.request('/payments/commercial-performance'),
    getAdvancedStats: (params: string = '') => api.request(`/payments/advanced-stats?${params}`),
    getCommercialFullStats: (params: string = '') => api.request(`/commercials/full-stats?${params}`),
  },
  dashboard: {
    getKpis: (params: string = '') => api.request(`/dashboard/kpi?${params}`),
  },
  products: {
    list: (params: string = '') => api.request(`/products?${params}`),
    show: (id: number) => api.request(`/products/${id}`),
    create: (data: FormData | any) => api.request('/products', { method: 'POST', body: data instanceof FormData ? data : JSON.stringify(data) }),
    update: (id: number, data: FormData | any) => {
        if (data instanceof FormData) {
            data.append('_method', 'PUT');
            return api.request(`/products/${id}`, { method: 'POST', body: data });
        }
        return api.request(`/products/${id}`, { method: 'PUT', body: JSON.stringify(data) });
    },
    delete: (id: number) => api.request(`/products/${id}`, { method: 'DELETE' }),
  },
  categories: {
    list: (params: string = '') => api.request(`/categories?${params}`),
    show: (id: number) => api.request(`/categories/${id}`),
    create: (data: any) => api.request('/categories', { method: 'POST', body: JSON.stringify(data) }),
    update: (id: number, data: any) => api.request(`/categories/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    delete: (id: number) => api.request(`/categories/${id}`, { method: 'DELETE' }),
  },
  brands: {
    list: (params: string = '') => api.request(`/brands?${params}`),
    show: (id: number) => api.request(`/brands/${id}`),
    create: (data: any) => api.request('/brands', { method: 'POST', body: JSON.stringify(data) }),
    update: (id: number, data: any) => api.request(`/brands/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    delete: (id: number) => api.request(`/brands/${id}`, { method: 'DELETE' }),
  },
  promotions: {
    list: (params: string = '') => api.request(`/promotions?${params}`),
    show: (id: number) => api.request(`/promotions/${id}`),
    create: (data: any) => api.request('/promotions', { method: 'POST', body: JSON.stringify(data) }),
    update: (id: number, data: any) => api.request(`/promotions/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    delete: (id: number) => api.request(`/promotions/${id}`, { method: 'DELETE' }),
  },
  clients: {
    list: (params: string = '') => api.request(`/clients?${params}`),
    show: (id: number) => api.request(`/clients/${id}`),
    full: (id: number) => api.request(`/clients/${id}/full`),
    create: (data: any) => api.request('/clients', { method: 'POST', body: JSON.stringify(data) }),
    update: (id: number, data: any) => api.request(`/clients/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    delete: (id: number) => api.request(`/clients/${id}`, { method: 'DELETE' }),
    addMachine: (clientId: number, data: any) => api.request(`/clients/${clientId}/machines`, { method: 'POST', body: JSON.stringify(data) }),
  },
  clientMachines: {
    list: (clientId: number | string) => api.request(`/clients/${clientId}/machines`),
  },
  machines: {
    list: (params: string = '') => api.request(`/machines?${params}`),
    show: (id: number) => api.request(`/machines/${id}`),
    create: (data: FormData) => api.request('/machines', { method: 'POST', body: data }),
    update: (id: number, data: FormData) => {
        data.append('_method', 'PUT');
        return api.request(`/machines/${id}`, { method: 'POST', body: data });
    },
    delete: (id: number) => api.request(`/machines/${id}`, { method: 'DELETE' }),
    uploadDocument: (machineId: number, formData: FormData) => api.request(`/machines/${machineId}/documents`, { method: 'POST', body: formData }),
    deleteDocument: (machineId: number, docId: number) => api.request(`/machines/${machineId}/documents/${docId}`, { method: 'DELETE' }),
  },
  orders: {
    list: (params: string = '') => api.request(`/orders?${params}`),
    show: (id: number) => api.request(`/orders/${id}`),
    updateStatus: (id: number, status: string) => api.request(`/orders/${id}/status`, { method: 'POST', body: JSON.stringify({ status }) }),
    updateLogistics: (id: number, data: any) => api.request(`/orders/${id}/logistics`, { method: 'POST', body: JSON.stringify(data) }),
    assignDelivery: (id: number, data: { driver_id: number, delivery_date: string }) => api.request(`/orders/${id}/assign-delivery`, { method: 'POST', body: JSON.stringify(data) }),
    delete: (id: number) => api.request(`/orders/${id}`, { method: 'DELETE' }),
  },
  reclamations: {
    list: (params: string = '') => api.request(`/reclamations?${params}`),
    show: (id: number) => api.request(`/reclamations/${id}`),
    create: (data: any) => api.request('/reclamations', { method: 'POST', body: data instanceof FormData ? data : JSON.stringify(data) }),
    update: (id: number, data: any) => api.request(`/reclamations/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    updateStatus: (id: number, status: string) => api.request(`/reclamations/${id}/status`, { method: 'POST', body: JSON.stringify({ status }) }),
    updateType: (id: number, type: string) => api.request(`/reclamations/${id}/type`, { method: 'POST', body: JSON.stringify({ type, reclamation_type: type }) }),
    assign: (id: number, data: { technician_id: number }) => api.request(`/reclamations/${id}/assign`, { method: 'POST', body: JSON.stringify(data) }),
    addMessage: (id: number, data: { message: string, type: string }) => api.request(`/reclamations/${id}/messages`, { method: 'POST', body: JSON.stringify(data) }),
    addUsedPart: (id: number, data: any) => api.request(`/reclamations/${id}/used-parts`, { method: 'POST', body: JSON.stringify(data) }),
    uploadGallery: (id: number, formData: FormData) => api.request(`/reclamations/${id}/gallery`, { method: 'POST', body: formData }),
    delete: (id: number) => api.request(`/reclamations/${id}`, { method: 'DELETE' }),
  },
  technicians: {
    list: () => api.request('/users'), 
  },
  visits: {
    list: (params: string = '') => api.request(`/technician-visits?${params}`),
    create: (data: any) => api.request('/technician-visits', { method: 'POST', body: JSON.stringify(data) }),
    updateStatus: (id: number, status: string) => api.request(`/technician-visits/${id}/status`, { method: 'POST', body: JSON.stringify({ status }) }),
    delete: (id: number) => api.request(`/technician-visits/${id}`, { method: 'DELETE' }),
  },
  formations: {
    list: (params: string = '') => api.request(`/formations?${params}`),
    show: (id: number) => api.request(`/formations/${id}`),
    registrations: (id: number) => api.request(`/formations/${id}/registrations`),
    updateRegistration: (regId: number, status: string) => api.request(`/formation-registrations/${regId}/status`, { method: 'POST', body: JSON.stringify({ status }) }),
    create: (data: FormData | any) => api.request('/formations', { method: 'POST', body: data instanceof FormData ? data : JSON.stringify(data) }),
    update: (id: number, data: FormData | any) => {
        if (data instanceof FormData) {
            data.append('_method', 'PUT');
            return api.request(`/formations/${id}`, { method: 'POST', body: data });
        }
        return api.request(`/formations/${id}`, { method: 'PUT', body: JSON.stringify(data) });
    },
    delete: (id: number) => api.request(`/formations/${id}`, { method: 'DELETE' }),
  },
  reels: {
    list: () => api.request('/reels'),
    show: (id: number) => api.request(`/reels/${id}`),
    create: (data: FormData) => api.request('/reels', { method: 'POST', body: data }),
    updateStatus: (id: number, is_active: boolean) => api.request(`/reels/${id}/status`, { method: 'PUT', body: JSON.stringify({ is_active }) }),
    delete: (id: number) => api.request(`/reels/${id}`, { method: 'DELETE' }),
  },
  news: {
    list: (params: string = '') => api.request(`/news?${params}`),
    show: (id: number) => api.request(`/news/${id}`),
    create: (data: FormData) => api.request('/news', { method: 'POST', body: data }),
    update: (id: number, data: FormData) => {
        data.append('_method', 'PUT');
        return api.request(`/news/${id}`, { method: 'POST', body: data });
    },
    toggle: (id: number) => api.request(`/news/${id}/toggle`, { method: 'POST' }),
    delete: (id: number) => api.request(`/news/${id}`, { method: 'DELETE' }),
  },
  tracking: {
    getAllLastPositions: () => api.request('/technicians/positions/now'),
    getTrajet: (id: number, date: string) => api.request(`/technicians/${id}/trajet?date=${date}`),
    getDeliveryPositions: () => api.request('/drivers/positions/now'),
    getDriverTrajet: (id: number, date: string) => api.request(`/drivers/${id}/trajet?date=${date}`),
    // Commercial GPS Tracking
    getCommercialLastPositions: () => api.request('/commercials/positions/now'),
    getCommercialTrajet: (id: number, date: string) => api.request(`/commercials/${id}/trajet?date=${date}`),
    storeCommercialLocation: (data: { commercial_id: number; latitude: number; longitude: number }) => 
      api.request('/commercial-locations', { method: 'POST', body: JSON.stringify(data) }),
  },
  commercialTracking: {
    getAllLastPositions: () => api.request('/commercials/positions/now'),
    getTrajet: (id: number, date: string) => api.request(`/commercials/${id}/trajet?date=${date}`),
    storeLocation: (data: { commercial_id: number; latitude: number; longitude: number }) => 
      api.request('/commercial-locations', { method: 'POST', body: JSON.stringify(data) }),
  },
  reviews: {
      list: (params: string = '') => api.request(`/reviews?${params}`),
      stats: () => api.request('/reviews/stats'),
  },
  notifications: {
      send: (data: any) => api.request('/admin/notifications/send', { method: 'POST', body: JSON.stringify(data) })
  },
  spareParts: {
    list: (params: string = '') => api.request(`/spare-parts?${params}`),
    show: (id: number) => api.request(`/spare-parts/${id}`),
    create: (data: any) => api.request('/spare-parts', { method: 'POST', body: JSON.stringify(data) }),
    update: (id: number, data: any) => api.request(`/spare-parts/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    delete: (id: number) => api.request(`/spare-parts/${id}`, { method: 'DELETE' }),
  },
  partPriceRequests: {
    list: (params: string = '') => api.request(`/part-price-requests?${params}`),
    show: (id: number) => api.request(`/part-price-requests/${id}`),
    update: (id: number, data: any) => api.request(`/part-price-requests/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    quote: (id: number, data: { quoted_price: number, notes?: string }) => api.request(`/part-price-requests/${id}/quote`, { method: 'POST', body: JSON.stringify(data) }),
    approve: (id: number) => api.request(`/part-price-requests/${id}/approve`, { method: 'POST' }),
    reject: (id: number) => api.request(`/part-price-requests/${id}/reject`, { method: 'POST' }),
    delete: (id: number) => api.request(`/part-price-requests/${id}`, { method: 'DELETE' }),
    create: (data: any) => api.request('/part-price-requests', { method: 'POST', body: JSON.stringify(data) }),
  },
  fidelityRules: {
    list: (params: string = '') => api.request(`/fidelity-rules?${params}`),
    show: (id: number) => api.request(`/fidelity-rules/${id}`),
    create: (data: any) => api.request('/fidelity-rules', { method: 'POST', body: JSON.stringify(data) }),
    update: (id: number, data: any) => api.request(`/fidelity-rules/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    delete: (id: number) => api.request(`/fidelity-rules/${id}`, { method: 'DELETE' }),
    toggleStatus: (id: number) => api.request(`/fidelity-rules/${id}/toggle-status`, { method: 'POST' }),
  },
  fidelityPoints: {
    get: (clientId: number) => api.request(`/clients/${clientId}/fidelity-points`),
    adjust: (clientId: number, data: { points: number, description: string }) => api.request(`/clients/${clientId}/fidelity-points/adjust`, { method: 'POST', body: JSON.stringify({ ...data, client_id: clientId }) }),
    transactions: (clientId: number) => api.request(`/clients/${clientId}/fidelity-transactions`),
  },
  leads: {
    list: (params: string = '') => api.request(`/leads${params ? (params.startsWith('?') ? params : '?' + params) : ''}`),
    show: (id: number) => api.request(`/leads/${id}`),
    create: (data: any) => api.request('/leads', { method: 'POST', body: JSON.stringify(data) }),
    update: (id: number, data: any) => api.request(`/leads/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    updateStatus: (id: number, status: string) => api.request(`/leads/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) }),
    delete: (id: number) => api.request(`/leads/${id}`, { method: 'DELETE' }),
  },
  commercialVisits: {
    getAll: () => api.request('/commercial-visits/all'),
    list: (params: string = '') => api.request(`/commercial-visits${params ? (params.startsWith('?') ? params : '?' + params) : ''}`),
    show: (id: number) => api.request(`/commercial-visits/${id}`),
    create: (data: any) => api.request('/commercial-visits', { method: 'POST', body: JSON.stringify(data) }),
    update: (id: number, data: any) => api.request(`/commercial-visits/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    assign: (id: number, data: any) => api.request(`/commercial-visits/${id}/assign`, { method: 'POST', body: JSON.stringify(data) }),
    updateStatus: (id: number, status: string) => api.request(`/commercial-visits/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) }),
    delete: (id: number) => api.request(`/commercial-visits/${id}`, { method: 'DELETE' }),
  }
};