
export type Status = 'pending' | 'validated' | 'preparing' | 'shipped' | 'completed' | 'cancelled';
export type ReclamationStatus = 'new' | 'in_progress' | 'waiting_client' | 'resolved' | 'closed';
export type ReclamationType = 'simple' | 'complexe';
export type Priority = 'High' | 'Medium' | 'Low';
export type PaymentMethod = 'Espèces' | 'Chèque' | 'Virement' | 'Effet' | 'Autre';
export type PaymentStatus = 'paid' | 'pending' | 'unpaid';

export interface Permissions {
  [key: string]: {
    view: boolean;
    add: boolean;
    edit: boolean;
    delete: boolean;
  };
}

export interface User {
  id: number;
  name: string;
  email: string;
  role_id: number;
  client_id?: number;
  avatar_url?: string;
  region?: string;
  created_at: string;
  permissions?: Permissions;
}

export interface Client {
  id: number;
  code: string;
  name: string;
  contact_name?: string;
  email?: string;
  phone?: string;
  mobile?: string;
  address?: string;
  city?: string;
  country?: string;
  status: 'active' | 'inactive';
  notes?: string;
  commercial_id?: number;
  commercial?: User;
}

export interface Payment {
  id: number;
  client_id: number;
  amount: number;
  payment_date: string;
  due_date?: string;
  method: PaymentMethod;
  status: PaymentStatus;
  reference?: string;
  notes?: string;
  created_at: string;
}

export interface Document {
  id: number;
  title: string;
  file_path: string;
  created_at: string;
}

export interface Brand {
  id: number;
  name: string;
  slug: string;
  is_active: boolean | number;
  description?: string;
}

export interface Category {
  id: number;
  name: string;
  slug: string;
  is_active: boolean | number;
  description?: string;
}

export interface Product {
  id: number;
  sku: string;
  name: string;
  description?: string;
  price_ht: number;
  price_ttc?: number;
  tax_rate?: number;
  stock_qty: number;
  stock_alert_threshold?: number;
  category_id?: number;
  brand_id?: number;
  image_url?: string;
  is_active: boolean | number;
  type?: string;
}

export interface Machine {
  id: number;
  reference: string;
  serial_no: string;
  name: string;
  brand_id?: number;
  brand?: Brand;
  category_id?: number;
  category?: Category;
  model?: string;
  description?: string;
  image_url?: string;
  is_active: boolean | number;
  price_ht: number;
  min_price_ht: number;
  accessories?: string; // Checklist for "pieces à main"
  documents?: Document[];
}

export interface Order {
  id: number;
  order_number: string;
  order_type: 'product' | 'machine' | 'mixed';
  client_id: number;
  status: Status;
  total_ht: number;
  total_ttc: number;
  ordered_at: string;
  client?: Client;
  notes?: string;
  shipping_company?: string;
  tracking_url?: string;
  items?: any[];
}

export interface Reclamation {
  id: number;
  client_id: number;
  subject: string;
  description: string;
  reclamation_type?: ReclamationType;
  status_id?: number;
  status_label?: ReclamationStatus;
  status?: {
    id: number;
    name: string;
    slug: ReclamationStatus;
  };
  priority_id?: number;
  priority_label?: string;
  priority?: {
    id: number;
    name: string;
    slug: string;
  };
  client_machine_id?: number;
  client_machine?: any;
  is_machine_functional?: boolean;
  created_at: string;
  resolved_at?: string;
  client?: Client;
  assigned_technician_id?: number;
  assigned_technician?: User;
  media?: any[];
  channel?: string;
  source_app?: string;
  sla_response_deadline?: string;
  sla_resolution_deadline?: string;
}

export interface Promotion {
  id: number;
  name: string;
  code?: string | null;
  description?: string | null;
  promo_type: 'percentage' | 'fixed_amount';
  value: number;
  usage_limit?: number | null;
  used_count?: number | null;
  promotionable_id?: number | null;
  promotionable_type?: string | null;
  promotionable?: any;
  start_date: string;
  end_date: string;
  is_active: boolean | number;
  created_at?: string;
  updated_at?: string;
}